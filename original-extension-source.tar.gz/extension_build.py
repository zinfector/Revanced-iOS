"""Original extension build, portable provenance capture, and verified DEX import.

No installer or app class is loaded. Gradle runs only the upstream extension
tasks. Receipts describe output bytes, not cross-platform semantic equivalence.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

PLUGIN_COMMIT = "7bdf4324e1ad394cd33f8b77e1c166b5257bbbd5"
TASKS = [":extensions:shared:syncExtension", ":extensions:youtube:syncExtension"]
EXCLUDED = {".git", ".gradle", ".idea", "build", "node_modules", "__pycache__"}


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def tree(root):
    return {p.relative_to(root).as_posix(): sha(p) for p in sorted(root.rglob("*"))
            if p.is_file() and not any(x in EXCLUDED for x in p.relative_to(root).parts)}


def copy_snapshot(source, target):
    values = tree(source)
    for relative in values:
        p = target / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / relative, p)
    return values


def prepare(source, plugin, out):
    source, plugin, out = map(lambda p: Path(p).resolve(), (source, plugin, out))
    commit = subprocess.check_output(["git", "-C", str(plugin), "rev-parse", "HEAD"], text=True).strip()
    if commit != PLUGIN_COMMIT:
        raise ValueError("Wrong upstream plugin revision")
    if subprocess.check_output(["git", "-C", str(plugin), "status", "--porcelain"], text=True).strip():
        raise ValueError("Pinned upstream plugin has local changes")
    out.mkdir(parents=True, exist_ok=False)
    sources = copy_snapshot(source, out / "source")
    plugins = copy_snapshot(plugin, out / "plugin")
    capture = Path(__file__).with_name("extension_capture.gradle")
    shutil.copyfile(capture, out / capture.name)
    shutil.copyfile(__file__, out / "extension_build.py")
    value = {"schema": "installer.extension-build-preparation.v1", "sources": sources,
             "plugin_sources": plugins, "plugin_commit": commit, "tasks": TASKS,
             "tools": {"extension_capture.gradle": sha(out / capture.name),
                       "extension_build.py": sha(out / "extension_build.py")},
             "original_files_modified": False, "installer_jvm_executed": False}
    write(out / "preparation.json", value)
    return value


def verify_preparation(root):
    value = json.loads((root / "preparation.json").read_text(encoding="utf-8"))
    if value.get("schema") != "installer.extension-build-preparation.v1" or value.get("plugin_commit") != PLUGIN_COMMIT or value.get("tasks") != TASKS:
        raise ValueError("Unknown extension build preparation")
    for folder, key in (("source", "sources"), ("plugin", "plugin_sources")):
        if tree(root / folder) != value[key]:
            raise ValueError("Extension build snapshot changed: " + folder)
    for name, digest in value["tools"].items():
        if sha(root / name) != digest:
            raise ValueError("Build observation tool changed")
    return value


def add_file(path, output):
    digest = sha(path)
    dest = output / "files" / digest / path.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        shutil.copyfile(path, dest)
    return {"path": dest.relative_to(output).as_posix(), "sha256": digest}


def classpath_item(path, output):
    if path.is_file():
        return add_file(path, output)
    if not path.is_dir():
        # Gradle declares Kotlin output directories even for NO-SOURCE tasks.
        # javac ignores these absent entries; preserve that fact, not a fake jar.
        return {"kind": "absent_classpath_entry", "original_path": str(path)}
    # Convert directories to a portable jar; preserve exact class/resource bytes.
    tmp = output / "directory-classpath.jar"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(path.rglob("*")):
            if p.is_file():
                info = zipfile.ZipInfo(p.relative_to(path).as_posix(), (1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, p.read_bytes())
    row = add_file(tmp, output)
    tmp.unlink()
    row["kind"] = "directory_snapshot_jar"
    return row


def build(root, output):
    root, output = Path(root).resolve(), Path(output).resolve()
    prepared = verify_preparation(root)
    output.mkdir(parents=True, exist_ok=False)
    capture = output / "capture"
    capture.mkdir()
    env = dict(os.environ, RV_EXTENSION_CAPTURE=str(capture), RV_PINNED_PLUGIN=str(root / "plugin"))
    wrapper = root / "source" / ("gradlew.bat" if os.name == "nt" else "gradlew")
    if os.name != "nt":
        wrapper.chmod(wrapper.stat().st_mode | 0o100)
    command = [str(wrapper), "--no-daemon", "--no-configuration-cache", "--console=plain",
               "--init-script", str(root / "extension_capture.gradle"), *TASKS]
    with (output / "gradle.log").open("w", encoding="utf-8") as log:
        result = subprocess.run(command, cwd=root / "source", env=env, stdout=log, stderr=subprocess.STDOUT)
    write(output / "build-status.json", {"schema": "installer.extension-build-status.v1", "exit_code": result.returncode,
          "preparation_sha256": sha(root / "preparation.json"), "tasks": TASKS,
          "installer_jvm_executed": False, "original_files_modified": False})
    if result.returncode:
        raise RuntimeError("Original extension build failed; see " + str(output / "gradle.log"))
    # Gradle may create ignored build directories, never edit original inputs.
    verify_preparation(root)
    graph = json.loads((capture / "graph.json").read_text())
    if not all(t in graph["tasks"] for t in TASKS):
        raise ValueError("Original extension targets absent from executed graph")
    if any("publish" in t.lower() or t == ":patches:buildAndroid" for t in graph["tasks"]):
        raise ValueError("Unexpected task executed")
    extensions = {}
    for name in ("shared", "youtube"):
        candidates = list((root / "source" / "extensions" / name / "build" / "revanced").rglob(name + ".rve"))
        if len(candidates) != 1 or candidates[0].read_bytes()[:4] != b"dex\n":
            raise ValueError("Expected one raw DEX resource: " + name)
        extensions["extensions/" + name + ".rve"] = add_file(candidates[0], output)
    compilations = []
    for file in sorted(capture.glob("_*.json")):
        c = json.loads(file.read_text())
        if not c["project"].startswith(":extensions:"):
            continue
        sources = []
        for p in map(Path, c["sources"]):
            relative = p.relative_to(root / "source").as_posix()
            sources.append({**add_file(p, output), "origin": relative,
                            "generated": relative not in prepared["sources"]})
        all_args = c["compilerArgs"] + c.get("argumentProviders", [])
        system = None
        if "--system" in all_args:
            system = classpath_item(Path(all_args[all_args.index("--system") + 1]), output)
            system["kind"] = "compiler_system_image_zip"
        compilations.append({**{k: c[k] for k in ("project", "task", "sourceCompatibility", "targetCompatibility", "compilerArgs")},
                             "argumentProviders": c.get("argumentProviders", []), "system_image": system,
                             "compilerVersion": c.get("compilerVersion"),
                             "sources": sources,
                             "classpath": [classpath_item(Path(p), output) for p in c["classpath"]],
                             "bootstrap": [classpath_item(Path(p), output) for p in c["bootstrap"]],
                             "classes": classpath_item(Path(c["destination"]), output)})
    if not compilations:
        raise ValueError("No original Java compiler inputs captured")
    # Mutable/SNAPSHOT dependencies are locked to actual artifact bytes, not version labels.
    resolved = [add_file(p, output) for p in sorted((Path.home() / ".gradle/caches/modules-2/files-2.1").rglob("*"))
                if p.is_file() and p.suffix in (".jar", ".pom", ".module", ".exe")]
    write(output / "preparation.json", prepared)
    receipt = {"schema": "installer.extension-build.v1", "source_manifest": "preparation.json",
               "source_manifest_sha256": sha(output / "preparation.json"), "extensions": extensions,
               "compilations": compilations, "resolved_dependency_files": resolved,
               "graph": graph, "logs": [add_file(output / "gradle.log", output)],
               "r8_metadata": [add_file(p, output) for p in sorted((root / "source/extensions").rglob("*"))
                               if p.is_file() and "/outputs/mapping/release/" in p.as_posix()],
               "native_semantics_admitted": False, "installer_jvm_executed": False,
               "app_code_executed": False, "original_files_modified": False}
    write(output / "extension-build.json", receipt)
    return receipt


def verify_build(receipt, source=None):
    receipt = Path(receipt).resolve()
    value = json.loads(receipt.read_text(encoding="utf-8"))
    if value.get("schema") != "installer.extension-build.v1" or any(value.get(k) is not False for k in
            ("native_semantics_admitted", "installer_jvm_executed", "app_code_executed", "original_files_modified")):
        raise ValueError("Invalid extension build receipt")
    def check(row):
        p = (receipt.parent / row["path"]).resolve()
        if not p.is_relative_to(receipt.parent) or sha(p) != row["sha256"]:
            raise ValueError("Changed/escaping extension artifact: " + row["path"])
        return p
    manifest = check({"path": value["source_manifest"], "sha256": value["source_manifest_sha256"]})
    prepared = json.loads(manifest.read_text())
    if prepared["plugin_commit"] != PLUGIN_COMMIT or value["graph"]["installerJvmExecuted"] is not False or not all(t in value["graph"]["tasks"] for t in TASKS):
        raise ValueError("Wrong extension toolchain/task graph")
    if source is not None and tree(Path(source)) != prepared["sources"]:
        raise ValueError("Build does not correspond to current original source snapshot")
    for row in [*value["extensions"].values(), *value["resolved_dependency_files"], *value["logs"], *value.get("r8_metadata", [])]:
        check(row)
    for c in value["compilations"]:
        for row in [*c["sources"], *c["classpath"], *c["bootstrap"], c["classes"], *([c["system_image"]] if c.get("system_image") else [])]:
            if row.get("kind") != "absent_classpath_entry": check(row)
    if set(value["extensions"]) != {"extensions/shared.rve", "extensions/youtube.rve"}:
        raise ValueError("Missing original extensions")
    for row in value["extensions"].values():
        if check(row).read_bytes()[:4] != b"dex\n":
            raise ValueError("Extension is not raw DEX")
    return value


def import_dex(receipt, source, library, ordering_sources, out):
    from ..dex.build import build as index_dex
    from ..dex.ordering import verify as verify_order
    receipt, out = Path(receipt).resolve(), Path(out).resolve()
    value = verify_build(receipt, source)
    out.mkdir(parents=True, exist_ok=False)
    entries = {}
    for name, row in value["extensions"].items():
        stem = Path(name).stem
        index_dex(receipt.parent / row["path"], Path(library), out / stem, name)
        verify_order(out / stem / "dex-context-manifest.json", Path(ordering_sources), out / (stem + "-order"))
        p = out / (stem + "-order") / "dex-context-manifest.json"
        entries[name] = {"path": str(p), "sha256": sha(p)}
    write(out / "extension-import.json", {"schema": "installer.extension-import.v1",
          "build": {"path": str(receipt), "sha256": sha(receipt)}, "extensions": entries,
          "source_correspondence_verified": True, "native_semantics_admitted": False})
    return entries


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    q = sub.add_parser("prepare")
    for key in ("source", "plugin", "out"): q.add_argument("--" + key, type=Path, required=True)
    q = sub.add_parser("build")
    for key in ("prepared", "out"): q.add_argument("--" + key, type=Path, required=True)
    q = sub.add_parser("verify")
    q.add_argument("--receipt", type=Path, required=True); q.add_argument("--source", type=Path)
    q = sub.add_parser("import")
    for key in ("receipt", "source", "library", "ordering-sources", "out"): q.add_argument("--" + key, type=Path, required=True)
    a = p.parse_args()
    if a.command == "prepare": value = prepare(a.source, a.plugin, a.out)
    elif a.command == "build": value = build(a.prepared, a.out)
    elif a.command == "verify": value = verify_build(a.receipt, a.source)
    else: value = import_dex(a.receipt, a.source, a.library, a.ordering_sources, a.out)
    print(json.dumps({"command": a.command, "schema": value.get("schema"), "extensions": list(value.get("extensions", value))}))


if __name__ == "__main__": main()
