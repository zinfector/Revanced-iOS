package app.revanced.extension.youtube.settings.preference;

import static app.revanced.extension.shared.StringRef.str;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.util.AttributeSet;

import androidx.annotation.Nullable;

import app.revanced.extension.shared.Logger;
import app.revanced.extension.shared.Utils;
import app.revanced.extension.shared.settings.BaseSettings;
import app.revanced.extension.shared.settings.Setting;
import app.revanced.extension.shared.settings.preference.BulletPointPreference;
import app.revanced.extension.shared.spoof.ClientType;
import app.revanced.extension.youtube.settings.Settings;

@SuppressWarnings({"deprecation", "unused"})
public class SpoofVideoStreamsSideEffectsPreference extends Preference {

    @Nullable
    private ClientType currentClientType;

    private final SharedPreferences.OnSharedPreferenceChangeListener listener = (sharedPreferences, str) -> {
        // Because this listener may run before the ReVanced settings fragment updates Settings,
        // this could show the prior config and not the current.
        //
        // Push this call to the end of the main run queue,
        // so all other listeners are done and Settings is up to date.
        Utils.runOnMainThread(this::updateUI);
    };

    public SpoofVideoStreamsSideEffectsPreference(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public SpoofVideoStreamsSideEffectsPreference(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public SpoofVideoStreamsSideEffectsPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SpoofVideoStreamsSideEffectsPreference(Context context) {
        super(context);
    }

    private void addChangeListener() {
        Setting.preferences.preferences.registerOnSharedPreferenceChangeListener(listener);
    }

    private void removeChangeListener() {
        Setting.preferences.preferences.unregisterOnSharedPreferenceChangeListener(listener);
    }

    @Override
    protected void onAttachedToHierarchy(PreferenceManager preferenceManager) {
        super.onAttachedToHierarchy(preferenceManager);
        updateUI();
        addChangeListener();
    }

    @Override
    protected void onPrepareForRemoval() {
        super.onPrepareForRemoval();
        removeChangeListener();
    }

    private void updateUI() {
        ClientType clientType = Settings.SPOOF_VIDEO_STREAMS_CLIENT_TYPE.get();
        if (currentClientType == clientType) {
            return;
        }
        currentClientType = clientType;

        Logger.printDebug(() -> "Updating spoof stream side effects preference");
        setEnabled(BaseSettings.SPOOF_VIDEO_STREAMS.get());

        String summary = "";

        switch (clientType) {
            case ANDROID_CREATOR ->
                    summary = str("revanced_spoof_video_streams_about_no_audio_tracks")
                            + '\n' + str("revanced_spoof_video_streams_about_no_stable_volume")
                            + '\n' + str("revanced_spoof_video_streams_about_no_av1")
                            + '\n' + str("revanced_spoof_video_streams_about_no_force_original_audio");
            case ANDROID_REEL ->
                    summary = str("revanced_spoof_video_streams_about_playback_failure");
            // VR 1.61 is not exposed in the UI and should never be reached here.
            case ANDROID_VR_1_43_32, ANDROID_VR_1_61_48 ->
                    summary = str("revanced_spoof_video_streams_about_playback_failure")
                            + '\n' + str("revanced_spoof_video_streams_about_no_audio_tracks")
                            + '\n' + str("revanced_spoof_video_streams_about_no_stable_volume");
            case VISIONOS -> summary = str("revanced_spoof_video_streams_about_experimental")
                    + '\n' + str("revanced_spoof_video_streams_about_playback_failure")
                    + '\n' + str("revanced_spoof_video_streams_about_no_audio_tracks")
                    + '\n' + str("revanced_spoof_video_streams_about_no_av1");
            default -> Logger.printException(() -> "Unknown client: " + clientType);
        }

        // Only Android Reel and Android VR supports 360° VR immersive mode.
        if (!clientType.name().startsWith("ANDROID_VR") && clientType != ClientType.ANDROID_REEL) {
            summary += '\n' + str("revanced_spoof_video_streams_about_no_immersive_mode");
        }

        // Use better formatting for bullet points.
        setSummary(BulletPointPreference.formatIntoBulletPoints(summary));
    }
}
