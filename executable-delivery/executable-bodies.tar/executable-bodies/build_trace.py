"""Structured build failures without executing policies or validation suites."""
from datetime import datetime, timezone
import json
from pathlib import Path
import traceback


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def log_tail(path, limit=32768):
    if not path or not Path(path).is_file():
        return ''
    try:
        with Path(path).open('rb') as stream:
            stream.seek(0, 2)
            stream.seek(max(0, stream.tell() - limit))
            return stream.read().decode('utf-8', errors='replace')
    except OSError as error:
        return 'Could not read diagnostic log: ' + str(error)


class ToolFailure(RuntimeError):
    def __init__(self, argv, returncode=None, *, cwd=None, log=None,
                 stdout='', stderr='', timeout=None):
        self.build_detail = dict(command=list(map(str, argv)), exit_code=returncode,
            cwd=str(cwd) if cwd else None, log=str(Path(log).resolve()) if log else None,
            stdout_tail=stdout[-32768:], stderr_tail=stderr[-32768:],
            log_tail=log_tail(log), timeout_seconds=timeout)
        super().__init__('Tool timed out: ' + str(argv[0]) if timeout is not None else
                         'Tool failed (' + str(returncode) + '): ' + str(argv[0]))


def failure_record(error, stage, **context):
    chain = []
    seen = set()
    cursor = error
    while cursor is not None and id(cursor) not in seen:
        seen.add(id(cursor))
        row = dict(type=type(cursor).__module__ + '.' + type(cursor).__qualname__,
                   message=str(cursor))
        if getattr(cursor, 'build_detail', None):
            row.update(cursor.build_detail)
        if isinstance(cursor, OSError):
            row.update(errno=cursor.errno, filename=cursor.filename,
                       filename2=getattr(cursor, 'filename2', None))
        chain.append(row)
        cursor = cursor.__cause__ or (None if cursor.__suppress_context__ else cursor.__context__)
    return dict(schema='installer.build-failure.v1', stage=stage, timestamp=timestamp(),
                context=context, causes=chain,
                traceback=''.join(traceback.format_exception(type(error), error, error.__traceback__)))


class BuildTrace:
    def __init__(self, path):
        self.path = Path(path)
        self.steps = []
        self.current = 'starting'

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(dict(schema='installer.build-trace.v1', steps=self.steps),
                                       indent=2) + '\n', encoding='utf-8')

    def start(self, stage, **context):
        if self.steps and self.steps[-1]['status'] == 'running':
            self.steps[-1].update(status='complete', finished=timestamp())
        self.current = stage
        self.steps.append(dict(stage=stage, status='running', started=timestamp(), context=context))
        self.save()

    def finish(self):
        if self.steps and self.steps[-1]['status'] == 'running':
            self.steps[-1].update(status='complete', finished=timestamp())
        self.save()

    def fail(self, error, **context):
        detail = failure_record(error, self.current, **context)
        if self.steps:
            self.steps[-1].update(status='failed', finished=timestamp(), failure=detail)
        try:
            self.save()
        except OSError as write_error:
            detail['diagnostic_write_error'] = str(write_error)
        return detail
