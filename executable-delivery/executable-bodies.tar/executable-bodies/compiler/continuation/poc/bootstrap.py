"""Generate generic runtime initialization and a source-key diagnostic setting."""
import json
from pathlib import Path

from ..emitter.symbols import parse_descriptor


def q(value):
    return json.dumps(value, ensure_ascii=True)


def java_source(emission, configuration, setting, context_root, policy):
    entries = {e["descriptor"]: e for e in emission["entry_points"]}
    bootstrap = entries[context_root]; decision = entries[policy]
    if (bootstrap["parameters"] != ["Landroid/content/Context;"] or bootstrap["result"] != "V"
            or not bootstrap["static_source"] or not decision["static_source"] or decision["parameters"] or decision["result"] != "Z"):
        raise ValueError("PoC bootstrap/policy entry signature mismatch")
    profile = dict(configuration["profile"]); resources = configuration.get("resources", {})
    for identifier, color in resources.get("colors", {}).items():
        profile["resource.color." + str(int(identifier))] = str(int(color))
    for locale, strings in resources.get("localized_strings", {}).items():
        for identifier, value in strings.items():
            profile["resource.string." + locale + "." + str(int(identifier))] = value
    factories = []
    def table(name, values, typ, encode):
        pairs = sorted(values.items(), key=lambda v: str(v[0])); calls = []
        for start in range(0, len(pairs), 128):
            helper = name + str(start // 128); calls.append(helper + "(values);")
            body = "\n".join("values.put(" + (str(int(k)) if name == "strings" else q(k)) + "," + encode(v) + ");" for k, v in pairs[start:start + 128])
            factories.append("private static void " + helper + "(Map<" + typ + "> values){" + body + "}\n")
        factories.append("private static Map<" + typ + "> " + name + "(){Map<" + typ + "> values=new LinkedHashMap<>();" + "".join(calls) + "return values;}\n")
    table("profile", profile, "String,String", q)
    table("ids", resources.get("ids", {}), "String,Integer", lambda n: str(int(n)))
    table("strings", resources.get("strings", {}), "Integer,String", q)
    source = '''package rv.executable;
import java.util.*;
/** Fresh generated initialization; no direct writes into translated source fields. */
public final class GeneratedPocBootstrap {
 private static IOSPlatformServices services;
 private static int state; // 0 not started, 1 initializing, 2 ready, 3 failed
 private static String failure="";
 private static synchronized IOSPlatformServices services(){
  if(services==null)services=new IOSPlatformServices(profile(),ids(),strings());return services;
 }
 public static synchronized boolean initializeRuntime(){
  if(state==2)return true;if(state!=0)return false;state=1;
  try {
   GeneratedForeign provider=new GeneratedForeign(services());
   GeneratedEntryPoints.configure(provider);
   GeneratedEntryPoints.CONTEXT(provider.context().o());
   GeneratedEntryPoints.POLICY(); // Preserve original active-use/static initialization.
   state=2;return true;
  } catch(Throwable error){failure=error.toString();state=3;return false;}
 }
 public static synchronized String status(){return state==2?"ready":state==3?"failed: "+failure:state==1?"initializing":"unconfigured";}
 public static boolean readSetting(){
  String value=services().preference(NAMESPACE,KEY);
  if(value==null)return DEFAULT;
  if(!value.equals("Z:0") && !value.equals("Z:1"))throw new IllegalStateException("Invalid Boolean preference");
  return value.equals("Z:1");
 }
 public static boolean writeSetting(boolean value){
  return services().commitPreferences(NAMESPACE,Collections.singletonMap(KEY,value?"Z:1":"Z:0"));
 }
'''
    source = source.replace("GeneratedEntryPoints.CONTEXT", "GeneratedEntryPoints." + bootstrap["java_method"])
    source = source.replace("GeneratedEntryPoints.POLICY", "GeneratedEntryPoints." + decision["java_method"])
    source = source.replace("NAMESPACE", q(setting["namespace"])).replace("KEY", q(setting["key"])).replace("DEFAULT", str(setting["default"]).lower())
    return source + "\n".join(factories) + "}\n"


def native_source(headers, plan):
    """Discover fresh C exports after J2ObjC translation, including backend renaming."""
    import re
    header = Path(headers) / "rv/executable/GeneratedPocBootstrap.h"
    text = header.read_text(encoding="utf-8"); names = {}
    for method, result, arguments in [("initializeRuntime", "bool", "void"), ("status", "NSString *", "void"),
                                      ("readSetting", "bool", "void"), ("writeSettingWithBoolean_", "bool", "bool")]:
        declarations = re.findall(r"FOUNDATION_EXPORT\s+([^;]*\b(\w+_" + method + r")\(([^;]*)\));", text)
        if len(declarations) != 1:
            raise ValueError("Fresh bootstrap declaration missing: " + method)
        declaration, symbol, formal = declarations[0]
        from ..emitter.symbols import canonical_c
        ret = declaration[:declaration.index(symbol)].strip()
        parameter = re.sub(r"\b\w+$", "", formal).strip() if arguments != "void" else formal.strip()
        if canonical_c(ret) != canonical_c(result) or canonical_c(parameter) != canonical_c(arguments):
            raise ValueError("Fresh bootstrap declaration ABI differs: " + method)
        names[method] = symbol
    mode = plan["mode"]; expected = 1 if mode in ("active", "diagnostic") else 0
    install = "RVGInstall()" if mode == "active" else "RVGInstallObservations()" if mode == "diagnostic" else "0"
    init = names["initializeRuntime"] + "()" if mode == "active" else "true"
    source = '''#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include "rv/executable/GeneratedPocBootstrap.h"
#include <stdbool.h>
extern unsigned RVGInstall(void);
extern void RVGSetEnabled(bool);
extern NSDictionary *RVGGuardReport(void);
extern unsigned RVGInstallObservations(void);
extern NSArray *RVGObservationSnapshot(void);
static NSString *installation=@"not_started";
NSDictionary *RVPOCReport(void) {
 @try { return @{@"mode":@MODE, @"installation":installation, @"runtime":STATUS(),
  @"settingKey":@SETTING, @"restartRequired":@RESTART, @"setting":@(READ()), @"guard":RVGGuardReport(),
  @"observations":RVGObservationSnapshot()}; }
 @catch(NSException *error){ return @{@"installation":installation,@"error":error.description}; }
}
bool RVPOCWriteSetting(bool value) { @try { return WRITE(value); } @catch(NSException *error){NSLog(@"[GeneratedPoC] setting failure: %@",error);return false;} }
bool RVPOCPresentSettings(UIViewController *presenter) {
 if(!NSThread.isMainThread || !presenter || !presenter.viewIfLoaded.window || presenter.presentedViewController)return false;
 @try {
  BOOL current=READ();
  NSString *message=[NSString stringWithFormat:@"Current value: %@. Changes require restarting the app.",current?@"ON":@"OFF"];
  UIAlertController *dialog=[UIAlertController alertControllerWithTitle:@SETTING message:message preferredStyle:UIAlertControllerStyleAlert];
  [dialog addAction:[UIAlertAction actionWithTitle:current?@"Turn OFF":@"Turn ON" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
   BOOL saved=RVPOCWriteSetting(!current);
   UIAlertController *notice=[UIAlertController alertControllerWithTitle:saved?@"Setting saved":@"Setting could not be saved"
    message:saved?@"Restart the app to apply this setting.":@"The preference service reported a write failure." preferredStyle:UIAlertControllerStyleAlert];
   [notice addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];
   [presenter presentViewController:notice animated:YES completion:nil];
  }]];
  [dialog addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
  [presenter presentViewController:dialog animated:YES completion:nil];return true;
 } @catch(NSException *error){NSLog(@"[GeneratedPoC] settings presentation failure: %@",error);return false;}
}
// Generic Objective-C access for debugger transports that can invoke reviewed selectors.
@interface RVGeneratedPocDiagnostics : NSObject
+ (NSDictionary *)report;
+ (BOOL)writeSetting:(BOOL)value;
+ (BOOL)presentSettings:(UIViewController *)presenter;
@end
@implementation RVGeneratedPocDiagnostics
+ (NSDictionary *)report { return RVPOCReport(); }
+ (BOOL)writeSetting:(BOOL)value { return RVPOCWriteSetting(value); }
+ (BOOL)presentSettings:(UIViewController *)presenter { return RVPOCPresentSettings(presenter); }
@end
static void activate(unsigned attempts) {
 if(!INIT){installation=@"initialization_failed";NSLog(@"[GeneratedPoC] %@",STATUS());return;}
 unsigned count=INSTALL;
 if(count==EXPECTED && count>0){ENABLED installation=@"installed";return;}
 installation=@"waiting_for_slot";
 if(attempts)dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{activate(attempts-1);});
 else installation=@"slot_installation_failed";
}
bool RVPOCInitializeInspection(void) { return INITIALIZE(); }
'''
    replacements = {"MODE": q(mode), "SETTING": q(plan["setting"]["key"]), "RESTART": str(plan["setting"]["restart_required"]).lower(),
                    "STATUS()": names["status"] + "()", "READ()": names["readSetting"] + "()",
                    "WRITE(value)": names["writeSettingWithBoolean_"] + "(value)", "INIT": init,
                    "INSTALL": install, "EXPECTED": str(expected), "ENABLED": "RVGSetEnabled(true);" if mode == "active" else "",
                    "INITIALIZE()": names["initializeRuntime"] + "()"}
    # Token replacement avoids replacing INIT within INITIALIZE.
    for token in sorted(replacements, key=len, reverse=True):
        source = re.sub(r"(?<![A-Za-z0-9_])" + re.escape(token) + r"(?![A-Za-z0-9_])", lambda _: replacements[token], source)
    if mode != "inspection":
        source += "__attribute__((constructor)) static void load(void){dispatch_async(dispatch_get_main_queue(),^{activate(60);});}\n"
    return source
