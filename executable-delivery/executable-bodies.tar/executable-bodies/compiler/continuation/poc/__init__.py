"""Scoped original-installer to fresh executable-runtime application integration."""
