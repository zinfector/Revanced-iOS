"""Emit invocation-local guards from canonical checked acquisition recipes."""
import json
import hashlib


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def emit(recipe, symbol):
    import re
    if not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',symbol):raise ValueError('Invalid receiver guard export')
    if recipe.get('schema')!='installer.receiver-guard.v1' or recipe.get('kind')!='callback_self':
        raise ValueError('Unsupported receiver acquisition recipe')
    if recipe.get('sha256')!=digest({k:v for k,v in recipe.items() if k!='sha256'}):
        raise ValueError('Receiver guard recipe changed after admission')
    if recipe.get('queue')!='main' or recipe.get('lifetime')!='invocation' or recipe.get('native_references_retained') is not False:
        raise ValueError('Invocation guard cannot replace a retained receiver/epoch adapter')
    if not recipe.get('role_proof_sha256') or not recipe.get('domain_sha256'):
        raise ValueError('Receiver guard has no checked role-domain identity')
    body='Class required=objc_getClass('+json.dumps(recipe['native_class'])+');return [NSThread isMainThread] && required && owner && [owner isKindOfClass:required];'
    return 'static bool '+symbol+'(id owner){'+body+'}\n'
