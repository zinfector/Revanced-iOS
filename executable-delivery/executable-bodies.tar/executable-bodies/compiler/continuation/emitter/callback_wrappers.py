"""Emit ordered static callbacks; one original continuation per native slot."""
from collections import defaultdict
from .objc_wrappers import encoding,ABI
from .image_identity import original_rva
from .symbols import canonical_c
from ..resolver.native_contracts import signature

C={'V':'void','Z':'bool','I':'int32_t','J':'int64_t','F':'float','D':'double','Ljava/lang/String;':'NSString *'}


def scalar(value,source_type,native_args):
    if value.get('kind')!='native_argument':raise ValueError('Callback needs an explicit native argument projection')
    index=value.get('slot')
    if type(index) is not int or not 0<=index<len(native_args):raise ValueError('Native callback slot outside ABI')
    native=native_args[index];expression='a'+str(index);conversion=value.get('conversion','identity')
    identity={'Z':{'B'},'I':{'i'},'J':{'q'},'F':{'f'},'D':{'d'},'Ljava/lang/String;':{'@'}}
    if conversion=='identity' and native in identity.get(source_type,set()):return expression
    if conversion=='seconds_to_milliseconds' and native=='d' and source_type=='J':
        if value.get('unit_contract')!='seconds' or value.get('rounding')!='toward_zero':raise ValueError('Time unit/rounding contract missing')
        return '(int64_t)('+expression+' * 1000.0)'
    if conversion=='milliseconds_to_seconds' and native=='q' and source_type=='D':
        if value.get('unit_contract')!='milliseconds':raise ValueError('Time unit contract missing')
        return '('+expression+' / 1000.0)'
    raise ValueError('Unsupported callback scalar representation')


def emit(bindings,symbols,transactional=False):
    policies={r['descriptor']:r for r in symbols['symbols'] if r['status']=='linked'}
    groups=defaultdict(list);rows=[];held=[];headers=set()
    for binding in bindings.get('callbacks',[]):
        native=binding.get('method',{})
        groups[(native.get('class'),native.get('selector'),native.get('class_method',False))].append(binding)
    for key,group in sorted(groups.items(),key=lambda item:str(item[0])):
        identifier=group[0].get('composition_id',group[0].get('id'))
        try:
            native=group[0]['method'];result,args=encoding(native['encoding'])
            if result!='v' or len(args)!=native['selector'].count(':'):raise ValueError('Callback backend requires fixed void native entry')
            if native['selector'].startswith(('alloc','init','new','copy','mutableCopy')):raise ValueError('Ownership method family requires another backend')
            if any(b['method']!=native for b in group):raise ValueError('Composed native declarations differ')
            if len(group)>1 and (not group[0].get('composition_id') or any(b.get('composition_id')!=identifier for b in group)):
                raise ValueError('Several source requirements on one slot lack an ordered composition proof')
            if len({b.get('order',0) for b in group})!=len(group):raise ValueError('Source callback order is ambiguous')
            ordered=sorted(group,key=lambda b:b.get('order',0));before=[];after=[];checks=[];group_headers=set()
            guards={b['contract'].get('owner_guard_symbol') for b in group}
            if len(guards)!=1 or not next(iter(guards)):raise ValueError('Composed callbacks lack one executable owner guard')
            guard=next(iter(guards))
            if not __import__('re').fullmatch('[A-Za-z_][A-Za-z_0-9]*',guard):raise ValueError('Invalid guard export')
            for binding in ordered:
                if binding.get('status') not in ('admitted','experimental'):raise ValueError('Callback has no concrete emission contract')
                contract=binding['contract']
                if contract.get('phase') not in ('before_original','after_original'):raise ValueError('Callback phase unresolved')
                if contract.get('queue')!='main' or contract.get('multiplicity')!='each_invocation':raise ValueError('Unsupported queue/multiplicity')
                if contract.get('receiver_contract') not in ('same_item_live_owner','checked_invocation_owner'):
                    raise ValueError('Callback lacks an executable owner contract')
                if contract.get('source_exception_policy')!='propagate':raise ValueError('Original source exception semantics unresolved')
                parameters,returned=signature(binding['source_callback']);policy=policies.get(binding['source_callback'])
                if returned!='V' or not policy or policy['result']!='void' or any(t not in C or t=='V' for t in parameters):
                    raise ValueError('Fresh supported static void source callback missing')
                if len(parameters)!=len(contract['arguments']) or [canonical_c(p) for p in policy['parameters']]!=[canonical_c(C[t]) for t in parameters]:
                    raise ValueError('Callback source/native argument ABI differs')
                values=[scalar(v,t,args) for v,t in zip(contract['arguments'],parameters)]
                for value,typ in zip(contract['arguments'],parameters):
                    n=value['slot']
                    if typ=='Ljava/lang/String;':checks.append('(a'+str(n)+' == nil || [a'+str(n)+' isKindOfClass:[NSString class]])')
                    if value.get('conversion')=='seconds_to_milliseconds':checks.append('(isfinite(a'+str(n)+') && a'+str(n)+' >= 0 && a'+str(n)+' < 9223372036854775808.0/1000.0)')
                (before if contract['phase']=='before_original' else after).append(policy['symbol']+'('+', '.join(values)+');')
                group_headers.add(policy['header'])
            item=group[0]['contract'].get('item_argument')
            if item is not None:
                if type(item) is not int or not 0<=item<len(args) or args[item]!='@':raise ValueError('Item argument outside object ABI')
                checks.append('(a'+str(item)+' == nil || [a'+str(item)+' isKindOfClass:[NSString class]])')
            suffix='cb_'+str(len(rows));formals=', '.join(['id self','SEL cmd',*[ABI[t]+' a'+str(n) for n,t in enumerate(args)]])
            supplied=', '.join(['self','cmd',*['a'+str(n) for n in range(len(args))]])
            original='original_'+suffix+'('+supplied+');'
            def action(calls):
                if not calls:return ''
                return 'if('+guard+'(self)'+''.join(' && '+c for c in dict.fromkeys(checks))+') { '+''.join(calls)+' }'
            disabled='!atomic_load(&enabled) || ' if transactional else ''
            body='if('+disabled+'![NSThread isMainThread]) {'+original+'return;} '+action(before)+' '+original+' '+action(after)
            rows.append(dict(id=identifier,requirement=identifier,original_rva=original_rva(native,bindings['image']),native=native,
                declaration='typedef void (*Original_'+suffix+')('+formals+');\nstatic Original_'+suffix+' original_'+suffix+';\nstatic void wrapper_'+suffix+'('+formals+'){'+body+'}',
                wrapper_symbol='wrapper_'+suffix,original_symbol='original_'+suffix,owner_guard_symbol=guard,
                source_callbacks=[b['source_callback'] for b in ordered],headers=sorted(group_headers),
                experimental=any(b['status']=='experimental' for b in group),original_continuation='once_on_normal_callback_completion'))
            headers.update(group_headers)
        except (ValueError,KeyError,TypeError) as error:
            held.append(dict(requirement=identifier,reason=str(error)))
    source='#import <Foundation/Foundation.h>\n#include <math.h>\n#include <stdint.h>\n#include <stdbool.h>\n'+''.join('#include "'+h+'"\n' for h in sorted(headers))
    source+=''.join('extern bool '+g+'(id owner);\n' for g in sorted({r['owner_guard_symbol'] for r in rows}))
    source+='\n'.join(r['declaration'] for r in rows)
    return source,dict(schema='installer.source-callback-emission.v2',wrappers=rows,held=held,
        complete=bool(rows) and not held,installed=False,headers=sorted(headers),
        installation='shared_preflight_commit_rollback',source_exception_policy='propagate')
