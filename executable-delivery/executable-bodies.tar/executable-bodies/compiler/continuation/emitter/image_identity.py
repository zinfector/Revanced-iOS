"""Bind generated installation to an image UUID and expected original IMP RVA."""
import re


def uuid_guard(image, name="RVGImageMatches"):
    value = (image or {}).get("uuid", "").replace("-", "").lower()
    if not re.fullmatch(r"[0-9a-f]{32}", value):
        # Unbound plans compile for inspection but cannot install anything.
        return f"static bool {name}(void) {{ return false; }}\n"
    expected = ", ".join("0x" + value[i:i + 2] for i in range(0, 32, 2))
    return f'''static bool {name}(void) {{
 const struct mach_header_64 *header = (const struct mach_header_64 *)_dyld_get_image_header(0);
 if (!header || header->magic != MH_MAGIC_64) return false;
 const uint8_t expected[16] = {{ {expected} }};
 const uint8_t *cursor = (const uint8_t *)(header + 1), *end = cursor + header->sizeofcmds;
 for (uint32_t i = 0; i < header->ncmds; ++i) {{
  if (cursor + sizeof(struct load_command) > end) return false;
  const struct load_command *command = (const struct load_command *)cursor;
  if (command->cmdsize < sizeof(*command) || cursor + command->cmdsize > end) return false;
  if (command->cmd == LC_UUID && command->cmdsize >= sizeof(struct uuid_command)) return memcmp(((const struct uuid_command *)command)->uuid, expected, 16) == 0;
  cursor += command->cmdsize;
 }}
 return false;
}}
'''


def original_rva(method, image):
    if not image or "vmaddr" not in image or "entry" not in method:
        raise ValueError("Original image base/method entry witness unavailable")
    integer = lambda x: int(x, 0) if isinstance(x, str) else int(x)
    offset = integer(method["entry"]) - integer(image["vmaddr"])
    if offset < 0:
        raise ValueError("Original method entry precedes image base")
    return offset
