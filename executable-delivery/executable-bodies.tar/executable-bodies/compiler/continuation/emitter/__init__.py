"""Fresh generated glue; never selects old iOS feature implementations."""
