"""Link DEX policy signatures to emitted J2ObjC declarations, including prefixes."""
import hashlib
from pathlib import Path
import re

DEX = re.compile(r"^(L[^;]+;)->([^()]+)\((.*?)\)(.+)$")
TYPES = {"Z": ("bool", "Boolean"), "B": ("int8_t", "Byte"), "C": ("uint16_t", "Char"), "S": ("int16_t", "Short"),
         "I": ("int32_t", "Int"), "J": ("int64_t", "Long"), "F": ("float", "Float"), "D": ("double", "Double"),
         "V": ("void", ""), "Ljava/lang/String;": ("NSString *", "NSString")}
C_EQ = {"jboolean": "bool", "jbyte": "int8_t", "jchar": "uint16_t", "jshort": "int16_t", "jint": "int32_t", "jlong": "int64_t", "jfloat": "float", "jdouble": "double"}


def parse_descriptor(descriptor):
    match = DEX.fullmatch(descriptor)
    if not match:
        raise ValueError("Invalid DEX method descriptor: " + descriptor)
    args = re.findall(r"\[*L[^;]+;|\[*[ZBCSIJFD]", match[3])
    if "".join(args) != match[3]:
        raise ValueError("Malformed DEX parameter list")
    return match[1][1:-1], match[2], args, match[4]


def canonical_c(value):
    value = re.sub(r"\s+", " ", value.strip()).replace(" *", "*")
    return C_EQ.get(value, value)


def executable_inventory(emission, headers, prefix="RVEGeneratedEntryPoints"):
    """Derive entry identities from fresh translated declarations, before native linking."""
    header = Path(headers) / "rv/executable/GeneratedEntryPoints.h"
    text = header.read_text(encoding="utf-8")
    entries = []
    for entry in emission["entry_points"]:
        name = re.escape(prefix + "_" + entry["java_method"])
        declarations = re.findall(r"FOUNDATION_EXPORT\s+[^;{}]*?\b" + name + r"[A-Za-z0-9_]*\s*\([^;]*\);", text)
        if len(declarations) != 1:
            raise ValueError("Fresh native entry declaration missing/ambiguous: " + entry["descriptor"])
        symbol = re.search(r"\b(" + name + r"[A-Za-z0-9_]*)\s*\(", declarations[0])[1]
        entries.append({**entry, "native_symbol": "_" + symbol, "header_declarations": declarations,
                        "header": "rv/executable/GeneratedEntryPoints.h",
                        "header_sha256": hashlib.sha256(header.read_bytes()).hexdigest()})
    return {"schema": "installer.executable-native-inventory.v1", "entries": entries,
            "symbols_compiled": False, "native_binding_admitted": False}


def link_executable(requirements, inventory, headers):
    """Link exact source descriptors to generated executable-runtime entry declarations."""
    if inventory.get("schema") != "installer.executable-native-inventory.v1":
        raise ValueError("Executable entry inventory required")
    by_descriptor = {}
    for entry in inventory["entries"]:
        if entry["descriptor"] in by_descriptor:
            raise ValueError("Duplicate executable entry identity")
        by_descriptor[entry["descriptor"]] = entry
    rows = []
    descriptors = {p["source_dex_descriptor"] for r in requirements["requirements"] for p in r["policy_methods"]}
    for descriptor in sorted(descriptors):
        row = {"descriptor": descriptor, "status": "held"}
        try:
            entry = by_descriptor.get(descriptor)
            _, _, args, result = parse_descriptor(descriptor)
            if not entry or not entry.get("static_source") or entry["parameters"] != args or entry["result"] != result:
                raise ValueError("Missing static entry or source descriptor/entry ABI mismatch")
            if any(t not in TYPES for t in [*args, result]):
                raise ValueError("Executable wrapper marshalling supports primitive/String signatures only")
            relative = Path(entry["header"])
            root = Path(headers).resolve(); header = (root / relative).resolve()
            if relative.is_absolute() or root not in header.parents:
                raise ValueError("Entry header must be within fresh translation output")
            if hashlib.sha256(header.read_bytes()).hexdigest() != entry["header_sha256"]:
                raise ValueError("Fresh entry header differs from inventory")
            symbol = entry["native_symbol"].removeprefix("_")
            if not re.fullmatch(r"[A-Za-z_]\w*", symbol):
                raise ValueError("Invalid exported entry symbol")
            text = header.read_text(encoding="utf-8")
            matches = re.findall(r"FOUNDATION_EXPORT\s+([\w\s*]+?)\s*\b" + re.escape(symbol) + r"\(([^;]*)\);", text)
            valid = []
            for ret, parameters in matches:
                formals = [] if parameters.strip() in ("", "void") else [re.sub(r"\b\w+$", "", p).strip() for p in parameters.split(",")]
                if canonical_c(ret) == canonical_c(TYPES[result][0]) and [canonical_c(p) for p in formals] == [canonical_c(TYPES[a][0]) for a in args]:
                    valid.append(symbol)
            if len(valid) != 1:
                raise ValueError("Fresh executable entry prototype mismatch")
            row.update(status="linked", symbol=symbol, header=relative.as_posix(), header_path=str(header),
                       header_sha256=entry["header_sha256"], parameters=[TYPES[a][0] for a in args], result=TYPES[result][0],
                       backend="executable_runtime", java_method=entry["java_method"])
        except (ValueError, OSError, KeyError) as error:
            row["reason"] = str(error)
        rows.append(row)
    return {"schema": "installer.emitted-policy-symbols.v1", "symbols": rows}


def link(requirements, headers):
    rows = []
    descriptors = {method["source_dex_descriptor"] for req in requirements["requirements"] for method in req["policy_methods"]}
    for descriptor in sorted(descriptors):
        row = {"descriptor": descriptor, "status": "held"}
        owner, name, args, result = parse_descriptor(descriptor)
        header = Path(headers) / (owner + ".h")
        if not header.is_file() or any(typ not in TYPES for typ in [*args, result]):
            row["reason"] = "header or supported source signature unavailable"
            rows.append(row)
            continue
        text = header.read_text()
        suffix = name + ("With" + "_with".join(TYPES[x][1] for x in args) + "_" if args else "")
        functions = re.findall(r"FOUNDATION_EXPORT\s+([\w\s*]+?)\s*(\w+_" + re.escape(suffix) + r")\(([^;]*)\);", text)
        valid = []
        for ret, function, parameters in functions:
            formals = [] if parameters.strip() in ("", "void") else [re.sub(r"\b\w+$", "", p).strip() for p in parameters.split(",")]
            if canonical_c(ret) == canonical_c(TYPES[result][0]) and [canonical_c(p) for p in formals] == [canonical_c(TYPES[a][0]) for a in args]:
                valid.append(function)
        if len(valid) == 1:
            row.update(status="linked", symbol=valid[0], header=owner + ".h", header_path=str(header.resolve()),
                       header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(), parameters=[TYPES[a][0] for a in args], result=TYPES[result][0])
        else:
            row["reason"] = "emitted prototype is missing, ambiguous or differs from source signature"
        rows.append(row)
    return {"schema": "installer.emitted-policy-symbols.v1", "symbols": rows}
