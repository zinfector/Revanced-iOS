"""Join global guards and checked callback pipelines in one hook transaction."""
import json
from . import objc_wrappers
from . import callback_wrappers
from .receiver_guards import emit as emit_guard


def shape(requirement, native, contract=None):
    if requirement['operation']!='callback_pipeline':return objc_wrappers.shape(requirement,native)
    contract=contract or {}
    if requirement.get('backend')!='objc_callback_entry' or requirement.get('installer_conditions'):
        raise ValueError('Callback requires a supported unconditional original boundary')
    result,args=objc_wrappers.encoding(native['encoding'])
    if result!='v' or native.get('class_method') or native['selector'].count(':')!=len(args):
        raise ValueError('Callback needs a fixed void instance entry')
    if native['selector'].startswith(('alloc','init','new','copy','mutableCopy')):
        raise ValueError('Callback ownership method family unsupported')
    stages=requirement['pipeline']['stages'];callbacks=contract.get('callbacks',[])
    if not stages or len(stages)!=len(callbacks) or contract.get('event_role')!='invocation_owner':
        raise ValueError('Canonical admitted callback/receiver contract absent')
    for stage,callback in zip(stages,callbacks):
        if stage['descriptor']!=callback['source_callback'] or stage['order']!=callback['order']:
            raise ValueError('Callback contract differs from original instruction order')
    if not contract.get('receiver_guard'):raise ValueError('Executable receiver acquisition recipe absent')
    emit_guard(contract['receiver_guard'],'RVGShapeOnly')
    return result,args


def emit(requirements,bindings,symbols):
    reqs={r['id']:r for r in requirements['requirements']};global_rows=[];callback_rows=[];guards=[];held=[]
    occupied=set();guard_records=[]
    for row in bindings['bindings']:
        if row['status'] not in ('admitted','experimental'):continue
        req=reqs[row['requirement']]
        if req['operation']!='callback_pipeline':global_rows.append(row);continue
        try:
            if row['status']!='admitted':raise ValueError('Experimental nominations cannot activate a stateful callback')
            contract=row.get('contract') or row.get('evidence',{}).get('binding',{}).get('contract')
            native=row['binding'];shape(req,native,contract)
            key=(native['class'],native['selector'],native.get('class_method',False))
            if key in occupied:raise ValueError('Separate requirements on one slot need a final-source composition')
            occupied.add(key);symbol='RVGOwnerGuard_'+str(len(guard_records))
            recipe=contract['receiver_guard'];guards.append(emit_guard(recipe,symbol))
            guard_records.append(dict(requirement=req['id'],symbol=symbol,recipe=recipe))
            for stage in contract['callbacks']:
                value={**stage,'owner_guard_symbol':symbol}
                if recipe.get('item'):value['item_argument']=recipe['item']['slot']
                callback_rows.append(dict(id=req['id']+':'+str(stage['order']),composition_id=req['id'],
                    status='admitted',method=native,source_callback=stage['source_callback'],order=stage['order'],contract=value))
        except (ValueError,KeyError,TypeError) as error:
            held.append(dict(requirement=req['id'],reason=str(error)))
    _,base=objc_wrappers.emit(requirements,{**bindings,'bindings':global_rows},symbols)
    fragments=base['source_fragments'];held.extend(base['held'])
    global_slots={(r['binding']['class'],r['binding']['selector'],r['binding'].get('class_method',False)) for r in global_rows}
    if global_slots&occupied:held.append(dict(reason='Global guard and callback share a slot without source composition'))
    _,callbacks=callback_wrappers.emit(dict(image=bindings['image'],callbacks=callback_rows),symbols,transactional=True)
    held.extend(callbacks['held']);declarations=list(fragments['declarations']);installers=list(fragments['installers'])
    headers=set(fragments['headers']);headers.update(callbacks['headers']);rows=list(base['wrappers'])
    for callback in callbacks['wrappers']:
        native=callback['native'];result,args=objc_wrappers.encoding(native['encoding']);types=[result,'@',':',*args]
        declarations.append(callback['declaration'])
        installers.append('if (!RVGPlanSlot('+','.join([json.dumps(native['class']),json.dumps(native['selector']),
            'false',json.dumps(native['encoding']), '(IMP)'+callback['wrapper_symbol'],
            '(IMP *)&'+callback['original_symbol'],str(len(types)-1),
            '(const char *[]){'+', '.join(json.dumps(t) for t in types)+'}',str(callback['original_rva'])+'ULL'])+')) return 0;')
        rows.append({**callback,'operation':'callback_pipeline','semantic_admission':True})
    source=objc_wrappers.transaction_source(declarations,installers,len(rows),headers,bindings['image'],
        extra_source='#include <math.h>\n'+''.join(guards))
    return source,dict(schema='installer.native-hook-emission.v1',wrappers=rows,held=held,
        receiver_guards=guard_records,expected_slots=len(rows),complete=bool(rows) and not held,
        compiled_for_ios=False,device_verified=False,legacy_ios_implementation_used=False,
        activation='all_slots_preflight_then_commit_then_external_enable',
        rollback='restore_owned_IMPs_preserve_competing_hooks',same_slot_order='original_pipeline_stage_order')
