"""Typed wrappers from semantic edits, with original calls outside policy catches."""
import json
import re
from .image_identity import uuid_guard, original_rva

ABI = {"v": "void", "B": "bool", "c": "signed char", "i": "int", "q": "long long", "f": "float", "d": "double", "@": "id"}


def encoding(value):
    # Structs, blocks, pointers, qualified ownership, variadics and selectors as arguments stay held.
    tokens = re.findall(r"[A-Za-z@:#?^{}\[\]()]+|\d+", value)
    compact = re.sub(r"\d+", "", value)
    if not compact or compact[0] not in ABI or compact[1:3] != "@:" or any(x not in ABI or x == "v" for x in compact[3:]):
        raise ValueError("Unsupported Objective-C ABI: " + value)
    if "".join(tokens) != value:
        raise ValueError("Malformed encoding")
    return compact[0], list(compact[3:])


def literal(value, result):
    if value.get("kind") == "void" and result == "v":
        return ""
    if value.get("kind") != "constant":
        raise ValueError("Replacement must be typed constant")
    raw = value["value"]
    if result in ("B", "c") and isinstance(raw, bool):
        return "true" if raw else "false"
    if result in ("i", "q") and isinstance(raw, int) and not isinstance(raw, bool):
        bits = 32 if result == "i" else 64
        if not -(1 << (bits - 1)) <= raw < 1 << (bits - 1):
            raise ValueError("Replacement exceeds native integer width")
        return str(raw) + ("LL" if result == "q" else "")
    raise ValueError("Replacement type differs from ABI")


def emit(requirements, bindings, symbols):
    policies = {row["descriptor"]: row for row in symbols["symbols"] if row["status"] == "linked"}
    reqs = {r["id"]: r for r in requirements["requirements"]}
    headers, declarations, installers, receipts, held = set(), [], [], [], []
    occupied = set()
    for row in bindings["bindings"]:
        if row["status"] != "admitted":
            continue
        req, native = reqs[row["requirement"]], row["binding"]
        try:
            result, args = encoding(native["encoding"])
            rva = original_rva(native, bindings.get("image"))
            key = (native["class"], native["selector"], native.get("class_method", False))
            if key in occupied:
                raise ValueError("Multiple edits on one slot require ordered composition")
            if native["selector"].count(":") != len(args):
                raise ValueError("Selector argument count differs from ABI")
            if result == "@" or any(native["selector"].startswith(x) for x in ("init", "alloc", "new", "copy", "mutableCopy")):
                raise ValueError("Object return ownership/family backend not admitted")
            if row.get("event_role") != "global":
                raise ValueError("Owner-scoped wrapper needs an admitted role predicate backend")
            if req.get("installer_conditions"):
                raise ValueError("Version/installer branch applicability must be resolved by planner before emission")
            if req["operation"] not in ("guard_entry", "bypass_body", "transform_normal_result", "replace_normal_result"):
                raise ValueError("Interception shape requires another backend")
            suffix = str(len(receipts))
            arguments = [f"{ABI[t]} a{i}" for i, t in enumerate(args)]
            signature = ", ".join(["id self", "SEL cmd", *arguments])
            original_args = ", ".join(["self", "cmd", *[f"a{i}" for i in range(len(args))]])
            call_original = f"original_{suffix}({original_args})"
            passthrough = (call_original + "; return;" if result == "v" else "return " + call_original + ";")
            semantic = req["semantics"]

            def policy_call(expression, original=False):
                if expression.get("kind") == "not":
                    return "!(" + policy_call(expression["value"], original) + ")"
                if expression.get("kind") != "call_extension":
                    raise ValueError("Unsupported policy expression")
                descriptor = expression["method"]["source_dex_descriptor"]
                policy = policies.get(descriptor)
                if not policy:
                    raise ValueError("Original Android policy has no emitted symbol")
                supplied = expression["arguments"]
                expected = ["bool"] if original and result in ("B", "c") else []
                if policy["parameters"] != expected or policy["result"] != "bool" or len(supplied) != len(expected):
                    raise ValueError("Policy/native signature or input provenance differs")
                if expected and supplied[0].get("kind") != "original_normal_result":
                    raise ValueError("Policy input is not the original normal result")
                headers.add(policy["header"])
                return policy["symbol"] + ("(value)" if original else "()")

            operation = req["operation"]
            if operation == "guard_entry":
                if result != "v" or semantic.get("allowed_path") != "original_body" or semantic.get("suppressed_path") != "return_void":
                    raise ValueError("Unsupported guard branching semantics")
                body = f"bool allow = true;\n  @try {{ evaluating_{suffix} = true; allow = {policy_call(semantic['condition'])}; }}\n  @catch (NSException *error) {{ RVGRecordFailure(error); }}\n  @finally {{ evaluating_{suffix} = false; }}\n  if (!allow) {{ atomic_fetch_add(&suppressedCalls, 1); return; }}\n  atomic_fetch_add(&allowedCalls, 1);\n  {passthrough}"
            elif operation == "bypass_body":
                body = "return" + (" " + literal(semantic["result"], result) if result != "v" else "") + ";"
            else:
                if result == "v":
                    raise ValueError("Cannot transform a void result")
                transform = policy_call(semantic["transform"], True) if operation == "transform_normal_result" else literal(semantic["result"], result)
                body = f"{ABI[result]} value = {call_original};\n  @try {{ evaluating_{suffix} = true; return {transform}; }}\n  @catch (NSException *error) {{ RVGRecordFailure(error); return value; }}\n  @finally {{ evaluating_{suffix} = false; }}"
            declarations.append(f"typedef {ABI[result]} (*Original_{suffix})({signature});\nstatic Original_{suffix} original_{suffix};\nstatic _Thread_local bool evaluating_{suffix};\nstatic {ABI[result]} wrapper_{suffix}({signature}) {{\n  if (!atomic_load(&enabled) || evaluating_{suffix}) {{ {passthrough} }}\n  {body}\n}}")
            expected_types = [result, "@", ":", *args]
            installers.append(f"installed += RVGInstallSlot({json.dumps(native['class'])}, {json.dumps(native['selector'])}, {'true' if native.get('class_method') else 'false'}, {json.dumps(native['encoding'])}, (IMP)wrapper_{suffix}, (IMP *)&original_{suffix}, {len(expected_types) - 1}, (const char *[]){{{', '.join(json.dumps(x) for x in expected_types)}}}, {rva}ULL);")
            occupied.add(key)
            receipts.append({"requirement": req["id"], "class": native["class"], "selector": native["selector"], "operation": operation, "original_effects": "source-derived original-call placement", "typed_signature": signature})
        except ValueError as error:
            held.append({"requirement": req["id"], "reason": str(error)})
    prelude = '''// Generated from source semantics and admitted bindings. No feature driver switch.
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
static atomic_bool enabled = false;
static atomic_ullong allowedCalls = 0, suppressedCalls = 0, policyFailures = 0;
static NSString *slotStatus = @"not_attempted";
static void RVGRecordFailure(NSException *error) { atomic_fetch_add(&policyFailures, 1); NSLog(@"[GeneratedInstaller] %@", error); }
void RVGSetEnabled(bool value) { atomic_store(&enabled, value); }
NSDictionary *RVGGuardReport(void) { return @{@"enabled":@(atomic_load(&enabled)), @"allowed":@(atomic_load(&allowedCalls)), @"suppressed":@(atomic_load(&suppressedCalls)), @"policyFailures":@(atomic_load(&policyFailures)), @"slotStatus":slotStatus}; }
static bool RVGInstallSlot(const char *className, const char *selectorName, bool classMethod, const char *encoding, IMP replacement, IMP *original, unsigned count, const char **types, uint64_t originalRVA) {
  Class cls = objc_getClass(className);
  if (!cls) { slotStatus=@"class_unavailable"; return false; }
  if (classMethod) cls = object_getClass(cls);
  SEL selector = sel_registerName(selectorName);
  Method method = class_getInstanceMethod(cls, selector);
  if (!method || method_getNumberOfArguments(method) != count) { slotStatus=@"method_or_argument_count_mismatch"; return false; }
  char *actual = method_copyReturnType(method);
  bool valid = actual && strcmp(actual, types[0]) == 0;
  free(actual);
  for (unsigned i = 0; valid && i < count; ++i) {
    actual = method_copyArgumentType(method, i);
    valid = actual && strcmp(actual, types[i + 1]) == 0;
    free(actual);
  }
  if (!valid) { slotStatus=@"abi_mismatch"; return false; }
  IMP previous = method_getImplementation(method);
  if (*original) { slotStatus=previous==replacement ? @"installed" : @"replaced_by_another_hook"; return previous==replacement; }
  if ((uintptr_t)previous != (uintptr_t)_dyld_get_image_header(0) + originalRVA) { slotStatus=@"original_imp_mismatch"; return false; }
  *original = previous;
  if (!class_addMethod(cls, selector, replacement, encoding)) class_replaceMethod(cls, selector, replacement, encoding);
  slotStatus=@"installed";
  return true;
}
'''
    source = prelude + "\n" + uuid_guard(bindings.get("image")) + "\n" + "\n".join('#include "' + h + '"' for h in sorted(headers)) + "\n\n" + "\n\n".join(declarations)
    source += "\nunsigned RVGInstall(void) { @synchronized(NSProcessInfo.processInfo) { if (!RVGImageMatches()) return 0; unsigned installed = 0;\n  " + "\n  ".join(installers) + "\n  return installed; } }\n"
    return source, {"schema": "installer.objc-emission.v2", "wrappers": receipts, "held": held,
                    "compiled_for_ios": False, "device_verified": False, "legacy_ios_implementation_used": False}
