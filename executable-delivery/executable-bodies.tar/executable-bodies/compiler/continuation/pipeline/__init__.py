"""Authoritative, obligation-driven source-to-native bundle pipeline."""
