"""Generic UIKit controls from fresh translated settings exports; no feature logic."""
from pathlib import Path
import re


def emit(headers):
    text=(Path(headers)/'rv/executable/GeneratedSettings.h').read_text(encoding='utf-8')
    names={}
    from ..emitter.symbols import canonical_c
    for method,result,args in (('snapshot','id<JavaUtilList>','void'),('writeWithNSString_withNSString_','bool','NSString *,NSString *')):
        rows=re.findall(r'FOUNDATION_EXPORT\s+([^;]*\b(\w+_'+method+r')\(([^;]*)\));',text)
        if len(rows)!=1:raise ValueError('Fresh settings export missing: '+method)
        declaration,symbol,formal=rows[0];actual=declaration[:declaration.index(symbol)].strip()
        types=','.join(re.sub(r'\b\w+$','',p).strip() for p in formal.split(',')) if args!='void' else formal.strip()
        if canonical_c(actual)!=canonical_c(result) or canonical_c(types)!=canonical_c(args):raise ValueError('Fresh settings export ABI differs')
        names[method]=symbol
    source='''#import <UIKit/UIKit.h>
#include <stdbool.h>
#include "rv/executable/GeneratedSettings.h"
#include "java/util/List.h"
#include "java/util/Map.h"
static NSArray *RVGBSettingsSnapshot(void) {
 NSMutableArray *rows=[NSMutableArray array];id<JavaUtilList> list=SNAPSHOT();
 for(jint i=0;i<[list size];++i){id<JavaUtilMap> row=[list getWithInt:i];NSMutableDictionary *value=[NSMutableDictionary dictionary];
  for(NSString *key in @[@"id",@"key",@"type",@"title",@"value",@"display"]){id item=[row getWithId:key];value[key]=item?:NSNull.null;}[rows addObject:value];}
 return rows;
}
@interface RVGBSettingsController : UITableViewController
@property(nonatomic,strong) NSArray *settings;
@end
@implementation RVGBSettingsController
- (void)viewDidLoad {[super viewDidLoad];self.title=@"Translated settings";self.settings=RVGBSettingsSnapshot();
 self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(close)];}
- (void)close {[self dismissViewControllerAnimated:YES completion:nil];}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {return self.settings.count;}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"setting"];
 if(!cell)cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"setting"];
 NSDictionary *row=self.settings[indexPath.row];cell.textLabel.text=row[@"title"];
 id display=row[@"display"];cell.detailTextLabel.text=display==NSNull.null?@"Default":display;cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;return cell;
}
- (void)save:(NSDictionary *)row input:(NSString *)input {
 BOOL saved=NO;NSString *message=nil;
 @try {saved=WRITE(row[@"id"],input);message=saved?@"Restart the app to apply this setting.":@"The preference service could not save this setting.";}
 @catch(NSException *error){message=error.reason?:@"The value could not be saved.";}
 self.settings=RVGBSettingsSnapshot();[self.tableView reloadData];
 UIAlertController *notice=[UIAlertController alertControllerWithTitle:saved?@"Setting saved":@"Setting not saved" message:message preferredStyle:UIAlertControllerStyleAlert];
 [notice addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:notice animated:YES completion:nil];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 [tableView deselectRowAtIndexPath:indexPath animated:YES];NSDictionary *row=self.settings[indexPath.row];
 BOOL boolean=[row[@"type"] isEqual:@"bool"];
 UIAlertController *dialog=[UIAlertController alertControllerWithTitle:row[@"title"] message:@"Changes require restarting the app." preferredStyle:UIAlertControllerStyleAlert];
 if(boolean){
  for(NSString *choice in @[@"true",@"false"])[dialog addAction:[UIAlertAction actionWithTitle:[choice isEqual:@"true"]?@"On":@"Off" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self save:row input:choice];}]];
 }else{
  [dialog addTextFieldWithConfigurationHandler:^(UITextField *field){id value=row[@"display"];if([value isKindOfClass:NSString.class])field.text=value;}];
  [dialog addAction:[UIAlertAction actionWithTitle:@"Save" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self save:row input:dialog.textFields.firstObject.text?:@""];}]];
 }
 [dialog addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:dialog animated:YES completion:nil];
}
@end
bool RVGBPresentSettings(UIViewController *presenter) {
 if(!NSThread.isMainThread || !presenter.viewIfLoaded.window || presenter.presentedViewController)return false;
 @try {[presenter presentViewController:[[UINavigationController alloc] initWithRootViewController:[[RVGBSettingsController alloc] initWithStyle:UITableViewStyleInsetGrouped]] animated:YES completion:nil];return true;}
 @catch(NSException *error){NSLog(@"[GeneratedSettings] %@",error);return false;}
}
'''
    return source.replace('SNAPSHOT()',names['snapshot']+'()').replace('WRITE(',names['writeWithNSString_withNSString_']+'(')
