"""The executable native subset shared by admission and provider generation."""
import re

TYPES = {"Z": "B", "I": "i", "J": "q", "F": "f", "D": "d", "V": "v", "Ljava/lang/String;": "@"}


def signature(descriptor):
    member = descriptor.split("->", 1)[1]
    parameters, result = member[member.index("(") + 1:].split(")", 1)
    return re.findall(r"\[*L[^;]+;|\[*[ZBCSIJFD]", parameters), result


def encoding_types(encoding):
    # Fixed scalar/id methods only. Blocks, structs, pointers and qualifiers hold.
    if not re.fullmatch(r"[vBi qfd@:0-9]+".replace(" ", ""), encoding):
        return []
    return re.findall(r"[vBiqfd@:]", encoding)


def obligations(operation, method, contract):
    errors = []
    if operation["kind"] not in ("call", "virtual_call"):
        return ["abi: backend currently accepts method calls only"]
    if any(site.get("opcode", "").startswith("INVOKE_STATIC") for site in operation.get("source_sites", [])):
        errors.append("abi: source has a static call site")
    params, result = signature(operation["descriptor"])
    native = encoding_types(method["encoding"])
    if contract.get("backend") != "fixed_objc_method" or method.get("class_method"):
        errors.append("abi: only fixed instance method dispatch is supported")
    if method["selector"].startswith(("alloc", "init", "new", "copy", "mutableCopy")):
        errors.append("abi: Objective-C ownership method families require a separate backend")
    if contract.get("static") is not False:
        errors.append("abi: source call must be an instance method")
    if contract.get("parameters") != params or contract.get("result") != result:
        errors.append("abi: exact source signature mismatch")
    if any(t not in TYPES or t == "V" for t in params) or result not in TYPES:
        errors.append("abi: unsupported source value type")
    expected = [TYPES.get(result), "@", ":", *[TYPES.get(t) for t in params]]
    adapter = contract.get("adapter", "identity")
    native_order=None
    if adapter=='scalar_projection':
        from continuation.runtime.adapter_registry import scalar_arguments
        try:
            native_order=scalar_arguments(params,contract.get('parameter_projection'))
            expected=[TYPES.get(result),'@',':',*[TYPES[r['type']] for r in native_order]]
        except ValueError as error:errors.append('abi: '+str(error))
    elif adapter == "view_visibility":
        expected = ["v", "@", ":", "B"]
        if params != ["I"] or result != "V": errors.append("abi: visibility source prototype mismatch")
        sites = operation.get("source_sites", [])
        if not sites or any(len(site.get("arguments", [])) != 2 or site["arguments"][1]["origin"].get("kind") != "constant" or site["arguments"][1]["origin"].get("literal") not in (0,4) for site in sites):
            errors.append("abi: visibility requires all selected source sites to supply proven VISIBLE/INVISIBLE constants; GONE needs a layout adapter")
    elif adapter != "identity":
        errors.append("abi: adapter is not executable by this backend")
    if native != expected:
        errors.append("abi: native prototype differs from generated function pointer")
    if method["selector"].count(":") != len(expected) - 3:
        errors.append("abi: selector arity differs from prototype")
    input_units=contract.get('input_units',[])
    expected_units=[input_units[r['source_slot']] for r in native_order] if native_order is not None and len(input_units)==len(params) else input_units
    if expected_units != contract.get("native_input_units") or contract.get("result_units") != contract.get("native_result_units"):
        errors.append("units: conversion requires a supported explicit conversion adapter")
    if len(contract.get("input_units", [])) != len(params) or "result_units" not in contract:
        errors.append("units: every value requires declared units (null for nonnumeric values)")
    units = contract.get("input_units", [])
    if any(t in ("I", "J", "F", "D") and (i >= len(units) or not isinstance(units[i], str) or not units[i]) for i,t in enumerate(params)) or result in ("I", "J", "F", "D") and not contract.get("result_units"):
        errors.append("units: numeric values require named units")
    if contract.get("queue") not in ("main", "caller"):
        errors.append("queue: no executable queue contract")
    if contract.get("lifetime") != "weak_owner_slot_generation" or not all(contract.get(k) for k in ("role", "surface", "slot", "item_semantics")):
        errors.append("lifetime: incomplete live object identity contract")
    for step in contract.get("receiver_path", []):
        if step.get("kind") != "objc_object_ivar" or not all(isinstance(step.get(k), str) and step[k] for k in ("declaring_class", "name", "encoding")) or not re.fullmatch(r'@(?:"[^"\\]+")?', step.get("encoding", "")):
            errors.append("lifetime: unsupported symbolic receiver path step")
        if any(k in step for k in ("offset", "runtime_offset", "address", "handle")):
            errors.append("lifetime: receiver paths must not contain physical offsets/handles")
    if contract.get("receiver_path") and not contract.get("native_root_class"):
        errors.append("lifetime: root class required for symbolic receiver acquisition")
    if contract.get("error_policy") != "propagate":
        errors.append("error_policy: backend must propagate provider failures")
    return errors
