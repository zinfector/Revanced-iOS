"""Semantic requirements and independently evidenced native bindings."""
