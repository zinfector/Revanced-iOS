"""Resolved-source installation planner and fresh native glue generator."""
