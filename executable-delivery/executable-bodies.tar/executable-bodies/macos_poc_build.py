"""Translate fresh body sources, emit scoped glue from fresh headers, link once.

This portable script is archived with the selected emitter modules. It runs no
tests, policies or comparison harnesses. App activation is only generated code.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import traceback
import zipfile

J2OBJC_COMMIT = "1671e9afb72a16126d448f468db3e582358fba47"
PAYLOAD = "GeneratedEntryGuard.dylib"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


def capture(command):
    return subprocess.check_output(list(map(str, command)), text=True).strip()


def run(command, log):
    with Path(log).open("w", encoding="utf-8") as stream:
        result = subprocess.run(list(map(str, command)), stdout=stream, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError("Build failed: " + str(log))


def build(bundle, home, out):
    bundle, home, out = (Path(p).resolve() for p in (bundle, home, out))
    out.mkdir(parents=True, exist_ok=False)
    receipt = {"schema": "installer.poc-native-build.v1", "status": "started", "arm64_ios_compiled": False,
               "tests_run": False, "validations_run": False, "original_bodies_executed": False,
               "native_hooks_installed": False, "device_verified": False,
               "legacy_ios_feature_code_used": False, "compiled_feature_payload_reused": False}
    try:
        ledger = json.loads((bundle / "stage-ledger.json").read_text(encoding="utf-8"))
        actual = {p.relative_to(bundle).as_posix(): sha(p) for p in bundle.rglob("*") if p.is_file() and p.name != "stage-ledger.json"}
        if actual != ledger["files"]:
            raise ValueError("Staged source group changed")
        if capture(["git", "-C", home.parent, "rev-parse", "HEAD"]) != J2OBJC_COMMIT:
            raise ValueError("Unexpected J2ObjC revision")
        xcode = capture(["xcodebuild", "-version"])
        if not xcode.startswith("Xcode 16.4\n"):
            raise ValueError("Established Xcode 16.4 route required")
        bindings = json.loads((bundle / "foreign-bindings.json").read_text(encoding="utf-8"))
        if bindings["held"] or bindings["additional_original_roots"]:
            raise ValueError("Unclosed source foreign/callback frontier")
        with zipfile.ZipFile(home / "lib/jre_emul.jar") as archive:
            for witness in bindings["jre_classes"].values():
                raw = archive.read(witness["name"].replace(".", "/") + ".class")
                if hashlib.sha256(raw).hexdigest() != witness["classfile_sha256"]:
                    raise ValueError("Demanded JRE API witness differs from pinned runtime")
        plan = json.loads((bundle / "integration-plan.json").read_text(encoding="utf-8"))
        emission = json.loads((bundle / "emission.json").read_text(encoding="utf-8"))
        if plan["schema"] != "installer.entry-guard-poc.v1" or plan["mode"] not in ("inspection", "diagnostic", "active"):
            raise ValueError("Scoped integration plan required")
        if plan["mode"] == "active" and not plan["native_bindings"]["complete"]:
            raise ValueError("Active integration requires an admitted slot")
        receipt.update(mode=plan["mode"], source_plan_sha256=sha(bundle / "integration-plan.json"),
                       stage_ledger_sha256=sha(bundle / "stage-ledger.json"), j2objc_commit=J2OBJC_COMMIT, xcode=xcode)
        objc = out / "objc"; objc.mkdir(); prefixes = out / "prefixes.properties"
        prefixes.write_text("rv.executable=RVE\n", encoding="utf-8", newline="\n")
        inputs = bundle / "java"
        translate = [home / "j2objc", "-source", "17", "-use-arc", "--prefixes", prefixes,
                     "-sourcepath", inputs, "-d", objc, *sorted(inputs.rglob("*.java"))]
        receipt["translation_command"] = list(map(str, translate)); write(out / "receipt.json", receipt)
        run(translate, out / "translation.log")
        sys.path.insert(0, str(bundle / "compiler"))
        from continuation.emitter.symbols import executable_inventory, link_executable
        from continuation.emitter.objc_wrappers import emit as emit_wrappers
        from continuation.poc.bootstrap import native_source
        inventory = executable_inventory(emission, objc)
        symbols = link_executable(plan["requirements"], inventory, objc)
        if any(s["status"] != "linked" for s in symbols["symbols"]):
            raise ValueError("Fresh policy symbol closure incomplete: " + json.dumps(symbols))
        # Observation mode uses only the separately generated observation source.
        native_bindings = plan["native_bindings"] if plan["mode"] == "active" else {
            **plan["native_bindings"], "bindings": [], "complete": False}
        installer, wrappers = emit_wrappers(plan["requirements"], native_bindings, symbols)
        if wrappers["held"] or (plan["mode"] == "active" and len(wrappers["wrappers"]) != 1):
            raise ValueError("Scoped wrapper backend incomplete: " + json.dumps(wrappers))
        native = out / "generated"; native.mkdir()
        (native / "GeneratedInstaller.m").write_text(installer, encoding="utf-8", newline="\n")
        (native / "GeneratedBootstrap.m").write_text(native_source(objc, plan), encoding="utf-8", newline="\n")
        (native / "GeneratedObservations.m").write_text((bundle / "GeneratedObservations.m").read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
        (out / "integration-plan.json").write_bytes((bundle / "integration-plan.json").read_bytes())
        write(out / "policy-symbols.json", symbols)
        write(out / "wrapper-emission.json", wrappers); write(out / "entry-point-inventory.json", inventory)
        sdk = capture(["xcrun", "--sdk", "iphoneos", "--show-sdk-path"])
        payload = out / PAYLOAD; runtime = home / "lib/iphone/libjre_emul.a"
        arguments = ["-target", "arm64-apple-ios17.0", "-isysroot", sdk, "-fobjc-arc", "-fobjc-arc-exceptions", "-fblocks",
                     "-O2", "-g", "-Wno-parentheses-equality", "-I", home / "include", "-I", objc,
                     *sorted(objc.rglob("*.m")), *sorted(native.glob("*.m")), runtime,
                     "-framework", "Foundation", "-framework", "UIKit", "-framework", "QuartzCore", "-framework", "Security",
                     "-liconv", "-lz", "-licucore", "-dynamiclib", "-Wl,-install_name,@executable_path/Frameworks/" + PAYLOAD,
                     "-Wl,-headerpad,0x4000", "-o", payload]
        args = out / "compile.args"
        args.write_text("\n".join(json.dumps(str(a)) for a in arguments), encoding="utf-8", newline="\n")
        command = ["xcrun", "--sdk", "iphoneos", "clang", "@" + str(args)]
        receipt.update(ios_command=list(map(str, command)), runtime_sha256=sha(runtime), sdk=sdk)
        write(out / "receipt.json", receipt); run(command, out / "compile-ios.log")
        receipt.update(status="compiled", arm64_ios_compiled=True, payload=PAYLOAD, payload_sha256=sha(payload),
                       native_site_admitted=plan["mode"] == "active", original_methods=len(emission["methods"]),
                       ipa_packaging_allowed=plan["mode"] in ("diagnostic", "active"),
                       app_behavior_verified=False, full_installer_translation_claimed=False)
        receipt["diagnostic_report"]={"schema":"installer.report-buffer.v1","capacity":32768,
            "transport":"debug.read","generation_symbol":"_RVPOCReportGeneration",
            "length_symbol":"_RVPOCReportLength","buffer_symbol":"_RVPOCReportBuffer",
            "generation_bytes":8,"length_bytes":4,"encoding":"utf-8","publication":"odd-even-generation"}
    except Exception as error:
        receipt.update(status="failed", error=str(error))
        (out / "failure.txt").write_text(traceback.format_exc(), encoding="utf-8", newline="\n")
        raise
    finally:
        write(out / "receipt.json", receipt)
        write(out / "artifact-ledger.json", {p.relative_to(out).as_posix(): sha(p) for p in out.rglob("*") if p.is_file() and p.name != "artifact-ledger.json"})
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("bundle", "j2objc-home", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args(); print(json.dumps(build(args.bundle, args.j2objc_home, args.out), indent=2))
