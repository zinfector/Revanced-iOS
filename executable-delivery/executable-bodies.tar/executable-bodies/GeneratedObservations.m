// Diagnostic only. Does not call patch policies or admit application roles.
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <stdbool.h>
#include <string.h>
#include <stdint.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/mach_time.h>
static NSString *RVGProbeConfiguration(void) { return @"7f59bc6f614a7ebab89ea195332e37c96df99f2ee1f89a43d13032144aba2ca1"; }
static NSMutableArray *events;
static NSString *nonce;
static uint64_t eventCounter;
static _Thread_local bool tracing;
static id objectIdentity(id value) { if (!value) return NSNull.null; return @{ @"abi": @"@", @"handle": @((uintptr_t)(__bridge void *)value), @"class": @(class_getName(object_getClass(value))) }; }
static id floatingBits(const void *value, size_t count, NSString *abi) { return @{ @"abi": abi, @"bits_base64": [[NSData dataWithBytes:value length:count] base64EncodedStringWithOptions:0] }; }
static uint64_t trace(const char *method, id receiver, SEL selector, NSString *phase, NSArray *arguments, id result, NSString *exception, uint64_t invocation) {
 if (tracing) return 0;
 tracing = true;
 uint64_t event = 0;
 @try {
  @synchronized(NSProcessInfo.processInfo) {
   if (!events) { events = [NSMutableArray array]; nonce = NSUUID.UUID.UUIDString; }
   if (events.count == 256) [events removeObjectAtIndex:0];
   event = ++eventCounter;
   [events addObject:@{ @"process": nonce, @"event": @(event), @"invocation": @(invocation ?: event), @"monotonic_ticks": @(mach_absolute_time()), @"method": @(method), @"selector": @(sel_getName(selector)), @"receiver": objectIdentity(receiver), @"phase": phase, @"arguments": arguments ?: @[], @"result": result ?: NSNull.null, @"exception": exception ?: NSNull.null, @"main": @(NSThread.isMainThread), @"configuration": RVGProbeConfiguration() }];
  }
 } @catch (NSException *error) { } @finally { tracing = false; }
 return event;
}
NSArray *RVGObservationSnapshot(void) { @synchronized(NSProcessInfo.processInfo) { return [events copy] ?: @[]; } }
static bool install(const char *name, const char *selectorName, bool classMethod, const char *encoding, IMP replacement, IMP *original, uint64_t rva) {
 Class cls = objc_getClass(name); if (!cls) return false;
 if (classMethod) cls = object_getClass(cls);
 SEL selector = sel_registerName(selectorName); Method method = class_getInstanceMethod(cls, selector);
 if (!method || strcmp(method_getTypeEncoding(method), encoding) != 0) return false;
 IMP previous = method_getImplementation(method);
 if (*original) return previous == replacement;
 if ((uintptr_t)previous != (uintptr_t)_dyld_get_image_header(0) + rva) return false;
 *original = previous;
 if (!class_addMethod(cls, selector, replacement, encoding)) class_replaceMethod(cls, selector, replacement, encoding);
 return true;
}

static bool RVGObservationImageMatches(void) {
 const struct mach_header_64 *header = (const struct mach_header_64 *)_dyld_get_image_header(0);
 if (!header || header->magic != MH_MAGIC_64) return false;
 const uint8_t expected[16] = { 0x1f, 0x61, 0x66, 0x5a, 0x5d, 0x4a, 0x35, 0x66, 0x8b, 0x77, 0xda, 0x82, 0x1e, 0x1d, 0x6c, 0x17 };
 const uint8_t *cursor = (const uint8_t *)(header + 1), *end = cursor + header->sizeofcmds;
 for (uint32_t i = 0; i < header->ncmds; ++i) {
  if (cursor + sizeof(struct load_command) > end) return false;
  const struct load_command *command = (const struct load_command *)cursor;
  if (command->cmdsize < sizeof(*command) || cursor + command->cmdsize > end) return false;
  if (command->cmd == LC_UUID && command->cmdsize >= sizeof(struct uuid_command)) return memcmp(((const struct uuid_command *)command)->uuid, expected, 16) == 0;
  cursor += command->cmdsize;
 }
 return false;
}


unsigned RVGInstallObservations(void) { @synchronized(NSProcessInfo.processInfo) { if (!RVGObservationImageMatches()) return 0; unsigned count = 0;
  
  return count; } }
