#import <Foundation/Foundation.h>
unsigned RVGInstallObservations(void){return 0;}
NSArray *RVGObservationSnapshot(void){return @[];}
