package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_9c0501ff5cac449eab1d {
static ClassInfo info_9c0501ff5cac449eab1d() {return new ClassInfo("Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda1;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
