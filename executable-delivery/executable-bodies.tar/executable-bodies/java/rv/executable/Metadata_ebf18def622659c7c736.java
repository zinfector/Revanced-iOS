package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_ebf18def622659c7c736 {
static ClassInfo info_ebf18def622659c7c736() {return new ClassInfo("Lapp/revanced/extension/shared/settings/Setting$ImportExportCallback;", "Ljava/lang/Object;", new String[]{}, 1537, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("settingsExported(Landroid/content/Context;)V", 1025), new MethodInfo("settingsImported(Landroid/content/Context;)V", 1025)});}
}
