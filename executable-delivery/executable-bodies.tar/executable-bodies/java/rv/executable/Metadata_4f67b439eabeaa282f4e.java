package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_4f67b439eabeaa282f4e {
static ClassInfo info_4f67b439eabeaa282f4e() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;", "Ljava/lang/Object;", new String[]{}, 1, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;->fullscreenButtonRef:Ljava/lang/ref/WeakReference;", "Ljava/lang/ref/WeakReference;", 9, ExecutableRuntime.zero("Ljava/lang/ref/WeakReference;"))}, new MethodInfo[]{new MethodInfo("$r8$lambda$5eR5QwU9-EbC4vsUfd4Jr2Kna64()Ljava/lang/String;", 4105), new MethodInfo("-$$Nest$smfullscreenButtonVisibilityChanged(Z)V", 4169), new MethodInfo("<clinit>()V", 65544), new MethodInfo("<init>()V", 65537), new MethodInfo("fullscreenButtonVisibilityCallbacksExist()Z", 10), new MethodInfo("fullscreenButtonVisibilityChanged(Z)V", 10), new MethodInfo("setFullscreenCloseButton(Landroid/view/View;)V", 9)}, "PlayerControlsPatch");}
}
