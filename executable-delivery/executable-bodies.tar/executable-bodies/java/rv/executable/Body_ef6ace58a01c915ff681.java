package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_ef6ace58a01c915ff681 {
static Value m_287778e30226e43446e3b6c5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;->f$0:Ljava/lang/String;", r[0], false, r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a756fe8933230d6509ce26fd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;->f$0:Ljava/lang/String;", r[1], false); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;", "Lapp/revanced/extension/shared/Utils;->$r8$lambda$PkKfpt--1hDmVmbZfHETPMoR8mo(Ljava/lang/String;)Ljava/lang/String;", Value.NULL, new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
