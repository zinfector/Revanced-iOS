package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_fb2cff6286d661a16a24 {
static Value m_55096cdc469f04bd6060d295(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;","Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->access$isOpen$cp()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_258c415db93d41e904c543b3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;");
r[1] = rt.check(arguments[0], "Lkotlin/jvm/internal/DefaultConstructorMarker;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;","Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d6cf00b826e45ef2b2971d10(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
