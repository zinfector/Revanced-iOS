package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_fb2cff6286d661a16a24 {
static Value m_c0b3adef4f43917c5497e3a6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;");
r[2] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->access$isOpen$cp()Z", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc = (ExecutableRuntime.equal(r[0], r[2])) ? 12 : 3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion$$ExternalSyntheticLambda0;"); pc = 4; continue; }
case 4: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion$$ExternalSyntheticLambda0;-><init>()V", r[0], new Value[]{}); pc = 5; continue; }
case 5: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V", Value.NULL, new Value[]{r[0]}); pc = 6; continue; }
case 6: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->access$setOpen$cp(Z)V", Value.NULL, new Value[]{r[2]}); pc = 7; continue; }
case 7: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;->getOnChange()Lapp/revanced/extension/youtube/shared/Event;", r[1], new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;", Value.NULL, new Value[]{r[2]}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/Event;->invoke(Ljava/lang/Object;)V", r[0], new Value[]{r[2]}); pc = 12; continue; }
case 12: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_55096cdc469f04bd6060d295(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->access$isOpen$cp()Z", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0], "Z"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_258c415db93d41e904c543b3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;");
r[1] = rt.check(arguments[0], "Lkotlin/jvm/internal/DefaultConstructorMarker;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a2a769c23787f1593833d7e0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->access$getOnChange$cp()Lapp/revanced/extension/youtube/shared/Event;", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0], "Lapp/revanced/extension/youtube/shared/Event;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d6cf00b826e45ef2b2971d10(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_93f3e11306b0dccc9360e7ac(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->access$isOpen$cp()Z", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 3; continue; }
case 3: { r[2] = Value.ref("ShortsPlayerState open changed to: "); pc = 4; continue; }
case 4: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V", r[1], new Value[]{r[2]}); pc = 5; continue; }
case 5: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;", r[1], new Value[]{r[0]}); pc = 6; continue; }
case 6: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;", r[1], new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
