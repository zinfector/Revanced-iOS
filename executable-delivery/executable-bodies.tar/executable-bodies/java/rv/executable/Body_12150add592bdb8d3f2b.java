package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_12150add592bdb8d3f2b {
static Value m_18d009105a1da42494259e89(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[20];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/spoof/ClientType;"); pc = 1; continue; }
case 1: { r[6] = rt.readField("Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;", Value.NULL, true); pc = 2; continue; }
case 2: { r[7] = rt.readField("Landroid/os/Build;->MODEL:Ljava/lang/String;", Value.NULL, true); pc = 3; continue; }
case 3: { r[9] = rt.readField("Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;", Value.NULL, true); pc = 4; continue; }
case 4: { r[1] = rt.readField("Landroid/os/Build$VERSION;->SDK_INT:I", Value.NULL, true); pc = 5; continue; }
case 5: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/lang/String;->valueOf(I)Ljava/lang/String;", Value.NULL, new Value[]{r[1]}); pc = 6; continue; }
case 6: { r[10] = result; pc = 7; continue; }
case 7: { r[11] = rt.readField("Landroid/os/Build;->ID:Ljava/lang/String;", Value.NULL, true); pc = 8; continue; }
case 8: { r[15] = Value.i32(0); pc = 9; continue; }
case 9: { r[16] = Value.ref("Android Reel"); pc = 10; continue; }
case 10: { r[1] = Value.ref("ANDROID_REEL"); pc = 11; continue; }
case 11: { r[2] = Value.i32(0); pc = 12; continue; }
case 12: { r[3] = Value.i32(3); pc = 13; continue; }
case 13: { r[4] = Value.ref("ANDROID"); pc = 14; continue; }
case 14: { r[5] = Value.ref("com.google.android.youtube"); pc = 15; continue; }
case 15: { r[8] = Value.ref("Android"); pc = 16; continue; }
case 16: { r[12] = Value.ref("20.44.38"); pc = 17; continue; }
case 17: { r[13] = Value.i32(1); pc = 18; continue; }
case 18: { r[14] = Value.i32(1); pc = 19; continue; }
case 19: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType;-><init>(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;)V", r[0], new Value[]{r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16]}); pc = 20; continue; }
case 20: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_REEL:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true, r[0]); pc = 21; continue; }
case 21: { r[1] = rt.allocate("Lapp/revanced/extension/shared/spoof/ClientType;"); pc = 22; continue; }
case 22: { r[16] = Value.i32(1); pc = 23; continue; }
case 23: { r[17] = Value.ref("Android VR 1.61"); pc = 24; continue; }
case 24: { r[2] = Value.ref("ANDROID_VR_1_61_48"); pc = 25; continue; }
case 25: { r[3] = Value.i32(1); pc = 26; continue; }
case 26: { r[4] = Value.i32(28); pc = 27; continue; }
case 27: { r[5] = Value.ref("ANDROID_VR"); pc = 28; continue; }
case 28: { r[6] = Value.ref("com.google.android.apps.youtube.vr.oculus"); pc = 29; continue; }
case 29: { r[7] = Value.ref("Oculus"); pc = 30; continue; }
case 30: { r[8] = Value.ref("Quest 3"); pc = 31; continue; }
case 31: { r[9] = Value.ref("Android"); pc = 32; continue; }
case 32: { r[10] = Value.ref("12"); pc = 33; continue; }
case 33: { r[11] = Value.ref("32"); pc = 34; continue; }
case 34: { r[12] = Value.ref("SQ3A.220605.009.A1"); pc = 35; continue; }
case 35: { r[13] = Value.ref("1.61.48"); pc = 36; continue; }
case 36: { r[14] = Value.i32(0); pc = 37; continue; }
case 37: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType;-><init>(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;)V", r[1], new Value[]{r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17]}); pc = 38; continue; }
case 38: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_VR_1_61_48:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true, r[1]); pc = 39; continue; }
case 39: { r[2] = rt.allocate("Lapp/revanced/extension/shared/spoof/ClientType;"); pc = 40; continue; }
case 40: { r[5] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->id:I", r[1], false); pc = 41; continue; }
case 41: { r[6] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->clientName:Ljava/lang/String;", r[1], false); pc = 42; continue; }
case 42: { r[7] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->packageName:Ljava/lang/String;", r[1], false); pc = 43; continue; }
case 43: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[7]}); pc = 44; continue; }
case 44: { r[8] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->deviceMake:Ljava/lang/String;", r[1], false); pc = 45; continue; }
case 45: { r[9] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->deviceModel:Ljava/lang/String;", r[1], false); pc = 46; continue; }
case 46: { r[10] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->osName:Ljava/lang/String;", r[1], false); pc = 47; continue; }
case 47: { r[11] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->osVersion:Ljava/lang/String;", r[1], false); pc = 48; continue; }
case 48: { r[12] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->androidSdkVersion:Ljava/lang/String;", r[1], false); pc = 49; continue; }
case 49: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[12]}); pc = 50; continue; }
case 50: { r[13] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->buildId:Ljava/lang/String;", r[1], false); pc = 51; continue; }
case 51: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[13]}); pc = 52; continue; }
case 52: { r[15] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->useAuth:Z", r[1], false); pc = 53; continue; }
case 53: { r[0] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->supportsMultiAudioTracks:Z", r[1], false); pc = 54; continue; }
case 54: { r[1] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->usePlayerEndpoint:Z", r[1], false); pc = 55; continue; }
case 55: { r[18] = Value.ref("Android VR 1.43"); pc = 56; continue; }
case 56: { r[3] = Value.ref("ANDROID_VR_1_43_32"); pc = 57; continue; }
case 57: { r[4] = Value.i32(2); pc = 58; continue; }
case 58: { r[14] = Value.ref("1.43.32"); pc = 59; continue; }
case 59: { r[16] = r[0]; pc = 60; continue; }
case 60: { r[17] = r[1]; pc = 61; continue; }
case 61: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType;-><init>(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;)V", r[2], new Value[]{r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18]}); pc = 62; continue; }
case 62: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_VR_1_43_32:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true, r[2]); pc = 63; continue; }
case 63: { r[3] = rt.allocate("Lapp/revanced/extension/shared/spoof/ClientType;"); pc = 64; continue; }
case 64: { r[18] = Value.i32(1); pc = 65; continue; }
case 65: { r[19] = Value.ref("Android Studio"); pc = 66; continue; }
case 66: { r[4] = Value.ref("ANDROID_CREATOR"); pc = 67; continue; }
case 67: { r[5] = Value.i32(3); pc = 68; continue; }
case 68: { r[6] = Value.i32(14); pc = 69; continue; }
case 69: { r[7] = Value.ref("ANDROID_CREATOR"); pc = 70; continue; }
case 70: { r[8] = Value.ref("com.google.android.apps.youtube.creator"); pc = 71; continue; }
case 71: { r[9] = Value.ref("Google"); pc = 72; continue; }
case 72: { r[10] = Value.ref("Pixel 9 Pro Fold"); pc = 73; continue; }
case 73: { r[11] = Value.ref("Android"); pc = 74; continue; }
case 74: { r[12] = Value.ref("15"); pc = 75; continue; }
case 75: { r[13] = Value.ref("35"); pc = 76; continue; }
case 76: { r[14] = Value.ref("AP3A.241005.015.A2"); pc = 77; continue; }
case 77: { r[15] = Value.ref("23.47.101"); pc = 78; continue; }
case 78: { r[16] = Value.i32(1); pc = 79; continue; }
case 79: { r[17] = Value.i32(0); pc = 80; continue; }
case 80: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType;-><init>(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;)V", r[3], new Value[]{r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19]}); pc = 81; continue; }
case 81: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_CREATOR:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true, r[3]); pc = 82; continue; }
case 82: { r[4] = rt.allocate("Lapp/revanced/extension/shared/spoof/ClientType;"); pc = 83; continue; }
case 83: { r[17] = Value.i32(1); pc = 84; continue; }
case 84: { r[18] = Value.ref("visionOS"); pc = 85; continue; }
case 85: { r[5] = Value.ref("VISIONOS"); pc = 86; continue; }
case 86: { r[6] = Value.i32(4); pc = 87; continue; }
case 87: { r[7] = Value.i32(101); pc = 88; continue; }
case 88: { r[8] = Value.ref("VISIONOS"); pc = 89; continue; }
case 89: { r[9] = Value.ref("Apple"); pc = 90; continue; }
case 90: { r[10] = Value.ref("RealityDevice14,1"); pc = 91; continue; }
case 91: { r[11] = Value.ref("visionOS"); pc = 92; continue; }
case 92: { r[12] = Value.ref("1.3.21O771"); pc = 93; continue; }
case 93: { r[13] = Value.ref("0.1"); pc = 94; continue; }
case 94: { r[14] = Value.ref("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"); pc = 95; continue; }
case 95: { r[15] = Value.i32(0); pc = 96; continue; }
case 96: { r[16] = Value.i32(0); pc = 97; continue; }
case 97: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType;-><init>(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;)V", r[4], new Value[]{r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18]}); pc = 98; continue; }
case 98: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->VISIONOS:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true, r[4]); pc = 99; continue; }
case 99: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType;->$values()[Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, new Value[]{}); pc = 100; continue; }
case 100: { r[0] = result; pc = 101; continue; }
case 101: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->$VALUES:[Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true, r[0]); pc = 102; continue; }
case 102: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_34e111fd948269b985d4cc29(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 16) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[17];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/spoof/ClientType;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "I");
r[4] = rt.check(arguments[3], "Ljava/lang/String;");
r[5] = rt.check(arguments[4], "Ljava/lang/String;");
r[6] = rt.check(arguments[5], "Ljava/lang/String;");
r[7] = rt.check(arguments[6], "Ljava/lang/String;");
r[8] = rt.check(arguments[7], "Ljava/lang/String;");
r[9] = rt.check(arguments[8], "Ljava/lang/String;");
r[10] = rt.check(arguments[9], "Ljava/lang/String;");
r[11] = rt.check(arguments[10], "Ljava/lang/String;");
r[12] = rt.check(arguments[11], "Ljava/lang/String;");
r[13] = rt.check(arguments[12], "Z");
r[14] = rt.check(arguments[13], "Z");
r[15] = rt.check(arguments[14], "Z");
r[16] = rt.check(arguments[15], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->id:I", r[0], false, r[3]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->clientName:Ljava/lang/String;", r[0], false, r[4]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->packageName:Ljava/lang/String;", r[0], false, r[5]); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->deviceMake:Ljava/lang/String;", r[0], false, r[6]); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->deviceModel:Ljava/lang/String;", r[0], false, r[7]); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->osName:Ljava/lang/String;", r[0], false, r[8]); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->osVersion:Ljava/lang/String;", r[0], false, r[9]); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->androidSdkVersion:Ljava/lang/String;", r[0], false, r[10]); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->buildId:Ljava/lang/String;", r[0], false, r[11]); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->clientVersion:Ljava/lang/String;", r[0], false, r[12]); pc = 11; continue; }
case 11: { r[1] = r[13]; pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->useAuth:Z", r[0], false, r[1]); pc = 13; continue; }
case 13: { r[1] = r[14]; pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->supportsMultiAudioTracks:Z", r[0], false, r[1]); pc = 15; continue; }
case 15: { r[1] = r[15]; pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->usePlayerEndpoint:Z", r[0], false, r[1]); pc = 17; continue; }
case 17: { r[1] = r[16]; pc = 18; continue; }
case 18: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->friendlyName:Ljava/lang/String;", r[0], false, r[1]); pc = 19; continue; }
case 19: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/util/Locale;->getDefault()Ljava/util/Locale;", Value.NULL, new Value[]{}); pc = 20; continue; }
case 20: { r[1] = result; pc = 21; continue; }
case 21: { r[2] = Value.i32(6); pc = 22; continue; }
case 22: { r[2] = rt.newArray("[Ljava/lang/Object;", r[2].i()); pc = 23; continue; }
case 23: { r[3] = Value.i32(0); pc = 24; continue; }
case 24: { rt.arrayPut(r[2], r[3].i(), r[5]); pc = 25; continue; }
case 25: { r[3] = Value.i32(1); pc = 26; continue; }
case 26: { rt.arrayPut(r[2], r[3].i(), r[12]); pc = 27; continue; }
case 27: { r[3] = Value.i32(2); pc = 28; continue; }
case 28: { rt.arrayPut(r[2], r[3].i(), r[9]); pc = 29; continue; }
case 29: { r[3] = Value.i32(3); pc = 30; continue; }
case 30: { rt.arrayPut(r[2], r[3].i(), r[1]); pc = 31; continue; }
case 31: { r[1] = Value.i32(4); pc = 32; continue; }
case 32: { rt.arrayPut(r[2], r[1].i(), r[7]); pc = 33; continue; }
case 33: { r[1] = Value.i32(5); pc = 34; continue; }
case 34: { rt.arrayPut(r[2], r[1].i(), r[11]); pc = 35; continue; }
case 35: { r[1] = Value.ref("%s/%s (Linux; U; Android %s; %s; %s; Build/%s)"); pc = 36; continue; }
case 36: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;", Value.NULL, new Value[]{r[1], r[2]}); pc = 37; continue; }
case 37: { r[1] = result; pc = 38; continue; }
case 38: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->userAgent:Ljava/lang/String;", r[0], false, r[1]); pc = 39; continue; }
case 39: { r[1] = rt.allocate("Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;"); pc = 40; continue; }
case 40: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;-><init>(Lapp/revanced/extension/shared/spoof/ClientType;)V", r[1], new Value[]{r[0]}); pc = 41; continue; }
case 41: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V", Value.NULL, new Value[]{r[1]}); pc = 42; continue; }
case 42: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_459751c7641a42267267d4aa(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 14) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[15];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/spoof/ClientType;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "I");
r[4] = rt.check(arguments[3], "Ljava/lang/String;");
r[5] = rt.check(arguments[4], "Ljava/lang/String;");
r[6] = rt.check(arguments[5], "Ljava/lang/String;");
r[7] = rt.check(arguments[6], "Ljava/lang/String;");
r[8] = rt.check(arguments[7], "Ljava/lang/String;");
r[9] = rt.check(arguments[8], "Ljava/lang/String;");
r[10] = rt.check(arguments[9], "Ljava/lang/String;");
r[11] = rt.check(arguments[10], "Z");
r[12] = rt.check(arguments[11], "Z");
r[13] = rt.check(arguments[12], "Z");
r[14] = rt.check(arguments[13], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->id:I", r[0], false, r[3]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->clientName:Ljava/lang/String;", r[0], false, r[4]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->deviceMake:Ljava/lang/String;", r[0], false, r[5]); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->deviceModel:Ljava/lang/String;", r[0], false, r[6]); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->osName:Ljava/lang/String;", r[0], false, r[7]); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->osVersion:Ljava/lang/String;", r[0], false, r[8]); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->clientVersion:Ljava/lang/String;", r[0], false, r[9]); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->userAgent:Ljava/lang/String;", r[0], false, r[10]); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->useAuth:Z", r[0], false, r[11]); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->supportsMultiAudioTracks:Z", r[0], false, r[12]); pc = 11; continue; }
case 11: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->usePlayerEndpoint:Z", r[0], false, r[13]); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->friendlyName:Ljava/lang/String;", r[0], false, r[14]); pc = 13; continue; }
case 13: { r[1] = Value.i32(0); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->packageName:Ljava/lang/String;", r[0], false, r[1]); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->androidSdkVersion:Ljava/lang/String;", r[0], false, r[1]); pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType;->buildId:Ljava/lang/String;", r[0], false, r[1]); pc = 17; continue; }
case 17: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f23ebd6323178824208d93bf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(5); pc = 1; continue; }
case 1: { r[0] = rt.newArray("[Lapp/revanced/extension/shared/spoof/ClientType;", r[0].i()); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_REEL:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true); pc = 3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_VR_1_61_48:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true); pc = 6; continue; }
case 6: { r[2] = Value.i32(1); pc = 7; continue; }
case 7: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_VR_1_43_32:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true); pc = 9; continue; }
case 9: { r[2] = Value.i32(2); pc = 10; continue; }
case 10: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 11; continue; }
case 11: { r[1] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_CREATOR:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true); pc = 12; continue; }
case 12: { r[2] = Value.i32(3); pc = 13; continue; }
case 13: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 14; continue; }
case 14: { r[1] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->VISIONOS:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true); pc = 15; continue; }
case 15: { r[2] = Value.i32(4); pc = 16; continue; }
case 16: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 17; continue; }
case 17: { return rt.check(r[0], "[Lapp/revanced/extension/shared/spoof/ClientType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c81c8651d99d2fefab322813(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/shared/spoof/ClientType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType;->lambda$new$0()Ljava/lang/String;", r[0], new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_76885699c89917cda5540bbc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/spoof/ClientType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("userAgent: "); pc = 2; continue; }
case 2: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V", r[0], new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->userAgent:Ljava/lang/String;", r[2], false); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;", r[0], new Value[]{r[1]}); pc = 5; continue; }
case 5: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/spoof/ClientType;", "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;", r[0], new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
