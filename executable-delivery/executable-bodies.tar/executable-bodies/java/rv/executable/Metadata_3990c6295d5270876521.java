package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_3990c6295d5270876521 {
static ClassInfo info_3990c6295d5270876521() {return new ClassInfo("Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticLambda12;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "ToolbarPreferenceFragment$$ExternalSyntheticLambda12");}
}
