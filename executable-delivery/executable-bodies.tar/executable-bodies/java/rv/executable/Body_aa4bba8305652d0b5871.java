package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_aa4bba8305652d0b5871 {
static Value m_874833438afacfff7f19b24d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/LogBufferManager;->logBuffer:Ljava/util/Deque;", Value.NULL, true); pc = 2; continue; }
case 2: { result = rt.invoke("interface", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/util/Deque;->addLast(Ljava/lang/Object;)V", r[0], new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/LogBufferManager;->logBufferByteSize:Ljava/util/concurrent/atomic/AtomicInteger;", Value.NULL, true); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/lang/String;->length()I", r[1], new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I", r[0], new Value[]{r[1]}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { r[0] = Value.i32(900000); pc = 9; continue; }
case 9: { pc = (r[1].i() > r[0].i()) ? 15 : 10; continue; }
case 10: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/preference/LogBufferManager;->logBuffer:Ljava/util/Deque;", Value.NULL, true); pc = 11; continue; }
case 11: { result = rt.invoke("interface", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/util/Deque;->size()I", r[1], new Value[]{}); pc = 12; continue; }
case 12: { r[1] = result; pc = 13; continue; }
case 13: { r[0] = Value.i32(10000); pc = 14; continue; }
case 14: { pc = (r[1].i() <= r[0].i()) ? 20 : 15; continue; }
case 15: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/preference/LogBufferManager;->logBuffer:Ljava/util/Deque;", Value.NULL, true); pc = 16; continue; }
case 16: { result = rt.invoke("interface", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/util/Deque;->pollFirst()Ljava/lang/Object;", r[1], new Value[]{}); pc = 17; continue; }
case 17: { r[1] = result; pc = 18; continue; }
case 18: { r[1] = rt.cast(r[1], "Ljava/lang/String;"); pc = 19; continue; }
case 19: { pc = (!ExecutableRuntime.equal(r[1], Value.i32(0))) ? 21 : 20; continue; }
case 20: { return Value.VOID; }
case 21: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/LogBufferManager;->logBufferByteSize:Ljava/util/concurrent/atomic/AtomicInteger;", Value.NULL, true); pc = 22; continue; }
case 22: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/lang/String;->length()I", r[1], new Value[]{}); pc = 23; continue; }
case 23: { r[1] = result; pc = 24; continue; }
case 24: { r[1] = Value.i32(-(r[1].i())); pc = 25; continue; }
case 25: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I", r[0], new Value[]{r[1]}); pc = 26; continue; }
case 26: { r[1] = result; pc = 27; continue; }
case 27: { pc = 8; continue; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9363c35a6f21cff9591fbce8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/util/concurrent/ConcurrentLinkedDeque;"); pc = 1; continue; }
case 1: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/util/concurrent/ConcurrentLinkedDeque;-><init>()V", r[0], new Value[]{}); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/settings/preference/LogBufferManager;->logBuffer:Ljava/util/Deque;", Value.NULL, true, r[0]); pc = 3; continue; }
case 3: { r[0] = rt.allocate("Ljava/util/concurrent/atomic/AtomicInteger;"); pc = 4; continue; }
case 4: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/preference/LogBufferManager;", "Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V", r[0], new Value[]{}); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/settings/preference/LogBufferManager;->logBufferByteSize:Ljava/util/concurrent/atomic/AtomicInteger;", Value.NULL, true, r[0]); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
