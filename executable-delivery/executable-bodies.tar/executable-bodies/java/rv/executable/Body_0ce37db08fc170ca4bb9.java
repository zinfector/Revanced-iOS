package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_0ce37db08fc170ca4bb9 {
static Value m_59f8e3585f92ca36dc31752d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda2;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda2;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_dd9623fdb97f3bdb5a35ce67(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda2;");
r[1] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[1] = rt.cast(r[1],"Landroid/view/View;"); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda2;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->$r8$lambda$VZPCP1ViIP4CXpCVJ1ok8KkAHrI(Landroid/view/View;)Z",Value.NULL,new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { return rt.check(r[1],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
