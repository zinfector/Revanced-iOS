package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_159132c79c75bf69 extends RuntimeForeign.SourceProxy {
Source_159132c79c75bf69(RuntimeForeign owner,Instance source){super(owner,source);}

}
