package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_6f15001b8d1fb4bd6160 {
static Value m_6cbd9a6be9c24ea8758d9fdd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;->f$0:Ljava/lang/String;",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3ba00e770feb65d54b294842(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;->f$0:Ljava/lang/String;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->$r8$lambda$_IAZLxfnVyfkx4Ec7TlYc3uUA7o(Ljava/lang/String;)V",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
