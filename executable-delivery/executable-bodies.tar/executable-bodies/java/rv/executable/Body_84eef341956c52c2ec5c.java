package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_84eef341956c52c2ec5c {
static Value m_92feb7b35f5a447212eab0c7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new VerifyError("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(arguments[0], "Landroid/content/pm/PackageManager;");
r[1] = rt.check(arguments[1], "Ljava/lang/String;");
r[2] = rt.check(arguments[2], "Landroid/content/pm/PackageManager$PackageInfoFlags;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticApiModelOutline1;", "Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;Landroid/content/pm/PackageManager$PackageInfoFlags;)Landroid/content/pm/PackageInfo;", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0], "Landroid/content/pm/PackageInfo;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
