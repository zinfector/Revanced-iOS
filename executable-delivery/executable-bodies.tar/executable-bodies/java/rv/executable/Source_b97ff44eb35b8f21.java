package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_b97ff44eb35b8f21 extends RuntimeForeign.SourceProxy {
Source_b97ff44eb35b8f21(RuntimeForeign owner,Instance source){super(owner,source);}

}
