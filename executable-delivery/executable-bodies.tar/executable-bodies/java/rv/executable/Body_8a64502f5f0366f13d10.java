package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_8a64502f5f0366f13d10 {
static Value m_0314e00b5ca8d2c7db3205b1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/StringRef;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/shared/StringRef;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b0f5a9fa7bca942d56fcb798(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/util/HashMap;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Ljava/util/HashMap;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/StringRef;","Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/StringRef;->strings:Ljava/util/Map;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = Value.ref(""); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef;->constant(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[0]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/StringRef;->empty:Lapp/revanced/extension/shared/StringRef;",Value.NULL,true,r[0]); pc = 9; continue; }
case 9: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_865194adfb88bcd5ae72fe34(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/StringRef;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/StringRef;->value:Ljava/lang/String;",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b1847bd0af87c4c89d01db5a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/StringRef;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = Value.i32(1); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/StringRef;->resolved:Z",r[0],false,r[1]); pc = 4; continue; }
case 4: { return rt.check(r[0],"Lapp/revanced/extension/shared/StringRef;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_91c015ef4b1c0fa1c9fd1aa6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[4] = rt.check(receiver, "Lapp/revanced/extension/shared/StringRef;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/StringRef;->resolved:Z",r[4],false); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?36:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/shared/StringRef;->resources:Landroid/content/res/Resources;",Value.NULL,true); pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?6:4; continue; }
case 4: { r[0] = rt.readField("Lapp/revanced/extension/shared/StringRef;->packageName:Ljava/lang/String;",Value.NULL,true); pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?14:6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/StringRef;","Landroid/content/Context;->getResources()Landroid/content/res/Resources;",r[0],new Value[]{}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/shared/StringRef;->resources:Landroid/content/res/Resources;",Value.NULL,true,r[1]); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/StringRef;","Landroid/content/Context;->getPackageName()Ljava/lang/String;",r[0],new Value[]{}); pc = 12; continue; }
case 12: { r[0] = result; pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/shared/StringRef;->packageName:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 14; continue; }
case 14: { r[0] = Value.i32(1); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/shared/StringRef;->resolved:Z",r[4],false,r[0]); pc = 16; continue; }
case 16: { r[0] = rt.readField("Lapp/revanced/extension/shared/StringRef;->resources:Landroid/content/res/Resources;",Value.NULL,true); pc = 17; continue; }
case 17: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?33:18; continue; }
case 18: { r[1] = rt.readField("Lapp/revanced/extension/shared/StringRef;->value:Ljava/lang/String;",r[4],false); pc = 19; continue; }
case 19: { r[2] = Value.ref("string"); pc = 20; continue; }
case 20: { r[3] = rt.readField("Lapp/revanced/extension/shared/StringRef;->packageName:Ljava/lang/String;",Value.NULL,true); pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/StringRef;","Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I",r[0],new Value[]{r[1], r[2], r[3]}); pc = 22; continue; }
case 22: { r[0] = result; pc = 23; continue; }
case 23: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?28:24; continue; }
case 24: { r[0] = rt.allocate("Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda0;"); pc = 25; continue; }
case 25: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda0;-><init>(Lapp/revanced/extension/shared/StringRef;)V",r[0],new Value[]{r[4]}); pc = 26; continue; }
case 26: { result=rt.invoke("static","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 27; continue; }
case 27: { pc=36; continue; }
case 28: { r[1] = rt.readField("Lapp/revanced/extension/shared/StringRef;->resources:Landroid/content/res/Resources;",Value.NULL,true); pc = 29; continue; }
case 29: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/StringRef;","Landroid/content/res/Resources;->getString(I)Ljava/lang/String;",r[1],new Value[]{r[0]}); pc = 30; continue; }
case 30: { r[0] = result; pc = 31; continue; }
case 31: { rt.writeField("Lapp/revanced/extension/shared/StringRef;->value:Ljava/lang/String;",r[4],false,r[0]); pc = 32; continue; }
case 32: { pc=36; continue; }
case 33: { r[0] = rt.allocate("Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda1;"); pc = 34; continue; }
case 34: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda1;-><init>()V",r[0],new Value[]{}); pc = 35; continue; }
case 35: { result=rt.invoke("static","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 36; continue; }
case 36: { r[0] = rt.readField("Lapp/revanced/extension/shared/StringRef;->value:Ljava/lang/String;",r[4],false); pc = 37; continue; }
case 37: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_66b62221303e905aa8502f13(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/shared/StringRef;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef;->lambda$toString$0()Ljava/lang/String;",r[0],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2bc1f0774a35eff4cea7d8cc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Could not resolve resources!"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9bc748c27ced789a94fed7aa(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef;->sfc(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[0]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6c68f19ad9024b92261ec34a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/StringRef;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Resource not found: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/shared/StringRef;->value:Ljava/lang/String;",r[2],false); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/StringRef;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/StringRef;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_58d39b751c25c7e863643912(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/StringRef;->strings:Ljava/util/Map;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("interface","Lapp/revanced/extension/shared/StringRef;","Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;",r[0],new Value[]{r[2]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/shared/StringRef;"); pc = 4; continue; }
case 4: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?8:5; continue; }
case 5: { r[1] = rt.allocate("Lapp/revanced/extension/shared/StringRef;"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 7; continue; }
case 7: { result=rt.invoke("interface","Lapp/revanced/extension/shared/StringRef;","Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",r[0],new Value[]{r[2], r[1]}); pc = 8; continue; }
case 8: { return rt.check(r[1],"Lapp/revanced/extension/shared/StringRef;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0a5a719e6cc20d9610350091(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Ljava/lang/String;");
r[1] = rt.check(arguments[1], "[Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/StringRef;","Lapp/revanced/extension/shared/StringRef;->str(Ljava/lang/String;)Ljava/lang/String;",Value.NULL,new Value[]{r[0]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/StringRef;","Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
