package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_896de86b41e1bdaf6e65 {
static ClassInfo info_896de86b41e1bdaf6e65() {return new ClassInfo("Lcom/android/tools/r8/RecordTag;", "Ljava/lang/Object;", new String[]{}, 5121, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633)}, "RecordTag");}
}
