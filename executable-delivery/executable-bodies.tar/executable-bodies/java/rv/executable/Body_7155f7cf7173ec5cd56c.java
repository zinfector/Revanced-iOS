package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_7155f7cf7173ec5cd56c {
static Value m_17f5c550a2e24ebb05503307(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;->f$0:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_95d40b2f597ebfaf8a240a23(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;->f$0:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->$r8$lambda$ouqswKKKpNktBetk7T1KlrS5_2E(Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;)V",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
