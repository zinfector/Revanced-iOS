package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_3816cd254757e540cc55 {
static ClassInfo info_3816cd254757e540cc55() {return new ClassInfo("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion$$ExternalSyntheticLambda0;->f$0:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;", "Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "PlayerControlsVisibility$Companion$$ExternalSyntheticLambda0");}
}
