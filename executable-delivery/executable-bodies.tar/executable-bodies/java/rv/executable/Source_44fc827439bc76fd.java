package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_44fc827439bc76fd extends RuntimeForeign.SourceProxy {
Source_44fc827439bc76fd(RuntimeForeign owner,Instance source){super(owner,source);}

}
