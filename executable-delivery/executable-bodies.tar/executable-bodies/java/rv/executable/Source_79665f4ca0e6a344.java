package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_79665f4ca0e6a344 extends RuntimeForeign.SourceProxy {
Source_79665f4ca0e6a344(RuntimeForeign owner,Instance source){super(owner,source);}

}
