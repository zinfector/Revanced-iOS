package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_94f5dd01c854d73d0df5 {
static ClassInfo info_94f5dd01c854d73d0df5() {return new ClassInfo("Lkotlin/collections/CollectionsKt__CollectionsKt;", "Lkotlin/collections/CollectionsKt__CollectionsJVMKt;", new String[]{}, 1025, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("emptyList()Ljava/util/List;", 25), new MethodInfo("listOf([Ljava/lang/Object;)Ljava/util/List;", 137), new MethodInfo("throwIndexOverflow()V", 9)}, "CollectionsKt__CollectionsKt");}
}
