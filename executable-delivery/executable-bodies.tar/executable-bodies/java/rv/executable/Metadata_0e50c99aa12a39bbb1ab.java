package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_0e50c99aa12a39bbb1ab {
static ClassInfo info_0e50c99aa12a39bbb1ab() {return new ClassInfo("Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "ShortsPlayerState$Companion$$ExternalSyntheticLambda0");}
}
