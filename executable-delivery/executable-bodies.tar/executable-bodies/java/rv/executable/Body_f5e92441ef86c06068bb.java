package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_f5e92441ef86c06068bb {
static Value m_18d44577ccb8daf976ad893f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/litho/PlayerFlyoutMenuItemsFilter$HideAudioFlyoutMenuAvailability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/litho/PlayerFlyoutMenuItemsFilter$HideAudioFlyoutMenuAvailability;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
