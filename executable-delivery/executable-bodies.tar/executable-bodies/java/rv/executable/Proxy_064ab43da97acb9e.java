package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_064ab43da97acb9e extends RuntimeForeign.SourceProxy implements java.util.RandomAccess {
Proxy_064ab43da97acb9e(RuntimeForeign owner,Instance source){super(owner,source);}

}
