package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_777a0a0383a7f2c056d3 {
static Value m_fb86535b43d8d243659732d3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/search/YouTubeSearchResultsAdapter;");
r[1] = rt.check(arguments[0], "Landroid/content/Context;");
r[2] = rt.check(arguments[1], "Ljava/util/List;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;");
r[4] = rt.check(arguments[3], "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchResultsAdapter;","Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;-><init>(Landroid/content/Context;Ljava/util/List;Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;)V",r[0],new Value[]{r[1], r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
