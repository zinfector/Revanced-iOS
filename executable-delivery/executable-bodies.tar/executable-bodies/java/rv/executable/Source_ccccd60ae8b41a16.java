package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_ccccd60ae8b41a16 extends RuntimeForeign.SourceProxy {
Source_ccccd60ae8b41a16(RuntimeForeign owner,Instance source){super(owner,source);}

}
