package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_98d044ae4a6ff70e528e {
static Value m_0c30b1b0cfbf8981ce5a6a12(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Ljava/lang/Object;");
r[1] = rt.check(arguments[1], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc = (!ExecutableRuntime.equal(r[0], Value.i32(0))) ? 6 : 1; continue; }
case 1: { pc = (!ExecutableRuntime.equal(r[1], Value.i32(0))) ? 4 : 2; continue; }
case 2: { r[0] = Value.i32(1); pc = 3; continue; }
case 3: { return rt.check(r[0], "Z"); }
case 4: { r[0] = Value.i32(0); pc = 5; continue; }
case 5: { return rt.check(r[0], "Z"); }
case 6: { result = rt.invoke("virtual", "Lkotlin/jvm/internal/Intrinsics;", "Ljava/lang/Object;->equals(Ljava/lang/Object;)Z", r[0], new Value[]{r[1]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0], "Z"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
