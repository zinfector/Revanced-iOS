package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8f0c59d98f03fe0efa93 {
static ClassInfo info_8f0c59d98f03fe0efa93() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;->f$0:J", "J", 4113, ExecutableRuntime.zero("J"))}, new MethodInfo[]{new MethodInfo("<init>(J)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "VideoInformation$$ExternalSyntheticLambda21");}
}
