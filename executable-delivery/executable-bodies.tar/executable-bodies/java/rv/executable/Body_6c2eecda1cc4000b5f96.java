package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_6c2eecda1cc4000b5f96 {
static Value m_c6dd8d5fc98086b9498bc141(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda0;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[2] = rt.check(arguments[1], "Landroid/view/View$OnClickListener;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda0;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda0;->f$0:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",r[0],false,r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda0;->f$1:Landroid/view/View$OnClickListener;",r[0],false,r[2]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
