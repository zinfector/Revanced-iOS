package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_a75eb7ff037a4fb98e60 {
static Value m_e0ac5b6a64f9b95d0882837c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractList$Companion;");
r[1] = rt.check(arguments[0], "Lkotlin/jvm/internal/DefaultConstructorMarker;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lkotlin/collections/AbstractList$Companion;", "Lkotlin/collections/AbstractList$Companion;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b13895dab051abb051bb6f68(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractList$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lkotlin/collections/AbstractList$Companion;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_acbde2707524379d861f769c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new VerifyError("Parameter arity");
Value[] r = new Value[6];
r[3] = rt.check(receiver, "Lkotlin/collections/AbstractList$Companion;");
r[4] = rt.check(arguments[0], "Ljava/util/Collection;");
r[5] = rt.check(arguments[1], "Ljava/util/Collection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lkotlin/collections/AbstractList$Companion;", "Ljava/lang/Object;->getClass()Ljava/lang/Class;", r[4], new Value[]{}); pc = 1; continue; }
case 1: { result = rt.invoke("virtual", "Lkotlin/collections/AbstractList$Companion;", "Ljava/lang/Object;->getClass()Ljava/lang/Class;", r[5], new Value[]{}); pc = 2; continue; }
case 2: { result = rt.invoke("interface", "Lkotlin/collections/AbstractList$Companion;", "Ljava/util/Collection;->size()I", r[4], new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { result = rt.invoke("interface", "Lkotlin/collections/AbstractList$Companion;", "Ljava/util/Collection;->size()I", r[5], new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { r[2] = Value.i32(0); pc = 7; continue; }
case 7: { pc = (ExecutableRuntime.equal(r[0], r[1])) ? 9 : 8; continue; }
case 8: { return rt.check(r[2], "Z"); }
case 9: { result = rt.invoke("interface", "Lkotlin/collections/AbstractList$Companion;", "Ljava/util/Collection;->iterator()Ljava/util/Iterator;", r[5], new Value[]{}); pc = 10; continue; }
case 10: { r[5] = result; pc = 11; continue; }
case 11: { result = rt.invoke("interface", "Lkotlin/collections/AbstractList$Companion;", "Ljava/util/Collection;->iterator()Ljava/util/Iterator;", r[4], new Value[]{}); pc = 12; continue; }
case 12: { r[4] = result; pc = 13; continue; }
case 13: { result = rt.invoke("interface", "Lkotlin/collections/AbstractList$Companion;", "Ljava/util/Iterator;->hasNext()Z", r[4], new Value[]{}); pc = 14; continue; }
case 14: { r[0] = result; pc = 15; continue; }
case 15: { pc = (ExecutableRuntime.equal(r[0], Value.i32(0))) ? 24 : 16; continue; }
case 16: { result = rt.invoke("interface", "Lkotlin/collections/AbstractList$Companion;", "Ljava/util/Iterator;->next()Ljava/lang/Object;", r[4], new Value[]{}); pc = 17; continue; }
case 17: { r[0] = result; pc = 18; continue; }
case 18: { result = rt.invoke("interface", "Lkotlin/collections/AbstractList$Companion;", "Ljava/util/Iterator;->next()Ljava/lang/Object;", r[5], new Value[]{}); pc = 19; continue; }
case 19: { r[1] = result; pc = 20; continue; }
case 20: { result = rt.invoke("static", "Lkotlin/collections/AbstractList$Companion;", "Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z", Value.NULL, new Value[]{r[0], r[1]}); pc = 21; continue; }
case 21: { r[0] = result; pc = 22; continue; }
case 22: { pc = (!ExecutableRuntime.equal(r[0], Value.i32(0))) ? 13 : 23; continue; }
case 23: { return rt.check(r[2], "Z"); }
case 24: { r[4] = Value.i32(1); pc = 25; continue; }
case 25: { return rt.check(r[4], "Z"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d2e0d385327233bbdccb6817(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new VerifyError("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(receiver, "Lkotlin/collections/AbstractList$Companion;");
r[3] = rt.check(arguments[0], "I");
r[4] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc = (r[3].i() < 0) ? 3 : 1; continue; }
case 1: { pc = (r[3].i() >= r[4].i()) ? 3 : 2; continue; }
case 2: { return Value.VOID; }
case 3: { r[0] = Value.ref("index: "); pc = 4; continue; }
case 4: { r[1] = Value.ref(", size: "); pc = 5; continue; }
case 5: { result = rt.invoke("static", "Lkotlin/collections/AbstractList$Companion;", "Lkotlin/collections/EmptyList$$ExternalSyntheticBUOutline0;->m(Ljava/lang/String;ILjava/lang/Object;I)V", Value.NULL, new Value[]{r[0], r[3], r[1], r[4]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
