package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_87d368802e6a5f676589 {
static ClassInfo info_87d368802e6a5f676589() {return new ClassInfo("Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda0;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "VideoState$Companion$$ExternalSyntheticLambda0");}
}
