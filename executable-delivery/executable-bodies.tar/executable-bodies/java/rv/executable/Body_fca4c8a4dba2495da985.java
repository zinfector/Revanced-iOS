package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_fca4c8a4dba2495da985 {
static Value m_fdafebe32b03af72e365be61(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda0;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda0;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_906a3f2f5e34e62a3b7d062a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda0;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda0;", "Lapp/revanced/extension/youtube/settings/Settings;->$r8$lambda$_RhLRoQPlSzC3ZzUsO5MKuJhIV0()Ljava/lang/String;", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
