package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_6983dfe60f90e8467f0f {
static ClassInfo info_6983dfe60f90e8467f0f() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch$1;", "Ljava/lang/Object;", new String[]{"Landroid/view/View$OnAttachStateChangeListener;"}, 0, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("onViewAttachedToWindow(Landroid/view/View;)V", 1), new MethodInfo("onViewDetachedFromWindow(Landroid/view/View;)V", 1)}, "");}
}
