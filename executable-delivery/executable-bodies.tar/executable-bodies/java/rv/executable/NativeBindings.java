package rv.executable;

import java.lang.ref.WeakReference;
import java.util.*;
import rv.executable.ExecutableRuntime.*;

/** Current-runtime native boundary. References are projections, never integer handles. */
public abstract class NativeBindings {
    protected final PlatformServices services;
    private final String process=UUID.randomUUID().toString();
    private final Map<List<String>,Ref> slots=new HashMap<>();
    private long generation;
    protected NativeBindings(PlatformServices services){this.services=Objects.requireNonNull(services);}

    public static final class Ref {
        public final String sourceType,role,surface,item,slot,process;
        public final long generation;
        private final WeakReference<Object> owner;
        private final Ref parent;
        private final NativeBindings registry;
        private Ref(NativeBindings registry,String type,String role,String surface,String item,String slot,Object owner,long generation){
            this(registry,type,role,surface,item,slot,owner,generation,null);
        }
        private Ref(NativeBindings registry,String type,String role,String surface,String item,String slot,Object owner,long generation,Ref parent){
            this.registry=registry;sourceType=type;this.role=role;this.surface=surface;this.item=item;this.slot=slot;
            process=registry.process;this.generation=generation;this.owner=new WeakReference<>(owner);this.parent=parent;
        }
    }
    public abstract boolean handles(String descriptor);
    public abstract boolean staticCall(String descriptor);
    protected abstract Value invoke(String descriptor,Value receiver,Value[] args)throws Throwable;
    /** Hold the registry lock through synchronous effects so another thread
     * cannot retire/rebind the slot between the check and the native call. */
    public final synchronized Value call(String descriptor,Value receiver,Value[] args)throws Throwable{return invoke(descriptor,receiver,args);}
    protected abstract boolean accepts(String type,String role,String surface,String slot);

    /** Only an established interception/acquisition adapter may supply this object.
     * Rebinding a slot retires the previous item; parallel slots remain distinct. */
    public synchronized Value bind(String type,String role,String surface,String item,String slot,Object owner){
        Objects.requireNonNull(owner);Objects.requireNonNull(item);
        if(item.isEmpty() || !accepts(type,role,surface,slot))throw new MissingOperation("native-acquisition-contract:"+type);
        List<String> key=Arrays.asList(role,surface,slot);Ref previous=slots.get(key);
        if(previous!=null && previous.owner.get()==owner && previous.sourceType.equals(type) && previous.item.equals(item))return Value.ref(previous);
        Ref current=new Ref(this,type,role,surface,item,slot,owner,nextGeneration());slots.put(key,current);return Value.ref(current);
    }
    private long nextGeneration(){generation=Math.incrementExact(generation);return generation;}
    private boolean live(Ref ref,int depth){
        return depth<64 && ref.registry==this && process.equals(ref.process) && ref.owner.get()!=null
            && slots.get(Arrays.asList(ref.role,ref.surface,ref.slot))==ref
            && (ref.parent==null || ref.item.equals(ref.parent.item) && live(ref.parent,depth+1));
    }
    /** Project only a proved child/selection path. The child inherits the
     * parent's item epoch; a live child cannot outlast a retired/rebound parent. */
    public synchronized Value project(Value parentValue,String type,String role,String surface,String slot,Object child){
        Objects.requireNonNull(child);
        if(!(parentValue.o() instanceof Ref))throw new MissingOperation("native-projection-parent-required");
        Ref parent=(Ref)parentValue.o();
        if(!live(parent,0) || !accepts(type,role,surface,slot))throw new MissingOperation("native-projection-contract:"+type);
        List<String> key=Arrays.asList(role,surface,slot);
        for(Ref ancestor=parent;ancestor!=null;ancestor=ancestor.parent)
            if(key.equals(Arrays.asList(ancestor.role,ancestor.surface,ancestor.slot)))throw new MissingOperation("native-projection-slot-collision");
        Ref previous=slots.get(key);
        if(previous!=null && previous.parent==parent && previous.owner.get()==child && previous.sourceType.equals(type))return Value.ref(previous);
        Ref current=new Ref(this,type,role,surface,parent.item,slot,child,nextGeneration(),parent);slots.put(key,current);return Value.ref(current);
    }
    public synchronized void retire(String role,String surface,String slot){slots.remove(Arrays.asList(role,surface,slot));}
    public synchronized void retireAll(){slots.clear();}
    public synchronized Object owner(Value value,String type,String role,String surface,String slot,String queue){
        if(queue.equals("main") && !services.isMainThread())throw new MissingOperation("native-wrong-queue:"+role);
        if(!(value.o() instanceof Ref))throw new MissingOperation("native-reference-required:"+type);
        Ref ref=(Ref)value.o();Object object=ref.owner.get();
        if(!live(ref,0) || object==null)
            throw new MissingOperation("native-stale-reference:"+role);
        if(!ref.sourceType.equals(type) || !ref.role.equals(role) || !ref.surface.equals(surface) || !ref.slot.equals(slot))
            throw new MissingOperation("native-owner-role-mismatch:"+role);
        return object;
    }
    @FunctionalInterface public interface Callback {
        Value invoke(Value[] captures,Value[] arguments)throws Throwable;
    }
    public final class Lease {
        private final Ref ref;
        private final String queue;
        private final boolean once,discardCancelled;
        private final Value[] captures;
        private final Callback callback;
        private boolean cancelled,delivered;
        private Lease(Ref ref,String queue,boolean once,boolean discardCancelled,Value[] captures,Callback callback){
            this.ref=ref;this.queue=queue;this.once=once;this.discardCancelled=discardCancelled;
            this.captures=captures.clone();this.callback=Objects.requireNonNull(callback);
        }
        public void cancel(){synchronized(NativeBindings.this){cancelled=true;}}
        /** Retain the registry lock through effects, including reentrant source
         * execution. Cancellation or rebinding cannot race this delivery. */
        public Value invoke(Value[] arguments)throws Throwable {synchronized(NativeBindings.this){
            if(cancelled || !live(ref,0)){
                if(discardCancelled)return Value.VOID;
                throw new MissingOperation("native-callback-retired");
            }
            if(queue.equals("main") && !services.isMainThread())throw new MissingOperation("native-callback-wrong-queue");
            if(once && delivered)throw new MissingOperation("native-callback-multiplicity");
            delivered=true;return callback.invoke(captures.clone(),arguments.clone());
        }}
    }
    /** This mechanism does not infer queue, multiplicity or cancellation. A
     * generated adapter may use it only after those source relations are admitted. */
    public synchronized Lease capture(Value value,String queue,boolean once,boolean discardCancelled,Value[] captures,Callback callback){
        if(!(value.o() instanceof Ref) || !live((Ref)value.o(),0))throw new MissingOperation("native-callback-owner-required");
        if(!queue.equals("main") && !queue.equals("caller"))throw new MissingOperation("native-callback-queue-contract");
        return new Lease((Ref)value.o(),queue,once,discardCancelled,captures,callback);
    }
}
