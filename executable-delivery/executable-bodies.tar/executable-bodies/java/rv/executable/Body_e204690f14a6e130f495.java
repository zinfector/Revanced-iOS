package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_e204690f14a6e130f495 {
static Value m_f4d78743aa09196e1c528fda(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new VerifyError("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(arguments[0], "Ljava/lang/Appendable;");
r[1] = rt.check(arguments[1], "Ljava/lang/Object;");
r[2] = rt.check(arguments[2], "Lkotlin/jvm/functions/Function1;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lkotlin/text/StringsKt__AppendableKt;", "Ljava/lang/Object;->getClass()Ljava/lang/Class;", r[0], new Value[]{}); pc = 1; continue; }
case 1: { pc = (ExecutableRuntime.equal(r[2], Value.i32(0))) ? 7 : 2; continue; }
case 2: { result = rt.invoke("interface", "Lkotlin/text/StringsKt__AppendableKt;", "Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;", r[2], new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { r[1] = rt.cast(r[1], "Ljava/lang/CharSequence;"); pc = 5; continue; }
case 5: { result = rt.invoke("interface", "Lkotlin/text/StringsKt__AppendableKt;", "Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;", r[0], new Value[]{r[1]}); pc = 6; continue; }
case 6: { return Value.VOID; }
case 7: { pc = (!ExecutableRuntime.equal(r[1], Value.i32(0))) ? 10 : 8; continue; }
case 8: { r[2] = Value.i32(1); pc = 9; continue; }
case 9: { pc = 11; continue; }
case 10: { r[2] = Value.i32(rt.isInstance(r[1].o(), "Ljava/lang/CharSequence;") ? 1 : 0); pc = 11; continue; }
case 11: { pc = (ExecutableRuntime.equal(r[2], Value.i32(0))) ? 15 : 12; continue; }
case 12: { r[1] = rt.cast(r[1], "Ljava/lang/CharSequence;"); pc = 13; continue; }
case 13: { result = rt.invoke("interface", "Lkotlin/text/StringsKt__AppendableKt;", "Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;", r[0], new Value[]{r[1]}); pc = 14; continue; }
case 14: { return Value.VOID; }
case 15: { r[2] = Value.i32(rt.isInstance(r[1].o(), "Ljava/lang/Character;") ? 1 : 0); pc = 16; continue; }
case 16: { pc = (ExecutableRuntime.equal(r[2], Value.i32(0))) ? 22 : 17; continue; }
case 17: { r[1] = rt.cast(r[1], "Ljava/lang/Character;"); pc = 18; continue; }
case 18: { result = rt.invoke("virtual", "Lkotlin/text/StringsKt__AppendableKt;", "Ljava/lang/Character;->charValue()C", r[1], new Value[]{}); pc = 19; continue; }
case 19: { r[1] = result; pc = 20; continue; }
case 20: { result = rt.invoke("interface", "Lkotlin/text/StringsKt__AppendableKt;", "Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;", r[0], new Value[]{r[1]}); pc = 21; continue; }
case 21: { return Value.VOID; }
case 22: { result = rt.invoke("virtual", "Lkotlin/text/StringsKt__AppendableKt;", "Ljava/lang/Object;->toString()Ljava/lang/String;", r[1], new Value[]{}); pc = 23; continue; }
case 23: { r[1] = result; pc = 24; continue; }
case 24: { result = rt.invoke("interface", "Lkotlin/text/StringsKt__AppendableKt;", "Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;", r[0], new Value[]{r[1]}); pc = 25; continue; }
case 25: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
