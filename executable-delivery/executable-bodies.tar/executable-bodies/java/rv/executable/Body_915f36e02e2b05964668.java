package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_915f36e02e2b05964668 {
static Value m_e66704f48c718b724d8ad10b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[10];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1; continue; }
case 1: { r[1] = rt.readField("Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = Value.ref("revanced_debug"); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[1]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->DEBUG:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 5; continue; }
case 5: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 6; continue; }
case 6: { r[3] = Value.ref("revanced_debug_stacktrace"); pc = 7; continue; }
case 7: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 8; continue; }
case 8: { r[4] = result; pc = 9; continue; }
case 9: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[2], new Value[]{r[3], r[1], r[4]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->DEBUG_STACKTRACE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[2]); pc = 11; continue; }
case 11: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 12; continue; }
case 12: { r[3] = rt.readField("Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;", Value.NULL, true); pc = 13; continue; }
case 13: { r[4] = Value.ref("revanced_debug_toast_on_error_user_dialog_message"); pc = 14; continue; }
case 14: { r[5] = Value.ref("revanced_debug_toast_on_error"); pc = 15; continue; }
case 15: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V", r[2], new Value[]{r[5], r[3], r[4]}); pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->DEBUG_TOAST_ON_ERROR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[2]); pc = 17; continue; }
case 17: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 18; continue; }
case 18: { r[4] = Value.i32(0); pc = 19; continue; }
case 19: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[4]}); pc = 20; continue; }
case 20: { r[5] = result; pc = 21; continue; }
case 21: { r[6] = Value.ref("revanced_check_environment_warnings_issued"); pc = 22; continue; }
case 22: { r[7] = Value.i32(1); pc = 23; continue; }
case 23: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;ZZ)V", r[2], new Value[]{r[6], r[5], r[7], r[4]}); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->CHECK_ENVIRONMENT_WARNINGS_ISSUED:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[2]); pc = 25; continue; }
case 25: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 26; continue; }
case 26: { r[5] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->DEFAULT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 27; continue; }
case 27: { r[6] = Value.ref("revanced_language_user_dialog_message"); pc = 28; continue; }
case 28: { r[8] = Value.ref("revanced_language"); pc = 29; continue; }
case 29: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;ZLjava/lang/String;)V", r[2], new Value[]{r[8], r[5], r[7], r[6]}); pc = 30; continue; }
case 30: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->REVANCED_LANGUAGE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[2]); pc = 31; continue; }
case 31: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 32; continue; }
case 32: { r[5] = Value.ref("revanced_show_menu_icons"); pc = 33; continue; }
case 33: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[2], new Value[]{r[5], r[3], r[7]}); pc = 34; continue; }
case 34: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->SHOW_MENU_ICONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[2]); pc = 35; continue; }
case 35: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 36; continue; }
case 36: { r[5] = Value.ref("revanced_settings_disable_bold_icons"); pc = 37; continue; }
case 37: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[2], new Value[]{r[5], r[1], r[7]}); pc = 38; continue; }
case 38: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->SETTINGS_DISABLE_BOLD_ICONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[2]); pc = 39; continue; }
case 39: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 40; continue; }
case 40: { r[5] = Value.ref("revanced_settings_search_history"); pc = 41; continue; }
case 41: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[2], new Value[]{r[5], r[3], r[7]}); pc = 42; continue; }
case 42: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->SETTINGS_SEARCH_HISTORY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[2]); pc = 43; continue; }
case 43: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 44; continue; }
case 44: { r[5] = Value.ref("revanced_settings_search_entries"); pc = 45; continue; }
case 45: { r[6] = Value.ref(""); pc = 46; continue; }
case 46: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[2], new Value[]{r[5], r[6]}); pc = 47; continue; }
case 47: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->SETTINGS_SEARCH_ENTRIES:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[2]); pc = 48; continue; }
case 48: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/LongSetting;"); pc = 49; continue; }
case 49: { r[8] = Value.i64(-1L); r[9] = r[8]; pc = 50; continue; }
case 50: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;", Value.NULL, new Value[]{r[8]}); pc = 51; continue; }
case 51: { r[5] = result; pc = 52; continue; }
case 52: { r[8] = Value.ref("revanced_last_time_app_was_launched"); pc = 53; continue; }
case 53: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/LongSetting;-><init>(Ljava/lang/String;Ljava/lang/Long;ZZ)V", r[2], new Value[]{r[8], r[5], r[4], r[4]}); pc = 54; continue; }
case 54: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->FIRST_TIME_APP_LAUNCHED:Lapp/revanced/extension/shared/settings/LongSetting;", Value.NULL, true, r[2]); pc = 55; continue; }
case 55: { r[5] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 56; continue; }
case 56: { r[8] = Value.ref("revanced_gms_core_check_updates"); pc = 57; continue; }
case 57: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[5], new Value[]{r[8], r[3], r[7]}); pc = 58; continue; }
case 58: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->GMS_CORE_CHECK_UPDATES:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[5]); pc = 59; continue; }
case 59: { r[5] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 60; continue; }
case 60: { r[8] = Value.ref("revanced_spoof_video_streams"); pc = 61; continue; }
case 61: { r[9] = Value.ref("revanced_spoof_video_streams_user_dialog_message"); pc = 62; continue; }
case 62: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLjava/lang/String;)V", r[5], new Value[]{r[8], r[3], r[7], r[9]}); pc = 63; continue; }
case 63: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->SPOOF_VIDEO_STREAMS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[5]); pc = 64; continue; }
case 64: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 65; continue; }
case 65: { r[9] = Value.ref("revanced_spoof_video_streams_stats_for_nerds"); pc = 66; continue; }
case 66: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[5]}); pc = 67; continue; }
case 67: { r[5] = result; pc = 68; continue; }
case 68: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[9], r[3], r[5]}); pc = 69; continue; }
case 69: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->SPOOF_STREAMING_DATA_STATS_FOR_NERDS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[8]); pc = 70; continue; }
case 70: { r[5] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 71; continue; }
case 71: { r[8] = Value.ref("revanced_sanitize_sharing_links"); pc = 72; continue; }
case 72: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[5], new Value[]{r[8], r[3]}); pc = 73; continue; }
case 73: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->SANITIZE_SHARING_LINKS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[5]); pc = 74; continue; }
case 74: { r[5] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 75; continue; }
case 75: { r[8] = Value.ref("revanced_replace_music_with_youtube"); pc = 76; continue; }
case 76: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[5], new Value[]{r[8], r[1]}); pc = 77; continue; }
case 77: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->REPLACE_MUSIC_LINKS_WITH_YOUTUBE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[5]); pc = 78; continue; }
case 78: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 79; continue; }
case 79: { r[5] = Value.ref("revanced_check_watch_history_domain_name"); pc = 80; continue; }
case 80: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZZ)V", r[1], new Value[]{r[5], r[3], r[4], r[4]}); pc = 81; continue; }
case 81: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->CHECK_WATCH_HISTORY_DOMAIN_NAME:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[1]); pc = 82; continue; }
case 82: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 83; continue; }
case 83: { r[3] = Value.ref("revanced_custom_branding_icon"); pc = 84; continue; }
case 84: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch;->getDefaultIconStyle()Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, new Value[]{}); pc = 85; continue; }
case 85: { r[4] = result; pc = 86; continue; }
case 86: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;Z)V", r[1], new Value[]{r[3], r[4], r[7]}); pc = 87; continue; }
case 87: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->CUSTOM_BRANDING_ICON:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[1]); pc = 88; continue; }
case 88: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 89; continue; }
case 89: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch;->getDefaultAppNameIndex()I", Value.NULL, new Value[]{}); pc = 90; continue; }
case 90: { r[3] = result; pc = 91; continue; }
case 91: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[3]}); pc = 92; continue; }
case 92: { r[3] = result; pc = 93; continue; }
case 93: { r[4] = Value.ref("revanced_custom_branding_name"); pc = 94; continue; }
case 94: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;Z)V", r[1], new Value[]{r[4], r[3], r[7]}); pc = 95; continue; }
case 95: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->CUSTOM_BRANDING_NAME:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[1]); pc = 96; continue; }
case 96: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 97; continue; }
case 97: { r[3] = Value.ref("revanced_disabled_feature_flags"); pc = 98; continue; }
case 98: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 99; continue; }
case 99: { r[0] = result; pc = 100; continue; }
case 100: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[3], r[6], r[7], r[0]}); pc = 101; continue; }
case 101: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseSettings;->DISABLED_FEATURE_FLAGS:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 102; continue; }
case 102: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Ljava/lang/System;->currentTimeMillis()J", Value.NULL, new Value[]{}); pc = 103; continue; }
case 103: { r[0] = result; r[1] = r[0]; pc = 104; continue; }
case 104: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/LongSetting;->get()Ljava/lang/Long;", r[2], new Value[]{}); pc = 105; continue; }
case 105: { r[3] = result; pc = 106; continue; }
case 106: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Ljava/lang/Long;->longValue()J", r[3], new Value[]{}); pc = 107; continue; }
case 107: { r[3] = result; r[4] = r[3]; pc = 108; continue; }
case 108: { r[5] = Value.i64(0L); r[6] = r[5]; pc = 109; continue; }
case 109: { r[3] = Value.i32(ExecutableRuntime.compareLong(r[3].j(), r[5].j())); pc = 110; continue; }
case 110: { pc = (r[3].i() >= 0) ? 117 : 111; continue; }
case 111: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BaseSettings$$ExternalSyntheticLambda0;"); pc = 112; continue; }
case 112: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/BaseSettings$$ExternalSyntheticLambda0;-><init>()V", r[3], new Value[]{}); pc = 113; continue; }
case 113: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;)V", Value.NULL, new Value[]{r[3]}); pc = 114; continue; }
case 114: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;", Value.NULL, new Value[]{r[0]}); pc = 115; continue; }
case 115: { r[0] = result; pc = 116; continue; }
case 116: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BaseSettings;", "Lapp/revanced/extension/shared/settings/Setting;->save(Ljava/lang/Object;)V", r[2], new Value[]{r[0]}); pc = 117; continue; }
case 117: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_765db2d4d5614bf392fbc526(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("First launch of installation with no prior app data"); pc = 1; continue; }
case 1: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
