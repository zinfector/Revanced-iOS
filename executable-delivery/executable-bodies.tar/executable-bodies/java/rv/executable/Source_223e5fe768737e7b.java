package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_223e5fe768737e7b extends RuntimeForeign.SourceProxy {
Source_223e5fe768737e7b(RuntimeForeign owner,Instance source){super(owner,source);}

}
