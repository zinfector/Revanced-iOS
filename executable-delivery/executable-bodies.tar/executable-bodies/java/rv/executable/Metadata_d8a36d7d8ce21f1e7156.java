package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_d8a36d7d8ce21f1e7156 {
static ClassInfo info_d8a36d7d8ce21f1e7156() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda19;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda19;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "Utils$$ExternalSyntheticLambda19");}
}
