package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_47309fb353cfd3f1b327 {
static ClassInfo info_47309fb353cfd3f1b327() {return new ClassInfo("Lkotlin/jvm/functions/Function1;", "Ljava/lang/Object;", new String[]{}, 1537, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("invoke(Ljava/lang/Object;)Ljava/lang/Object;", 1025)});}
}
