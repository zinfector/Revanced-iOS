package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_6ea2e06564ab182fd2b8 {
static Value m_da88c61d7ad72ff21311d37b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractList$IteratorImpl;");
r[1] = rt.check(arguments[0], "Lkotlin/collections/AbstractList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lkotlin/collections/AbstractList$IteratorImpl;->this$0:Lkotlin/collections/AbstractList;", r[0], false, r[1]); pc = 1; continue; }
case 1: { result = rt.invoke("direct", "Lkotlin/collections/AbstractList$IteratorImpl;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3eb2717cad73d7b65ec5688b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lkotlin/collections/AbstractList$IteratorImpl;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/collections/AbstractList$IteratorImpl;->index:I", r[2], false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lkotlin/collections/AbstractList$IteratorImpl;->this$0:Lkotlin/collections/AbstractList;", r[2], false); pc = 2; continue; }
case 2: { result = rt.invoke("virtual", "Lkotlin/collections/AbstractList$IteratorImpl;", "Lkotlin/collections/AbstractCollection;->size()I", r[1], new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { pc = (r[0].i() >= r[1].i()) ? 7 : 5; continue; }
case 5: { r[0] = Value.i32(1); pc = 6; continue; }
case 6: { return rt.check(r[0], "Z"); }
case 7: { r[0] = Value.i32(0); pc = 8; continue; }
case 8: { return rt.check(r[0], "Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fa8151e3a0520c740f447a94(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lkotlin/collections/AbstractList$IteratorImpl;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lkotlin/collections/AbstractList$IteratorImpl;", "Lkotlin/collections/AbstractList$IteratorImpl;->hasNext()Z", r[3], new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc = (ExecutableRuntime.equal(r[0], Value.i32(0))) ? 10 : 3; continue; }
case 3: { r[0] = rt.readField("Lkotlin/collections/AbstractList$IteratorImpl;->this$0:Lkotlin/collections/AbstractList;", r[3], false); pc = 4; continue; }
case 4: { r[1] = rt.readField("Lkotlin/collections/AbstractList$IteratorImpl;->index:I", r[3], false); pc = 5; continue; }
case 5: { r[2] = Value.i32((r[1].i()) + (1)); pc = 6; continue; }
case 6: { rt.writeField("Lkotlin/collections/AbstractList$IteratorImpl;->index:I", r[3], false, r[2]); pc = 7; continue; }
case 7: { result = rt.invoke("virtual", "Lkotlin/collections/AbstractList$IteratorImpl;", "Lkotlin/collections/AbstractList;->get(I)Ljava/lang/Object;", r[0], new Value[]{r[1]}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { return rt.check(r[0], "Ljava/lang/Object;"); }
case 10: { r[0] = rt.allocate("Ljava/util/NoSuchElementException;"); pc = 11; continue; }
case 11: { result = rt.invoke("direct", "Lkotlin/collections/AbstractList$IteratorImpl;", "Ljava/util/NoSuchElementException;-><init>()V", r[0], new Value[]{}); pc = 12; continue; }
case 12: { ExecutableRuntime.raise(r[0].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
