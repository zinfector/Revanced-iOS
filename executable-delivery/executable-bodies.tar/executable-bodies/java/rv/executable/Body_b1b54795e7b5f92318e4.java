package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_b1b54795e7b5f92318e4 {
static Value m_a9a1ad6084dfb709174c39c6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList$ListIteratorImpl;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[2] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[0] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractList$ListIteratorImpl;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e65bee9b0ef7cff4352f45f3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList$ListIteratorImpl;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$IteratorImpl;->getIndex()I",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[0] = Value.i32((r[0].i()) + (-1)); pc = 3; continue; }
case 3: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_357a2ed77c436a06b5421f70(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList$ListIteratorImpl;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[2] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[0] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractList$ListIteratorImpl;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_83490b679bbe4ee76aa0e7fa(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList$ListIteratorImpl;");
r[2] = rt.check(arguments[0], "Lkotlin/collections/AbstractList;");
r[3] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lkotlin/collections/AbstractList$ListIteratorImpl;->this$0:Lkotlin/collections/AbstractList;",r[1],false,r[2]); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$IteratorImpl;-><init>(Lkotlin/collections/AbstractList;)V",r[1],new Value[]{r[2]}); pc = 2; continue; }
case 2: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractCollection;->size()I",r[2],new Value[]{}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$Companion;->checkPositionIndex$kotlin_stdlib(II)V",r[0],new Value[]{r[3], r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$IteratorImpl;->setIndex(I)V",r[1],new Value[]{r[3]}); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_dcdce7a682bbf1a7b2a9aea6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList$ListIteratorImpl;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$IteratorImpl;->getIndex()I",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(r[0].i() <= 0)?5:3; continue; }
case 3: { r[0] = Value.i32(1); pc = 4; continue; }
case 4: { return rt.check(r[0],"Z"); }
case 5: { r[0] = Value.i32(0); pc = 6; continue; }
case 6: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c0f74891003516762ecf12fb(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lkotlin/collections/AbstractList$ListIteratorImpl;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$ListIteratorImpl;->hasPrevious()Z",r[2],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?13:3; continue; }
case 3: { r[0] = rt.readField("Lkotlin/collections/AbstractList$ListIteratorImpl;->this$0:Lkotlin/collections/AbstractList;",r[2],false); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$IteratorImpl;->getIndex()I",r[2],new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { r[1] = Value.i32((r[1].i()) + (-1)); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$IteratorImpl;->setIndex(I)V",r[2],new Value[]{r[1]}); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$IteratorImpl;->getIndex()I",r[2],new Value[]{}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList;->get(I)Ljava/lang/Object;",r[0],new Value[]{r[1]}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { return rt.check(r[0],"Ljava/lang/Object;"); }
case 13: { r[0] = rt.allocate("Ljava/util/NoSuchElementException;"); pc = 14; continue; }
case 14: { result=rt.invoke("direct","Lkotlin/collections/AbstractList$ListIteratorImpl;","Ljava/util/NoSuchElementException;-><init>()V",r[0],new Value[]{}); pc = 15; continue; }
case 15: { ExecutableRuntime.raise(r[0].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9d2ecc9033ba1d155426f16f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList$ListIteratorImpl;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$ListIteratorImpl;","Lkotlin/collections/AbstractList$IteratorImpl;->getIndex()I",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
