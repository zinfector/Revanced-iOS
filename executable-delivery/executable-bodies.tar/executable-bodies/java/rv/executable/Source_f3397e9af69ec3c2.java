package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_f3397e9af69ec3c2 extends RuntimeForeign.SourceProxy implements java.io.Serializable,java.lang.Comparable {
Source_f3397e9af69ec3c2(RuntimeForeign owner,Instance source){super(owner,source);}
public int compareTo(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I",new Value[]{owner.importValue(a0)}); return result.i();}
}
