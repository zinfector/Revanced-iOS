package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_1c198ddf9656d99a extends RuntimeForeign.SourceProxy implements com.google.j2objc.NSFastEnumeration {
Proxy_1c198ddf9656d99a(RuntimeForeign owner,Instance source){super(owner,source);}

}
