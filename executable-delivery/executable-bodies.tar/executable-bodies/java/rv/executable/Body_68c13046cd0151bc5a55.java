package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_68c13046cd0151bc5a55 {
static Value m_6f9aa82c9c131bb95318d829(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Landroid/content/res/ColorStateList;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(16842910); pc = 2; continue; }
case 2: { result=rt.filledArray("[I",new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { result=rt.filledArray("[[I",new Value[]{r[1]}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { r[2] = Value.i32(872415231); pc = 7; continue; }
case 7: { result=rt.filledArray("[I",new Value[]{r[2]}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Landroid/content/res/ColorStateList;-><init>([[I[I)V",r[0],new Value[]{r[1], r[2]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;->rippleColorStateList:Landroid/content/res/ColorStateList;",Value.NULL,true,r[0]); pc = 11; continue; }
case 11: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1899f12d8a1e82d2f32d08ce(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_SQUARE_LAYOUT:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;",r[3],new Value[]{}); pc = 6; continue; }
case 6: { r[1] = result; pc = 7; continue; }
case 7: { r[1] = rt.cast(r[1],"Landroid/view/ViewGroup$MarginLayoutParams;"); pc = 8; continue; }
case 8: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?11:9; continue; }
case 9: { r[2] = Value.i32(0); pc = 10; continue; }
case 10: { pc=12; continue; }
case 11: { r[2] = Value.i32(12); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V",r[1],new Value[]{r[2]}); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V",r[3],new Value[]{r[1]}); pc = 14; continue; }
case 14: { r[1] = rt.allocate("Landroid/graphics/drawable/GradientDrawable;"); pc = 15; continue; }
case 15: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Landroid/graphics/drawable/GradientDrawable;-><init>()V",r[1],new Value[]{}); pc = 16; continue; }
case 16: { r[2] = Value.ref("skip_ad_button_background_color"); pc = 17; continue; }
case 17: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Lapp/revanced/extension/shared/Utils;->getResourceColor(Ljava/lang/String;)I",Value.NULL,new Value[]{r[2]}); pc = 18; continue; }
case 18: { r[2] = result; pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Landroid/graphics/drawable/GradientDrawable;->setColor(I)V",r[1],new Value[]{r[2]}); pc = 20; continue; }
case 20: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?23:21; continue; }
case 21: { r[0] = Value.i32(0); pc = 22; continue; }
case 22: { pc=25; continue; }
case 23: { r[0] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp16:I",Value.NULL,true); pc = 24; continue; }
case 24: { r[0] = Value.f32((float)(r[0].i())); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V",r[1],new Value[]{r[0]}); pc = 26; continue; }
case 26: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;","Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V",r[3],new Value[]{r[1]}); pc = 27; continue; }
case 27: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
