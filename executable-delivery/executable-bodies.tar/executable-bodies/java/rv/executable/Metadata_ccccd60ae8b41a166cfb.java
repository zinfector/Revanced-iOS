package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_ccccd60ae8b41a166cfb {
static ClassInfo info_ccccd60ae8b41a166cfb() {return new ClassInfo("Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;->f$0:Lapp/revanced/extension/shared/spoof/ClientType;", "Lapp/revanced/extension/shared/spoof/ClientType;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/shared/spoof/ClientType;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/shared/spoof/ClientType;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "ClientType$$ExternalSyntheticLambda0");}
}
