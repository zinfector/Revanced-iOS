package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_24c06b67a1f1a1ccb9b8 {
static Value m_0e805ed957476b08b7dbf78c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/Setting;");
r[2] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;->f$0:Lapp/revanced/extension/shared/settings/Setting;", r[0], false, r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;", r[0], false, r[2]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_92b7634282e73104cc8039f6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;->f$0:Lapp/revanced/extension/shared/settings/Setting;", r[2], false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;", r[2], false); pc = 2; continue; }
case 2: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;", "Lapp/revanced/extension/shared/settings/Setting;->$r8$lambda$IXcJ1mUP4JmnMpW3OjTXM-8V83M(Lapp/revanced/extension/shared/settings/Setting;Ljava/lang/String;)Ljava/lang/String;", Value.NULL, new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
