package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_f95b77da5c8aa1ca extends RuntimeForeign.SourceProxy {
Source_f95b77da5c8aa1ca(RuntimeForeign owner,Instance source){super(owner,source);}

}
