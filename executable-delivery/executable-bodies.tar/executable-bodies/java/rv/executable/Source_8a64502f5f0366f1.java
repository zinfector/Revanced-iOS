package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_8a64502f5f0366f1 extends RuntimeForeign.SourceProxy {
Source_8a64502f5f0366f1(RuntimeForeign owner,Instance source){super(owner,source);}

}
