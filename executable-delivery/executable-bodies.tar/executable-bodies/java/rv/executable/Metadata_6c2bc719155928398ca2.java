package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_6c2bc719155928398ca2 {
static ClassInfo info_6c2bc719155928398ca2() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda4;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buttonEnabled()Z", 17)}, "SponsorBlockViewController$$ExternalSyntheticLambda4");}
}
