package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_9bf65b9de6856e2e8acb {
static Value m_c56940f83c109cabec57b4f7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
r[7] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;"); pc = 1; continue; }
case 1: { r[2] = Value.ref("revanced_sb_create_segment_button"); pc = 2; continue; }
case 2: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda0;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda0;-><init>()V",r[4],new Value[]{}); pc = 4; continue; }
case 4: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda1;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda1;-><init>()V",r[5],new Value[]{}); pc = 6; continue; }
case 6: { r[6] = Value.i32(0); pc = 7; continue; }
case 7: { r[3] = Value.i32(0); pc = 8; continue; }
case 8: { r[1] = r[7]; pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;-><init>(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;Landroid/view/View$OnClickListener;Landroid/view/View$OnLongClickListener;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;->instance:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true,r[0]); pc = 11; continue; }
case 11: { r[7] = Value.ref("revanced_sb_create_segment_button"); pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/shared/Utils;->getChildViewByResourceName(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;",Value.NULL,new Value[]{r[1], r[7]}); pc = 13; continue; }
case 13: { r[7] = result; pc = 14; continue; }
case 14: { r[7] = rt.cast(r[7],"Landroid/widget/ImageView;"); pc = 15; continue; }
case 15: { return Value.VOID; }
case 16: { r[0] = Value.ref(exception); exception=null; pc = 17; continue; }
case 17: { r[7] = r[0]; pc = 18; continue; }
case 18: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda2;"); pc = 19; continue; }
case 19: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda2;-><init>()V",r[0],new Value[]{}); pc = 20; continue; }
case 20: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[7]}); pc = 21; continue; }
case 21: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 15) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=16; continue; } }
throw error;
}
}

}

static Value m_d2c5ba4d0a7fbeb9998da04a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Z");
r[2] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;->instance:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?3:2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->setVisibility(ZZ)V",r[0],new Value[]{r[1], r[2]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4bbfec23350a4836a8d74e0b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;->instance:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?3:2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->setVisibilityImmediate(Z)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b5f40c3994e3487e7d0402c8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;->instance:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?3:2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->setVisibilityNegatedImmediate()V",r[0],new Value[]{}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e2cf79413d7a9ab207ce1a80(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->DRAWABLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/shared/Utils;->appIsUsingBoldIcons()Z",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?6:4; continue; }
case 4: { r[1] = Value.ref("revanced_sb_logo_bold"); pc = 5; continue; }
case 5: { pc=7; continue; }
case 6: { r[1] = Value.ref("revanced_sb_logo"); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;->DRAWABLE_SB_LOGO:I",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b8f700f3cff46b5840f9d88b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;->isButtonEnabled()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_88cda86142d8f9d330c66490(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("initialize failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9372b5ecc338ae56d731e28e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_ENABLED:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?17:6; continue; }
case 6: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CREATE_NEW_SEGMENT:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 10; continue; }
case 10: { r[0] = result; pc = 11; continue; }
case 11: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?17:12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->isAdProgressTextVisible()Z",Value.NULL,new Value[]{}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?17:15; continue; }
case 15: { r[0] = Value.i32(1); pc = 16; continue; }
case 16: { return rt.check(r[0],"Z"); }
case 17: { r[0] = Value.i32(0); pc = 18; continue; }
case 18: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
