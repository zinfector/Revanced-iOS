package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_ce682bb1eb14374173a0 {
static Value m_557f7dd6944393f029c20e62(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->$VALUES:[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true); pc = 1; continue; }
case 1: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", "[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->clone()Ljava/lang/Object;", r[0], new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0], "[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); pc = 4; continue; }
case 4: { return rt.check(r[0], "[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_92d48f06a31d7e6ea7034656(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("ORIGINAL"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->ORIGINAL:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true, r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("ROUNDED"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->ROUNDED:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true, r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("MINIMAL"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->MINIMAL:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true, r[0]); pc = 15; continue; }
case 15: { r[0] = rt.allocate("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); pc = 16; continue; }
case 16: { r[1] = Value.ref("SCALED"); pc = 17; continue; }
case 17: { r[2] = Value.i32(3); pc = 18; continue; }
case 18: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->SCALED:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true, r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); pc = 21; continue; }
case 21: { r[1] = Value.ref("CUSTOM"); pc = 22; continue; }
case 22: { r[2] = Value.i32(4); pc = 23; continue; }
case 23: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->CUSTOM:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true, r[0]); pc = 25; continue; }
case 25: { result = rt.invoke("static", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->$values()[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, new Value[]{}); pc = 26; continue; }
case 26: { r[0] = result; pc = 27; continue; }
case 27: { rt.writeField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->$VALUES:[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true, r[0]); pc = 28; continue; }
case 28: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0ac845beff6df61c0cabafa0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e7af86ac19d510e60007cad7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(5); pc = 1; continue; }
case 1: { r[0] = rt.newArray("[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", r[0].i()); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->ORIGINAL:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true); pc = 3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->ROUNDED:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true); pc = 6; continue; }
case 6: { r[2] = Value.i32(1); pc = 7; continue; }
case 7: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->MINIMAL:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true); pc = 9; continue; }
case 9: { r[2] = Value.i32(2); pc = 10; continue; }
case 10: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 11; continue; }
case 11: { r[1] = rt.readField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->SCALED:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true); pc = 12; continue; }
case 12: { r[2] = Value.i32(3); pc = 13; continue; }
case 13: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 14; continue; }
case 14: { r[1] = rt.readField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->CUSTOM:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true); pc = 15; continue; }
case 15: { r[2] = Value.i32(4); pc = 16; continue; }
case 16: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 17; continue; }
case 17: { return rt.check(r[0], "[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
