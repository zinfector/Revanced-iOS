package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_297cb4519d0e35fa8b25 {
static ClassInfo info_297cb4519d0e35fa8b25() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda20;", "Ljava/lang/Object;", new String[]{"Ljava/util/concurrent/ThreadFactory;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;", 17)}, "Utils$$ExternalSyntheticLambda20");}
}
