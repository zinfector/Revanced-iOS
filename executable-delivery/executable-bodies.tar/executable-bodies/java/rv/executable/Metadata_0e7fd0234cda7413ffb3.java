package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_0e7fd0234cda7413ffb3 {
static ClassInfo info_0e7fd0234cda7413ffb3() {return new ClassInfo("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda5;", "Ljava/lang/Object;", new String[]{"Ljava/lang/Runnable;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda5;->f$0:Landroid/view/View;", "Landroid/view/View;", 4113, ExecutableRuntime.zero("Landroid/view/View;"))}, new MethodInfo[]{new MethodInfo("<init>(Landroid/view/View;)V", 69633), new MethodInfo("run()V", 17)}, "PlayerControlButton$$ExternalSyntheticLambda5");}
}
