package rv.executable;
import rv.executable.ExecutableRuntime.*;
public final class GeneratedForeign extends RuntimeForeign {
 public GeneratedForeign(PlatformServices services){super(services);}
 protected boolean callStatic(String method){switch(method){
case "Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;": return false;
case "Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;": return false;
case "Landroid/content/Context;->getPackageName()Ljava/lang/String;": return false;
case "Landroid/content/Context;->getResources()Landroid/content/res/Resources;": return false;
case "Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;": return false;
case "Landroid/content/SharedPreferences$Editor;->commit()Z": return false;
case "Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;": return false;
case "Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;": return false;
case "Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;": return false;
case "Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;": return false;
case "Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z": return false;
case "Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F": return false;
case "Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I": return false;
case "Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J": return false;
case "Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;": return false;
case "Landroid/content/pm/PackageManager$PackageInfoFlags;->of(J)Landroid/content/pm/PackageManager$PackageInfoFlags;": return true;
case "Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;": return false;
case "Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;Landroid/content/pm/PackageManager$PackageInfoFlags;)Landroid/content/pm/PackageInfo;": return false;
case "Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V": return false;
case "Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V": return false;
case "Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V": return false;
case "Landroid/content/res/Resources;->getColor(I)I": return false;
case "Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;": return false;
case "Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I": return false;
case "Landroid/content/res/Resources;->getString(I)Ljava/lang/String;": return false;
case "Landroid/graphics/Color;->argb(IIII)I": return true;
case "Landroid/graphics/Color;->blue(I)I": return true;
case "Landroid/graphics/Color;->green(I)I": return true;
case "Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I": return true;
case "Landroid/graphics/Color;->red(I)I": return true;
case "Landroid/os/Handler;-><init>(Landroid/os/Looper;)V": return false;
case "Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z": return false;
case "Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;": return true;
case "Landroid/os/Looper;->isCurrentThread()Z": return false;
case "Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I": return true;
case "Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I": return true;
case "Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I": return true;
case "Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I": return true;
case "Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I": return true;
case "Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I": return true;
case "Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;": return true;
case "Landroid/widget/Toast;->show()V": return false;
case "Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V": return false;
case "Ljava/io/StringWriter;-><init>()V": return false;
case "Ljava/io/StringWriter;->toString()Ljava/lang/String;": return false;
case "Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;": return false;
case "Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;": return false;
case "Ljava/lang/Boolean;->booleanValue()Z": return false;
case "Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;": return true;
case "Ljava/lang/Character;->charValue()C": return false;
case "Ljava/lang/Class;->getComponentType()Ljava/lang/Class;": return false;
case "Ljava/lang/Class;->getName()Ljava/lang/String;": return false;
case "Ljava/lang/Class;->getSimpleName()Ljava/lang/String;": return false;
case "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V": return false;
case "Ljava/lang/Enum;->name()Ljava/lang/String;": return false;
case "Ljava/lang/Enum;->ordinal()I": return false;
case "Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;": return true;
case "Ljava/lang/Float;->floatValue()F": return false;
case "Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;": return true;
case "Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;": return true;
case "Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V": return false;
case "Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V": return false;
case "Ljava/lang/Integer;->intValue()I": return false;
case "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;": return true;
case "Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;": return true;
case "Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;": return false;
case "Ljava/lang/Long;->longValue()J": return false;
case "Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;": return true;
case "Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;": return true;
case "Ljava/lang/Math;->min(II)I": return true;
case "Ljava/lang/Object;-><init>()V": return false;
case "Ljava/lang/Object;->clone()Ljava/lang/Object;": return false;
case "Ljava/lang/Object;->equals(Ljava/lang/Object;)Z": return false;
case "Ljava/lang/Object;->getClass()Ljava/lang/Class;": return false;
case "Ljava/lang/Object;->hashCode()I": return false;
case "Ljava/lang/Object;->toString()Ljava/lang/String;": return false;
case "Ljava/lang/OutOfMemoryError;-><init>()V": return false;
case "Ljava/lang/Runnable;->run()V": return false;
case "Ljava/lang/String;->compareTo(Ljava/lang/String;)I": return false;
case "Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;": return true;
case "Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;": return true;
case "Ljava/lang/String;->indexOf(I)I": return false;
case "Ljava/lang/String;->indexOf(II)I": return false;
case "Ljava/lang/String;->lastIndexOf(I)I": return false;
case "Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I": return false;
case "Ljava/lang/String;->length()I": return false;
case "Ljava/lang/String;->startsWith(Ljava/lang/String;)Z": return false;
case "Ljava/lang/String;->substring(I)Ljava/lang/String;": return false;
case "Ljava/lang/String;->substring(II)Ljava/lang/String;": return false;
case "Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;": return false;
case "Ljava/lang/String;->valueOf(I)Ljava/lang/String;": return true;
case "Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;": return true;
case "Ljava/lang/StringBuilder;-><init>()V": return false;
case "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V": return false;
case "Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;": return false;
case "Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;": return false;
case "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;": return false;
case "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;": return false;
case "Ljava/lang/System;->currentTimeMillis()J": return true;
case "Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V": return false;
case "Ljava/lang/Thread;->setPriority(I)V": return false;
case "Ljava/lang/Throwable;-><init>()V": return false;
case "Ljava/lang/Throwable;->getMessage()Ljava/lang/String;": return false;
case "Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V": return false;
case "Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V": return false;
case "Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;": return true;
case "Ljava/util/ArrayList;-><init>()V": return false;
case "Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;": return true;
case "Ljava/util/Collection;->isEmpty()Z": return false;
case "Ljava/util/Collection;->iterator()Ljava/util/Iterator;": return false;
case "Ljava/util/Collection;->size()I": return false;
case "Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;": return true;
case "Ljava/util/Deque;->addLast(Ljava/lang/Object;)V": return false;
case "Ljava/util/Deque;->pollFirst()Ljava/lang/Object;": return false;
case "Ljava/util/Deque;->size()I": return false;
case "Ljava/util/HashMap;-><init>()V": return false;
case "Ljava/util/HashMap;-><init>(I)V": return false;
case "Ljava/util/Iterator;->hasNext()Z": return false;
case "Ljava/util/Iterator;->next()Ljava/lang/Object;": return false;
case "Ljava/util/List;->add(Ljava/lang/Object;)Z": return false;
case "Ljava/util/List;->iterator()Ljava/util/Iterator;": return false;
case "Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;": return false;
case "Ljava/util/List;->size()I": return false;
case "Ljava/util/ListIterator;->hasPrevious()Z": return false;
case "Ljava/util/ListIterator;->nextIndex()I": return false;
case "Ljava/util/ListIterator;->previous()Ljava/lang/Object;": return false;
case "Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;": return true;
case "Ljava/util/Locale;->getDefault()Ljava/util/Locale;": return true;
case "Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;": return false;
case "Ljava/util/NoSuchElementException;-><init>()V": return false;
case "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;": return true;
case "Ljava/util/concurrent/ConcurrentLinkedDeque;-><init>()V": return false;
case "Ljava/util/concurrent/SynchronousQueue;-><init>()V": return false;
case "Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V": return false;
case "Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V": return false;
case "Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I": return false;
case "Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;": return true;
case "[Lapp/revanced/extension/shared/Logger$LogLevel;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/shared/ResourceType;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/shared/settings/AppLanguage;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/shared/spoof/ClientType;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->clone()Ljava/lang/Object;": return false;
case "[Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->clone()Ljava/lang/Object;": return false;
default:throw new MissingOperation(method);}}
 protected boolean fieldStatic(String field){switch(field){
case "Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;": return false;
case "Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;": return true;
case "Landroid/os/Build$VERSION;->SDK_INT:I": return true;
case "Landroid/os/Build;->ID:Ljava/lang/String;": return true;
case "Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;": return true;
case "Landroid/os/Build;->MODEL:Ljava/lang/String;": return true;
case "Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;": return true;
case "Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;": return true;
case "Ljava/util/Locale;->US:Ljava/util/Locale;": return true;
case "Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;": return true;
default:throw new MissingOperation(field);}}
 protected Value jreCall(String method,Value receiver,Value[] args)throws Throwable {switch(method){
case "Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V": {construct(receiver, new java.lang.UnsupportedOperationException((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;"))); return Value.VOID;}
case "Ljava/util/Collection;->isEmpty()Z": {return Value.i32((((java.util.Collection)exportObject(receiver.o(),"Ljava/util/Collection;")).isEmpty() ? 1 : 0));}
case "Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;": {return importValue(((java.lang.Iterable)exportObject(receiver.o(),"Ljava/lang/Iterable;")).iterator());}
case "Ljava/util/Iterator;->hasNext()Z": {return Value.i32((((java.util.Iterator)exportObject(receiver.o(),"Ljava/util/Iterator;")).hasNext() ? 1 : 0));}
case "Ljava/util/Iterator;->next()Ljava/lang/Object;": {return importValue(((java.util.Iterator)exportObject(receiver.o(),"Ljava/util/Iterator;")).next());}
case "Ljava/util/List;->iterator()Ljava/util/Iterator;": {return importValue(((java.util.List)exportObject(receiver.o(),"Ljava/util/List;")).iterator());}
case "Ljava/util/List;->size()I": {return Value.i32(((java.util.List)exportObject(receiver.o(),"Ljava/util/List;")).size());}
case "Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;": {return importValue(((java.util.List)exportObject(receiver.o(),"Ljava/util/List;")).listIterator(args[0].i()));}
case "Ljava/util/ListIterator;->hasPrevious()Z": {return Value.i32((((java.util.ListIterator)exportObject(receiver.o(),"Ljava/util/ListIterator;")).hasPrevious() ? 1 : 0));}
case "Ljava/util/ListIterator;->previous()Ljava/lang/Object;": {return importValue(((java.util.ListIterator)exportObject(receiver.o(),"Ljava/util/ListIterator;")).previous());}
case "Ljava/util/ListIterator;->nextIndex()I": {return Value.i32(((java.util.ListIterator)exportObject(receiver.o(),"Ljava/util/ListIterator;")).nextIndex());}
case "Ljava/lang/Boolean;->booleanValue()Z": {return Value.i32((((java.lang.Boolean)exportObject(receiver.o(),"Ljava/lang/Boolean;")).booleanValue() ? 1 : 0));}
case "Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;": {return importValue(java.util.regex.Pattern.compile((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")));}
case "Ljava/util/concurrent/SynchronousQueue;-><init>()V": {construct(receiver, new java.util.concurrent.SynchronousQueue()); return Value.VOID;}
case "Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V": {construct(receiver, new java.util.concurrent.ThreadPoolExecutor(args[0].i(), args[1].i(), args[2].j(), (java.util.concurrent.TimeUnit)exportObject(args[3].o(),"Ljava/util/concurrent/TimeUnit;"), (java.util.concurrent.BlockingQueue)exportObject(args[4].o(),"Ljava/util/concurrent/BlockingQueue;"), (java.util.concurrent.ThreadFactory)exportObject(args[5].o(),"Ljava/util/concurrent/ThreadFactory;"))); return Value.VOID;}
case "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;": {return importValue(java.lang.Integer.valueOf(args[0].i()));}
case "Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;": {return importValue(java.lang.Long.valueOf(args[0].j()));}
case "Ljava/lang/System;->currentTimeMillis()J": {return Value.i64(java.lang.System.currentTimeMillis());}
case "Ljava/lang/Long;->longValue()J": {return Value.i64(((java.lang.Long)exportObject(receiver.o(),"Ljava/lang/Long;")).longValue());}
case "Ljava/util/Locale;->getDefault()Ljava/util/Locale;": {return importValue(java.util.Locale.getDefault());}
case "Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V": {construct(receiver, new java.lang.Thread((java.lang.Runnable)exportObject(args[0].o(),"Ljava/lang/Runnable;"))); return Value.VOID;}
case "Ljava/lang/Thread;->setPriority(I)V": {((java.lang.Thread)exportObject(receiver.o(),"Ljava/lang/Thread;")).setPriority(args[0].i()); return Value.VOID;}
case "Ljava/lang/String;->valueOf(I)Ljava/lang/String;": {return importValue(java.lang.String.valueOf(args[0].i()));}
case "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;": {return importValue(java.util.Objects.requireNonNull((java.lang.Object)exportObject(args[0].o(),"Ljava/lang/Object;")));}
case "Ljava/util/Collection;->size()I": {return Value.i32(((java.util.Collection)exportObject(receiver.o(),"Ljava/util/Collection;")).size());}
case "Ljava/util/Collection;->iterator()Ljava/util/Iterator;": {return importValue(((java.util.Collection)exportObject(receiver.o(),"Ljava/util/Collection;")).iterator());}
case "Ljava/lang/OutOfMemoryError;-><init>()V": {construct(receiver, new java.lang.OutOfMemoryError()); return Value.VOID;}
case "Ljava/util/NoSuchElementException;-><init>()V": {construct(receiver, new java.util.NoSuchElementException()); return Value.VOID;}
case "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V": {construct(receiver, new java.lang.StringBuilder((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;"))); return Value.VOID;}
case "Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;": {return importValue(((java.lang.StringBuilder)exportObject(receiver.o(),"Ljava/lang/StringBuilder;")).append(args[0].i()));}
case "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;": {return importValue(((java.lang.StringBuilder)exportObject(receiver.o(),"Ljava/lang/StringBuilder;")).append((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")));}
case "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;": {return importValue(((java.lang.StringBuilder)exportObject(receiver.o(),"Ljava/lang/StringBuilder;")).toString());}
case "Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V": {construct(receiver, new java.lang.IllegalArgumentException((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;"))); return Value.VOID;}
case "Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V": {construct(receiver, new java.lang.IndexOutOfBoundsException((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;"))); return Value.VOID;}
case "Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;": {return importValue(java.lang.Float.valueOf(args[0].f()));}
case "Ljava/lang/Math;->min(II)I": {return Value.i32(java.lang.Math.min(args[0].i(), args[1].i()));}
case "Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;": {return importValue(java.lang.String.format((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;"), (java.lang.Object[])exportObject(args[1].o(),"[Ljava/lang/Object;")));}
case "Ljava/lang/String;->compareTo(Ljava/lang/String;)I": {return Value.i32(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).compareTo((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")));}
case "Ljava/util/ArrayList;-><init>()V": {construct(receiver, new java.util.ArrayList()); return Value.VOID;}
case "Ljava/util/HashMap;-><init>()V": {construct(receiver, new java.util.HashMap()); return Value.VOID;}
case "Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;": {return importValue(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).toLowerCase((java.util.Locale)exportObject(args[0].o(),"Ljava/util/Locale;")));}
case "Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;": {return importValue(java.util.Locale.forLanguageTag((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")));}
case "Ljava/lang/String;->startsWith(Ljava/lang/String;)Z": {return Value.i32((((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).startsWith((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")) ? 1 : 0));}
case "Ljava/lang/String;->length()I": {return Value.i32(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).length());}
case "Ljava/lang/Float;->floatValue()F": {return Value.f32(((java.lang.Float)exportObject(receiver.o(),"Ljava/lang/Float;")).floatValue());}
case "Ljava/util/List;->add(Ljava/lang/Object;)Z": {return Value.i32((((java.util.List)exportObject(receiver.o(),"Ljava/util/List;")).add((java.lang.Object)exportObject(args[0].o(),"Ljava/lang/Object;")) ? 1 : 0));}
case "Ljava/lang/Throwable;->getMessage()Ljava/lang/String;": {return importValue(((java.lang.Throwable)exportObject(receiver.o(),"Ljava/lang/Throwable;")).getMessage());}
case "Ljava/lang/StringBuilder;-><init>()V": {construct(receiver, new java.lang.StringBuilder()); return Value.VOID;}
case "Ljava/io/StringWriter;-><init>()V": {construct(receiver, new java.io.StringWriter()); return Value.VOID;}
case "Ljava/lang/Throwable;-><init>()V": {construct(receiver, new java.lang.Throwable()); return Value.VOID;}
case "Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V": {construct(receiver, new java.io.PrintWriter((java.io.Writer)exportObject(args[0].o(),"Ljava/io/Writer;"))); return Value.VOID;}
case "Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V": {((java.lang.Throwable)exportObject(receiver.o(),"Ljava/lang/Throwable;")).printStackTrace((java.io.PrintWriter)exportObject(args[0].o(),"Ljava/io/PrintWriter;")); return Value.VOID;}
case "Ljava/io/StringWriter;->toString()Ljava/lang/String;": {return importValue(((java.io.StringWriter)exportObject(receiver.o(),"Ljava/io/StringWriter;")).toString());}
case "Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I": {return Value.i32(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).lastIndexOf((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")));}
case "Ljava/lang/String;->indexOf(II)I": {return Value.i32(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).indexOf(args[0].i(), args[1].i()));}
case "Ljava/lang/String;->substring(I)Ljava/lang/String;": {return importValue(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).substring(args[0].i()));}
case "Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;": {return importValue(java.util.Collections.synchronizedMap((java.util.Map)exportObject(args[0].o(),"Ljava/util/Map;")));}
case "Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;": {return importValue(((java.lang.StringBuilder)exportObject(receiver.o(),"Ljava/lang/StringBuilder;")).append((java.lang.Object)exportObject(args[0].o(),"Ljava/lang/Object;")));}
case "Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;": {return importValue(java.lang.String.format((java.util.Locale)exportObject(args[0].o(),"Ljava/util/Locale;"), (java.lang.String)exportObject(args[1].o(),"Ljava/lang/String;"), (java.lang.Object[])exportObject(args[2].o(),"[Ljava/lang/Object;")));}
case "Ljava/lang/String;->substring(II)Ljava/lang/String;": {return importValue(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).substring(args[0].i(), args[1].i()));}
case "Ljava/lang/String;->indexOf(I)I": {return Value.i32(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).indexOf(args[0].i()));}
case "Ljava/lang/String;->lastIndexOf(I)I": {return Value.i32(((java.lang.String)exportObject(receiver.o(),"Ljava/lang/String;")).lastIndexOf(args[0].i()));}
case "Ljava/util/Deque;->addLast(Ljava/lang/Object;)V": {((java.util.Deque)exportObject(receiver.o(),"Ljava/util/Deque;")).addLast((java.lang.Object)exportObject(args[0].o(),"Ljava/lang/Object;")); return Value.VOID;}
case "Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I": {return Value.i32(((java.util.concurrent.atomic.AtomicInteger)exportObject(receiver.o(),"Ljava/util/concurrent/atomic/AtomicInteger;")).addAndGet(args[0].i()));}
case "Ljava/util/Deque;->size()I": {return Value.i32(((java.util.Deque)exportObject(receiver.o(),"Ljava/util/Deque;")).size());}
case "Ljava/util/Deque;->pollFirst()Ljava/lang/Object;": {return importValue(((java.util.Deque)exportObject(receiver.o(),"Ljava/util/Deque;")).pollFirst());}
case "Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;": {return importValue(((java.util.Map)exportObject(receiver.o(),"Ljava/util/Map;")).put((java.lang.Object)exportObject(args[0].o(),"Ljava/lang/Object;"), (java.lang.Object)exportObject(args[1].o(),"Ljava/lang/Object;")));}
case "Ljava/util/HashMap;-><init>(I)V": {construct(receiver, new java.util.HashMap(args[0].i())); return Value.VOID;}
case "Ljava/util/concurrent/ConcurrentLinkedDeque;-><init>()V": {construct(receiver, new java.util.concurrent.ConcurrentLinkedDeque()); return Value.VOID;}
case "Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V": {construct(receiver, new java.util.concurrent.atomic.AtomicInteger()); return Value.VOID;}
case "Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;": {return importValue(java.lang.Boolean.valueOf(args[0].z()));}
case "Ljava/lang/Runnable;->run()V": {((java.lang.Runnable)exportObject(receiver.o(),"Ljava/lang/Runnable;")).run(); return Value.VOID;}
case "Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;": {return importValue(java.lang.Long.valueOf((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")));}
case "Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;": {return importValue(java.lang.Integer.valueOf((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")));}
case "Ljava/lang/Integer;->intValue()I": {return Value.i32(((java.lang.Integer)exportObject(receiver.o(),"Ljava/lang/Integer;")).intValue());}
case "Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;": {return importValue(java.lang.Float.valueOf((java.lang.String)exportObject(args[0].o(),"Ljava/lang/String;")));}
case "Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;": {return importValue(((java.lang.Appendable)exportObject(receiver.o(),"Ljava/lang/Appendable;")).append((java.lang.CharSequence)exportObject(args[0].o(),"Ljava/lang/CharSequence;")));}
case "Ljava/lang/Character;->charValue()C": {return Value.i32(((java.lang.Character)exportObject(receiver.o(),"Ljava/lang/Character;")).charValue());}
case "Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;": {return importValue(((java.lang.Appendable)exportObject(receiver.o(),"Ljava/lang/Appendable;")).append((char)args[0].i()));}
case "Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;": {return importValue(java.lang.String.valueOf((java.lang.Object)exportObject(args[0].o(),"Ljava/lang/Object;")));}
default:throw new MissingOperation(method);}}
 protected Value jreField(String field,Value receiver)throws Throwable {switch(field){
case "Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;": {return importValue(java.util.concurrent.TimeUnit.SECONDS);}
case "Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;": {return importValue(java.lang.Boolean.FALSE);}
case "Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;": {return importValue(java.lang.Boolean.TRUE);}
case "Ljava/util/Locale;->US:Ljava/util/Locale;": {return importValue(java.util.Locale.US);}
default:throw new MissingOperation(field);}}
 protected Class<?> hostClass(String type){switch(type){
case "Landroid/content/res/Resources$NotFoundException;": return AndroidOperations.ResourceNotFoundException.class;
case "Ljava/io/Closeable;": return java.io.Closeable.class;
case "Ljava/io/Flushable;": return java.io.Flushable.class;
case "Ljava/io/PrintWriter;": return java.io.PrintWriter.class;
case "Ljava/io/Serializable;": return java.io.Serializable.class;
case "Ljava/io/StringWriter;": return java.io.StringWriter.class;
case "Ljava/io/Writer;": return java.io.Writer.class;
case "Ljava/lang/Appendable;": return java.lang.Appendable.class;
case "Ljava/lang/AutoCloseable;": return java.lang.AutoCloseable.class;
case "Ljava/lang/Boolean;": return java.lang.Boolean.class;
case "Ljava/lang/CharSequence;": return java.lang.CharSequence.class;
case "Ljava/lang/Character;": return java.lang.Character.class;
case "Ljava/lang/Class;": return java.lang.Class.class;
case "Ljava/lang/ClassCastException;": return java.lang.ClassCastException.class;
case "Ljava/lang/Cloneable;": return java.lang.Cloneable.class;
case "Ljava/lang/Comparable;": return java.lang.Comparable.class;
case "Ljava/lang/Enum;": return java.lang.Enum.class;
case "Ljava/lang/Error;": return java.lang.Error.class;
case "Ljava/lang/Exception;": return java.lang.Exception.class;
case "Ljava/lang/Float;": return java.lang.Float.class;
case "Ljava/lang/IllegalArgumentException;": return java.lang.IllegalArgumentException.class;
case "Ljava/lang/IncompatibleClassChangeError;": return java.lang.IncompatibleClassChangeError.class;
case "Ljava/lang/IndexOutOfBoundsException;": return java.lang.IndexOutOfBoundsException.class;
case "Ljava/lang/Integer;": return java.lang.Integer.class;
case "Ljava/lang/Iterable;": return java.lang.Iterable.class;
case "Ljava/lang/LinkageError;": return java.lang.LinkageError.class;
case "Ljava/lang/Long;": return java.lang.Long.class;
case "Ljava/lang/Math;": return java.lang.Math.class;
case "Ljava/lang/NoSuchFieldError;": return java.lang.NoSuchFieldError.class;
case "Ljava/lang/Number;": return java.lang.Number.class;
case "Ljava/lang/NumberFormatException;": return java.lang.NumberFormatException.class;
case "Ljava/lang/Object;": return java.lang.Object.class;
case "Ljava/lang/OutOfMemoryError;": return java.lang.OutOfMemoryError.class;
case "Ljava/lang/Runnable;": return java.lang.Runnable.class;
case "Ljava/lang/RuntimeException;": return java.lang.RuntimeException.class;
case "Ljava/lang/String;": return java.lang.String.class;
case "Ljava/lang/StringBuilder;": return java.lang.StringBuilder.class;
case "Ljava/lang/System;": return java.lang.System.class;
case "Ljava/lang/Thread;": return java.lang.Thread.class;
case "Ljava/lang/Throwable;": return java.lang.Throwable.class;
case "Ljava/lang/UnsupportedOperationException;": return java.lang.UnsupportedOperationException.class;
case "Ljava/lang/VirtualMachineError;": return java.lang.VirtualMachineError.class;
case "Ljava/lang/reflect/AnnotatedElement;": return java.lang.reflect.AnnotatedElement.class;
case "Ljava/lang/reflect/Array;": return java.lang.reflect.Array.class;
case "Ljava/lang/reflect/GenericDeclaration;": return java.lang.reflect.GenericDeclaration.class;
case "Ljava/lang/reflect/Type;": return java.lang.reflect.Type.class;
case "Ljava/util/AbstractCollection;": return java.util.AbstractCollection.class;
case "Ljava/util/AbstractList;": return java.util.AbstractList.class;
case "Ljava/util/AbstractMap;": return java.util.AbstractMap.class;
case "Ljava/util/AbstractQueue;": return java.util.AbstractQueue.class;
case "Ljava/util/ArrayList;": return java.util.ArrayList.class;
case "Ljava/util/Arrays;": return java.util.Arrays.class;
case "Ljava/util/Collection;": return java.util.Collection.class;
case "Ljava/util/Collections;": return java.util.Collections.class;
case "Ljava/util/Deque;": return java.util.Deque.class;
case "Ljava/util/HashMap;": return java.util.HashMap.class;
case "Ljava/util/Iterator;": return java.util.Iterator.class;
case "Ljava/util/List;": return java.util.List.class;
case "Ljava/util/ListIterator;": return java.util.ListIterator.class;
case "Ljava/util/Locale;": return java.util.Locale.class;
case "Ljava/util/Map;": return java.util.Map.class;
case "Ljava/util/NoSuchElementException;": return java.util.NoSuchElementException.class;
case "Ljava/util/Objects;": return java.util.Objects.class;
case "Ljava/util/Queue;": return java.util.Queue.class;
case "Ljava/util/RandomAccess;": return java.util.RandomAccess.class;
case "Ljava/util/concurrent/AbstractExecutorService;": return java.util.concurrent.AbstractExecutorService.class;
case "Ljava/util/concurrent/BlockingQueue;": return java.util.concurrent.BlockingQueue.class;
case "Ljava/util/concurrent/ConcurrentLinkedDeque;": return java.util.concurrent.ConcurrentLinkedDeque.class;
case "Ljava/util/concurrent/Executor;": return java.util.concurrent.Executor.class;
case "Ljava/util/concurrent/ExecutorService;": return java.util.concurrent.ExecutorService.class;
case "Ljava/util/concurrent/SynchronousQueue;": return java.util.concurrent.SynchronousQueue.class;
case "Ljava/util/concurrent/ThreadFactory;": return java.util.concurrent.ThreadFactory.class;
case "Ljava/util/concurrent/ThreadPoolExecutor;": return java.util.concurrent.ThreadPoolExecutor.class;
case "Ljava/util/concurrent/TimeUnit;": return java.util.concurrent.TimeUnit.class;
case "Ljava/util/concurrent/atomic/AtomicInteger;": return java.util.concurrent.atomic.AtomicInteger.class;
case "Ljava/util/regex/Pattern;": return java.util.regex.Pattern.class;
default:return null;}}
 protected String[] hostParents(String type){switch(type){
case "Lcom/google/j2objc/NSException;": return new String[]{"Ljava/lang/Object;"};
case "Lcom/google/j2objc/NSFastEnumeration;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/io/Closeable;": return new String[]{"Ljava/lang/Object;","Ljava/lang/AutoCloseable;"};
case "Ljava/io/Flushable;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/io/PrintWriter;": return new String[]{"Ljava/io/Writer;"};
case "Ljava/io/Serializable;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/io/StringWriter;": return new String[]{"Ljava/io/Writer;"};
case "Ljava/io/Writer;": return new String[]{"Ljava/lang/Object;","Ljava/lang/Appendable;","Ljava/io/Closeable;","Ljava/io/Flushable;"};
case "Ljava/lang/AbstractStringBuilder;": return new String[]{"Ljava/lang/Object;","Ljava/lang/Appendable;","Ljava/lang/CharSequence;"};
case "Ljava/lang/Appendable;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/AutoCloseable;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/Boolean;": return new String[]{"Ljava/lang/Object;","Ljava/io/Serializable;","Ljava/lang/Comparable;"};
case "Ljava/lang/CharSequence;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/Character;": return new String[]{"Ljava/lang/Object;","Ljava/io/Serializable;","Ljava/lang/Comparable;"};
case "Ljava/lang/Class;": return new String[]{"Ljava/lang/Object;","Ljava/io/Serializable;","Ljava/lang/reflect/GenericDeclaration;","Ljava/lang/reflect/Type;","Ljava/lang/reflect/AnnotatedElement;"};
case "Ljava/lang/ClassCastException;": return new String[]{"Ljava/lang/RuntimeException;"};
case "Ljava/lang/Cloneable;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/Comparable;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/Enum;": return new String[]{"Ljava/lang/Object;","Ljava/lang/Comparable;","Ljava/io/Serializable;"};
case "Ljava/lang/Error;": return new String[]{"Ljava/lang/Throwable;"};
case "Ljava/lang/Exception;": return new String[]{"Ljava/lang/Throwable;"};
case "Ljava/lang/Float;": return new String[]{"Ljava/lang/Number;","Ljava/lang/Comparable;"};
case "Ljava/lang/IllegalArgumentException;": return new String[]{"Ljava/lang/RuntimeException;"};
case "Ljava/lang/IncompatibleClassChangeError;": return new String[]{"Ljava/lang/LinkageError;"};
case "Ljava/lang/IndexOutOfBoundsException;": return new String[]{"Ljava/lang/RuntimeException;"};
case "Ljava/lang/Integer;": return new String[]{"Ljava/lang/Number;","Ljava/lang/Comparable;"};
case "Ljava/lang/Iterable;": return new String[]{"Ljava/lang/Object;","Lcom/google/j2objc/NSFastEnumeration;"};
case "Ljava/lang/LinkageError;": return new String[]{"Ljava/lang/Error;"};
case "Ljava/lang/Long;": return new String[]{"Ljava/lang/Number;","Ljava/lang/Comparable;"};
case "Ljava/lang/Math;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/NoSuchFieldError;": return new String[]{"Ljava/lang/IncompatibleClassChangeError;"};
case "Ljava/lang/Number;": return new String[]{"Ljava/lang/Object;","Ljava/io/Serializable;"};
case "Ljava/lang/NumberFormatException;": return new String[]{"Ljava/lang/IllegalArgumentException;"};
case "Ljava/lang/Object;": return new String[]{};
case "Ljava/lang/OutOfMemoryError;": return new String[]{"Ljava/lang/VirtualMachineError;"};
case "Ljava/lang/Runnable;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/RuntimeException;": return new String[]{"Ljava/lang/Exception;"};
case "Ljava/lang/String;": return new String[]{"Ljava/lang/Object;","Ljava/io/Serializable;","Ljava/lang/Comparable;","Ljava/lang/CharSequence;"};
case "Ljava/lang/StringBuilder;": return new String[]{"Ljava/lang/AbstractStringBuilder;","Ljava/io/Serializable;","Ljava/lang/CharSequence;"};
case "Ljava/lang/System;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/Thread;": return new String[]{"Ljava/lang/Object;","Ljava/lang/Runnable;"};
case "Ljava/lang/Throwable;": return new String[]{"Lcom/google/j2objc/NSException;","Ljava/io/Serializable;"};
case "Ljava/lang/UnsupportedOperationException;": return new String[]{"Ljava/lang/RuntimeException;"};
case "Ljava/lang/VirtualMachineError;": return new String[]{"Ljava/lang/Error;"};
case "Ljava/lang/reflect/AnnotatedElement;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/reflect/Array;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/lang/reflect/GenericDeclaration;": return new String[]{"Ljava/lang/Object;","Ljava/lang/reflect/AnnotatedElement;"};
case "Ljava/lang/reflect/Type;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/AbstractCollection;": return new String[]{"Ljava/lang/Object;","Ljava/util/Collection;"};
case "Ljava/util/AbstractList;": return new String[]{"Ljava/util/AbstractCollection;","Ljava/util/List;"};
case "Ljava/util/AbstractMap;": return new String[]{"Ljava/lang/Object;","Ljava/util/Map;"};
case "Ljava/util/AbstractQueue;": return new String[]{"Ljava/util/AbstractCollection;","Ljava/util/Queue;"};
case "Ljava/util/ArrayList;": return new String[]{"Ljava/util/AbstractList;","Ljava/util/List;","Ljava/util/RandomAccess;","Ljava/lang/Cloneable;","Ljava/io/Serializable;"};
case "Ljava/util/Arrays;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/Collection;": return new String[]{"Ljava/lang/Object;","Ljava/lang/Iterable;"};
case "Ljava/util/Collections;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/Deque;": return new String[]{"Ljava/lang/Object;","Ljava/util/Queue;"};
case "Ljava/util/HashMap;": return new String[]{"Ljava/util/AbstractMap;","Ljava/util/Map;","Ljava/lang/Cloneable;","Ljava/io/Serializable;"};
case "Ljava/util/Iterator;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/List;": return new String[]{"Ljava/lang/Object;","Ljava/util/Collection;"};
case "Ljava/util/ListIterator;": return new String[]{"Ljava/lang/Object;","Ljava/util/Iterator;"};
case "Ljava/util/Locale;": return new String[]{"Ljava/lang/Object;","Ljava/lang/Cloneable;","Ljava/io/Serializable;"};
case "Ljava/util/Map;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/NoSuchElementException;": return new String[]{"Ljava/lang/RuntimeException;"};
case "Ljava/util/Objects;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/Queue;": return new String[]{"Ljava/lang/Object;","Ljava/util/Collection;"};
case "Ljava/util/RandomAccess;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/concurrent/AbstractExecutorService;": return new String[]{"Ljava/lang/Object;","Ljava/util/concurrent/ExecutorService;"};
case "Ljava/util/concurrent/BlockingQueue;": return new String[]{"Ljava/lang/Object;","Ljava/util/Queue;"};
case "Ljava/util/concurrent/ConcurrentLinkedDeque;": return new String[]{"Ljava/util/AbstractCollection;","Ljava/util/Deque;","Ljava/io/Serializable;"};
case "Ljava/util/concurrent/Executor;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/concurrent/ExecutorService;": return new String[]{"Ljava/lang/Object;","Ljava/util/concurrent/Executor;"};
case "Ljava/util/concurrent/SynchronousQueue;": return new String[]{"Ljava/util/AbstractQueue;","Ljava/util/concurrent/BlockingQueue;","Ljava/io/Serializable;"};
case "Ljava/util/concurrent/ThreadFactory;": return new String[]{"Ljava/lang/Object;"};
case "Ljava/util/concurrent/ThreadPoolExecutor;": return new String[]{"Ljava/util/concurrent/AbstractExecutorService;"};
case "Ljava/util/concurrent/TimeUnit;": return new String[]{"Ljava/lang/Enum;"};
case "Ljava/util/concurrent/atomic/AtomicInteger;": return new String[]{"Ljava/lang/Number;","Ljava/io/Serializable;"};
case "Ljava/util/regex/Pattern;": return new String[]{"Ljava/lang/Object;","Ljava/io/Serializable;"};
default:return null;}}
 protected boolean hasDefaultMethods(String type){switch(type){
case "Ljava/lang/CharSequence;":return true;
case "Ljava/lang/Iterable;":return true;
case "Ljava/lang/reflect/AnnotatedElement;":return true;
case "Ljava/lang/reflect/Type;":return true;
case "Ljava/util/Collection;":return true;
case "Ljava/util/Iterator;":return true;
case "Ljava/util/List;":return true;
case "Ljava/util/Map;":return true;
default:return false;}}
 protected Object proxy(Instance source,String type){switch(source.type){
case "Lapp/revanced/extension/shared/Logger$LogLevel;":return new Source_7523b3dfcf6e9cce(this,source);
case "Lapp/revanced/extension/shared/ResourceType;":return new Source_30b7a0d747f1430f(this,source);
case "Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda0;":return new Source_27a213441bc2609e(this,source);
case "Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda1;":return new Source_ff325b9410f7ad20(this,source);
case "Lapp/revanced/extension/shared/StringRef;":return new Source_8a64502f5f0366f1(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda11;":return new Source_c6f73c647a22095c(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda12;":return new Source_97da4066bd739fb2(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;":return new Source_3f3d5393350478ab(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda14;":return new Source_44fc827439bc76fd(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;":return new Source_ef6ace58a01c915f(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;":return new Source_b0a3f6ebd0ef6eda(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda19;":return new Source_d8a36d7d8ce21f1e(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda20;":return new Source_297cb4519d0e35fa(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda21;":return new Source_51f82cb377d6f709(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda22;":return new Source_ed2ed15ecc8ac7f1(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;":return new Source_583c9901e1522f33(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;":return new Source_d0bc2b636d5ee94b(this,source);
case "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;":return new Source_a535b711d8747feb(this,source);
case "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;":return new Source_ce682bb1eb143741(this,source);
case "Lapp/revanced/extension/shared/settings/AppLanguage;":return new Source_bef7506f9e5f2e94(this,source);
case "Lapp/revanced/extension/shared/settings/BaseSettings$$ExternalSyntheticLambda0;":return new Source_223e5fe768737e7b(this,source);
case "Lapp/revanced/extension/shared/settings/BooleanSetting;":return new Source_053c9b94999db44f(this,source);
case "Lapp/revanced/extension/shared/settings/EnumSetting;":return new Source_ebb6a4acd04e8416(this,source);
case "Lapp/revanced/extension/shared/settings/FloatSetting;":return new Source_4618a44da73476a3(this,source);
case "Lapp/revanced/extension/shared/settings/IntegerSetting;":return new Source_8dfcf6ce14f90d7b(this,source);
case "Lapp/revanced/extension/shared/settings/LongSetting;":return new Source_8a92b8fa272aeaea(this,source);
case "Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;":return new Source_24c06b67a1f1a1cc(this,source);
case "Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda3;":return new Source_b97ff44eb35b8f21(this,source);
case "Lapp/revanced/extension/shared/settings/Setting$1;":return new Source_8b4c4cadf0482b15(this,source);
case "Lapp/revanced/extension/shared/settings/Setting$2;":return new Source_f95b77da5c8aa1ca(this,source);
case "Lapp/revanced/extension/shared/settings/Setting$3;":return new Source_79665f4ca0e6a344(this,source);
case "Lapp/revanced/extension/shared/settings/Setting$4;":return new Source_15944183166cc24e(this,source);
case "Lapp/revanced/extension/shared/settings/StringSetting;":return new Source_6071f2bc37956896(this,source);
case "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda0;":return new Source_91aaccb3908c857e(this,source);
case "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;":return new Source_55d067a69690dae1(this,source);
case "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;":return new Source_f16e5c4b0bb912bd(this,source);
case "Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;":return new Source_ccccd60ae8b41a16(this,source);
case "Lapp/revanced/extension/shared/spoof/ClientType;":return new Source_12150add592bdb8d(this,source);
case "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$DeArrowAvailability;":return new Source_a07b06d702917e44(this,source);
case "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$StillImagesAvailability;":return new Source_0dce8442be793112(this,source);
case "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;":return new Source_f3397e9af69ec3c2(this,source);
case "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;":return new Source_3fd6e167bd89e61d(this,source);
case "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;":return new Source_f34294fa42b07ded(this,source);
case "Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;":return new Source_680cffba1c4f1964(this,source);
case "Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$ChangeStartPageTypeAvailability;":return new Source_c454e2e008cd7727(this,source);
case "Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;":return new Source_33e252dd6782045d(this,source);
case "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;":return new Source_a132ee80c908c91c(this,source);
case "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;":return new Source_e5e8adc2cba94d2c(this,source);
case "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideOverlayButtonsAvailability;":return new Source_e3931ecf412b6e3b(this,source);
case "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideRewindOrOverlayOpacityAvailability;":return new Source_3a4f61ab95fd1c5b(this,source);
case "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideSubtextsAvailability;":return new Source_c6235261ff6a8712(this,source);
case "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHorizontalDragAvailability;":return new Source_15037f2b1a7a6384(this,source);
case "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;":return new Source_f8b2e462b46ee167(this,source);
case "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;":return new Source_4685a8b19c14e647(this,source);
case "Lapp/revanced/extension/youtube/patches/litho/PlayerFlyoutMenuItemsFilter$HideAudioFlyoutMenuAvailability;":return new Source_f5e92441ef86c060(this,source);
case "Lapp/revanced/extension/youtube/patches/spoof/SpoofVideoStreamsPatch$SpoofClientAv1Availability;":return new Source_159132c79c75bf69(this,source);
case "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;":return new Source_56535db281a49f5f(this,source);
case "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda0;":return new Source_fca4c8a4dba2495d(this,source);
case "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda1;":return new Source_9c0501ff5cac449e(this,source);
case "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda2;":return new Source_6aa96542e593de4d(this,source);
case "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda3;":return new Source_a1ff284cb003da86(this,source);
case "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;":return new Source_367790c6d20210ec(this,source);
case "Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$$ExternalSyntheticLambda5;":return new Source_22644240ba6c3ce9(this,source);
case "Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$1;":return new Source_42b0741da50e3a38(this,source);
case "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;":return new Source_56c07e7d87cd3353(this,source);
case "Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;":return new Source_e4671fd5213dde7c(this,source);
case "Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;":return new Source_df03f95cc38a5c68(this,source);
case "Lkotlin/collections/AbstractList$Companion;":return new Source_a75eb7ff037a4fb9(this,source);
case "Lkotlin/collections/AbstractList$IteratorImpl;":return new Source_6ea2e06564ab182f(this,source);
case "Lkotlin/collections/AbstractList$ListIteratorImpl;":return new Source_b1b54795e7b5f923(this,source);
case "Lkotlin/collections/AbstractList$SubList;":return new Source_2df84d76ede30468(this,source);
case "Lkotlin/enums/EnumEntriesList;":return new Source_e5f347db17d8082e(this,source);
default:break;} switch(type){
case "Ljava/io/Closeable;":return new Proxy_5d77620bc2db0d65(this,source);
case "Ljava/io/Flushable;":return new Proxy_97c87bc3aa9ae4c5(this,source);
case "Ljava/io/Serializable;":return new Proxy_44ee58b91d212a49(this,source);
case "Ljava/lang/Appendable;":return new Proxy_68422d511f1ca0c8(this,source);
case "Ljava/lang/AutoCloseable;":return new Proxy_9a0892293292960c(this,source);
case "Ljava/lang/CharSequence;":return new Proxy_75b0e7c6f1894060(this,source);
case "Ljava/lang/Cloneable;":return new Proxy_c306ca23baec0743(this,source);
case "Ljava/lang/Comparable;":return new Proxy_931efadc9226c870(this,source);
case "Ljava/lang/Iterable;":return new Proxy_fca47b82b05e4fd4(this,source);
case "Ljava/lang/Runnable;":return new Proxy_3382daff238827e1(this,source);
case "Ljava/util/Collection;":return new Proxy_c73b32c41931497e(this,source);
case "Ljava/util/Deque;":return new Proxy_3b120213e86fca9d(this,source);
case "Ljava/util/Iterator;":return new Proxy_4a4ebe7a6d7ab997(this,source);
case "Ljava/util/List;":return new Proxy_2571477d4b77d27c(this,source);
case "Ljava/util/ListIterator;":return new Proxy_f3180bebc61c6ee6(this,source);
case "Ljava/util/Map;":return new Proxy_ea411899534f2a5e(this,source);
case "Ljava/util/Queue;":return new Proxy_d8882623ab7ee8fe(this,source);
case "Ljava/util/RandomAccess;":return new Proxy_064ab43da97acb9e(this,source);
case "Ljava/util/concurrent/BlockingQueue;":return new Proxy_cb7ad88690968a68(this,source);
case "Ljava/util/concurrent/Executor;":return new Proxy_a2b90f18ded32793(this,source);
case "Ljava/util/concurrent/ExecutorService;":return new Proxy_11dd58280c928a82(this,source);
case "Ljava/util/concurrent/ThreadFactory;":return new Proxy_5b2f63edce0c9838(this,source);
default:return super.proxy(source,type);}}
}
