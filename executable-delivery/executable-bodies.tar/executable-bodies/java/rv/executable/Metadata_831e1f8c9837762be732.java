package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_831e1f8c9837762be732 {
static ClassInfo info_831e1f8c9837762be732() {return new ClassInfo("Lkotlin/Unit;", "Ljava/lang/Object;", new String[]{}, 17, new FieldInfo[]{new FieldInfo("Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;", "Lkotlin/Unit;", 25, ExecutableRuntime.zero("Lkotlin/Unit;"))}, new MethodInfo[]{new MethodInfo("<clinit>()V", 65544), new MethodInfo("<init>()V", 65537), new MethodInfo("toString()Ljava/lang/String;", 1)}, "Unit");}
}
