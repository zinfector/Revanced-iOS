package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_077a62a3602373627b5f {
static Value m_bc21ce5fcfe4e758ba33f1c5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord1;","Ljava/util/Objects;->hashCode(Ljava/lang/Object;)I",Value.NULL,new Value[]{r[0]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
