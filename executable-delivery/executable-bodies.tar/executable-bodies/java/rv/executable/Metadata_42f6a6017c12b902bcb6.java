package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_42f6a6017c12b902bcb6 {
static ClassInfo info_42f6a6017c12b902bcb6() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda26;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "VideoInformation$$ExternalSyntheticLambda26");}
}
