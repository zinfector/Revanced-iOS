package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_68422d511f1ca0c8 extends RuntimeForeign.SourceProxy implements java.lang.Appendable {
Proxy_68422d511f1ca0c8(RuntimeForeign owner,Instance source){super(owner,source);}
public java.lang.Appendable append(java.lang.CharSequence a0) {Value result=owner.callback(source,"Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;",new Value[]{owner.importValue(a0)}); return (java.lang.Appendable)owner.exportObject(result.o(),"Ljava/lang/Appendable;");}
public java.lang.Appendable append(java.lang.CharSequence a0,int a1,int a2) {Value result=owner.callback(source,"Ljava/lang/Appendable;->append(Ljava/lang/CharSequence;II)Ljava/lang/Appendable;",new Value[]{owner.importValue(a0),Value.i32(a1),Value.i32(a2)}); return (java.lang.Appendable)owner.exportObject(result.o(),"Ljava/lang/Appendable;");}
public java.lang.Appendable append(char a0) {Value result=owner.callback(source,"Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;",new Value[]{Value.i32(a0)}); return (java.lang.Appendable)owner.exportObject(result.o(),"Ljava/lang/Appendable;");}
}
