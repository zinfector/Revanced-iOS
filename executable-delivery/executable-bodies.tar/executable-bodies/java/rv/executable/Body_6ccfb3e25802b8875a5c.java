package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_6ccfb3e25802b8875a5c {
static Value m_3a757908cef7343d6ffb4846(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/Event;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/shared/Event;", "Ljava/lang/Object;-><init>()V", r[1], new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.allocate("Ljava/util/LinkedHashSet;"); pc = 2; continue; }
case 2: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/shared/Event;", "Ljava/util/LinkedHashSet;-><init>()V", r[0], new Value[]{}); pc = 3; continue; }
case 3: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/shared/Event;", "Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;", Value.NULL, new Value[]{r[0]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/shared/Event;->eventListeners:Ljava/util/Set;", r[1], false, r[0]); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_52075817321d108a1c2bb2f3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/Event;");
r[3] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/Event;->eventListeners:Ljava/util/Set;", r[2], false); pc = 1; continue; }
case 1: { result = rt.invoke("interface", "Lapp/revanced/extension/youtube/shared/Event;", "Ljava/util/Set;->iterator()Ljava/util/Iterator;", r[0], new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result = rt.invoke("interface", "Lapp/revanced/extension/youtube/shared/Event;", "Ljava/util/Iterator;->hasNext()Z", r[0], new Value[]{}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { pc = (ExecutableRuntime.equal(r[1], Value.i32(0))) ? 11 : 6; continue; }
case 6: { result = rt.invoke("interface", "Lapp/revanced/extension/youtube/shared/Event;", "Ljava/util/Iterator;->next()Ljava/lang/Object;", r[0], new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { r[1] = rt.cast(r[1], "Lkotlin/jvm/functions/Function1;"); pc = 9; continue; }
case 9: { result = rt.invoke("interface", "Lapp/revanced/extension/youtube/shared/Event;", "Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;", r[1], new Value[]{r[3]}); pc = 10; continue; }
case 10: { pc = 3; continue; }
case 11: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
