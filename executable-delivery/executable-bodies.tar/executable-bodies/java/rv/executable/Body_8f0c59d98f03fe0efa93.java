package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_8f0c59d98f03fe0efa93 {
static Value m_714f58675e8f2ef0b669cf83(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;");
r[1] = rt.check(arguments[0], "J"); r[2] = r[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;->f$0:J",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_623fc3c62269eecd0d8246cb(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;->f$0:J",r[2],false); r[1] = r[0]; pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;","Lapp/revanced/extension/youtube/patches/VideoInformation;->$r8$lambda$ydGFYi72i9uNA7kFDHK4N7oYMkc(J)Ljava/lang/String;",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
