package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_ff325b9410f7ad20 extends RuntimeForeign.SourceProxy {
Source_ff325b9410f7ad20(RuntimeForeign owner,Instance source){super(owner,source);}

}
