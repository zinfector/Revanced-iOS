package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_7aecc74a2da2c8c6f975 {
static Value m_7ec88caebe61b12355482607(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;");
r[1] = rt.check(arguments[0], "Landroid/app/Dialog;");
r[2] = rt.check(arguments[1], "Landroid/widget/LinearLayout;");
r[3] = rt.check(arguments[2], "Landroid/view/animation/Animation;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;->f$0:Landroid/app/Dialog;",r[0],false,r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;->f$1:Landroid/widget/LinearLayout;",r[0],false,r[2]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;->f$2:Landroid/view/animation/Animation;",r[0],false,r[3]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5d866dbe382c8364bda42ac3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;->f$0:Landroid/app/Dialog;",r[3],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;->f$1:Landroid/widget/LinearLayout;",r[3],false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;->f$2:Landroid/view/animation/Animation;",r[3],false); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->$r8$lambda$WofUY3uqZlsyThL8fNWGqJHcF4I(Landroid/app/Dialog;Landroid/widget/LinearLayout;Landroid/view/animation/Animation;)V",Value.NULL,new Value[]{r[0], r[1], r[2]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
