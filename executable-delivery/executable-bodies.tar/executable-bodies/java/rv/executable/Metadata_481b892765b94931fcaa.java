package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_481b892765b94931fcaa {
static ClassInfo info_481b892765b94931fcaa() {return new ClassInfo("Lkotlin/jvm/internal/CollectionToArray;", "Ljava/lang/Object;", new String[]{}, 1025, new FieldInfo[]{new FieldInfo("Lkotlin/jvm/internal/CollectionToArray;->EMPTY:[Ljava/lang/Object;", "[Ljava/lang/Object;", 25, ExecutableRuntime.zero("[Ljava/lang/Object;"))}, new MethodInfo[]{new MethodInfo("<clinit>()V", 65544), new MethodInfo("toArray(Ljava/util/Collection;)[Ljava/lang/Object;", 25), new MethodInfo("toArray(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;", 25)}, "CollectionToArray");}
}
