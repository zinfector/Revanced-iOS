package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_43633c29c739e5ca37d0 {
static Value m_ead3a828d63933bf70bb8f8f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
