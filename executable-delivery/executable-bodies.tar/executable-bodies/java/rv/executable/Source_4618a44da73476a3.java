package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_4618a44da73476a3 extends RuntimeForeign.SourceProxy {
Source_4618a44da73476a3(RuntimeForeign owner,Instance source){super(owner,source);}

}
