package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_7311cb618264216124cf {
static ClassInfo info_7311cb618264216124cf() {return new ClassInfo("Lapp/revanced/com/google/protobuf/Syntax$$ExternalSyntheticBUOutline0;", "Ljava/lang/Object;", new String[]{}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("m(Ljava/lang/String;)V", 4105)}, "Syntax$$ExternalSyntheticBUOutline0");}
}
