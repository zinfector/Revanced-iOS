package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_5d77620bc2db0d65 extends RuntimeForeign.SourceProxy implements java.io.Closeable {
Proxy_5d77620bc2db0d65(RuntimeForeign owner,Instance source){super(owner,source);}
public void close() {Value result=owner.callback(source,"Ljava/io/Closeable;->close()V",new Value[]{}); return;}
}
