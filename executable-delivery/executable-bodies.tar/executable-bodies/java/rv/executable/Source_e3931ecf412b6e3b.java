package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_e3931ecf412b6e3b extends RuntimeForeign.SourceProxy {
Source_e3931ecf412b6e3b(RuntimeForeign owner,Instance source){super(owner,source);}

}
