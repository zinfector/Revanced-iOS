package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_0ce37db08fc170ca4bb9 {
static ClassInfo info_0ce37db08fc170ca4bb9() {return new ClassInfo("Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda2;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Utils$MatchFilter;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("matches(Ljava/lang/Object;)Z", 17)}, "BaseActivityHook$$ExternalSyntheticLambda2");}
}
