package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_4a4ebe7a6d7ab997 extends RuntimeForeign.SourceProxy implements java.util.Iterator {
Proxy_4a4ebe7a6d7ab997(RuntimeForeign owner,Instance source){super(owner,source);}
public boolean hasNext() {Value result=owner.callback(source,"Ljava/util/Iterator;->hasNext()Z",new Value[]{}); return result.z();}
public java.lang.Object next() {Value result=owner.callback(source,"Ljava/util/Iterator;->next()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
}
