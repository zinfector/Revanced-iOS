package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_a535b711d8747feb extends RuntimeForeign.SourceProxy {
Source_a535b711d8747feb(RuntimeForeign owner,Instance source){super(owner,source);}

}
