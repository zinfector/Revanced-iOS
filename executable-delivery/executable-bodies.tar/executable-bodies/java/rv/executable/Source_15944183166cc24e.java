package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_15944183166cc24e extends RuntimeForeign.SourceProxy {
Source_15944183166cc24e(RuntimeForeign owner,Instance source){super(owner,source);}

}
