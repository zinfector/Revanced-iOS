package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_a75eb7ff037a4fb9 extends RuntimeForeign.SourceProxy {
Source_a75eb7ff037a4fb9(RuntimeForeign owner,Instance source){super(owner,source);}

}
