package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_c6f73c647a22095c1805 {
static ClassInfo info_c6f73c647a22095c1805() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda11;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
