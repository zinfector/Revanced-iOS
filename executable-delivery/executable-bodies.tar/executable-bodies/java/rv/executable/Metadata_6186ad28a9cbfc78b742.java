package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_6186ad28a9cbfc78b742 {
static ClassInfo info_6186ad28a9cbfc78b742() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton$$ExternalSyntheticLambda1;", "Ljava/lang/Object;", new String[]{"Landroid/view/View$OnClickListener;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("onClick(Landroid/view/View;)V", 17)}, "VotingButton$$ExternalSyntheticLambda1");}
}
