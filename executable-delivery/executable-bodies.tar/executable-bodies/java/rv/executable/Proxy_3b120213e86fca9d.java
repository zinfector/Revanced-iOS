package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_3b120213e86fca9d extends RuntimeForeign.SourceProxy implements java.util.Deque {
Proxy_3b120213e86fca9d(RuntimeForeign owner,Instance source){super(owner,source);}
public void addFirst(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->addFirst(Ljava/lang/Object;)V",new Value[]{owner.importValue(a0)}); return;}
public void addLast(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->addLast(Ljava/lang/Object;)V",new Value[]{owner.importValue(a0)}); return;}
public boolean offerFirst(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->offerFirst(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean offerLast(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->offerLast(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public java.lang.Object removeFirst() {Value result=owner.callback(source,"Ljava/util/Deque;->removeFirst()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object removeLast() {Value result=owner.callback(source,"Ljava/util/Deque;->removeLast()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object pollFirst() {Value result=owner.callback(source,"Ljava/util/Deque;->pollFirst()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object pollLast() {Value result=owner.callback(source,"Ljava/util/Deque;->pollLast()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object getFirst() {Value result=owner.callback(source,"Ljava/util/Deque;->getFirst()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object getLast() {Value result=owner.callback(source,"Ljava/util/Deque;->getLast()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object peekFirst() {Value result=owner.callback(source,"Ljava/util/Deque;->peekFirst()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object peekLast() {Value result=owner.callback(source,"Ljava/util/Deque;->peekLast()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public boolean removeFirstOccurrence(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->removeFirstOccurrence(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean removeLastOccurrence(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->removeLastOccurrence(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean add(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->add(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean offer(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->offer(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public java.lang.Object remove() {Value result=owner.callback(source,"Ljava/util/Deque;->remove()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object poll() {Value result=owner.callback(source,"Ljava/util/Deque;->poll()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object element() {Value result=owner.callback(source,"Ljava/util/Deque;->element()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object peek() {Value result=owner.callback(source,"Ljava/util/Deque;->peek()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public void push(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->push(Ljava/lang/Object;)V",new Value[]{owner.importValue(a0)}); return;}
public java.lang.Object pop() {Value result=owner.callback(source,"Ljava/util/Deque;->pop()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public boolean remove(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->remove(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean contains(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->contains(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int size() {Value result=owner.callback(source,"Ljava/util/Deque;->size()I",new Value[]{}); return result.i();}
public java.util.Iterator iterator() {Value result=owner.callback(source,"Ljava/util/Deque;->iterator()Ljava/util/Iterator;",new Value[]{}); return (java.util.Iterator)owner.exportObject(result.o(),"Ljava/util/Iterator;");}
public java.util.Iterator descendingIterator() {Value result=owner.callback(source,"Ljava/util/Deque;->descendingIterator()Ljava/util/Iterator;",new Value[]{}); return (java.util.Iterator)owner.exportObject(result.o(),"Ljava/util/Iterator;");}
public boolean isEmpty() {Value result=owner.callback(source,"Ljava/util/Deque;->isEmpty()Z",new Value[]{}); return result.z();}
public java.lang.Object[] toArray() {Value result=owner.callback(source,"Ljava/util/Deque;->toArray()[Ljava/lang/Object;",new Value[]{}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public java.lang.Object[] toArray(java.lang.Object[] a0) {Value result=owner.callback(source,"Ljava/util/Deque;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;",new Value[]{owner.importValue(a0)}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public boolean containsAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Deque;->containsAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean addAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Deque;->addAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean removeAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Deque;->removeAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean retainAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Deque;->retainAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public void clear() {Value result=owner.callback(source,"Ljava/util/Deque;->clear()V",new Value[]{}); return;}
public boolean equals(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Deque;->equals(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int hashCode() {Value result=owner.callback(source,"Ljava/util/Deque;->hashCode()I",new Value[]{}); return result.i();}
}
