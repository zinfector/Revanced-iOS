package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_e4671fd5213dde7ccea5 {
static Value m_a38f23fc83f2a774edf5f339(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->$VALUES:[Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Ljava/lang/Object;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_329836f8f9c3da6e6c4ff6a0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[15];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); pc = 1; continue; }
case 1: { r[7] = Value.i32(15); pc = 2; continue; }
case 2: { r[8] = Value.i32(0); pc = 3; continue; }
case 3: { r[1] = Value.ref("HORIZONTAL"); pc = 4; continue; }
case 4: { r[2] = Value.i32(0); pc = 5; continue; }
case 5: { r[3] = Value.i32(0); pc = 6; continue; }
case 6: { r[4] = Value.i32(0); pc = 7; continue; }
case 7: { r[5] = Value.i32(0); pc = 8; continue; }
case 8: { r[6] = Value.i32(0); pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;-><init>(Ljava/lang/String;IZZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->HORIZONTAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true,r[0]); pc = 11; continue; }
case 11: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); pc = 12; continue; }
case 12: { r[8] = Value.i32(14); pc = 13; continue; }
case 13: { r[9] = Value.i32(0); pc = 14; continue; }
case 14: { r[2] = Value.ref("HORIZONTAL_MINIMAL_TOP"); pc = 15; continue; }
case 15: { r[3] = Value.i32(1); pc = 16; continue; }
case 16: { r[4] = Value.i32(1); pc = 17; continue; }
case 17: { r[7] = Value.i32(0); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;-><init>(Ljava/lang/String;IZZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V",r[1],new Value[]{r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->HORIZONTAL_MINIMAL_TOP:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true,r[1]); pc = 20; continue; }
case 20: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); pc = 21; continue; }
case 21: { r[9] = Value.i32(12); pc = 22; continue; }
case 22: { r[10] = Value.i32(0); pc = 23; continue; }
case 23: { r[3] = Value.ref("HORIZONTAL_MINIMAL_CENTER"); pc = 24; continue; }
case 24: { r[4] = Value.i32(2); pc = 25; continue; }
case 25: { r[5] = Value.i32(1); pc = 26; continue; }
case 26: { r[6] = Value.i32(1); pc = 27; continue; }
case 27: { r[8] = Value.i32(0); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;-><init>(Ljava/lang/String;IZZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V",r[2],new Value[]{r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->HORIZONTAL_MINIMAL_CENTER:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true,r[2]); pc = 30; continue; }
case 30: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); pc = 31; continue; }
case 31: { r[10] = Value.i32(11); pc = 32; continue; }
case 32: { r[11] = Value.i32(0); pc = 33; continue; }
case 33: { r[4] = Value.ref("CIRCULAR"); pc = 34; continue; }
case 34: { r[5] = Value.i32(3); pc = 35; continue; }
case 35: { r[6] = Value.i32(0); pc = 36; continue; }
case 36: { r[8] = Value.i32(1); pc = 37; continue; }
case 37: { r[9] = Value.i32(0); pc = 38; continue; }
case 38: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;-><init>(Ljava/lang/String;IZZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V",r[3],new Value[]{r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11]}); pc = 39; continue; }
case 39: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->CIRCULAR:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true,r[3]); pc = 40; continue; }
case 40: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); pc = 41; continue; }
case 41: { r[11] = Value.i32(10); pc = 42; continue; }
case 42: { r[12] = Value.i32(0); pc = 43; continue; }
case 43: { r[5] = Value.ref("CIRCULAR_MINIMAL"); pc = 44; continue; }
case 44: { r[6] = Value.i32(4); pc = 45; continue; }
case 45: { r[7] = Value.i32(1); pc = 46; continue; }
case 46: { r[8] = Value.i32(0); pc = 47; continue; }
case 47: { r[9] = Value.i32(1); pc = 48; continue; }
case 48: { r[10] = Value.i32(0); pc = 49; continue; }
case 49: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;-><init>(Ljava/lang/String;IZZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V",r[4],new Value[]{r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12]}); pc = 50; continue; }
case 50: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->CIRCULAR_MINIMAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true,r[4]); pc = 51; continue; }
case 51: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); pc = 52; continue; }
case 52: { r[12] = Value.i32(7); pc = 53; continue; }
case 53: { r[13] = Value.i32(0); pc = 54; continue; }
case 54: { r[6] = Value.ref("VERTICAL"); pc = 55; continue; }
case 55: { r[7] = Value.i32(5); pc = 56; continue; }
case 56: { r[9] = Value.i32(0); pc = 57; continue; }
case 57: { r[11] = Value.i32(1); pc = 58; continue; }
case 58: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;-><init>(Ljava/lang/String;IZZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V",r[5],new Value[]{r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13]}); pc = 59; continue; }
case 59: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->VERTICAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true,r[5]); pc = 60; continue; }
case 60: { r[6] = rt.allocate("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); pc = 61; continue; }
case 61: { r[13] = Value.i32(6); pc = 62; continue; }
case 62: { r[14] = Value.i32(0); pc = 63; continue; }
case 63: { r[7] = Value.ref("VERTICAL_MINIMAL"); pc = 64; continue; }
case 64: { r[8] = Value.i32(6); pc = 65; continue; }
case 65: { r[9] = Value.i32(1); pc = 66; continue; }
case 66: { r[11] = Value.i32(0); pc = 67; continue; }
case 67: { r[12] = Value.i32(1); pc = 68; continue; }
case 68: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;-><init>(Ljava/lang/String;IZZZZILkotlin/jvm/internal/DefaultConstructorMarker;)V",r[6],new Value[]{r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14]}); pc = 69; continue; }
case 69: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->VERTICAL_MINIMAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true,r[6]); pc = 70; continue; }
case 70: { result=rt.invoke("static","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->$values()[Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,new Value[]{}); pc = 71; continue; }
case 71: { r[0] = result; pc = 72; continue; }
case 72: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->$VALUES:[Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true,r[0]); pc = 73; continue; }
case 73: { result=rt.invoke("static","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;",Value.NULL,new Value[]{r[0]}); pc = 74; continue; }
case 74: { r[0] = result; pc = 75; continue; }
case 75: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->$ENTRIES:Lkotlin/enums/EnumEntries;",Value.NULL,true,r[0]); pc = 76; continue; }
case 76: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3742368961a4eae1c5a497f4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 8) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[10];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "I");
r[4] = rt.check(arguments[2], "Z");
r[5] = rt.check(arguments[3], "Z");
r[6] = rt.check(arguments[4], "Z");
r[7] = rt.check(arguments[5], "Z");
r[8] = rt.check(arguments[6], "I");
r[9] = rt.check(arguments[7], "Lkotlin/jvm/internal/DefaultConstructorMarker;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[9] = Value.i32((r[8].i()) & (1)); pc = 1; continue; }
case 1: { r[0] = Value.i32(0); pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[9],Value.i32(0)))?4:3; continue; }
case 3: { r[4] = r[0]; pc = 4; continue; }
case 4: { r[9] = Value.i32((r[8].i()) & (2)); pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[9],Value.i32(0)))?7:6; continue; }
case 6: { r[5] = r[0]; pc = 7; continue; }
case 7: { r[9] = Value.i32((r[8].i()) & (4)); pc = 8; continue; }
case 8: { pc=(ExecutableRuntime.equal(r[9],Value.i32(0)))?10:9; continue; }
case 9: { r[6] = r[0]; pc = 10; continue; }
case 10: { r[8] = Value.i32((r[8].i()) & (8)); pc = 11; continue; }
case 11: { pc=(ExecutableRuntime.equal(r[8],Value.i32(0)))?20:12; continue; }
case 12: { r[8] = r[0]; pc = 13; continue; }
case 13: { r[7] = r[6]; pc = 14; continue; }
case 14: { r[6] = r[5]; pc = 15; continue; }
case 15: { r[5] = r[4]; pc = 16; continue; }
case 16: { r[4] = r[3]; pc = 17; continue; }
case 17: { r[3] = r[2]; pc = 18; continue; }
case 18: { r[2] = r[1]; pc = 19; continue; }
case 19: { pc=22; continue; }
case 20: { r[8] = r[7]; pc = 21; continue; }
case 21: { pc=13; continue; }
case 22: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;-><init>(Ljava/lang/String;IZZZZ)V",r[2],new Value[]{r[3], r[4], r[5], r[6], r[7], r[8]}); pc = 23; continue; }
case 23: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fcf57d7f78933cc2ef7d7619(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->HORIZONTAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->HORIZONTAL_MINIMAL_TOP:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->HORIZONTAL_MINIMAL_CENTER:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->CIRCULAR:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->CIRCULAR_MINIMAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->VERTICAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true); pc = 6; continue; }
case 6: { r[6] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->VERTICAL_MINIMAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",Value.NULL,true); pc = 7; continue; }
case 7: { result=rt.filledArray("[Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;",new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e19f6ff6f6838cc3b5e4b8b8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 6) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Z");
r[5] = rt.check(arguments[4], "Z");
r[6] = rt.check(arguments[5], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->isMinimal:Z",r[0],false,r[3]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->isHorizontalMinimalCenter:Z",r[0],false,r[4]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->isCircular:Z",r[0],false,r[5]); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->isVertical:Z",r[0],false,r[6]); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
