package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_0dce8442be793112 extends RuntimeForeign.SourceProxy {
Source_0dce8442be793112(RuntimeForeign owner,Instance source){super(owner,source);}

}
