package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_244f4feaa46fb984c788 {
static Value m_59057362d7980fa3ce77e431(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/requests/Route$CompiledRoute;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/requests/Route;");
r[2] = rt.check(arguments[1], "Ljava/lang/String;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/shared/requests/Route-IA;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route$CompiledRoute;","Lapp/revanced/extension/shared/requests/Route$CompiledRoute;-><init>(Lapp/revanced/extension/shared/requests/Route;Ljava/lang/String;)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b52b324c74693ec096fd33fa(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/requests/Route$CompiledRoute;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/requests/Route$CompiledRoute;->compiledRoute:Ljava/lang/String;",r[1],false); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c68d723f8f006441caa67ca5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/requests/Route$CompiledRoute;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/requests/Route$CompiledRoute;->baseRoute:Lapp/revanced/extension/shared/requests/Route;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Route$CompiledRoute;","Lapp/revanced/extension/shared/requests/Route;->-$$Nest$fgetmethod(Lapp/revanced/extension/shared/requests/Route;)Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Lapp/revanced/extension/shared/requests/Route$Method;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_52748732c782a3d296806be3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/requests/Route$CompiledRoute;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/requests/Route;");
r[2] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route$CompiledRoute;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/requests/Route$CompiledRoute;->baseRoute:Lapp/revanced/extension/shared/requests/Route;",r[0],false,r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/requests/Route$CompiledRoute;->compiledRoute:Ljava/lang/String;",r[0],false,r[2]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
