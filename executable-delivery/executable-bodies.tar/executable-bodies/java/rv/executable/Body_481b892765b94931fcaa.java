package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_481b892765b94931fcaa {
static Value m_b2ee6aa56470ea8481e20ff1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[4] = rt.check(arguments[0], "Ljava/util/Collection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[4],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Collection;->size()I",r[4],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?6:4; continue; }
case 4: { r[4] = rt.readField("Lkotlin/jvm/internal/CollectionToArray;->EMPTY:[Ljava/lang/Object;",Value.NULL,true); pc = 5; continue; }
case 5: { return rt.check(r[4],"[Ljava/lang/Object;"); }
case 6: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Collection;->iterator()Ljava/util/Iterator;",r[4],new Value[]{}); pc = 7; continue; }
case 7: { r[4] = result; pc = 8; continue; }
case 8: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Iterator;->hasNext()Z",r[4],new Value[]{}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?13:11; continue; }
case 11: { r[4] = rt.readField("Lkotlin/jvm/internal/CollectionToArray;->EMPTY:[Ljava/lang/Object;",Value.NULL,true); pc = 12; continue; }
case 12: { return rt.check(r[4],"[Ljava/lang/Object;"); }
case 13: { r[0] = rt.newArray("[Ljava/lang/Object;",r[0].i()); pc = 14; continue; }
case 14: { r[1] = Value.i32(0); pc = 15; continue; }
case 15: { r[2] = Value.i32((r[1].i()) + (1)); pc = 16; continue; }
case 16: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[4],new Value[]{}); pc = 17; continue; }
case 17: { r[3] = result; pc = 18; continue; }
case 18: { rt.arrayPut(r[0],r[1].i(),r[3]); pc = 19; continue; }
case 19: { r[1] = Value.i32(rt.length(r[0])); pc = 20; continue; }
case 20: { pc=(r[2].i() < r[1].i())?39:21; continue; }
case 21: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Iterator;->hasNext()Z",r[4],new Value[]{}); pc = 22; continue; }
case 22: { r[1] = result; pc = 23; continue; }
case 23: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?25:24; continue; }
case 24: { return rt.check(r[0],"[Ljava/lang/Object;"); }
case 25: { r[1] = Value.i32((r[2].i()) * (3)); pc = 26; continue; }
case 26: { r[1] = Value.i32((r[1].i()) + (1)); pc = 27; continue; }
case 27: { r[1] = Value.i32((r[1].i()) >>> (1)); pc = 28; continue; }
case 28: { pc=(r[1].i() > r[2].i())?35:29; continue; }
case 29: { r[1] = Value.i32(2147483645); pc = 30; continue; }
case 30: { pc=(r[2].i() >= r[1].i())?32:31; continue; }
case 31: { pc=35; continue; }
case 32: { r[4] = rt.allocate("Ljava/lang/OutOfMemoryError;"); pc = 33; continue; }
case 33: { result=rt.invoke("direct","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/OutOfMemoryError;-><init>()V",r[4],new Value[]{}); pc = 34; continue; }
case 34: { ExecutableRuntime.raise(r[4].o()); throw new AssertionError("Unreachable throw"); }
case 35: { result=rt.invoke("static","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;",Value.NULL,new Value[]{r[0], r[1]}); pc = 36; continue; }
case 36: { r[0] = result; pc = 37; continue; }
case 37: { r[1] = r[2]; pc = 38; continue; }
case 38: { pc=15; continue; }
case 39: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Iterator;->hasNext()Z",r[4],new Value[]{}); pc = 40; continue; }
case 40: { r[1] = result; pc = 41; continue; }
case 41: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?37:42; continue; }
case 42: { result=rt.invoke("static","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;",Value.NULL,new Value[]{r[0], r[2]}); pc = 43; continue; }
case 43: { r[4] = result; pc = 44; continue; }
case 44: { return rt.check(r[4],"[Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ccf1f96f0444dd7143a829f0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { r[0] = rt.newArray("[Ljava/lang/Object;",r[0].i()); pc = 2; continue; }
case 2: { rt.writeField("Lkotlin/jvm/internal/CollectionToArray;->EMPTY:[Ljava/lang/Object;",Value.NULL,true,r[0]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1fa2028a568a2153c53af45b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[5] = rt.check(arguments[0], "Ljava/util/Collection;");
r[6] = rt.check(arguments[1], "[Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[5],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[6],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Collection;->size()I",r[5],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[1] = Value.i32(0); pc = 5; continue; }
case 5: { r[2] = Value.i32(0); pc = 6; continue; }
case 6: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?11:7; continue; }
case 7: { r[5] = Value.i32(rt.length(r[6])); pc = 8; continue; }
case 8: { pc=(r[5].i() <= 0)?19:9; continue; }
case 9: { rt.arrayPut(r[6],r[2].i(),r[1]); pc = 10; continue; }
case 10: { return rt.check(r[6],"[Ljava/lang/Object;"); }
case 11: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Collection;->iterator()Ljava/util/Iterator;",r[5],new Value[]{}); pc = 12; continue; }
case 12: { r[5] = result; pc = 13; continue; }
case 13: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Iterator;->hasNext()Z",r[5],new Value[]{}); pc = 14; continue; }
case 14: { r[3] = result; pc = 15; continue; }
case 15: { pc=(!ExecutableRuntime.equal(r[3],Value.i32(0)))?20:16; continue; }
case 16: { r[5] = Value.i32(rt.length(r[6])); pc = 17; continue; }
case 17: { pc=(r[5].i() <= 0)?19:18; continue; }
case 18: { rt.arrayPut(r[6],r[2].i(),r[1]); pc = 19; continue; }
case 19: { return rt.check(r[6],"[Ljava/lang/Object;"); }
case 20: { r[3] = Value.i32(rt.length(r[6])); pc = 21; continue; }
case 21: { pc=(r[0].i() > r[3].i())?24:22; continue; }
case 22: { r[0] = r[6]; pc = 23; continue; }
case 23: { pc=32; continue; }
case 24: { result=rt.invoke("virtual","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[6],new Value[]{}); pc = 25; continue; }
case 25: { r[3] = result; pc = 26; continue; }
case 26: { result=rt.invoke("virtual","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/Class;->getComponentType()Ljava/lang/Class;",r[3],new Value[]{}); pc = 27; continue; }
case 27: { r[3] = result; pc = 28; continue; }
case 28: { result=rt.invoke("static","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;",Value.NULL,new Value[]{r[3], r[0]}); pc = 29; continue; }
case 29: { r[0] = result; pc = 30; continue; }
case 30: { result=rt.invoke("virtual","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[0],new Value[]{}); pc = 31; continue; }
case 31: { r[0] = rt.cast(r[0],"[Ljava/lang/Object;"); pc = 32; continue; }
case 32: { r[3] = Value.i32((r[2].i()) + (1)); pc = 33; continue; }
case 33: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[5],new Value[]{}); pc = 34; continue; }
case 34: { r[4] = result; pc = 35; continue; }
case 35: { rt.arrayPut(r[0],r[2].i(),r[4]); pc = 36; continue; }
case 36: { r[2] = Value.i32(rt.length(r[0])); pc = 37; continue; }
case 37: { pc=(r[3].i() < r[2].i())?56:38; continue; }
case 38: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Iterator;->hasNext()Z",r[5],new Value[]{}); pc = 39; continue; }
case 39: { r[2] = result; pc = 40; continue; }
case 40: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?42:41; continue; }
case 41: { return rt.check(r[0],"[Ljava/lang/Object;"); }
case 42: { r[2] = Value.i32((r[3].i()) * (3)); pc = 43; continue; }
case 43: { r[2] = Value.i32((r[2].i()) + (1)); pc = 44; continue; }
case 44: { r[2] = Value.i32((r[2].i()) >>> (1)); pc = 45; continue; }
case 45: { pc=(r[2].i() > r[3].i())?52:46; continue; }
case 46: { r[2] = Value.i32(2147483645); pc = 47; continue; }
case 47: { pc=(r[3].i() >= r[2].i())?49:48; continue; }
case 48: { pc=52; continue; }
case 49: { r[5] = rt.allocate("Ljava/lang/OutOfMemoryError;"); pc = 50; continue; }
case 50: { result=rt.invoke("direct","Lkotlin/jvm/internal/CollectionToArray;","Ljava/lang/OutOfMemoryError;-><init>()V",r[5],new Value[]{}); pc = 51; continue; }
case 51: { ExecutableRuntime.raise(r[5].o()); throw new AssertionError("Unreachable throw"); }
case 52: { result=rt.invoke("static","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;",Value.NULL,new Value[]{r[0], r[2]}); pc = 53; continue; }
case 53: { r[0] = result; pc = 54; continue; }
case 54: { r[2] = r[3]; pc = 55; continue; }
case 55: { pc=32; continue; }
case 56: { result=rt.invoke("interface","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Iterator;->hasNext()Z",r[5],new Value[]{}); pc = 57; continue; }
case 57: { r[2] = result; pc = 58; continue; }
case 58: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?54:59; continue; }
case 59: { pc=(!ExecutableRuntime.equal(r[0],r[6]))?62:60; continue; }
case 60: { rt.arrayPut(r[6],r[3].i(),r[1]); pc = 61; continue; }
case 61: { return rt.check(r[6],"[Ljava/lang/Object;"); }
case 62: { result=rt.invoke("static","Lkotlin/jvm/internal/CollectionToArray;","Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;",Value.NULL,new Value[]{r[0], r[3]}); pc = 63; continue; }
case 63: { r[5] = result; pc = 64; continue; }
case 64: { return rt.check(r[5],"[Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
