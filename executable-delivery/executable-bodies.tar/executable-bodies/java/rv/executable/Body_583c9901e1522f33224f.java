package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_583c9901e1522f33224f {
static Value m_0f533d2341ae262ff8bd7ea3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new VerifyError("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;");
r[1] = rt.check(arguments[0], "Ljava/lang/Runnable;");
r[2] = rt.check(arguments[1], "Ljava/lang/Exception;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;->f$0:Ljava/lang/Runnable;", r[0], false, r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;->f$1:Ljava/lang/Exception;", r[0], false, r[2]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_95e4860bda427e3ca538647b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;->f$0:Ljava/lang/Runnable;", r[2], false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;->f$1:Ljava/lang/Exception;", r[2], false); pc = 2; continue; }
case 2: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;", "Lapp/revanced/extension/shared/Utils;->$r8$lambda$jKtTIITmJaChn7ffOXGIB6aU-QE(Ljava/lang/Runnable;Ljava/lang/Exception;)Ljava/lang/String;", Value.NULL, new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
