package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_6d4fab3e7017e47449a0 {
static Value m_442ed6b763e6bbae7c35a3da(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
r[2] = rt.check(arguments[0], "Ljava/util/Collection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[2] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[0] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a61f3652f55dc2b76f7f67dd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[3] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
r[4] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("interface","Lkotlin/collections/AbstractCollection;","Ljava/util/Collection;->isEmpty()Z",r[3],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:4; continue; }
case 4: { return rt.check(r[1],"Z"); }
case 5: { result=rt.invoke("interface","Lkotlin/collections/AbstractCollection;","Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;",r[3],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { result=rt.invoke("interface","Lkotlin/collections/AbstractCollection;","Ljava/util/Iterator;->hasNext()Z",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?17:10; continue; }
case 10: { result=rt.invoke("interface","Lkotlin/collections/AbstractCollection;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[0],new Value[]{}); pc = 11; continue; }
case 11: { r[2] = result; pc = 12; continue; }
case 12: { result=rt.invoke("static","Lkotlin/collections/AbstractCollection;","Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z",Value.NULL,new Value[]{r[2], r[4]}); pc = 13; continue; }
case 13: { r[2] = result; pc = 14; continue; }
case 14: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?7:15; continue; }
case 15: { r[4] = Value.i32(1); pc = 16; continue; }
case 16: { return rt.check(r[4],"Z"); }
case 17: { return rt.check(r[1],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cca0dc6f6387adb09fc06c99(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
r[3] = rt.check(arguments[0], "Ljava/util/Collection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractCollection;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[3],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("interface","Lkotlin/collections/AbstractCollection;","Ljava/util/Collection;->isEmpty()Z",r[3],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[1] = Value.i32(1); pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?6:5; continue; }
case 5: { return rt.check(r[1],"Z"); }
case 6: { result=rt.invoke("interface","Lkotlin/collections/AbstractCollection;","Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;",r[3],new Value[]{}); pc = 7; continue; }
case 7: { r[3] = result; pc = 8; continue; }
case 8: { result=rt.invoke("interface","Lkotlin/collections/AbstractCollection;","Ljava/util/Iterator;->hasNext()Z",r[3],new Value[]{}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?18:11; continue; }
case 11: { result=rt.invoke("interface","Lkotlin/collections/AbstractCollection;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[3],new Value[]{}); pc = 12; continue; }
case 12: { r[0] = result; pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lkotlin/collections/AbstractCollection;","Lkotlin/collections/AbstractCollection;->contains(Ljava/lang/Object;)Z",r[2],new Value[]{r[0]}); pc = 14; continue; }
case 14: { r[0] = result; pc = 15; continue; }
case 15: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?8:16; continue; }
case 16: { r[3] = Value.i32(0); pc = 17; continue; }
case 17: { return rt.check(r[3],"Z"); }
case 18: { return rt.check(r[1],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_db5d125705a36a23c73f3117(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[2] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[0] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5da831ec899a49e9209d2168(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
r[2] = rt.check(arguments[0], "Ljava/util/Collection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[2] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[0] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e3bf432bfbff641d90625db6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
r[2] = rt.check(arguments[0], "Ljava/util/Collection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[2] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[0] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_12933a8753c809d8a0483319(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lkotlin/collections/AbstractCollection;","Lkotlin/jvm/internal/CollectionToArray;->toArray(Ljava/util/Collection;)[Ljava/lang/Object;",Value.NULL,new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"[Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d63ef89e8ca06424338f4d49(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[2] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[0] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2230d511186f289a87381faf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractCollection;","Lkotlin/collections/AbstractCollection;->size()I",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?5:3; continue; }
case 3: { r[0] = Value.i32(1); pc = 4; continue; }
case 4: { return rt.check(r[0],"Z"); }
case 5: { r[0] = Value.i32(0); pc = 6; continue; }
case 6: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_eb89ac4dfb93d6649ef38313(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractCollection;","Lkotlin/collections/AbstractCollection;->getSize()I",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a2496941aecdb49469aed5ed(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[0].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_53ded30c8edc216be7720fba(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
r[1] = rt.check(arguments[0], "[Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractCollection;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[1],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lkotlin/collections/AbstractCollection;","Lkotlin/jvm/internal/CollectionToArray;->toArray(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;",Value.NULL,new Value[]{r[0], r[1]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { return rt.check(r[1],"[Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_519a21e2db0132c270ef5928(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2c1a8b5e7d9b1bd4d9ed48e3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[10];
r[9] = rt.check(receiver, "Lkotlin/collections/AbstractCollection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[6] = rt.allocate("Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection;","Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;-><init>(Lkotlin/collections/AbstractCollection;)V",r[6],new Value[]{r[9]}); pc = 2; continue; }
case 2: { r[7] = Value.i32(24); pc = 3; continue; }
case 3: { r[8] = Value.i32(0); pc = 4; continue; }
case 4: { r[1] = Value.ref(", "); pc = 5; continue; }
case 5: { r[2] = Value.ref("["); pc = 6; continue; }
case 6: { r[3] = Value.ref("]"); pc = 7; continue; }
case 7: { r[4] = Value.i32(0); pc = 8; continue; }
case 8: { r[5] = Value.i32(0); pc = 9; continue; }
case 9: { r[0] = r[9]; pc = 10; continue; }
case 10: { result=rt.invoke("static","Lkotlin/collections/AbstractCollection;","Lkotlin/collections/CollectionsKt___CollectionsKt;->joinToString$default(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Lkotlin/jvm/functions/Function1;ILjava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8]}); pc = 11; continue; }
case 11: { r[1] = result; pc = 12; continue; }
case 12: { return rt.check(r[1],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2f561058beef3f9f89a00cf8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Lkotlin/collections/AbstractCollection;");
r[1] = rt.check(arguments[1], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[1],r[0]))?3:1; continue; }
case 1: { r[0] = Value.ref("(this Collection)"); pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/lang/CharSequence;"); }
case 3: { result=rt.invoke("static","Lkotlin/collections/AbstractCollection;","Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[1]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { return rt.check(r[0],"Ljava/lang/CharSequence;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
