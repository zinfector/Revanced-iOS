package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_1d5e16de9d752ac4f6d6 {
static Value m_903c7206169a18a5e7a1fa58(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/VideoState$Companion;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[2],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/youtube/shared/VideoState;->access$getNameToVideoState$cp()Ljava/util/Map;",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 6; continue; }
case 6: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?11:7; continue; }
case 7: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda0;"); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[2]}); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 10; continue; }
case 10: { return Value.VOID; }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/youtube/shared/VideoState;->access$getCurrentVideoState$cp()Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,new Value[]{}); pc = 12; continue; }
case 12: { r[2] = result; pc = 13; continue; }
case 13: { pc=(ExecutableRuntime.equal(r[2],r[0]))?18:14; continue; }
case 14: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;"); pc = 15; continue; }
case 15: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;-><init>(Lapp/revanced/extension/youtube/shared/VideoState;)V",r[2],new Value[]{r[0]}); pc = 16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 17; continue; }
case 17: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/youtube/shared/VideoState;->access$setCurrentVideoState$cp(Lapp/revanced/extension/youtube/shared/VideoState;)V",Value.NULL,new Value[]{r[0]}); pc = 18; continue; }
case 18: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_bb3ab385ac4cffef20d4815c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/VideoState$Companion;");
r[1] = rt.check(arguments[0], "Lkotlin/jvm/internal/DefaultConstructorMarker;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/youtube/shared/VideoState$Companion;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_eeaba67f631e20ee2c082b22(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/VideoState$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Lapp/revanced/extension/youtube/shared/VideoState;->access$getCurrentVideoState$cp()Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/VideoState;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_af824bdcaa5a800d57e4b87f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/VideoState$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_74b44fe9d549982b013dd37d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/VideoState;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("VideoState changed to: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a991ba5625c0dc2607e19c00(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Unknown VideoState encountered: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState$Companion;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
