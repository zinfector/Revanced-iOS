package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_c306ca23baec0743 extends RuntimeForeign.SourceProxy implements java.lang.Cloneable {
Proxy_c306ca23baec0743(RuntimeForeign owner,Instance source){super(owner,source);}

}
