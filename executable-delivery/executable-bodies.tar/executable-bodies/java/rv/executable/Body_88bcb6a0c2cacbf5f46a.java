package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_88bcb6a0c2cacbf5f46a {
static Value m_4805aa3424cfa4046147686a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Ljava/lang/Iterable;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lkotlin/collections/CollectionsKt__IterablesKt;", "Ljava/lang/Object;->getClass()Ljava/lang/Class;", r[1], new Value[]{}); pc = 1; continue; }
case 1: { r[0] = Value.i32(rt.isInstance(r[1].o(), "Ljava/util/Collection;") ? 1 : 0); pc = 2; continue; }
case 2: { pc = (ExecutableRuntime.equal(r[0], Value.i32(0))) ? 7 : 3; continue; }
case 3: { r[1] = rt.cast(r[1], "Ljava/util/Collection;"); pc = 4; continue; }
case 4: { result = rt.invoke("interface", "Lkotlin/collections/CollectionsKt__IterablesKt;", "Ljava/util/Collection;->size()I", r[1], new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { return rt.check(r[1], "I"); }
case 7: { return rt.check(r[2], "I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
