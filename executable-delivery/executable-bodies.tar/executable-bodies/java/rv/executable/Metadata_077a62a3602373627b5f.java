package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_077a62a3602373627b5f {
static ClassInfo info_077a62a3602373627b5f() {return new ClassInfo("Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord1;", "Ljava/lang/Object;", new String[]{}, 5121, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("m(Ljava/lang/Object;)I", 4105)}, "YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord1");}
}
