package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_095a546f728046baeff0 {
static ClassInfo info_095a546f728046baeff0() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buttonEnabled()Z", 17)}, "CreateSegmentButton$$ExternalSyntheticLambda0");}
}
