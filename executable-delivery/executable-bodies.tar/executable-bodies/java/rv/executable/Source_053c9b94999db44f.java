package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_053c9b94999db44f extends RuntimeForeign.SourceProxy {
Source_053c9b94999db44f(RuntimeForeign owner,Instance source){super(owner,source);}

}
