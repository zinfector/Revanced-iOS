package rv.executable;

import java.util.*;
import rv.executable.ExecutableRuntime.*;
import rv.executable.RuntimeForeign.*;

/** Android API compatibility contracts backed by platform services, not patches. */
final class AndroidOperations {
    static final class ResourceNotFoundException extends RuntimeException {
        ResourceNotFoundException(String message){super(message);}
    }
    static boolean knownType(String type){
        switch(type){case "Landroid/content/Context;":case "Landroid/content/SharedPreferences;":case "Landroid/content/SharedPreferences$Editor;":
            case "Landroid/content/pm/PackageManager;":case "Landroid/content/pm/PackageManager$PackageInfoFlags;":case "Landroid/content/pm/PackageInfo;":
            case "Landroid/content/res/Resources;":case "Landroid/content/res/Resources$NotFoundException;":case "Landroid/content/res/Configuration;":case "Landroid/os/LocaleList;":
            case "Landroid/os/Handler;":case "Landroid/os/Looper;":case "Landroid/widget/Toast;":
            case "Landroid/os/Build;":case "Landroid/os/Build$VERSION;":case "Landroid/graphics/Color;":case "Landroid/util/Log;":
            case "Landroid/util/Range;":case "Landroid/text/TextUtils;":return true;default:return false;}
    }
    static String[] parents(String type){return new String[]{type.equals("Landroid/content/res/Resources$NotFoundException;")?"Ljava/lang/RuntimeException;":"Ljava/lang/Object;"};}
    static String type(Object object){
        if(object instanceof ClosedRange)return "Landroid/util/Range;";
        if(object instanceof ResourceNotFoundException)return "Landroid/content/res/Resources$NotFoundException;";
        if(object instanceof Context)return "Landroid/content/Context;";if(object instanceof Preferences)return "Landroid/content/SharedPreferences;";
        if(object instanceof Editor)return "Landroid/content/SharedPreferences$Editor;";if(object instanceof Handler)return "Landroid/os/Handler;";
        if(object instanceof Looper)return "Landroid/os/Looper;";if(object instanceof PackageManager)return "Landroid/content/pm/PackageManager;";
        if(object instanceof PackageFlags)return "Landroid/content/pm/PackageManager$PackageInfoFlags;";if(object instanceof PackageInfo)return "Landroid/content/pm/PackageInfo;";
        if(object instanceof Resources)return "Landroid/content/res/Resources;";
        if(object instanceof Configuration)return "Landroid/content/res/Configuration;";
        if(object instanceof LocaleList)return "Landroid/os/LocaleList;";
        if(object instanceof Toast)return "Landroid/widget/Toast;";return null;
    }
    static String metadata(RuntimeForeign owner,String key){String value=owner.services.metadata(key);if(value==null)throw new MissingOperation("metadata:"+key);return value;}
    static Value field(RuntimeForeign owner,String field,Value receiver){
        if(field.startsWith("Landroid/content/res/Configuration;->")){
            Configuration config=(Configuration)Objects.requireNonNull(receiver.o());
            if(!config.initialized)throw new InvalidProgram("Configuration field before initialization");
            String name=field.substring(field.indexOf("->")+2,field.indexOf(':'));
            if(name.equals("locale"))return Value.ref(config.locale);
            Integer value=config.numbers.get(name);
            if(value==null)throw new MissingOperation("configuration-field:"+name);
            return Value.i32(value);
        }
        if(field.equals("Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;"))return Value.ref(((PackageInfo)receiver.o()).version);
        if(field.startsWith("Landroid/os/Build")){
            String name=field.substring(field.indexOf("->")+2,field.indexOf(':'));
            String value=metadata(owner,"compat.build."+name);return field.endsWith(":I")?Value.i32(Integer.parseInt(value)):Value.ref(value);
        }
        throw new MissingOperation("field:"+field);
    }
    static Value call(RuntimeForeign owner,String method,Value receiver,Value[] args)throws Throwable {
        if(method.startsWith("Landroid/util/Range;->"))return range(owner,method.split("->",2)[1],receiver,args);
        if(method.startsWith("Landroid/text/TextUtils;->")){
            CharSequence first=(CharSequence)owner.exportObject(args[0].o(),"Ljava/lang/CharSequence;");
            if(method.endsWith("join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;")){
                Iterable<?> values=(Iterable<?>)Objects.requireNonNull(owner.exportObject(args[1].o(),"Ljava/lang/Iterable;"));
                StringBuilder joined=new StringBuilder();boolean started=false;
                for(Object value:values){if(started)joined.append(first);joined.append(value);started=true;}
                return Value.ref(joined.toString());
            }
            if(method.endsWith("isEmpty(Ljava/lang/CharSequence;)Z"))return Value.i32(first==null || first.length()==0?1:0);
            if(method.endsWith("equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z")){
                CharSequence second=(CharSequence)owner.exportObject(args[1].o(),"Ljava/lang/CharSequence;");
                if(first==second)return Value.i32(1);if(first==null || second==null || first.length()!=second.length())return Value.i32(0);
                for(int i=0;i<first.length();i++)if(first.charAt(i)!=second.charAt(i))return Value.i32(0);
                return Value.i32(1);
            }
            throw new MissingOperation(method);
        }
        if(method.equals("Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V")){
            owner.construct(receiver,new ResourceNotFoundException((String)args[0].o()));return Value.VOID;
        }
        if(method.startsWith("Landroid/graphics/Color;"))return color(method.substring(method.indexOf("->")+2),args);
        if(method.startsWith("Landroid/util/Log;")){
            String name=method.substring(method.indexOf("->")+2,method.indexOf('('));int level=name.equals("e")?6:name.equals("i")?4:name.equals("d")?3:name.equals("w")?5:name.equals("v")?2:-1;
            if(level<0)throw new MissingOperation(method);
            Object error=args.length>2?owner.exportObject(args[2].o(),"Ljava/lang/Throwable;"):null;
            if(error!=null && !(error instanceof Throwable))throw new MissingOperation("log-throwable-representation");
            return Value.i32(owner.services.log(level,(String)args[0].o(),(String)args[1].o(),(Throwable)error));
        }
        if(method.startsWith("Landroid/content/Context;")){
            Objects.requireNonNull(receiver.o());String signature=method.split("->",2)[1];
            switch(signature){
                case "getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;":if(args[1].i()!=0)throw new MissingOperation("preferences-mode:"+args[1].i());return Value.ref(owner.preferences((String)args[0].o()));
                case "getPackageName()Ljava/lang/String;":return Value.ref(metadata(owner,"source.packageName"));
                case "getPackageManager()Landroid/content/pm/PackageManager;":return Value.ref(owner.packageManager);
                case "getResources()Landroid/content/res/Resources;":return Value.ref(((Context)receiver.o()).resources);
                case "createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;":
                    return Value.ref(new Context(new Resources((Configuration)Objects.requireNonNull(args[0].o()))));
                default:throw new MissingOperation(method);
            }
        }
        if(method.equals("Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V")){
            Configuration target=(Configuration)Objects.requireNonNull(receiver.o());
            Configuration source=new Configuration((Configuration)Objects.requireNonNull(args[0].o()));
            if(target.initialized)throw new InvalidProgram("Configuration initialized twice");
            target.locale=source.locale;target.numbers.putAll(source.numbers);target.initialized=true;return Value.VOID;
        }
        if(method.equals("Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V")){
            Configuration config=(Configuration)Objects.requireNonNull(receiver.o());
            if(!config.initialized)throw new InvalidProgram("Configuration locale before initialization");
            Locale locale=(Locale)owner.exportObject(args[0].o(),"Ljava/util/Locale;");
            config.locale=locale==null?null:(Locale)locale.clone();return Value.VOID;
        }
        if(method.equals("Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;")){
            Configuration config=(Configuration)Objects.requireNonNull(receiver.o());
            if(!config.initialized)throw new InvalidProgram("Configuration locales before initialization");
            return Value.ref(new LocaleList(config.locale));
        }
        if(method.startsWith("Landroid/os/LocaleList;->")){
            LocaleList list=(LocaleList)Objects.requireNonNull(receiver.o());
            switch(method.split("->",2)[1]){
                case "get(I)Ljava/util/Locale;":int index=args[0].i();return Value.ref(index>=0 && index<list.locales.length?list.locales[index]:null);
                case "size()I":return Value.i32(list.locales.length);
                case "isEmpty()Z":return Value.i32(list.locales.length==0?1:0);
                default:throw new MissingOperation(method);
            }
        }
        if(method.equals("Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;")){
            Resources resources=(Resources)Objects.requireNonNull(receiver.o());
            synchronized(resources){
                if(resources.configuration==null){
                    Configuration config=new Configuration();String tag=metadata(owner,"source.locale");
                    config.locale=Locale.forLanguageTag(tag);
                    if(config.locale.getLanguage().isEmpty())throw new MissingOperation("configuration-locale:"+tag);
                    for(String name:new String[]{"orientation","smallestScreenWidthDp","densityDpi","uiMode"}){
                        String value=owner.services.metadata("source.configuration."+name);
                        if(value!=null)config.numbers.put(name,Integer.parseInt(value));
                    }
                    config.initialized=true;resources.configuration=config;
                }
                return Value.ref(resources.configuration);
            }
        }
        if(method.equals("Landroid/content/res/Resources;->getColor(I)I")){
            Objects.requireNonNull(receiver.o());return Value.i32(owner.services.resourceColor(args[0].i()));
        }
        if(method.equals("Landroid/content/pm/PackageManager$PackageInfoFlags;->of(J)Landroid/content/pm/PackageManager$PackageInfoFlags;"))return Value.ref(new PackageFlags(args[0].j()));
        if(method.startsWith("Landroid/content/pm/PackageManager;->getPackageInfo(")){
            Objects.requireNonNull(receiver.o());String name=(String)args[0].o();long flags=args[1].kind==1?args[1].i():((PackageFlags)args[1].o()).bits;
            if(flags!=0)throw new MissingOperation("package-info-flags:"+flags);
            if(!metadata(owner,"source.packageName").equals(name))throw new MissingOperation("package-info:"+name);
            return Value.ref(new PackageInfo(metadata(owner,"source.versionName")));
        }
        if(method.startsWith("Landroid/content/SharedPreferences$Editor;")){
            Editor editor=(Editor)Objects.requireNonNull(receiver.o());String signature=method.split("->",2)[1];
            if(signature.equals("commit()Z"))return Value.i32(editor.commit()?1:0);
            String key=(String)args[0].o();String value;
            if(signature.startsWith("remove("))value=null;
            else if(signature.startsWith("putBoolean("))value="Z:"+(args[1].z()?"1":"0");
            else if(signature.startsWith("putString("))value=args[1].o()==null?null:"S:"+(String)args[1].o();
            else if(signature.startsWith("putInt("))value="I:"+args[1].i();
            else if(signature.startsWith("putLong("))value="J:"+args[1].j();
            else if(signature.startsWith("putFloat("))value="F:"+args[1].i();
            else throw new MissingOperation(method);
            return Value.ref(editor.put(key,value));
        }
        if(method.startsWith("Landroid/content/SharedPreferences;")){
            Preferences prefs=(Preferences)Objects.requireNonNull(receiver.o());String signature=method.split("->",2)[1];
            if(signature.equals("edit()Landroid/content/SharedPreferences$Editor;"))return Value.ref(new Editor(prefs));
            String key=Objects.requireNonNull((String)args[0].o()),stored=prefs.read(key);if(stored==null)return args[1];
            String expected=signature.startsWith("getBoolean(")?"Z:":signature.startsWith("getString(")?"S:":signature.startsWith("getFloat(")?"F:":signature.startsWith("getLong(")?"J:":signature.startsWith("getInt(")?"I:":null;
            if(expected==null)throw new MissingOperation(method);if(!stored.startsWith(expected))throw new ClassCastException("Preference type: "+key);
            String value=stored.substring(2);switch(expected){case "Z:":return Value.i32(value.equals("1")?1:0);case "I:":case "F:":return Value.i32(Integer.parseInt(value));case "J:":return Value.i64(Long.parseLong(value));default:return Value.ref(value);}
        }
        if(method.equals("Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;"))return Value.ref(owner.mainLooper());
        if(method.equals("Landroid/os/Looper;->isCurrentThread()Z")){Objects.requireNonNull(receiver.o());return Value.i32(owner.services.isMainThread()?1:0);}
        if(method.equals("Landroid/os/Handler;-><init>(Landroid/os/Looper;)V")){Handler handler=(Handler)receiver.o();if(args[0].o()!=owner.mainLooper())throw new MissingOperation("non-main-looper");handler.looper=owner.mainLooper();return Value.VOID;}
        if(method.equals("Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z")){
            Handler handler=(Handler)Objects.requireNonNull(receiver.o());if(handler.looper==null)throw new InvalidProgram("Handler not initialized");
            Runnable callback=(Runnable)owner.exportObject(args[0].o(),"Ljava/lang/Runnable;");Objects.requireNonNull(callback);
            return Value.i32(owner.services.postMain(callback,Math.max(0,args[1].j()))?1:0);
        }
        if(method.equals("Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I")){
            Objects.requireNonNull(receiver.o());return Value.i32(owner.services.resourceIdentifier((String)args[0].o(),(String)args[1].o(),(String)args[2].o()));
        }
        if(method.equals("Landroid/content/res/Resources;->getString(I)Ljava/lang/String;")){
            Resources resources=(Resources)Objects.requireNonNull(receiver.o());
            String locale=resources.configuration==null?metadata(owner,"source.locale"):resources.configuration.locale.toLanguageTag();
            return Value.ref(owner.services.resourceString(args[0].i(),locale));
        }
        if(method.equals("Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;")){
            Objects.requireNonNull(args[0].o());CharSequence message=(CharSequence)Objects.requireNonNull(owner.exportObject(args[1].o(),"Ljava/lang/CharSequence;"));return Value.ref(new Toast(message.toString(),args[2].i()));
        }
        if(method.equals("Landroid/widget/Toast;->show()V")){Toast toast=(Toast)Objects.requireNonNull(receiver.o());owner.services.toast(toast.message,toast.duration);return Value.VOID;}
        throw new MissingOperation(method);
    }
    /** Inclusive immutable bounds, with original Comparable callbacks retained.
     * Only enumerated API signatures route here. Other Range operations hold.
     * Contract source: Android framework android.util.Range / TextUtils. */
    static final class ClosedRange {
        final Comparable lower,upper;
        ClosedRange(Comparable lower,Comparable upper){
            this.lower=Objects.requireNonNull(lower);this.upper=Objects.requireNonNull(upper);
            if(lower.compareTo(upper)>0)throw new IllegalArgumentException("lower must be less than or equal to upper");
        }
        ClosedRange extend(ClosedRange other){
            int lo=other.lower.compareTo(lower),hi=other.upper.compareTo(upper);
            if(lo<=0 && hi>=0)return other;if(lo>=0 && hi<=0)return this;
            return new ClosedRange(lo>=0?lower:other.lower,hi<=0?upper:other.upper);
        }
        public boolean equals(Object other){return other==this || other instanceof ClosedRange && lower.equals(((ClosedRange)other).lower) && upper.equals(((ClosedRange)other).upper);}
        public String toString(){return "["+lower+", "+upper+"]";}
    }
    private static Comparable comparable(RuntimeForeign owner,Value value){return (Comparable)Objects.requireNonNull(owner.exportObject(value.o(),"Ljava/lang/Comparable;"));}
    private static ClosedRange closedRange(RuntimeForeign owner,Value value){return (ClosedRange)Objects.requireNonNull(owner.exportObject(value.o(),"Landroid/util/Range;"));}
    private static Value range(RuntimeForeign owner,String method,Value receiver,Value[] args){
        if(method.equals("<init>(Ljava/lang/Comparable;Ljava/lang/Comparable;)V")){
            owner.construct(receiver,new ClosedRange(comparable(owner,args[0]),comparable(owner,args[1])));return Value.VOID;
        }
        if(method.equals("create(Ljava/lang/Comparable;Ljava/lang/Comparable;)Landroid/util/Range;"))return owner.importValue(new ClosedRange(comparable(owner,args[0]),comparable(owner,args[1])));
        ClosedRange self=closedRange(owner,receiver);
        switch(method){
            case "getLower()Ljava/lang/Comparable;":return owner.importValue(self.lower);
            case "getUpper()Ljava/lang/Comparable;":return owner.importValue(self.upper);
            case "contains(Ljava/lang/Comparable;)Z":{Comparable value=comparable(owner,args[0]);return Value.i32(value.compareTo(self.lower)>=0 && value.compareTo(self.upper)<=0?1:0);}
            case "contains(Landroid/util/Range;)Z":{ClosedRange other=closedRange(owner,args[0]);return Value.i32(other.lower.compareTo(self.lower)>=0 && other.upper.compareTo(self.upper)<=0?1:0);}
            case "extend(Landroid/util/Range;)Landroid/util/Range;":return owner.importValue(self.extend(closedRange(owner,args[0])));
            case "extend(Ljava/lang/Comparable;Ljava/lang/Comparable;)Landroid/util/Range;":{
                Comparable lower=comparable(owner,args[0]),upper=comparable(owner,args[1]);int lo=lower.compareTo(self.lower),hi=upper.compareTo(self.upper);
                return owner.importValue(lo>=0 && hi<=0?self:new ClosedRange(lo>=0?self.lower:lower,hi<=0?self.upper:upper));}
            case "extend(Ljava/lang/Comparable;)Landroid/util/Range;":{Comparable value=comparable(owner,args[0]);return owner.importValue(self.extend(new ClosedRange(value,value)));}
            case "clamp(Ljava/lang/Comparable;)Ljava/lang/Comparable;":{Comparable value=comparable(owner,args[0]);return owner.importValue(value.compareTo(self.lower)<0?self.lower:value.compareTo(self.upper)>0?self.upper:value);}
            case "intersect(Landroid/util/Range;)Landroid/util/Range;":{ClosedRange other=closedRange(owner,args[0]);int lo=other.lower.compareTo(self.lower),hi=other.upper.compareTo(self.upper);
                if(lo<=0 && hi>=0)return receiver;if(lo>=0 && hi<=0)return args[0];return owner.importValue(new ClosedRange(lo>=0?other.lower:self.lower,hi<=0?other.upper:self.upper));}
            case "equals(Ljava/lang/Object;)Z":return Value.i32(self.equals(owner.exportObject(args[0].o(),"Ljava/lang/Object;"))?1:0);
            case "toString()Ljava/lang/String;":return Value.ref(self.toString());
            default:throw new MissingOperation("Range."+method);
        }
    }
    private static Value color(String signature,Value[] args){
        switch(signature){case "red(I)I":return Value.i32((args[0].i()>>>16)&255);case "green(I)I":return Value.i32((args[0].i()>>>8)&255);case "blue(I)I":return Value.i32(args[0].i()&255);
            case "argb(IIII)I":return Value.i32((args[0].i()<<24)|(args[1].i()<<16)|(args[2].i()<<8)|args[3].i());
            case "parseColor(Ljava/lang/String;)I":
                String text=(String)args[0].o();if(text.startsWith("#")){
                    if(text.length()!=7 && text.length()!=9)throw new IllegalArgumentException("Unknown color");
                    long parsed=Long.parseLong(text.substring(1),16);if(text.length()==7)parsed|=0xff000000L;return Value.i32((int)parsed);
                }
                String[] names={"black","darkgray","gray","lightgray","white","red","green","blue","yellow","cyan","magenta","aqua","fuchsia","darkgrey","grey","lightgrey","lime","maroon","navy","olive","purple","silver","teal"};
                int[] rgb={0,0x444444,0x888888,0xcccccc,0xffffff,0xff0000,0x00ff00,0x0000ff,0xffff00,0x00ffff,0xff00ff,0x00ffff,0xff00ff,0x444444,0x888888,0xcccccc,0x00ff00,0x800000,0x000080,0x808000,0x800080,0xc0c0c0,0x008080};
                for(int i=0;i<names.length;i++)if(names[i].equals(text.toLowerCase(Locale.ROOT)))return Value.i32(0xff000000|rgb[i]);throw new IllegalArgumentException("Unknown color");
            default:throw new MissingOperation("Color."+signature);
        }
    }
}
