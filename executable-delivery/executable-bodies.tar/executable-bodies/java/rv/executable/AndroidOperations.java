package rv.executable;

import java.util.*;
import rv.executable.ExecutableRuntime.*;
import rv.executable.RuntimeForeign.*;

/** Android API compatibility contracts backed by platform services, not patches. */
final class AndroidOperations {
    static boolean knownType(String type){
        switch(type){case "Landroid/content/Context;":case "Landroid/content/SharedPreferences;":case "Landroid/content/SharedPreferences$Editor;":
            case "Landroid/content/pm/PackageManager;":case "Landroid/content/pm/PackageManager$PackageInfoFlags;":case "Landroid/content/pm/PackageInfo;":
            case "Landroid/content/res/Resources;":case "Landroid/os/Handler;":case "Landroid/os/Looper;":case "Landroid/widget/Toast;":
            case "Landroid/os/Build;":case "Landroid/os/Build$VERSION;":case "Landroid/graphics/Color;":case "Landroid/util/Log;":return true;default:return false;}
    }
    static String[] parents(String type){return new String[]{"Ljava/lang/Object;"};}
    static String type(Object object){
        if(object instanceof Context)return "Landroid/content/Context;";if(object instanceof Preferences)return "Landroid/content/SharedPreferences;";
        if(object instanceof Editor)return "Landroid/content/SharedPreferences$Editor;";if(object instanceof Handler)return "Landroid/os/Handler;";
        if(object instanceof Looper)return "Landroid/os/Looper;";if(object instanceof PackageManager)return "Landroid/content/pm/PackageManager;";
        if(object instanceof PackageFlags)return "Landroid/content/pm/PackageManager$PackageInfoFlags;";if(object instanceof PackageInfo)return "Landroid/content/pm/PackageInfo;";
        if(object instanceof Resources)return "Landroid/content/res/Resources;";if(object instanceof Toast)return "Landroid/widget/Toast;";return null;
    }
    static String metadata(RuntimeForeign owner,String key){String value=owner.services.metadata(key);if(value==null)throw new MissingOperation("metadata:"+key);return value;}
    static Value field(RuntimeForeign owner,String field,Value receiver){
        if(field.equals("Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;"))return Value.ref(((PackageInfo)receiver.o()).version);
        if(field.startsWith("Landroid/os/Build")){
            String name=field.substring(field.indexOf("->")+2,field.indexOf(':'));
            String value=metadata(owner,"compat.build."+name);return field.endsWith(":I")?Value.i32(Integer.parseInt(value)):Value.ref(value);
        }
        throw new MissingOperation("field:"+field);
    }
    static Value call(RuntimeForeign owner,String method,Value receiver,Value[] args)throws Throwable {
        if(method.startsWith("Landroid/graphics/Color;"))return color(method.substring(method.indexOf("->")+2),args);
        if(method.startsWith("Landroid/util/Log;")){
            String name=method.substring(method.indexOf("->")+2,method.indexOf('('));int level=name.equals("e")?6:name.equals("i")?4:name.equals("d")?3:name.equals("w")?5:name.equals("v")?2:-1;
            if(level<0)throw new MissingOperation(method);
            Object error=args.length>2?owner.exportObject(args[2].o(),"Ljava/lang/Throwable;"):null;
            if(error!=null && !(error instanceof Throwable))throw new MissingOperation("log-throwable-representation");
            return Value.i32(owner.services.log(level,(String)args[0].o(),(String)args[1].o(),(Throwable)error));
        }
        if(method.startsWith("Landroid/content/Context;")){
            Objects.requireNonNull(receiver.o());String signature=method.split("->",2)[1];
            switch(signature){
                case "getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;":if(args[1].i()!=0)throw new MissingOperation("preferences-mode:"+args[1].i());return Value.ref(owner.preferences((String)args[0].o()));
                case "getPackageName()Ljava/lang/String;":return Value.ref(metadata(owner,"source.packageName"));
                case "getPackageManager()Landroid/content/pm/PackageManager;":return Value.ref(owner.packageManager);
                case "getResources()Landroid/content/res/Resources;":return Value.ref(owner.resources);
                default:throw new MissingOperation(method);
            }
        }
        if(method.equals("Landroid/content/pm/PackageManager$PackageInfoFlags;->of(J)Landroid/content/pm/PackageManager$PackageInfoFlags;"))return Value.ref(new PackageFlags(args[0].j()));
        if(method.startsWith("Landroid/content/pm/PackageManager;->getPackageInfo(")){
            Objects.requireNonNull(receiver.o());String name=(String)args[0].o();long flags=args[1].kind==1?args[1].i():((PackageFlags)args[1].o()).bits;
            if(flags!=0)throw new MissingOperation("package-info-flags:"+flags);
            if(!metadata(owner,"source.packageName").equals(name))throw new MissingOperation("package-info:"+name);
            return Value.ref(new PackageInfo(metadata(owner,"source.versionName")));
        }
        if(method.startsWith("Landroid/content/SharedPreferences$Editor;")){
            Editor editor=(Editor)Objects.requireNonNull(receiver.o());String signature=method.split("->",2)[1];
            if(signature.equals("commit()Z"))return Value.i32(editor.commit()?1:0);
            String key=(String)args[0].o();String value;
            if(signature.startsWith("remove("))value=null;
            else if(signature.startsWith("putBoolean("))value="Z:"+(args[1].z()?"1":"0");
            else if(signature.startsWith("putString("))value=args[1].o()==null?null:"S:"+(String)args[1].o();
            else if(signature.startsWith("putInt("))value="I:"+args[1].i();
            else if(signature.startsWith("putLong("))value="J:"+args[1].j();
            else if(signature.startsWith("putFloat("))value="F:"+args[1].i();
            else throw new MissingOperation(method);
            return Value.ref(editor.put(key,value));
        }
        if(method.startsWith("Landroid/content/SharedPreferences;")){
            Preferences prefs=(Preferences)Objects.requireNonNull(receiver.o());String signature=method.split("->",2)[1];
            if(signature.equals("edit()Landroid/content/SharedPreferences$Editor;"))return Value.ref(new Editor(prefs));
            String key=Objects.requireNonNull((String)args[0].o()),stored=prefs.read(key);if(stored==null)return args[1];
            String expected=signature.startsWith("getBoolean(")?"Z:":signature.startsWith("getString(")?"S:":signature.startsWith("getFloat(")?"F:":signature.startsWith("getLong(")?"J:":signature.startsWith("getInt(")?"I:":null;
            if(expected==null)throw new MissingOperation(method);if(!stored.startsWith(expected))throw new ClassCastException("Preference type: "+key);
            String value=stored.substring(2);switch(expected){case "Z:":return Value.i32(value.equals("1")?1:0);case "I:":case "F:":return Value.i32(Integer.parseInt(value));case "J:":return Value.i64(Long.parseLong(value));default:return Value.ref(value);}
        }
        if(method.equals("Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;"))return Value.ref(owner.mainLooper());
        if(method.equals("Landroid/os/Looper;->isCurrentThread()Z")){Objects.requireNonNull(receiver.o());return Value.i32(owner.services.isMainThread()?1:0);}
        if(method.equals("Landroid/os/Handler;-><init>(Landroid/os/Looper;)V")){Handler handler=(Handler)receiver.o();if(args[0].o()!=owner.mainLooper())throw new MissingOperation("non-main-looper");handler.looper=owner.mainLooper();return Value.VOID;}
        if(method.equals("Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z")){
            Handler handler=(Handler)Objects.requireNonNull(receiver.o());if(handler.looper==null)throw new InvalidProgram("Handler not initialized");
            Runnable callback=(Runnable)owner.exportObject(args[0].o(),"Ljava/lang/Runnable;");Objects.requireNonNull(callback);
            return Value.i32(owner.services.postMain(callback,Math.max(0,args[1].j()))?1:0);
        }
        if(method.equals("Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I")){
            Objects.requireNonNull(receiver.o());return Value.i32(owner.services.resourceIdentifier((String)args[0].o(),(String)args[1].o(),(String)args[2].o()));
        }
        if(method.equals("Landroid/content/res/Resources;->getString(I)Ljava/lang/String;")){Objects.requireNonNull(receiver.o());return Value.ref(owner.services.resourceString(args[0].i()));}
        if(method.equals("Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;")){
            Objects.requireNonNull(args[0].o());CharSequence message=(CharSequence)Objects.requireNonNull(owner.exportObject(args[1].o(),"Ljava/lang/CharSequence;"));return Value.ref(new Toast(message.toString(),args[2].i()));
        }
        if(method.equals("Landroid/widget/Toast;->show()V")){Toast toast=(Toast)Objects.requireNonNull(receiver.o());owner.services.toast(toast.message,toast.duration);return Value.VOID;}
        throw new MissingOperation(method);
    }
    private static Value color(String signature,Value[] args){
        switch(signature){case "red(I)I":return Value.i32((args[0].i()>>>16)&255);case "green(I)I":return Value.i32((args[0].i()>>>8)&255);case "blue(I)I":return Value.i32(args[0].i()&255);
            case "argb(IIII)I":return Value.i32((args[0].i()<<24)|(args[1].i()<<16)|(args[2].i()<<8)|args[3].i());
            case "parseColor(Ljava/lang/String;)I":
                String text=(String)args[0].o();if(text.startsWith("#")){
                    if(text.length()!=7 && text.length()!=9)throw new IllegalArgumentException("Unknown color");
                    long parsed=Long.parseLong(text.substring(1),16);if(text.length()==7)parsed|=0xff000000L;return Value.i32((int)parsed);
                }
                String[] names={"black","darkgray","gray","lightgray","white","red","green","blue","yellow","cyan","magenta","aqua","fuchsia","darkgrey","grey","lightgrey","lime","maroon","navy","olive","purple","silver","teal"};
                int[] rgb={0,0x444444,0x888888,0xcccccc,0xffffff,0xff0000,0x00ff00,0x0000ff,0xffff00,0x00ffff,0xff00ff,0x00ffff,0xff00ff,0x444444,0x888888,0xcccccc,0x00ff00,0x800000,0x000080,0x808000,0x800080,0xc0c0c0,0x008080};
                for(int i=0;i<names.length;i++)if(names[i].equals(text.toLowerCase(Locale.ROOT)))return Value.i32(0xff000000|rgb[i]);throw new IllegalArgumentException("Unknown color");
            default:throw new MissingOperation("Color."+signature);
        }
    }
}
