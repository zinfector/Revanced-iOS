package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_a2349c31c71e7c6042c2 {
static ClassInfo info_a2349c31c71e7c6042c2() {return new ClassInfo("Lkotlin/collections/CollectionsKt__IteratorsKt;", "Lkotlin/collections/CollectionsKt__IteratorsJVMKt;", new String[]{}, 1025, new FieldInfo[]{}, new MethodInfo[]{}, "CollectionsKt__IteratorsKt");}
}
