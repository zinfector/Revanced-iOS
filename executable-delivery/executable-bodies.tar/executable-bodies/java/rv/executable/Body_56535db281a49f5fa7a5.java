package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_56535db281a49f5fa7a5 {
static Value m_bca80a766b02c169692110e2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->$VALUES:[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 1; continue; }
case 1: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->clone()Ljava/lang/Object;", r[0], new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0], "[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 4; continue; }
case 4: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c8b7c9f5e24ee601cac534e1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("DISABLED"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->DISABLED:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("FPS_60_ONE_SECOND"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_ONE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("FPS_60_TWO_SECOND"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_TWO_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 15; continue; }
case 15: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 16; continue; }
case 16: { r[1] = Value.ref("FPS_60_FIVE_SECOND"); pc = 17; continue; }
case 17: { r[2] = Value.i32(3); pc = 18; continue; }
case 18: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_FIVE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 21; continue; }
case 21: { r[1] = Value.ref("FPS_60_BLACK_AND_WHITE"); pc = 22; continue; }
case 22: { r[2] = Value.i32(4); pc = 23; continue; }
case 23: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_BLACK_AND_WHITE:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 25; continue; }
case 25: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 26; continue; }
case 26: { r[1] = Value.ref("FPS_30_ONE_SECOND"); pc = 27; continue; }
case 27: { r[2] = Value.i32(5); pc = 28; continue; }
case 28: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_30_ONE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 30; continue; }
case 30: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 31; continue; }
case 31: { r[1] = Value.ref("FPS_30_TWO_SECOND"); pc = 32; continue; }
case 32: { r[2] = Value.i32(6); pc = 33; continue; }
case 33: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 34; continue; }
case 34: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_30_TWO_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 35; continue; }
case 35: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 36; continue; }
case 36: { r[1] = Value.ref("FPS_30_FIVE_SECOND"); pc = 37; continue; }
case 37: { r[2] = Value.i32(7); pc = 38; continue; }
case 38: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 39; continue; }
case 39: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_30_FIVE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 40; continue; }
case 40: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); pc = 41; continue; }
case 41: { r[1] = Value.ref("FPS_30_BLACK_AND_WHITE"); pc = 42; continue; }
case 42: { r[2] = Value.i32(8); pc = 43; continue; }
case 43: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[2]}); pc = 44; continue; }
case 44: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_30_BLACK_AND_WHITE:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 45; continue; }
case 45: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->$values()[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, new Value[]{}); pc = 46; continue; }
case 46: { r[0] = result; pc = 47; continue; }
case 47: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->$VALUES:[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true, r[0]); pc = 48; continue; }
case 48: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3da70d3f9b986640037f3228(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->style:I", r[0], false, r[3]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6eed2e7af6aff81621ce6c34(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->DISABLED:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_ONE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_TWO_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_FIVE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_BLACK_AND_WHITE:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_30_ONE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 6; continue; }
case 6: { r[6] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_30_TWO_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 7; continue; }
case 7: { r[7] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_30_FIVE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 8; continue; }
case 8: { r[8] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_30_BLACK_AND_WHITE:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 9; continue; }
case 9: { result = rt.filledArray("[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8]}); pc = 10; continue; }
case 10: { r[0] = result; pc = 11; continue; }
case 11: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
