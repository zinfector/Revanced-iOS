package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_7f9567bef928310b5514 {
static ClassInfo info_7f9567bef928310b5514() {return new ClassInfo("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Landroid/view/View$OnClickListener;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$$ExternalSyntheticLambda0;->f$0:Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;", "Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;)V", 69633), new MethodInfo("onClick(Landroid/view/View;)V", 17)}, "SearchHistoryManager$$ExternalSyntheticLambda0");}
}
