package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_70de28661cb47f4a82ea {
static ClassInfo info_70de28661cb47f4a82ea() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda5;", "Ljava/lang/Object;", new String[]{"Landroid/view/View$OnClickListener;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("onClick(Landroid/view/View;)V", 17)}, "SponsorBlockViewController$$ExternalSyntheticLambda5");}
}
