package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_fb2cff6286d661a1 extends RuntimeForeign.SourceProxy {
Source_fb2cff6286d661a1(RuntimeForeign owner,Instance source){super(owner,source);}

}
