package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_847cf4edd5079cce4397 {
static ClassInfo info_847cf4edd5079cce4397() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda7;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SBRequester$$ExternalSyntheticLambda7");}
}
