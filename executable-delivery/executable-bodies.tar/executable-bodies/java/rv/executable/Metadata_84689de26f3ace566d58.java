package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_84689de26f3ace566d58 {
static ClassInfo info_84689de26f3ace566d58() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch;", "Ljava/lang/Object;", new String[]{}, 1, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("onShortsCreate(Landroid/view/View;)V", 9), new MethodInfo("setPlayerType(Ljava/lang/Enum;)V", 9), new MethodInfo("setVideoState(Ljava/lang/Enum;)V", 9)}, "PlayerTypeHookPatch");}
}
