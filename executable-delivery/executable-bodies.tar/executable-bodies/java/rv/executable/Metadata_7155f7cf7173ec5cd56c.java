package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_7155f7cf7173ec5cd56c {
static ClassInfo info_7155f7cf7173ec5cd56c() {return new ClassInfo("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;", "Ljava/lang/Object;", new String[]{"Ljava/lang/Runnable;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;->f$0:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;", "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;)V", 69633), new MethodInfo("run()V", 17)}, "PlayerControlButton$$ExternalSyntheticLambda4");}
}
