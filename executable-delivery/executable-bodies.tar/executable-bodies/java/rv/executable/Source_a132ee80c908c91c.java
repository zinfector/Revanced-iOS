package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_a132ee80c908c91c extends RuntimeForeign.SourceProxy implements java.io.Serializable,java.lang.Comparable {
Source_a132ee80c908c91c(RuntimeForeign owner,Instance source){super(owner,source);}
public int compareTo(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I",new Value[]{owner.importValue(a0)}); return result.i();}
}
