package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_8d0dfc0c4b01cd96dde5 {
static Value m_d763338617254789efddae75(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(1); pc = 1; continue; }
case 1: { pc = (ExecutableRuntime.equal(r[3], Value.i32(0))) ? 3 : 2; continue; }
case 2: { return rt.check(r[0], "Z"); }
case 3: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/BackgroundPlaybackPatch;", "Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->isOpen()Z", Value.NULL, new Value[]{}); pc = 4; continue; }
case 4: { r[3] = result; pc = 5; continue; }
case 5: { r[1] = Value.i32(0); pc = 6; continue; }
case 6: { pc = (ExecutableRuntime.equal(r[3], Value.i32(0))) ? 8 : 7; continue; }
case 7: { return rt.check(r[1], "Z"); }
case 8: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/BackgroundPlaybackPatch;", "Lapp/revanced/extension/youtube/shared/PlayerType;->getCurrent()Lapp/revanced/extension/youtube/shared/PlayerType;", Value.NULL, new Value[]{}); pc = 9; continue; }
case 9: { r[3] = result; pc = 10; continue; }
case 10: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/patches/BackgroundPlaybackPatch;", "Lapp/revanced/extension/youtube/shared/PlayerType;->isNoneOrHidden()Z", r[3], new Value[]{}); pc = 11; continue; }
case 11: { r[2] = result; pc = 12; continue; }
case 12: { pc = (!ExecutableRuntime.equal(r[2], Value.i32(0))) ? 16 : 13; continue; }
case 13: { r[2] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->INLINE_MINIMAL:Lapp/revanced/extension/youtube/shared/PlayerType;", Value.NULL, true); pc = 14; continue; }
case 14: { pc = (ExecutableRuntime.equal(r[3], r[2])) ? 16 : 15; continue; }
case 15: { return rt.check(r[0], "Z"); }
case 16: { return rt.check(r[1], "Z"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
