package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_6071f2bc37956896 extends RuntimeForeign.SourceProxy {
Source_6071f2bc37956896(RuntimeForeign owner,Instance source){super(owner,source);}

}
