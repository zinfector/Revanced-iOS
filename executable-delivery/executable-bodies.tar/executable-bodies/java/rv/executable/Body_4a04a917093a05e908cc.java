package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_4a04a917093a05e908cc {
static Value m_b804d277075c5a4ef7ee86b4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?7:1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->isSearchActive()Z",r[1],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?7:4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->closeSearch()V",r[1],new Value[]{}); pc = 5; continue; }
case 5: { r[1] = Value.i32(1); pc = 6; continue; }
case 6: { return rt.check(r[1],"Z"); }
case 7: { r[1] = Value.i32(0); pc = 8; continue; }
case 8: { return rt.check(r[1],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b6fe2d44c88e197a9a911648(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(arguments[0], "Landroid/app/Activity;");
r[2] = rt.check(arguments[1], "Landroid/widget/Toolbar;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;-><init>(Landroid/app/Activity;Landroid/widget/Toolbar;Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;)V",r[0],new Value[]{r[1], r[2], r[3]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_14089213ab067b5f2c21931a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;");
r[3] = rt.check(arguments[0], "Landroid/app/Activity;");
r[4] = rt.check(arguments[1], "Landroid/widget/Toolbar;");
r[5] = rt.check(arguments[2], "Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter;-><init>(Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController-IA;)V",r[0],new Value[]{r[5], r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;-><init>(Landroid/app/Activity;Landroid/widget/Toolbar;Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;)V",r[2],new Value[]{r[3], r[4], r[0]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d8cd0a7bf44ce56cd6a1792d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[4] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/settings/search/YouTubeSearchResultsAdapter;"); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[4],false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->filteredSearchItems:Ljava/util/List;",r[4],false); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->fragment:Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;",r[4],false); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchResultsAdapter;-><init>(Landroid/content/Context;Ljava/util/List;Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;)V",r[0],new Value[]{r[1], r[2], r[3], r[4]}); pc = 5; continue; }
case 5: { return rt.check(r[0],"Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
