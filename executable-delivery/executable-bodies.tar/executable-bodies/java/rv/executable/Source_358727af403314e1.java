package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_358727af403314e1 extends RuntimeForeign.SourceProxy {
Source_358727af403314e1(RuntimeForeign owner,Instance source){super(owner,source);}

}
