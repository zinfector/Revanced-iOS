package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_4e1bb784f12a3155b7f3 {
static ClassInfo info_4e1bb784f12a3155b7f3() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda4;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda4;->f$0:J", "J", 4113, ExecutableRuntime.zero("J"))}, new MethodInfo[]{new MethodInfo("<init>(J)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "VideoInformation$$ExternalSyntheticLambda4");}
}
