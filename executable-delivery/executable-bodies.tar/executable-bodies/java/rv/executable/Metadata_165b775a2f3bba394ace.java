package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_165b775a2f3bba394ace {
static ClassInfo info_165b775a2f3bba394ace() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda1;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda1");}
}
