package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_64b215e53f701d6d15f2 {
static ClassInfo info_64b215e53f701d6d15f2() {return new ClassInfo("Lapp/revanced/extension/youtube/shared/PlayerType$Companion$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/shared/PlayerType$Companion$$ExternalSyntheticLambda0;->f$0:Lapp/revanced/extension/youtube/shared/PlayerType;", "Lapp/revanced/extension/youtube/shared/PlayerType;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/shared/PlayerType;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/shared/PlayerType;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
