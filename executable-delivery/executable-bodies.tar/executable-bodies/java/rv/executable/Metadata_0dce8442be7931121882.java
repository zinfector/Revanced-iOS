package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_0dce8442be7931121882 {
static ClassInfo info_0dce8442be7931121882() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$StillImagesAvailability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("usingStillImagesAnywhere()Z", 9), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
