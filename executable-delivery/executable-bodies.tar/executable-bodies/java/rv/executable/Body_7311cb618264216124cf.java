package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_7311cb618264216124cf {
static Value m_6f48c206c9d99d660256d76f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/IllegalArgumentException;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/com/google/protobuf/Syntax$$ExternalSyntheticBUOutline0;","Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { ExecutableRuntime.raise(r[0].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
