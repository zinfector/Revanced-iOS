package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_df03f95cc38a5c68cfb6 {
static Value m_79777d906dfcdebbfd135e72(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;");
r[1] = rt.check(arguments[0], "Lkotlin/collections/AbstractCollection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;->f$0:Lkotlin/collections/AbstractCollection;",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4fc3ef470c3ce69fc6f06b68(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;->f$0:Lkotlin/collections/AbstractCollection;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;","Lkotlin/collections/AbstractCollection;->$r8$lambda$RRlQOBNvJqinm9A-K_sSPMZpvJY(Lkotlin/collections/AbstractCollection;Ljava/lang/Object;)Ljava/lang/CharSequence;",Value.NULL,new Value[]{r[0], r[2]}); pc = 2; continue; }
case 2: { r[2] = result; pc = 3; continue; }
case 3: { return rt.check(r[2],"Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
