package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_d61441eb80fb935112af {
static Value m_04f780b10db3f2131fbd823a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[6] = rt.check(arguments[0], "Ljava/lang/CharSequence;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(8226); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/TextUtils;->indexOf(Ljava/lang/CharSequence;C)I",Value.NULL,new Value[]{r[6], r[0]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { pc=(r[1].i() >= 0)?5:4; continue; }
case 4: { return rt.check(r[6],"Ljava/lang/CharSequence;"); }
case 5: { r[1] = rt.allocate("Landroid/text/SpannableStringBuilder;"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V",r[1],new Value[]{r[6]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannableStringBuilder;->length()I",r[1],new Value[]{}); pc = 8; continue; }
case 8: { r[6] = result; pc = 9; continue; }
case 9: { r[2] = Value.i32(0); pc = 10; continue; }
case 10: { pc=(r[2].i() >= r[6].i())?41:11; continue; }
case 11: { r[3] = Value.i32(10); pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/TextUtils;->indexOf(Ljava/lang/CharSequence;CI)I",Value.NULL,new Value[]{r[1], r[3], r[2]}); pc = 13; continue; }
case 13: { r[3] = result; pc = 14; continue; }
case 14: { pc=(r[3].i() >= 0)?16:15; continue; }
case 15: { r[3] = r[6]; pc = 16; continue; }
case 16: { pc=(r[3].i() <= r[2].i())?39:17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannableStringBuilder;->charAt(I)C",r[1],new Value[]{r[2]}); pc = 18; continue; }
case 18: { r[4] = result; pc = 19; continue; }
case 19: { pc=(!ExecutableRuntime.equal(r[4],r[0]))?39:20; continue; }
case 20: { r[6] = Value.i32((r[2].i()) + (1)); pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannableStringBuilder;->length()I",r[1],new Value[]{}); pc = 22; continue; }
case 22: { r[4] = result; pc = 23; continue; }
case 23: { pc=(r[6].i() >= r[4].i())?29:24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannableStringBuilder;->charAt(I)C",r[1],new Value[]{r[6]}); pc = 25; continue; }
case 25: { r[4] = result; pc = 26; continue; }
case 26: { r[5] = Value.i32(32); pc = 27; continue; }
case 27: { pc=(!ExecutableRuntime.equal(r[4],r[5]))?29:28; continue; }
case 28: { r[6] = Value.i32((r[2].i()) + (2)); pc = 29; continue; }
case 29: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannableStringBuilder;->delete(II)Landroid/text/SpannableStringBuilder;",r[1],new Value[]{r[2], r[6]}); pc = 30; continue; }
case 30: { r[4] = rt.allocate("Landroid/text/style/BulletSpan;"); pc = 31; continue; }
case 31: { r[5] = Value.i32(20); pc = 32; continue; }
case 32: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/style/BulletSpan;-><init>(I)V",r[4],new Value[]{r[5]}); pc = 33; continue; }
case 33: { r[6] = Value.i32((r[6].i()) - (r[2].i())); pc = 34; continue; }
case 34: { r[3] = Value.i32((r[3].i()) - (r[6].i())); pc = 35; continue; }
case 35: { r[6] = Value.i32(33); pc = 36; continue; }
case 36: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V",r[1],new Value[]{r[4], r[2], r[3], r[6]}); pc = 37; continue; }
case 37: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannableStringBuilder;->length()I",r[1],new Value[]{}); pc = 38; continue; }
case 38: { r[6] = result; pc = 39; continue; }
case 39: { r[2] = Value.i32((r[3].i()) + (1)); pc = 40; continue; }
case 40: { pc=10; continue; }
case 41: { r[6] = rt.allocate("Landroid/text/SpannedString;"); pc = 42; continue; }
case 42: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;","Landroid/text/SpannedString;-><init>(Ljava/lang/CharSequence;)V",r[6],new Value[]{r[1]}); pc = 43; continue; }
case 43: { return rt.check(r[6],"Ljava/lang/CharSequence;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
