package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_ed2ed15ecc8ac7f1 extends RuntimeForeign.SourceProxy implements java.lang.Runnable {
Source_ed2ed15ecc8ac7f1(RuntimeForeign owner,Instance source){super(owner,source);}
public void run() {Value result=owner.callback(source,"Ljava/lang/Runnable;->run()V",new Value[]{}); return;}
}
