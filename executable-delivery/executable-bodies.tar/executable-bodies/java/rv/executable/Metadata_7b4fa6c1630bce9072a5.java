package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_7b4fa6c1630bce9072a5 {
static ClassInfo info_7b4fa6c1630bce9072a5() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda19;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda19");}
}
