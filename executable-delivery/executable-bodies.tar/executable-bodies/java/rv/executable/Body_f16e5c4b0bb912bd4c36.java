package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_f16e5c4b0bb912bd4c36 {
static Value m_7121f2050f51f245ff468656(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[3] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Object;-><init>()V",r[2],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[3]}); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->name:Ljava/lang/String;",r[2],false,r[3]); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[1] = Value.i32(0); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;",r[0],new Value[]{r[3], r[1]}); pc = 8; continue; }
case 8: { r[3] = result; pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[2],false,r[3]); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_58491756f04c5f8b6d5c9b15(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;",r[0],new Value[]{r[2]}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences$Editor;->commit()Z",r[2],new Value[]{}); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cb7a17bdcbb75ddd6f96f6fa(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->saveObjectAsString(Ljava/lang/String;Ljava/lang/Object;)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4f21d7f5e0dc9f01d99d879b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;",r[0],new Value[]{r[2], r[3]}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences$Editor;->commit()Z",r[2],new Value[]{}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_592a816eadec7fe6f7d8012a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Float;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->saveObjectAsString(Ljava/lang/String;Ljava/lang/Object;)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f134d6b1a689ece74000a8c5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Long;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->saveObjectAsString(Ljava/lang/String;Ljava/lang/Object;)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4c69686a34a9d3162122c990(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->saveObjectAsString(Ljava/lang/String;Ljava/lang/Object;)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_816cd44b2b69ad2eb1145453(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Integer;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->saveObjectAsString(Ljava/lang/String;Ljava/lang/Object;)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0bea180be35b93b15a42e566(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[3],Value.i32(0)))?6:4; continue; }
case 4: { r[3] = Value.i32(0); pc = 5; continue; }
case 5: { pc=8; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Object;->toString()Ljava/lang/String;",r[3],new Value[]{}); pc = 7; continue; }
case 7: { r[3] = result; pc = 8; continue; }
case 8: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;",r[0],new Value[]{r[2], r[3]}); pc = 9; continue; }
case 9: { r[2] = result; pc = 10; continue; }
case 10: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences$Editor;->commit()Z",r[2],new Value[]{}); pc = 11; continue; }
case 11: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a704b0e16145a9866727d9b9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[4] = rt.check(arguments[0], "Ljava/lang/String;");
r[5] = rt.check(arguments[1], "Ljava/lang/Long;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[3],false); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",r[0],new Value[]{r[4], r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?8:5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[4] = result; pc = 7; continue; }
case 7: { return rt.check(r[4],"Ljava/lang/Long;"); }
case 8: { return rt.check(r[5],"Ljava/lang/Long;"); }
case 9: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[3],false); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Long;->longValue()J",r[5],new Value[]{}); pc = 11; continue; }
case 11: { r[1] = result; r[2] = r[1]; pc = 12; continue; }
case 12: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J",r[0],new Value[]{r[4], r[1]}); pc = 13; continue; }
case 13: { r[0] = result; r[1] = r[0]; pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[0]}); pc = 15; continue; }
case 15: { r[4] = result; pc = 16; continue; }
case 16: { return rt.check(r[4],"Ljava/lang/Long;"); }
case 17: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeConflictingPreferenceKeyValue(Ljava/lang/String;)V",r[3],new Value[]{r[4]}); pc = 18; continue; }
case 18: { return rt.check(r[5],"Ljava/lang/Long;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 7) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=9; continue; } if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/NumberFormatException;")) { exception=ExecutableRuntime.caught(error); pc=9; continue; } }
if(pc >= 9 && pc < 16) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=17; continue; } }
throw error;
}
}

}

static Value m_fd790d3457b95a7658214f8b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[3]}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[1],false); pc = 2; continue; }
case 2: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",r[0],new Value[]{r[2], r[3]}); pc = 3; continue; }
case 3: { r[2] = result; pc = 4; continue; }
case 4: { return rt.check(r[2],"Ljava/lang/String;"); }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeConflictingPreferenceKeyValue(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 6; continue; }
case 6: { return rt.check(r[3],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 1 && pc < 4) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=5; continue; } }
throw error;
}
}

}

static Value m_2157606b0ca2ffb0b3972863(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[3] = rt.check(arguments[0], "Ljava/lang/String;");
r[4] = rt.check(arguments[1], "Ljava/lang/Float;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[2],false); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",r[0],new Value[]{r[3], r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?8:5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[3] = result; pc = 7; continue; }
case 7: { return rt.check(r[3],"Ljava/lang/Float;"); }
case 8: { return rt.check(r[4],"Ljava/lang/Float;"); }
case 9: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[2],false); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Float;->floatValue()F",r[4],new Value[]{}); pc = 11; continue; }
case 11: { r[1] = result; pc = 12; continue; }
case 12: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F",r[0],new Value[]{r[3], r[1]}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;",Value.NULL,new Value[]{r[0]}); pc = 15; continue; }
case 15: { r[3] = result; pc = 16; continue; }
case 16: { return rt.check(r[3],"Ljava/lang/Float;"); }
case 17: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeConflictingPreferenceKeyValue(Ljava/lang/String;)V",r[2],new Value[]{r[3]}); pc = 18; continue; }
case 18: { return rt.check(r[4],"Ljava/lang/Float;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 7) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=9; continue; } if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/NumberFormatException;")) { exception=ExecutableRuntime.caught(error); pc=9; continue; } }
if(pc >= 9 && pc < 16) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=17; continue; } }
throw error;
}
}

}

static Value m_2823f8bce473c272abb8a019(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[3] = rt.check(arguments[0], "Ljava/lang/String;");
r[4] = rt.check(arguments[1], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[4]}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[2],false); pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",r[0],new Value[]{r[3], r[1]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?17:6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[4],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;",Value.NULL,new Value[]{r[1], r[0]}); pc = 9; continue; }
case 9: { r[3] = result; pc = 10; continue; }
case 10: { return rt.check(r[3],"Ljava/lang/Enum;"); }
case 11: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;"); pc = 12; continue; }
case 12: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[0]}); pc = 13; continue; }
case 13: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeKey(Ljava/lang/String;)V",r[2],new Value[]{r[3]}); pc = 15; continue; }
case 15: { pc=17; continue; }
case 16: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeConflictingPreferenceKeyValue(Ljava/lang/String;)V",r[2],new Value[]{r[3]}); pc = 17; continue; }
case 17: { return rt.check(r[4],"Ljava/lang/Enum;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 1 && pc < 5) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=16; continue; } }
if(pc >= 6 && pc < 10) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/IllegalArgumentException;")) { exception=ExecutableRuntime.caught(error); pc=11; continue; } if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=16; continue; } }
if(pc >= 11 && pc < 15) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=16; continue; } }
throw error;
}
}

}

static Value m_e7487545cd5615779d894a29(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z",r[0],new Value[]{r[2], r[3]}); pc = 2; continue; }
case 2: { r[2] = result; pc = 3; continue; }
case 3: { return rt.check(r[2],"Z"); }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeConflictingPreferenceKeyValue(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 5; continue; }
case 5: { return rt.check(r[3],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 3) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=4; continue; } }
throw error;
}
}

}

static Value m_5f005ff95cf48f751126dff2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[3] = rt.check(arguments[0], "Ljava/lang/String;");
r[4] = rt.check(arguments[1], "Ljava/lang/Integer;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[2],false); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;",r[0],new Value[]{r[3], r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?8:5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[3] = result; pc = 7; continue; }
case 7: { return rt.check(r[3],"Ljava/lang/Integer;"); }
case 8: { return rt.check(r[4],"Ljava/lang/Integer;"); }
case 9: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->preferences:Landroid/content/SharedPreferences;",r[2],false); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Integer;->intValue()I",r[4],new Value[]{}); pc = 11; continue; }
case 11: { r[1] = result; pc = 12; continue; }
case 12: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I",r[0],new Value[]{r[3], r[1]}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[0]}); pc = 15; continue; }
case 15: { r[3] = result; pc = 16; continue; }
case 16: { return rt.check(r[3],"Ljava/lang/Integer;"); }
case 17: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeConflictingPreferenceKeyValue(Ljava/lang/String;)V",r[2],new Value[]{r[3]}); pc = 18; continue; }
case 18: { return rt.check(r[4],"Ljava/lang/Integer;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 7) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=9; continue; } if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/NumberFormatException;")) { exception=ExecutableRuntime.caught(error); pc=9; continue; } }
if(pc >= 9 && pc < 16) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/ClassCastException;")) { exception=ExecutableRuntime.caught(error); pc=17; continue; } }
throw error;
}
}

}

static Value m_42cc3317eef7494f281eefde(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->name:Ljava/lang/String;",r[1],false); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2e1875d54c5839b600715ca4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda0;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[2]}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeKey(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_13c1e58a2e02d3438b1ad107(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Using default, and ignoring unknown enum value: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cc1d5fcc8e173e1e35d30a4b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Found conflicting preference: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
