package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_ff325b9410f7ad20e82c {
static ClassInfo info_ff325b9410f7ad20e82c() {return new ClassInfo("Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda1;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "StringRef$$ExternalSyntheticLambda1");}
}
