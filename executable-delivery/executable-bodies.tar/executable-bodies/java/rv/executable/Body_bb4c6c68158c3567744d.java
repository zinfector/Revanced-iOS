package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_bb4c6c68158c3567744d {
static Value m_c9e10d56a24291bd1a9ec2f4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->searchHistoryContainer:Landroid/widget/FrameLayout;",r[2],false); pc = 1; continue; }
case 1: { r[1] = Value.i32(8); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/View;->setVisibility(I)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f7d65e1960da797a3aaca9dd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ID:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = Value.ref("clear_history_button"); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_CLEAR_HISTORY_BUTTON:I",Value.NULL,true,r[1]); pc = 5; continue; }
case 5: { r[1] = Value.ref("history_text"); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_HISTORY_TEXT:I",Value.NULL,true,r[1]); pc = 9; continue; }
case 9: { r[1] = Value.ref("history_icon"); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 11; continue; }
case 11: { r[1] = result; pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_HISTORY_ICON:I",Value.NULL,true,r[1]); pc = 13; continue; }
case 13: { r[1] = Value.ref("delete_icon"); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 15; continue; }
case 15: { r[1] = result; pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_DELETE_ICON:I",Value.NULL,true,r[1]); pc = 17; continue; }
case 17: { r[1] = Value.ref("empty_history_title"); pc = 18; continue; }
case 18: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 19; continue; }
case 19: { r[1] = result; pc = 20; continue; }
case 20: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_EMPTY_HISTORY_TITLE:I",Value.NULL,true,r[1]); pc = 21; continue; }
case 21: { r[1] = Value.ref("empty_history_summary"); pc = 22; continue; }
case 22: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 23; continue; }
case 23: { r[1] = result; pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_EMPTY_HISTORY_SUMMARY:I",Value.NULL,true,r[1]); pc = 25; continue; }
case 25: { r[1] = Value.ref("search_history_header"); pc = 26; continue; }
case 26: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 27; continue; }
case 27: { r[1] = result; pc = 28; continue; }
case 28: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_HISTORY_HEADER:I",Value.NULL,true,r[1]); pc = 29; continue; }
case 29: { r[1] = Value.ref("revanced_settings_search_tips_summary"); pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 31; continue; }
case 31: { r[1] = result; pc = 32; continue; }
case 32: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_TIPS_SUMMARY:I",Value.NULL,true,r[1]); pc = 33; continue; }
case 33: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->LAYOUT:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 34; continue; }
case 34: { r[2] = Value.ref("revanced_preference_search_history_screen"); pc = 35; continue; }
case 35: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 36; continue; }
case 36: { r[2] = result; pc = 37; continue; }
case 37: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->LAYOUT_REVANCED_PREFERENCE_SEARCH_HISTORY_SCREEN:I",Value.NULL,true,r[2]); pc = 38; continue; }
case 38: { r[2] = Value.ref("revanced_preference_search_history_item"); pc = 39; continue; }
case 39: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 40; continue; }
case 40: { r[1] = result; pc = 41; continue; }
case 41: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->LAYOUT_REVANCED_PREFERENCE_SEARCH_HISTORY_ITEM:I",Value.NULL,true,r[1]); pc = 42; continue; }
case 42: { r[1] = Value.ref("search_history_list"); pc = 43; continue; }
case 43: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 44; continue; }
case 44: { r[0] = result; pc = 45; continue; }
case 45: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_HISTORY_LIST:I",Value.NULL,true,r[0]); pc = 46; continue; }
case 46: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->DRAWABLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 47; continue; }
case 47: { r[1] = Value.ref("revanced_settings_search_remove"); pc = 48; continue; }
case 48: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 49; continue; }
case 49: { r[1] = result; pc = 50; continue; }
case 50: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_REMOVE_ICON:I",Value.NULL,true,r[1]); pc = 51; continue; }
case 51: { r[1] = Value.ref("revanced_settings_search_remove_bold"); pc = 52; continue; }
case 52: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 53; continue; }
case 53: { r[1] = result; pc = 54; continue; }
case 54: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_REMOVE_ICON_BOLD:I",Value.NULL,true,r[1]); pc = 55; continue; }
case 55: { r[1] = Value.ref("revanced_settings_arrow_time"); pc = 56; continue; }
case 56: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 57; continue; }
case 57: { r[1] = result; pc = 58; continue; }
case 58: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_ARROW_TIME_ICON:I",Value.NULL,true,r[1]); pc = 59; continue; }
case 59: { r[1] = Value.ref("revanced_settings_arrow_time_bold"); pc = 60; continue; }
case 60: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 61; continue; }
case 61: { r[0] = result; pc = 62; continue; }
case 62: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_ARROW_TIME_ICON_BOLD:I",Value.NULL,true,r[0]); pc = 63; continue; }
case 63: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_578bde78968a076cd751e8ea(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[13];
r[9] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;");
r[10] = rt.check(arguments[0], "Landroid/app/Activity;");
r[11] = rt.check(arguments[1], "Landroid/widget/FrameLayout;");
r[12] = rt.check(arguments[2], "Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$OnSelectHistoryItemListener;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Ljava/lang/Object;-><init>()V",r[9],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->activity:Landroid/app/Activity;",r[9],false,r[10]); pc = 2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->SETTINGS_SEARCH_HISTORY:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->showSettingsSearchHistory:Z",r[9],false,r[0]); pc = 8; continue; }
case 8: { r[1] = rt.allocate("Ljava/util/LinkedList;"); pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Ljava/util/LinkedList;-><init>()V",r[1],new Value[]{}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->searchHistory:Ljava/util/Deque;",r[9],false,r[1]); pc = 11; continue; }
case 11: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?25:12; continue; }
case 12: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->SETTINGS_SEARCH_ENTRIES:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;",r[0],new Value[]{}); pc = 14; continue; }
case 14: { r[0] = result; pc = 15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/patches/EnableDebuggingPatch$$ExternalSyntheticBackport0;->m(Ljava/lang/String;)Z",Value.NULL,new Value[]{r[0]}); pc = 16; continue; }
case 16: { r[2] = result; pc = 17; continue; }
case 17: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?27:18; continue; }
case 18: { r[2] = Value.ref("\n"); pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;",r[0],new Value[]{r[2]}); pc = 20; continue; }
case 20: { r[0] = result; pc = 21; continue; }
case 21: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;",Value.NULL,new Value[]{r[0]}); pc = 22; continue; }
case 22: { r[0] = result; pc = 23; continue; }
case 23: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Ljava/util/Deque;->addAll(Ljava/util/Collection;)Z",r[1],new Value[]{r[0]}); pc = 24; continue; }
case 24: { pc=27; continue; }
case 25: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->SETTINGS_SEARCH_ENTRIES:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 26; continue; }
case 26: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/settings/Setting;->resetToDefault()Ljava/lang/Object;",r[0],new Value[]{}); pc = 27; continue; }
case 27: { r[0] = rt.allocate("Landroid/widget/FrameLayout;"); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V",r[0],new Value[]{r[10]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->searchHistoryContainer:Landroid/widget/FrameLayout;",r[9],false,r[0]); pc = 30; continue; }
case 30: { r[2] = Value.i32(8); pc = 31; continue; }
case 31: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/View;->setVisibility(I)V",r[0],new Value[]{r[2]}); pc = 32; continue; }
case 32: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;",Value.NULL,new Value[]{r[10]}); pc = 33; continue; }
case 33: { r[2] = result; pc = 34; continue; }
case 34: { r[3] = rt.readField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->LAYOUT_REVANCED_PREFERENCE_SEARCH_HISTORY_SCREEN:I",Value.NULL,true); pc = 35; continue; }
case 35: { r[4] = Value.i32(0); pc = 36; continue; }
case 36: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;",r[2],new Value[]{r[3], r[0], r[4]}); pc = 37; continue; }
case 37: { r[2] = result; pc = 38; continue; }
case 38: { r[3] = rt.allocate("Landroid/widget/FrameLayout$LayoutParams;"); pc = 39; continue; }
case 39: { r[4] = Value.i32(-1); pc = 40; continue; }
case 40: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V",r[3],new Value[]{r[4], r[4]}); pc = 41; continue; }
case 41: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V",r[0],new Value[]{r[2], r[3]}); pc = 42; continue; }
case 42: { r[3] = rt.allocate("Landroid/widget/FrameLayout$LayoutParams;"); pc = 43; continue; }
case 43: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V",r[3],new Value[]{r[4], r[4]}); pc = 44; continue; }
case 44: { r[4] = Value.i32(48); pc = 45; continue; }
case 45: { rt.writeField("Landroid/widget/FrameLayout$LayoutParams;->gravity:I",r[3],false,r[4]); pc = 46; continue; }
case 46: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V",r[11],new Value[]{r[0], r[3]}); pc = 47; continue; }
case 47: { r[11] = rt.readField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_HISTORY_LIST:I",Value.NULL,true); pc = 48; continue; }
case 48: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/View;->findViewById(I)Landroid/view/View;",r[0],new Value[]{r[11]}); pc = 49; continue; }
case 49: { r[11] = result; pc = 50; continue; }
case 50: { r[6] = r[11]; pc = 51; continue; }
case 51: { r[6] = rt.cast(r[6],"Landroid/widget/LinearLayout;"); pc = 52; continue; }
case 52: { pc=(ExecutableRuntime.equal(r[6],Value.i32(0)))?79:53; continue; }
case 53: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;"); pc = 54; continue; }
case 54: { r[7] = rt.allocate("Ljava/util/ArrayList;"); pc = 55; continue; }
case 55: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V",r[7],new Value[]{r[1]}); pc = 56; continue; }
case 56: { r[4] = r[9]; pc = 57; continue; }
case 57: { r[5] = r[10]; pc = 58; continue; }
case 58: { r[8] = r[12]; pc = 59; continue; }
case 59: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;-><init>(Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;Landroid/content/Context;Landroid/widget/LinearLayout;Ljava/util/Collection;Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$OnSelectHistoryItemListener;)V",r[3],new Value[]{r[4], r[5], r[6], r[7], r[8]}); pc = 60; continue; }
case 60: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->searchHistoryAdapter:Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;",r[4],false,r[3]); pc = 61; continue; }
case 61: { r[10] = rt.readField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_CLEAR_HISTORY_BUTTON:I",Value.NULL,true); pc = 62; continue; }
case 62: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/View;->findViewById(I)Landroid/view/View;",r[0],new Value[]{r[10]}); pc = 63; continue; }
case 63: { r[10] = result; pc = 64; continue; }
case 64: { r[10] = rt.cast(r[10],"Landroid/widget/TextView;"); pc = 65; continue; }
case 65: { r[11] = rt.allocate("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$$ExternalSyntheticLambda0;"); pc = 66; continue; }
case 66: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$$ExternalSyntheticLambda0;-><init>(Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;)V",r[11],new Value[]{r[9]}); pc = 67; continue; }
case 67: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V",r[10],new Value[]{r[11]}); pc = 68; continue; }
case 68: { r[10] = Value.ref("revanced_settings_search_tips_summary"); pc = 69; continue; }
case 69: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/StringRef;->str(Ljava/lang/String;)Ljava/lang/String;",Value.NULL,new Value[]{r[10]}); pc = 70; continue; }
case 70: { r[10] = result; pc = 71; continue; }
case 71: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Lapp/revanced/extension/shared/settings/preference/BulletPointPreference;->formatIntoBulletPoints(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;",Value.NULL,new Value[]{r[10]}); pc = 72; continue; }
case 72: { r[10] = result; pc = 73; continue; }
case 73: { r[11] = rt.readField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->ID_SEARCH_TIPS_SUMMARY:I",Value.NULL,true); pc = 74; continue; }
case 74: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/view/View;->findViewById(I)Landroid/view/View;",r[2],new Value[]{r[11]}); pc = 75; continue; }
case 75: { r[11] = result; pc = 76; continue; }
case 76: { r[11] = rt.cast(r[11],"Landroid/widget/TextView;"); pc = 77; continue; }
case 77: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V",r[11],new Value[]{r[10]}); pc = 78; continue; }
case 78: { return Value.VOID; }
case 79: { r[4] = r[9]; pc = 80; continue; }
case 80: { r[10] = rt.allocate("Ljava/lang/IllegalStateException;"); pc = 81; continue; }
case 81: { r[11] = Value.ref("Search history list view not found in container"); pc = 82; continue; }
case 82: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;","Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V",r[10],new Value[]{r[11]}); pc = 83; continue; }
case 83: { ExecutableRuntime.raise(r[10].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
