package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_9c0501ff5cac449e extends RuntimeForeign.SourceProxy {
Source_9c0501ff5cac449e(RuntimeForeign owner,Instance source){super(owner,source);}

}
