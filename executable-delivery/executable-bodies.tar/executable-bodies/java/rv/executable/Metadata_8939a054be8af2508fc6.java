package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8939a054be8af2508fc6 {
static ClassInfo info_8939a054be8af2508fc6() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$MatchFilter;", "Ljava/lang/Object;", new String[]{}, 1537, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("matches(Ljava/lang/Object;)Z", 1025)}, "MatchFilter");}
}
