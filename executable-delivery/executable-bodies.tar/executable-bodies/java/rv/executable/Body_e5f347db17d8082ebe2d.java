package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_e5f347db17d8082ebe2d {
static Value m_06c01890fd1cd59abc2e301c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[1] = rt.check(arguments[0], "[Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lkotlin/enums/EnumEntriesList;", "Ljava/lang/Object;->getClass()Ljava/lang/Class;", r[1], new Value[]{}); pc = 1; continue; }
case 1: { result = rt.invoke("direct", "Lkotlin/enums/EnumEntriesList;", "Lkotlin/collections/AbstractList;-><init>()V", r[0], new Value[]{}); pc = 2; continue; }
case 2: { rt.writeField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;", r[0], false, r[1]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6e77ed3fa705df7dcb973d27(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;", r[1], false); pc = 1; continue; }
case 1: { r[0] = Value.i32(rt.length(r[0])); pc = 2; continue; }
case 2: { return rt.check(r[0], "I"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_670b41a08076c0e92c5e43a1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[1] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lkotlin/enums/EnumEntriesList;", "Lkotlin/enums/EnumEntriesList;->get(I)Ljava/lang/Enum;", r[0], new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[1] = result; pc = 2; continue; }
case 2: { return rt.check(r[1], "Ljava/lang/Object;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7520c335c93a2f560c3bbe5f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[3] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;", r[2], false); pc = 2; continue; }
case 2: { r[1] = Value.i32(rt.length(r[1])); pc = 3; continue; }
case 3: { result = rt.invoke("virtual", "Lkotlin/enums/EnumEntriesList;", "Lkotlin/collections/AbstractList$Companion;->checkElementIndex$kotlin_stdlib(II)V", r[0], new Value[]{r[3], r[1]}); pc = 4; continue; }
case 4: { r[0] = rt.readField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;", r[2], false); pc = 5; continue; }
case 5: { r[3] = rt.arrayGet(r[0], r[3].i()); pc = 6; continue; }
case 6: { return rt.check(r[3], "Ljava/lang/Enum;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
