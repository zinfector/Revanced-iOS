package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_e5f347db17d8082ebe2d {
static Value m_52e34d9e14a6fd63117f31a8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(rt.isInstance(r[2].o(),"Ljava/lang/Enum;")?1:0); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?4:2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { return rt.check(r[2],"Z"); }
case 4: { r[2] = rt.cast(r[2],"Ljava/lang/Enum;"); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Lkotlin/enums/EnumEntriesList;->contains(Ljava/lang/Enum;)Z",r[1],new Value[]{r[2]}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { return rt.check(r[2],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5a9dbbaccad24809fcdc608f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(rt.isInstance(r[2].o(),"Ljava/lang/Enum;")?1:0); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?4:2; continue; }
case 2: { r[2] = Value.i32(-1); pc = 3; continue; }
case 3: { return rt.check(r[2],"I"); }
case 4: { r[2] = rt.cast(r[2],"Ljava/lang/Enum;"); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Lkotlin/enums/EnumEntriesList;->indexOf(Ljava/lang/Enum;)I",r[1],new Value[]{r[2]}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { return rt.check(r[2],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_bf6585400bca4dbd8498ebec(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(rt.isInstance(r[2].o(),"Ljava/lang/Enum;")?1:0); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?4:2; continue; }
case 2: { r[2] = Value.i32(-1); pc = 3; continue; }
case 3: { return rt.check(r[2],"I"); }
case 4: { r[2] = rt.cast(r[2],"Ljava/lang/Enum;"); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Lkotlin/enums/EnumEntriesList;->lastIndexOf(Ljava/lang/Enum;)I",r[1],new Value[]{r[2]}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { return rt.check(r[2],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8875d1e2d3b345b1232f2b22(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[3] = rt.check(arguments[0], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[3],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;",r[2],false); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Ljava/lang/Enum;->ordinal()I",r[3],new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { result=rt.invoke("static","Lkotlin/enums/EnumEntriesList;","Lkotlin/collections/ArraysKt___ArraysKt;->getOrNull([Ljava/lang/Object;I)Ljava/lang/Object;",Value.NULL,new Value[]{r[0], r[1]}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { r[0] = rt.cast(r[0],"Ljava/lang/Enum;"); pc = 7; continue; }
case 7: { pc=(!ExecutableRuntime.equal(r[0],r[3]))?10:8; continue; }
case 8: { r[3] = Value.i32(1); pc = 9; continue; }
case 9: { return rt.check(r[3],"Z"); }
case 10: { r[3] = Value.i32(0); pc = 11; continue; }
case 11: { return rt.check(r[3],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2b46e244fabc568086900f55(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[3] = rt.check(arguments[0], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[3],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Ljava/lang/Enum;->ordinal()I",r[3],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[1] = rt.readField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;",r[2],false); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lkotlin/enums/EnumEntriesList;","Lkotlin/collections/ArraysKt___ArraysKt;->getOrNull([Ljava/lang/Object;I)Ljava/lang/Object;",Value.NULL,new Value[]{r[1], r[0]}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { r[1] = rt.cast(r[1],"Ljava/lang/Enum;"); pc = 7; continue; }
case 7: { pc=(!ExecutableRuntime.equal(r[1],r[3]))?9:8; continue; }
case 8: { return rt.check(r[0],"I"); }
case 9: { r[3] = Value.i32(-1); pc = 10; continue; }
case 10: { return rt.check(r[3],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5117e260f93c22d09f639fa5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[1] = rt.check(arguments[0], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[1],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Lkotlin/enums/EnumEntriesList;->indexOf(Ljava/lang/Enum;)I",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { return rt.check(r[1],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_06c01890fd1cd59abc2e301c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[1] = rt.check(arguments[0], "[Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[1],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lkotlin/enums/EnumEntriesList;","Lkotlin/collections/AbstractList;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { rt.writeField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;",r[0],false,r[1]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6e77ed3fa705df7dcb973d27(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;",r[1],false); pc = 1; continue; }
case 1: { r[0] = Value.i32(rt.length(r[0])); pc = 2; continue; }
case 2: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_670b41a08076c0e92c5e43a1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[1] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Lkotlin/enums/EnumEntriesList;->get(I)Ljava/lang/Enum;",r[0],new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[1] = result; pc = 2; continue; }
case 2: { return rt.check(r[1],"Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7520c335c93a2f560c3bbe5f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lkotlin/enums/EnumEntriesList;");
r[3] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;",r[2],false); pc = 2; continue; }
case 2: { r[1] = Value.i32(rt.length(r[1])); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesList;","Lkotlin/collections/AbstractList$Companion;->checkElementIndex$kotlin_stdlib(II)V",r[0],new Value[]{r[3], r[1]}); pc = 4; continue; }
case 4: { r[0] = rt.readField("Lkotlin/enums/EnumEntriesList;->entries:[Ljava/lang/Enum;",r[2],false); pc = 5; continue; }
case 5: { r[3] = rt.arrayGet(r[0],r[3].i()); pc = 6; continue; }
case 6: { return rt.check(r[3],"Ljava/lang/Enum;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
