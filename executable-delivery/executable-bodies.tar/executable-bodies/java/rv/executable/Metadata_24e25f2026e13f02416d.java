package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_24e25f2026e13f02416d {
static ClassInfo info_24e25f2026e13f02416d() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda12;", "Ljava/lang/Object;", new String[]{"Ljava/lang/Runnable;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda12;->f$0:J", "J", 4113, ExecutableRuntime.zero("J"))}, new MethodInfo[]{new MethodInfo("<init>(J)V", 69633), new MethodInfo("run()V", 17)}, "SBRequester$$ExternalSyntheticLambda12");}
}
