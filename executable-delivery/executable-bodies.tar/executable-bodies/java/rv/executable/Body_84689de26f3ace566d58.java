package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_84689de26f3ace566d58 {
static Value m_7d8c0694bc1ee573e049c794(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch$1;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch;","Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch$1;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch;","Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V",r[1],new Value[]{r[0]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9929696ca0383e5fa524cf78(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?2:1; continue; }
case 1: { return Value.VOID; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch;","Ljava/lang/Enum;->name()Ljava/lang/String;",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch;","Lapp/revanced/extension/youtube/shared/PlayerType;->setFromString(Ljava/lang/String;)V",Value.NULL,new Value[]{r[0]}); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_12ed84ce7260fefca2d85f6e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?2:1; continue; }
case 1: { return Value.VOID; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch;","Ljava/lang/Enum;->name()Ljava/lang/String;",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/PlayerTypeHookPatch;","Lapp/revanced/extension/youtube/shared/VideoState;->setFromString(Ljava/lang/String;)V",Value.NULL,new Value[]{r[0]}); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
