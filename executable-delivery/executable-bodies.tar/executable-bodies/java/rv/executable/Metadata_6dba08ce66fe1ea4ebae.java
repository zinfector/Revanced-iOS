package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_6dba08ce66fe1ea4ebae {
static ClassInfo info_6dba08ce66fe1ea4ebae() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda2;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentCategory$$ExternalSyntheticLambda2");}
}
