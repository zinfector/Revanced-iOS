package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_44ee58b91d212a49 extends RuntimeForeign.SourceProxy implements java.io.Serializable {
Proxy_44ee58b91d212a49(RuntimeForeign owner,Instance source){super(owner,source);}

}
