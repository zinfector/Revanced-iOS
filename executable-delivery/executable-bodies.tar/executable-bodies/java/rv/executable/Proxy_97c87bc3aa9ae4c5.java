package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_97c87bc3aa9ae4c5 extends RuntimeForeign.SourceProxy implements java.io.Flushable {
Proxy_97c87bc3aa9ae4c5(RuntimeForeign owner,Instance source){super(owner,source);}
public void flush() {Value result=owner.callback(source,"Ljava/io/Flushable;->flush()V",new Value[]{}); return;}
}
