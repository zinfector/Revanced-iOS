package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8b4c4cadf0482b15b17f {
static ClassInfo info_8b4c4cadf0482b15b17f() {return new ClassInfo("Lapp/revanced/extension/shared/settings/Setting$1;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 0, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/settings/Setting$1;->val$parent:Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/BooleanSetting;", 4112, ExecutableRuntime.zero("Lapp/revanced/extension/shared/settings/BooleanSetting;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/shared/settings/BooleanSetting;)V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
