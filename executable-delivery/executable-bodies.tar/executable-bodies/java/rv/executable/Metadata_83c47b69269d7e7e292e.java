package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_83c47b69269d7e7e292e {
static ClassInfo info_83c47b69269d7e7e292e() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda12;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda12");}
}
