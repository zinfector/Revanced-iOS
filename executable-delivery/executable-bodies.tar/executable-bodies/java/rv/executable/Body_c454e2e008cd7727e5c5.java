package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_c454e2e008cd7727e5c5 {
static Value m_cfe447aa3d9f8b246be6210c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$ChangeStartPageTypeAvailability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$ChangeStartPageTypeAvailability;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
