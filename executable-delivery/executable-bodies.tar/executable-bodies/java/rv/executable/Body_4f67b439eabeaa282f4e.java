package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_4f67b439eabeaa282f4e {
static Value m_c60a165c0205e786eb9f4d23(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[2]}); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;->fullscreenButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$$ExternalSyntheticLambda0;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$$ExternalSyntheticLambda0;-><init>()V",r[0],new Value[]{}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;->fullscreenButtonVisibilityCallbacksExist()Z",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?10:9; continue; }
case 9: { return Value.VOID; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;","Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;",r[2],new Value[]{}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$1;"); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$1;-><init>(Landroid/view/View;)V",r[1],new Value[]{r[2]}); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;","Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V",r[0],new Value[]{r[1]}); pc = 15; continue; }
case 15: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2563f20a9afe189635c88893(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch;->fullscreenButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7d6bd17a8acc7f5e9e971b19(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b9676baf149c5bd19afb3704(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Fullscreen button set"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
