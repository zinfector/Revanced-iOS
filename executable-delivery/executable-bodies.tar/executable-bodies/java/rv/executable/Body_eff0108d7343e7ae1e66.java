package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_eff0108d7343e7ae1e66 {
static Value m_3e1c0e3fabd1b5f8257ef9ed(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$1;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$1;->this$0:Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;",r[0],false,r[1]); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$1;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
