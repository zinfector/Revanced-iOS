package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_33e252dd6782045dc001 {
static Value m_a1140f9a96e9c5ed03330b15(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->$VALUES:[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3438229b0c5f02624d0b84f7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 1; continue; }
case 1: { r[1] = Value.ref(""); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { r[3] = Value.ref("DEFAULT"); pc = 4; continue; }
case 4: { r[4] = Value.i32(0); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[3], r[4], r[1], r[2]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 7; continue; }
case 7: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 8; continue; }
case 8: { r[1] = rt.readField("Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;",Value.NULL,true); pc = 9; continue; }
case 9: { r[2] = Value.ref("ALL_SUBSCRIPTIONS"); pc = 10; continue; }
case 10: { r[3] = Value.i32(1); pc = 11; continue; }
case 11: { r[4] = Value.ref("FEchannels"); pc = 12; continue; }
case 12: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[2], r[3], r[4], r[1]}); pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->ALL_SUBSCRIPTIONS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 14; continue; }
case 14: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 15; continue; }
case 15: { r[2] = Value.i32(2); pc = 16; continue; }
case 16: { r[3] = Value.ref("FEguide_builder"); pc = 17; continue; }
case 17: { r[4] = Value.ref("BROWSE"); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->BROWSE:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 21; continue; }
case 21: { r[2] = Value.i32(3); pc = 22; continue; }
case 22: { r[3] = Value.ref("FEexplore"); pc = 23; continue; }
case 23: { r[4] = Value.ref("EXPLORE"); pc = 24; continue; }
case 24: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 25; continue; }
case 25: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->EXPLORE:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 26; continue; }
case 26: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 27; continue; }
case 27: { r[2] = Value.i32(4); pc = 28; continue; }
case 28: { r[3] = Value.ref("FEhistory"); pc = 29; continue; }
case 29: { r[4] = Value.ref("HISTORY"); pc = 30; continue; }
case 30: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 31; continue; }
case 31: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->HISTORY:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 32; continue; }
case 32: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 33; continue; }
case 33: { r[2] = Value.i32(5); pc = 34; continue; }
case 34: { r[3] = Value.ref("FElibrary"); pc = 35; continue; }
case 35: { r[4] = Value.ref("LIBRARY"); pc = 36; continue; }
case 36: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 37; continue; }
case 37: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->LIBRARY:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 38; continue; }
case 38: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 39; continue; }
case 39: { r[2] = Value.i32(6); pc = 40; continue; }
case 40: { r[3] = Value.ref("FEstorefront"); pc = 41; continue; }
case 41: { r[4] = Value.ref("MOVIE"); pc = 42; continue; }
case 42: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 43; continue; }
case 43: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->MOVIE:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 44; continue; }
case 44: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 45; continue; }
case 45: { r[2] = Value.i32(7); pc = 46; continue; }
case 46: { r[3] = Value.ref("FEactivity"); pc = 47; continue; }
case 47: { r[4] = Value.ref("NOTIFICATIONS"); pc = 48; continue; }
case 48: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 49; continue; }
case 49: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->NOTIFICATIONS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 50; continue; }
case 50: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 51; continue; }
case 51: { r[2] = Value.i32(8); pc = 52; continue; }
case 52: { r[3] = Value.ref("FEplaylist_aggregation"); pc = 53; continue; }
case 53: { r[4] = Value.ref("PLAYLISTS"); pc = 54; continue; }
case 54: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 55; continue; }
case 55: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->PLAYLISTS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 56; continue; }
case 56: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 57; continue; }
case 57: { r[2] = Value.i32(9); pc = 58; continue; }
case 58: { r[3] = Value.ref("FEsubscriptions"); pc = 59; continue; }
case 59: { r[4] = Value.ref("SUBSCRIPTIONS"); pc = 60; continue; }
case 60: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 61; continue; }
case 61: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SUBSCRIPTIONS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 62; continue; }
case 62: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 63; continue; }
case 63: { r[2] = Value.i32(10); pc = 64; continue; }
case 64: { r[3] = Value.ref("FEtrending"); pc = 65; continue; }
case 65: { r[4] = Value.ref("TRENDING"); pc = 66; continue; }
case 66: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 67; continue; }
case 67: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->TRENDING:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 68; continue; }
case 68: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 69; continue; }
case 69: { r[2] = Value.i32(11); pc = 70; continue; }
case 70: { r[3] = Value.ref("FEclips"); pc = 71; continue; }
case 71: { r[4] = Value.ref("YOUR_CLIPS"); pc = 72; continue; }
case 72: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 73; continue; }
case 73: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->YOUR_CLIPS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 74; continue; }
case 74: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 75; continue; }
case 75: { r[2] = Value.i32(12); pc = 76; continue; }
case 76: { r[3] = Value.ref("UCtFRv9O2AHqOZjjynzrv-xg"); pc = 77; continue; }
case 77: { r[4] = Value.ref("COURSES"); pc = 78; continue; }
case 78: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 79; continue; }
case 79: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->COURSES:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 80; continue; }
case 80: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 81; continue; }
case 81: { r[2] = Value.i32(13); pc = 82; continue; }
case 82: { r[3] = Value.ref("UCrpQ4p1Ql_hG8rKXIKM1MOQ"); pc = 83; continue; }
case 83: { r[4] = Value.ref("FASHION"); pc = 84; continue; }
case 84: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 85; continue; }
case 85: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->FASHION:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 86; continue; }
case 86: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 87; continue; }
case 87: { r[2] = Value.i32(14); pc = 88; continue; }
case 88: { r[3] = Value.ref("UCOpNcN46UbXVtpKMrmU4Abg"); pc = 89; continue; }
case 89: { r[4] = Value.ref("GAMING"); pc = 90; continue; }
case 90: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 91; continue; }
case 91: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->GAMING:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 92; continue; }
case 92: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 93; continue; }
case 93: { r[2] = Value.i32(15); pc = 94; continue; }
case 94: { r[3] = Value.ref("UC4R8DWoMoI7CAwX8_LjQHig"); pc = 95; continue; }
case 95: { r[4] = Value.ref("LIVE"); pc = 96; continue; }
case 96: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 97; continue; }
case 97: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->LIVE:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 98; continue; }
case 98: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 99; continue; }
case 99: { r[2] = Value.i32(16); pc = 100; continue; }
case 100: { r[3] = Value.ref("UC-9-kyTW8ZkZNDHQJ6FgpwQ"); pc = 101; continue; }
case 101: { r[4] = Value.ref("MUSIC"); pc = 102; continue; }
case 102: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 103; continue; }
case 103: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->MUSIC:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 104; continue; }
case 104: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 105; continue; }
case 105: { r[2] = Value.i32(17); pc = 106; continue; }
case 106: { r[3] = Value.ref("UCYfdidRxbB8Qhf0Nx7ioOYw"); pc = 107; continue; }
case 107: { r[4] = Value.ref("NEWS"); pc = 108; continue; }
case 108: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 109; continue; }
case 109: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->NEWS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 110; continue; }
case 110: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 111; continue; }
case 111: { r[2] = Value.i32(18); pc = 112; continue; }
case 112: { r[3] = Value.ref("UCkYQyvc_i9hXEo4xic9Hh2g"); pc = 113; continue; }
case 113: { r[4] = Value.ref("SHOPPING"); pc = 114; continue; }
case 114: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 115; continue; }
case 115: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SHOPPING:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 116; continue; }
case 116: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 117; continue; }
case 117: { r[2] = Value.i32(19); pc = 118; continue; }
case 118: { r[3] = Value.ref("UCEgdi0XIXXZ-qJOFPf4JSKw"); pc = 119; continue; }
case 119: { r[4] = Value.ref("SPORTS"); pc = 120; continue; }
case 120: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 121; continue; }
case 121: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SPORTS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 122; continue; }
case 122: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 123; continue; }
case 123: { r[2] = Value.i32(20); pc = 124; continue; }
case 124: { r[3] = Value.ref("UCzuqhhs6NWbgTzMuM09WKDQ"); pc = 125; continue; }
case 125: { r[4] = Value.ref("VIRTUAL_REALITY"); pc = 126; continue; }
case 126: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 127; continue; }
case 127: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->VIRTUAL_REALITY:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 128; continue; }
case 128: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 129; continue; }
case 129: { r[2] = Value.i32(21); pc = 130; continue; }
case 130: { r[3] = Value.ref("VLLL"); pc = 131; continue; }
case 131: { r[4] = Value.ref("LIKED_VIDEO"); pc = 132; continue; }
case 132: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 133; continue; }
case 133: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->LIKED_VIDEO:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 134; continue; }
case 134: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 135; continue; }
case 135: { r[2] = Value.i32(22); pc = 136; continue; }
case 136: { r[3] = Value.ref("VLWL"); pc = 137; continue; }
case 137: { r[4] = Value.ref("WATCH_LATER"); pc = 138; continue; }
case 138: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 139; continue; }
case 139: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->WATCH_LATER:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 140; continue; }
case 140: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 141; continue; }
case 141: { r[1] = rt.readField("Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;",Value.NULL,true); pc = 142; continue; }
case 142: { r[2] = Value.ref("SEARCH"); pc = 143; continue; }
case 143: { r[3] = Value.i32(23); pc = 144; continue; }
case 144: { r[4] = Value.ref("com.google.android.youtube.action.open.search"); pc = 145; continue; }
case 145: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[2], r[3], r[4], r[1]}); pc = 146; continue; }
case 146: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SEARCH:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 147; continue; }
case 147: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); pc = 148; continue; }
case 148: { r[2] = Value.i32(24); pc = 149; continue; }
case 149: { r[3] = Value.ref("com.google.android.youtube.action.open.shorts"); pc = 150; continue; }
case 150: { r[4] = Value.ref("SHORTS"); pc = 151; continue; }
case 151: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Boolean;)V",r[0],new Value[]{r[4], r[2], r[3], r[1]}); pc = 152; continue; }
case 152: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SHORTS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 153; continue; }
case 153: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->$values()[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,new Value[]{}); pc = 154; continue; }
case 154: { r[0] = result; pc = 155; continue; }
case 155: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->$VALUES:[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true,r[0]); pc = 156; continue; }
case 156: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_800c29014c3068e06840ffc1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Ljava/lang/String;");
r[4] = rt.check(arguments[3], "Ljava/lang/Boolean;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->id:Ljava/lang/String;",r[0],false,r[3]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->isBrowseId:Ljava/lang/Boolean;",r[0],false,r[4]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9a9752ee48c682cd43354cc7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[26];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 1; continue; }
case 1: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->ALL_SUBSCRIPTIONS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 2; continue; }
case 2: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->BROWSE:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 3; continue; }
case 3: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->EXPLORE:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 4; continue; }
case 4: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->HISTORY:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 5; continue; }
case 5: { r[6] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->LIBRARY:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 6; continue; }
case 6: { r[7] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->MOVIE:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 7; continue; }
case 7: { r[8] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->NOTIFICATIONS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 8; continue; }
case 8: { r[9] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->PLAYLISTS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 9; continue; }
case 9: { r[10] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SUBSCRIPTIONS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 10; continue; }
case 10: { r[11] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->TRENDING:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 11; continue; }
case 11: { r[12] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->YOUR_CLIPS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 12; continue; }
case 12: { r[13] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->COURSES:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 13; continue; }
case 13: { r[14] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->FASHION:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 14; continue; }
case 14: { r[15] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->GAMING:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 15; continue; }
case 15: { r[16] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->LIVE:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 16; continue; }
case 16: { r[17] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->MUSIC:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 17; continue; }
case 17: { r[18] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->NEWS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 18; continue; }
case 18: { r[19] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SHOPPING:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 19; continue; }
case 19: { r[20] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SPORTS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 20; continue; }
case 20: { r[21] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->VIRTUAL_REALITY:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 21; continue; }
case 21: { r[22] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->LIKED_VIDEO:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 22; continue; }
case 22: { r[23] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->WATCH_LATER:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 23; continue; }
case 23: { r[24] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SEARCH:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 24; continue; }
case 24: { r[25] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->SHORTS:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",Value.NULL,true); pc = 25; continue; }
case 25: { result=rt.filledArray("[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;",new Value[]{r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19], r[20], r[21], r[22], r[23], r[24], r[25]}); pc = 26; continue; }
case 26: { r[0] = result; pc = 27; continue; }
case 27: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
