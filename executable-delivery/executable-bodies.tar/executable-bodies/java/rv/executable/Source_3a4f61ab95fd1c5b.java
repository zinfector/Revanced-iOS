package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_3a4f61ab95fd1c5b extends RuntimeForeign.SourceProxy {
Source_3a4f61ab95fd1c5b(RuntimeForeign owner,Instance source){super(owner,source);}

}
