package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_ca85ace2b1e85762 extends RuntimeForeign.SourceProxy {
Source_ca85ace2b1e85762(RuntimeForeign owner,Instance source){super(owner,source);}

}
