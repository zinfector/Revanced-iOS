package rv.executable;
import rv.executable.ExecutableRuntime.*;
public final class GeneratedEntryPoints {
private static volatile ExecutableRuntime configured;
public static synchronized void configure(Foreign provider) {
 if(configured!=null)throw new IllegalStateException("Body runtime already configured");
 configured=new ExecutableRuntime(new GeneratedProgram(),provider);
}
public static ExecutableRuntime runtime() {
 ExecutableRuntime value=configured;
 if(value==null)throw new IllegalStateException("Foreign providers must be configured before policy initialization");
 return value;
}
public static boolean entry_ef6c964cdf661b97f2ab644a() throws Throwable {Value value=runtime().invoke("static", null, "Lapp/revanced/extension/youtube/patches/VideoAdsPatch;->shouldShowAds()Z", Value.NULL, new Value[]{}); return value.z();}
public static void entry_a7fb137736614ef3973ebdfc(Object a0) throws Throwable {runtime().invoke("static", null, "Lapp/revanced/extension/shared/Utils;->setContext(Landroid/content/Context;)V", Value.NULL, new Value[]{Value.ref(a0)});}
}
