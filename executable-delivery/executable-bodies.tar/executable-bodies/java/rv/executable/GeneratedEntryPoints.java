package rv.executable;
import rv.executable.ExecutableRuntime.*;
public final class GeneratedEntryPoints {
private static volatile ExecutableRuntime configured;
public static synchronized void configure(Foreign provider) {
 if(configured!=null)throw new IllegalStateException("Body runtime already configured");
 configured=new ExecutableRuntime(new GeneratedProgram(),provider);
}
public static ExecutableRuntime runtime() {
 ExecutableRuntime value=configured;
 if(value==null)throw new IllegalStateException("Foreign providers must be configured before policy initialization");
 return value;
}
public static void entry_5b419a7dc26ec10cef157a72(boolean a0) throws Throwable {runtime().invoke("static", null, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->setOpen(Z)V", Value.NULL, new Value[]{Value.i32(a0 ? 1 : 0)});}
public static boolean entry_c857be1760d3b002f1b03766() throws Throwable {Value value=runtime().invoke("static", null, "Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->isOpen()Z", Value.NULL, new Value[]{}); return value.z();}
public static void entry_5809fd4b801f810fddfd4c6c(String a0) throws Throwable {runtime().invoke("static", null, "Lapp/revanced/extension/youtube/shared/PlayerType;->setFromString(Ljava/lang/String;)V", Value.NULL, new Value[]{Value.ref(a0)});}
public static boolean entry_d763338617254789efddae75(boolean a0) throws Throwable {Value value=runtime().invoke("static", null, "Lapp/revanced/extension/youtube/patches/BackgroundPlaybackPatch;->isBackgroundPlaybackAllowed(Z)Z", Value.NULL, new Value[]{Value.i32(a0 ? 1 : 0)}); return value.z();}
public static boolean entry_ef6c964cdf661b97f2ab644a() throws Throwable {Value value=runtime().invoke("static", null, "Lapp/revanced/extension/youtube/patches/VideoAdsPatch;->shouldShowAds()Z", Value.NULL, new Value[]{}); return value.z();}
}
