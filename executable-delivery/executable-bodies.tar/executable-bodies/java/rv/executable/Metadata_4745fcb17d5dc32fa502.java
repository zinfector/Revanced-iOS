package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_4745fcb17d5dc32fa502 {
static ClassInfo info_4745fcb17d5dc32fa502() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lkotlin/jvm/functions/Function1;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("invoke(Ljava/lang/Object;)Ljava/lang/Object;", 17)}, "SponsorBlockViewController$$ExternalSyntheticLambda0");}
}
