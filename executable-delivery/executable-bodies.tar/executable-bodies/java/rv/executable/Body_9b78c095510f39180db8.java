package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_9b78c095510f39180db8 {
static Value m_a04dc89774c532ef5d76fc97(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;");
r[1] = rt.check(arguments[0], "J"); r[2] = r[1];
r[3] = rt.check(arguments[1], "J"); r[4] = r[3];
r[5] = rt.check(arguments[2], "J"); r[6] = r[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;->f$0:J",r[0],false,r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;->f$1:J",r[0],false,r[3]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;->f$2:J",r[0],false,r[5]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cc3b55d6823c2566d4417868(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[6] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;->f$0:J",r[6],false); r[1] = r[0]; pc = 1; continue; }
case 1: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;->f$1:J",r[6],false); r[3] = r[2]; pc = 2; continue; }
case 2: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;->f$2:J",r[6],false); r[5] = r[4]; pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;","Lapp/revanced/extension/youtube/patches/VideoInformation;->$r8$lambda$VDDmvEKAPKGcsj1s5MWlJQhO4bs(JJJ)Ljava/lang/String;",Value.NULL,new Value[]{r[0], r[2], r[4]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
