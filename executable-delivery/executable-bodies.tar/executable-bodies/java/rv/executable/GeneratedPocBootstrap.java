package rv.executable;
import java.util.*;
/** Fresh generated initialization; no direct writes into translated source fields. */
public final class GeneratedPocBootstrap {
 private static IOSPlatformServices services;
 private static int state; // 0 not started, 1 initializing, 2 ready, 3 failed
 private static String failure="";
 private static synchronized IOSPlatformServices services(){
  if(services==null)services=new IOSPlatformServices(profile(),ids(),strings());return services;
 }
 public static synchronized boolean initializeRuntime(){
  if(state==2)return true;if(state!=0)return false;state=1;
  try {
   GeneratedForeign provider=new GeneratedForeign(services());
   GeneratedEntryPoints.configure(provider);
   GeneratedEntryPoints.entry_a7fb137736614ef3973ebdfc(provider.context().o());
   GeneratedEntryPoints.entry_ef6c964cdf661b97f2ab644a(); // Preserve original active-use/static initialization.
   state=2;return true;
  } catch(Throwable error){failure=error.toString();state=3;return false;}
 }
 public static synchronized String status(){return state==2?"ready":state==3?"failed: "+failure:state==1?"initializing":"unconfigured";}
 public static boolean readSetting(){
  String value=services().preference("revanced_prefs","revanced_hide_video_ads");
  if(value==null)return true;
  if(!value.equals("Z:0") && !value.equals("Z:1"))throw new IllegalStateException("Invalid Boolean preference");
  return value.equals("Z:1");
 }
 public static boolean writeSetting(boolean value){
  return services().commitPreferences("revanced_prefs",Collections.singletonMap("revanced_hide_video_ads",value?"Z:1":"Z:0"));
 }
private static void profile0(Map<String,String> values){values.put("compat.build.ID","RVGenerated-API28");
values.put("compat.build.MANUFACTURER","ReVanced");
values.put("compat.build.MODEL","Generated compatibility context");
values.put("compat.build.RELEASE","9");
values.put("compat.build.SDK_INT","28");
values.put("source.locale","en");
values.put("source.packageName","com.google.android.youtube");
values.put("source.versionName","20.40.45");}

private static Map<String,String> profile(){Map<String,String> values=new LinkedHashMap<>();profile0(values);return values;}

private static Map<String,Integer> ids(){Map<String,Integer> values=new LinkedHashMap<>();return values;}

private static Map<Integer,String> strings(){Map<Integer,String> values=new LinkedHashMap<>();return values;}
}
