package rv.executable;
import java.util.*;
/** Fresh generated initialization; no direct writes into translated source fields. */
public final class GeneratedPocBootstrap {
 private static IOSPlatformServices services;
 private static int state; // 0 not started, 1 initializing, 2 ready, 3 failed
 private static String failure="";
 private static String stage="not_started";
 private static GeneratedForeign provider;
 private static Throwable originalFailure;
 private static Map<String,Object> failureDetails=Collections.emptyMap();
 private static String bounded(String text,int limit){return text==null?"":text.length()>limit?text.substring(0,limit):text;}
 private static Map<String,Object> describeFailure(Throwable error){
  Map<String,Object> details=new LinkedHashMap<>();details.put("stage",stage);
  List<Object> chain=new ArrayList<>();Set<Throwable> seen=Collections.newSetFromMap(new IdentityHashMap<>());
  for(Throwable cursor=error;cursor!=null && seen.add(cursor) && chain.size()<8;){
   Map<String,Object> row=new LinkedHashMap<>();row.put("type",cursor.getClass().getName());row.put("message",bounded(cursor.getMessage(),512));
   List<String> stack=new ArrayList<>();StackTraceElement[] frames=cursor.getStackTrace();
   for(int i=0;i<frames.length && i<12;i++)stack.add(bounded(frames[i].toString(),256));
   row.put("stack",stack);chain.add(row);
   Throwable next=cursor.getCause();
   if((next==null || next==cursor) && cursor instanceof ExceptionInInitializerError)next=((ExceptionInInitializerError)cursor).getException();
   cursor=next;
  }
  details.put("causes",chain);if(provider!=null)details.put("foreignBoundary",provider.failureContext());
  try{details.put("failedSourceClasses",GeneratedEntryPoints.runtime().failedClasses());}catch(Throwable ignored){}
  return details;
 }
 private static synchronized IOSPlatformServices services(){
  if(services==null)services=new IOSPlatformServices(profile(),ids(),strings());return services;
 }
 public static synchronized boolean initializeRuntime(){
  if(state==2)return true;if(state!=0)return false;state=1;
  try {
   stage="array_runtime";ArrayInterop.prepare();
   stage="configure";provider=new GeneratedForeign(services());
   GeneratedEntryPoints.configure(provider);
   stage="source_context";
   GeneratedEntryPoints.entry_a7fb137736614ef3973ebdfc(provider.context().o());
   stage="source_policy";
   GeneratedEntryPoints.entry_ef6c964cdf661b97f2ab644a(); // Preserve original active-use/static initialization.
   stage="ready";state=2;return true;
  } catch(Throwable error){
   originalFailure=error;failure=bounded(error.toString(),1024);state=3;
   try{failureDetails=describeFailure(error);}catch(Throwable diagnosticsError){failureDetails=Collections.singletonMap("stage",stage);}
   return false;
  }
 }
 public static synchronized String status(){return state==2?"ready":state==3?"failed: "+failure:state==1?"initializing":"unconfigured";}
 public static synchronized Map<String,Object> diagnostics(){
  Map<String,Object> report=new LinkedHashMap<>();report.put("state",state);report.put("stage",stage);report.put("failure",failureDetails);return report;
 }
 public static boolean readSetting(){
  String value=services().preference("revanced_prefs","revanced_hide_video_ads");
  if(value==null)return true;
  if(!value.equals("Z:0") && !value.equals("Z:1"))throw new IllegalStateException("Invalid Boolean preference");
  return value.equals("Z:1");
 }
 public static boolean writeSetting(boolean value){
  return services().commitPreferences("revanced_prefs",Collections.singletonMap("revanced_hide_video_ads",value?"Z:1":"Z:0"));
 }
private static void profile0(Map<String,String> values){values.put("compat.build.ID","RVGenerated-API28");
values.put("compat.build.MANUFACTURER","ReVanced");
values.put("compat.build.MODEL","Generated compatibility context");
values.put("compat.build.RELEASE","9");
values.put("compat.build.SDK_INT","28");
values.put("source.locale","en");
values.put("source.packageName","com.google.android.youtube");
values.put("source.versionName","20.40.45");}

private static Map<String,String> profile(){Map<String,String> values=new LinkedHashMap<>();profile0(values);return values;}

private static Map<String,Integer> ids(){Map<String,Integer> values=new LinkedHashMap<>();return values;}

private static Map<Integer,String> strings(){Map<Integer,String> values=new LinkedHashMap<>();return values;}
}
