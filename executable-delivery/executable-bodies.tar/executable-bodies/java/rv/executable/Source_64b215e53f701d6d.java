package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_64b215e53f701d6d extends RuntimeForeign.SourceProxy {
Source_64b215e53f701d6d(RuntimeForeign owner,Instance source){super(owner,source);}

}
