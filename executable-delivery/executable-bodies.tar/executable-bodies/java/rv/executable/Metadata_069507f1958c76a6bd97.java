package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_069507f1958c76a6bd97 {
static ClassInfo info_069507f1958c76a6bd97() {return new ClassInfo("Lkotlin/collections/MapsKt__MapWithDefaultKt;", "Ljava/lang/Object;", new String[]{}, 1025, new FieldInfo[]{}, new MethodInfo[]{});}
}
