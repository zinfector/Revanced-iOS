package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_7966805ff5583f4fbedf {
static Value m_d279d9bda881804131a3008e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/AbstractPreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/AbstractPreferenceFragment;","Landroid/preference/PreferenceFragment;-><init>()V",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/preference/AbstractPreferenceFragment$$ExternalSyntheticLambda11;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/AbstractPreferenceFragment;","Lapp/revanced/extension/shared/settings/preference/AbstractPreferenceFragment$$ExternalSyntheticLambda11;-><init>(Lapp/revanced/extension/shared/settings/preference/AbstractPreferenceFragment;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/settings/preference/AbstractPreferenceFragment;->listener:Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;",r[1],false,r[0]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
