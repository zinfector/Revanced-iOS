package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_3382daff238827e1 extends RuntimeForeign.SourceProxy implements java.lang.Runnable {
Proxy_3382daff238827e1(RuntimeForeign owner,Instance source){super(owner,source);}
public void run() {Value result=owner.callback(source,"Ljava/lang/Runnable;->run()V",new Value[]{}); return;}
}
