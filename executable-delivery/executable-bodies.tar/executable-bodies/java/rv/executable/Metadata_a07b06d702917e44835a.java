package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_a07b06d702917e44835a {
static ClassInfo info_a07b06d702917e44835a() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$DeArrowAvailability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("usingDeArrowAnywhere()Z", 9), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
