package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_4588ddf4c97cb80d201e {
static ClassInfo info_4588ddf4c97cb80d201e() {return new ClassInfo("Lkotlin/enums/EnumEntries;", "Ljava/lang/Object;", new String[]{"Ljava/util/List;"}, 1537, new FieldInfo[]{}, new MethodInfo[]{});}
}
