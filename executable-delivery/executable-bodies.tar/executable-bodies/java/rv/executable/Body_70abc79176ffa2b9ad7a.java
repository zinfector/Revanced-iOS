package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_70abc79176ffa2b9ad7a {
static Value m_f39591cbf5fcbb0cdb71fd6f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[1] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->compareTo(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)I",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { return rt.check(r[1],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7371b0818e5c3f7d32ec5f5d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->UUID:Ljava/lang/String;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/util/Objects;->hashCode(Ljava/lang/Object;)I",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_bb10b668fca81648d1340d1c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[4] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[5] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[4],false); r[1] = r[0]; pc = 1; continue; }
case 1: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[5],false); r[3] = r[2]; pc = 2; continue; }
case 2: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[2].j())); pc = 3; continue; }
case 3: { pc=(r[0].i() > 0)?10:4; continue; }
case 4: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[5],false); r[1] = r[0]; pc = 5; continue; }
case 5: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[4],false); r[3] = r[2]; pc = 6; continue; }
case 6: { r[5] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[2].j())); pc = 7; continue; }
case 7: { pc=(r[5].i() > 0)?10:8; continue; }
case 8: { r[5] = Value.i32(1); pc = 9; continue; }
case 9: { return rt.check(r[5],"Z"); }
case 10: { r[5] = Value.i32(0); pc = 11; continue; }
case 11: { return rt.check(r[5],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_464b8dedc8b56de5791c1c10(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[0], "J"); r[4] = r[3];
r[5] = rt.check(arguments[1], "J"); r[6] = r[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[2],false); r[1] = r[0]; pc = 1; continue; }
case 1: { r[0] = Value.i64((r[0].j()) - (r[3].j())); r[1] = r[0]; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/Math;->abs(J)J",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[3] = result; r[4] = r[3]; pc = 4; continue; }
case 4: { r[3] = Value.i32(ExecutableRuntime.compareLong(r[3].j(), r[5].j())); pc = 5; continue; }
case 5: { pc=(r[3].i() > 0)?8:6; continue; }
case 6: { r[3] = Value.i32(1); pc = 7; continue; }
case 7: { return rt.check(r[3],"Z"); }
case 8: { r[3] = Value.i32(0); pc = 9; continue; }
case 9: { return rt.check(r[3],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5c973727196260b0b978c364(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[5] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[6] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[5],false); r[1] = r[0]; pc = 1; continue; }
case 1: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[6],false); r[3] = r[2]; pc = 2; continue; }
case 2: { r[4] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[2].j())); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[4],Value.i32(0)))?11:4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->length()J",r[6],new Value[]{}); pc = 5; continue; }
case 5: { r[0] = result; r[1] = r[0]; pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->length()J",r[5],new Value[]{}); pc = 7; continue; }
case 7: { r[2] = result; r[3] = r[2]; pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/Long;->compare(JJ)I",Value.NULL,new Value[]{r[0], r[2]}); pc = 9; continue; }
case 9: { r[6] = result; pc = 10; continue; }
case 10: { return rt.check(r[6],"I"); }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/Long;->compare(JJ)I",Value.NULL,new Value[]{r[0], r[2]}); pc = 12; continue; }
case 12: { r[6] = result; pc = 13; continue; }
case 13: { return rt.check(r[6],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_abb890c28b6e8ef3124bfc03(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[2],false); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviour:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",r[0],false); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->skipAutomatically:Z",r[0],false); pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?10:4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->didAutoSkipped:Z",r[2],false); pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?8:6; continue; }
case 6: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SKIP_AUTOMATICALLY_ONCE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",Value.NULL,true); pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[0],r[1]))?10:8; continue; }
case 8: { r[0] = Value.i32(1); pc = 9; continue; }
case 9: { return rt.check(r[0],"Z"); }
case 10: { r[0] = Value.i32(0); pc = 11; continue; }
case 11: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_afd852b1698a16be92a1cbff(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[5] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[5],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?5:3; continue; }
case 3: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 4; continue; }
case 4: { pc=6; continue; }
case 5: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[5],false); r[1] = r[0]; pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[0]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[5],false); r[2] = r[1]; pc = 9; continue; }
case 9: { r[3] = Value.i64(1L); r[4] = r[3]; pc = 10; continue; }
case 10: { r[1] = Value.i64((r[1].j()) - (r[3].j())); r[2] = r[1]; pc = 11; continue; }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[1]}); pc = 12; continue; }
case 12: { r[1] = result; pc = 13; continue; }
case 13: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Landroid/util/Range;->create(Ljava/lang/Comparable;Ljava/lang/Comparable;)Landroid/util/Range;",Value.NULL,new Value[]{r[0], r[1]}); pc = 14; continue; }
case 14: { r[0] = result; pc = 15; continue; }
case 15: { return rt.check(r[0],"Landroid/util/Range;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7fe531941da89c9d5fe17837(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[0], "J"); r[4] = r[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[2],false); r[1] = r[0]; pc = 1; continue; }
case 1: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[3].j())); pc = 2; continue; }
case 2: { pc=(r[0].i() > 0)?8:3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[2],false); r[1] = r[0]; pc = 4; continue; }
case 4: { r[3] = Value.i32(ExecutableRuntime.compareLong(r[3].j(), r[0].j())); pc = 5; continue; }
case 5: { pc=(r[3].i() >= 0)?8:6; continue; }
case 6: { r[3] = Value.i32(1); pc = 7; continue; }
case 7: { return rt.check(r[3],"Z"); }
case 8: { r[3] = Value.i32(0); pc = 9; continue; }
case 9: { return rt.check(r[3],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_097346cb4838f96066f5128b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[4] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[4],false); r[1] = r[0]; pc = 1; continue; }
case 1: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[4],false); r[3] = r[2]; pc = 2; continue; }
case 2: { r[0] = Value.i64((r[0].j()) - (r[2].j())); r[1] = r[0]; pc = 3; continue; }
case 3: { return rt.check(r[0],"J"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_261371283d5f569b4ba90879(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[5] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[5],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[5],false); r[2] = r[1]; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoLength()J",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[3] = result; r[4] = r[3]; pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->getSkipButtonText(JJ)Lapp/revanced/extension/shared/StringRef;",r[0],new Value[]{r[1], r[3]}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/shared/StringRef;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e6cf3b89d7192ffe24bdd680(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[5] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[5],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[5],false); r[2] = r[1]; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoLength()J",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[3] = result; r[4] = r[3]; pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->getSkippedToastText(JJ)Lapp/revanced/extension/shared/StringRef;",r[0],new Value[]{r[1], r[3]}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Lapp/revanced/extension/shared/StringRef;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6fc57356bdc98bc4d9b609f4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[0], "J"); r[4] = r[3];
r[5] = rt.check(arguments[1], "J"); r[6] = r[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[2],false); r[1] = r[0]; pc = 1; continue; }
case 1: { r[0] = Value.i64((r[0].j()) - (r[3].j())); r[1] = r[0]; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/Math;->abs(J)J",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[3] = result; r[4] = r[3]; pc = 4; continue; }
case 4: { r[3] = Value.i32(ExecutableRuntime.compareLong(r[3].j(), r[5].j())); pc = 5; continue; }
case 5: { pc=(r[3].i() > 0)?8:6; continue; }
case 6: { r[3] = Value.i32(1); pc = 7; continue; }
case 7: { return rt.check(r[3],"Z"); }
case 8: { r[3] = Value.i32(0); pc = 9; continue; }
case 9: { return rt.check(r[3],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f3b0a559b981bca91ee36a96(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 5) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;");
r[3] = rt.check(arguments[1], "Ljava/lang/String;");
r[4] = rt.check(arguments[2], "J"); r[5] = r[4];
r[6] = rt.check(arguments[3], "J"); r[7] = r[6];
r[8] = rt.check(arguments[4], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/Object;-><init>()V",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = Value.i32(0); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->didAutoSkipped:Z",r[1],false,r[0]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->recordedAsSkipped:Z",r[1],false,r[0]); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[1],false,r[2]); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->UUID:Ljava/lang/String;",r[1],false,r[3]); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[1],false,r[4]); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[1],false,r[6]); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->isLocked:Z",r[1],false,r[8]); pc = 9; continue; }
case 9: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2a0cee78ca11dda0e86a420d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
r[7] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[8] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(1); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[7],r[8]))?3:2; continue; }
case 2: { return rt.check(r[0],"Z"); }
case 3: { r[1] = Value.i32(rt.isInstance(r[8].o(),"Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;")?1:0); pc = 4; continue; }
case 4: { r[2] = Value.i32(0); pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?24:6; continue; }
case 6: { r[8] = rt.cast(r[8],"Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"); pc = 7; continue; }
case 7: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->UUID:Ljava/lang/String;",r[7],false); pc = 8; continue; }
case 8: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->UUID:Ljava/lang/String;",r[8],false); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z",Value.NULL,new Value[]{r[1], r[3]}); pc = 10; continue; }
case 10: { r[1] = result; pc = 11; continue; }
case 11: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?24:12; continue; }
case 12: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[7],false); pc = 13; continue; }
case 13: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[8],false); pc = 14; continue; }
case 14: { pc=(!ExecutableRuntime.equal(r[1],r[3]))?24:15; continue; }
case 15: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[7],false); r[4] = r[3]; pc = 16; continue; }
case 16: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[8],false); r[6] = r[5]; pc = 17; continue; }
case 17: { r[1] = Value.i32(ExecutableRuntime.compareLong(r[3].j(), r[5].j())); pc = 18; continue; }
case 18: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?24:19; continue; }
case 19: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[7],false); r[4] = r[3]; pc = 20; continue; }
case 20: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[8],false); r[6] = r[5]; pc = 21; continue; }
case 21: { r[8] = Value.i32(ExecutableRuntime.compareLong(r[3].j(), r[5].j())); pc = 22; continue; }
case 22: { pc=(!ExecutableRuntime.equal(r[8],Value.i32(0)))?24:23; continue; }
case 23: { return rt.check(r[0],"Z"); }
case 24: { return rt.check(r[2],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_be3e4813e781c61934dd7c89(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("SponsorSegment{category="); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[3],false); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { r[1] = Value.ref(", start="); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[3],false); r[2] = r[1]; pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 9; continue; }
case 9: { r[1] = Value.ref(", end="); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 11; continue; }
case 11: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[3],false); r[2] = r[1]; pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 13; continue; }
case 13: { r[1] = Value.i32(125); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 16; continue; }
case 16: { r[0] = result; pc = 17; continue; }
case 17: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
