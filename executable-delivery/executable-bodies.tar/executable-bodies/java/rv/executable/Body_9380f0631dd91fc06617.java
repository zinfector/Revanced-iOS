package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_9380f0631dd91fc06617 {
static Value m_e68742371c5b8296b0bcce4a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->$VALUES:[Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState;","Ljava/lang/Object;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/shared/VideoState;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ebdb334d2f1911616c1f1f41(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->Companion:Lapp/revanced/extension/youtube/shared/VideoState$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState$Companion;->setFromString(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f0c6cd2625ab3c9143445baf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("NEW"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->NEW:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("PLAYING"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->PLAYING:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("PAUSED"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->PAUSED:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true,r[0]); pc = 15; continue; }
case 15: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 16; continue; }
case 16: { r[1] = Value.ref("RECOVERABLE_ERROR"); pc = 17; continue; }
case 17: { r[2] = Value.i32(3); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->RECOVERABLE_ERROR:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true,r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 21; continue; }
case 21: { r[1] = Value.ref("UNRECOVERABLE_ERROR"); pc = 22; continue; }
case 22: { r[2] = Value.i32(4); pc = 23; continue; }
case 23: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->UNRECOVERABLE_ERROR:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true,r[0]); pc = 25; continue; }
case 25: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 26; continue; }
case 26: { r[1] = Value.ref("ENDED"); pc = 27; continue; }
case 27: { r[2] = Value.i32(5); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->ENDED:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true,r[0]); pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState;->$values()[Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,new Value[]{}); pc = 31; continue; }
case 31: { r[0] = result; pc = 32; continue; }
case 32: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->$VALUES:[Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true,r[0]); pc = 33; continue; }
case 33: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState;","Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;",Value.NULL,new Value[]{r[0]}); pc = 34; continue; }
case 34: { r[0] = result; pc = 35; continue; }
case 35: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->$ENTRIES:Lkotlin/enums/EnumEntries;",Value.NULL,true,r[0]); pc = 36; continue; }
case 36: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/VideoState$Companion;"); pc = 37; continue; }
case 37: { r[1] = Value.i32(0); pc = 38; continue; }
case 38: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V",r[0],new Value[]{r[1]}); pc = 39; continue; }
case 39: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->Companion:Lapp/revanced/extension/youtube/shared/VideoState$Companion;",Value.NULL,true,r[0]); pc = 40; continue; }
case 40: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState;->getEntries()Lkotlin/enums/EnumEntries;",Value.NULL,new Value[]{}); pc = 41; continue; }
case 41: { r[0] = result; pc = 42; continue; }
case 42: { r[1] = Value.i32(10); pc = 43; continue; }
case 43: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState;","Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 44; continue; }
case 44: { r[1] = result; pc = 45; continue; }
case 45: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState;","Lkotlin/collections/MapsKt__MapsJVMKt;->mapCapacity(I)I",Value.NULL,new Value[]{r[1]}); pc = 46; continue; }
case 46: { r[1] = result; pc = 47; continue; }
case 47: { r[2] = Value.i32(16); pc = 48; continue; }
case 48: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState;","Lkotlin/ranges/RangesKt___RangesKt;->coerceAtLeast(II)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 49; continue; }
case 49: { r[1] = result; pc = 50; continue; }
case 50: { r[2] = rt.allocate("Ljava/util/LinkedHashMap;"); pc = 51; continue; }
case 51: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Ljava/util/LinkedHashMap;-><init>(I)V",r[2],new Value[]{r[1]}); pc = 52; continue; }
case 52: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/VideoState;","Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;",r[0],new Value[]{}); pc = 53; continue; }
case 53: { r[0] = result; pc = 54; continue; }
case 54: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/VideoState;","Ljava/util/Iterator;->hasNext()Z",r[0],new Value[]{}); pc = 55; continue; }
case 55: { r[1] = result; pc = 56; continue; }
case 56: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?65:57; continue; }
case 57: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/VideoState;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[0],new Value[]{}); pc = 58; continue; }
case 58: { r[1] = result; pc = 59; continue; }
case 59: { r[3] = r[1]; pc = 60; continue; }
case 60: { r[3] = rt.cast(r[3],"Lapp/revanced/extension/youtube/shared/VideoState;"); pc = 61; continue; }
case 61: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState;","Ljava/lang/Enum;->name()Ljava/lang/String;",r[3],new Value[]{}); pc = 62; continue; }
case 62: { r[3] = result; pc = 63; continue; }
case 63: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/VideoState;","Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",r[2],new Value[]{r[3], r[1]}); pc = 64; continue; }
case 64: { pc=54; continue; }
case 65: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->nameToVideoState:Ljava/util/Map;",Value.NULL,true,r[2]); pc = 66; continue; }
case 66: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_38fd47e90fa325f67571bff0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->Companion:Lapp/revanced/extension/youtube/shared/VideoState$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/VideoState;","Lapp/revanced/extension/youtube/shared/VideoState$Companion;->getCurrent()Lapp/revanced/extension/youtube/shared/VideoState;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/VideoState;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b3fa8808947dd5d4685df236(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/VideoState;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f307df63e09482f9e34a1fa6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->NEW:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->PLAYING:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->PAUSED:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->RECOVERABLE_ERROR:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->UNRECOVERABLE_ERROR:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->ENDED:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 6; continue; }
case 6: { result=rt.filledArray("[Lapp/revanced/extension/youtube/shared/VideoState;",new Value[]{r[0], r[1], r[2], r[3], r[4], r[5]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/shared/VideoState;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b4e3dc2ada3408c73d78367a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->$ENTRIES:Lkotlin/enums/EnumEntries;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lkotlin/enums/EnumEntries;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9efb11cc5dc787ada5822063(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->nameToVideoState:Ljava/util/Map;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/util/Map;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_942aa1cea06267fdadcc8a44(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->currentVideoState:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/VideoState;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5bfb41dee17c539455d4f7ae(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/VideoState;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState;->currentVideoState:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true,r[0]); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
