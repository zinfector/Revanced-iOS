package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_49e598caf985ea3dcf15 {
static ClassInfo info_49e598caf985ea3dcf15() {return new ClassInfo("Lapp/revanced/extension/shared/settings/Setting$Availability;", "Ljava/lang/Object;", new String[]{}, 1537, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("getParentSettings()Ljava/util/List;", 1025), new MethodInfo("isAvailable()Z", 1025)}, "Availability");}
}
