package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_107d026c1e4a09aaf0a9 {
static Value m_328e9e8221a9c97bf49d1b51(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/requests/Route$Method;->$VALUES:[Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route$Method;","[Lapp/revanced/extension/shared/requests/Route$Method;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/shared/requests/Route$Method;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/shared/requests/Route$Method;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_278fe7742d62b000715fbbc1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route$Method;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("GET"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route$Method;","Lapp/revanced/extension/shared/requests/Route$Method;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/requests/Route$Method;->GET:Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route$Method;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("POST"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route$Method;","Lapp/revanced/extension/shared/requests/Route$Method;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/requests/Route$Method;->POST:Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Route$Method;","Lapp/revanced/extension/shared/requests/Route$Method;->$values()[Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,new Value[]{}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/requests/Route$Method;->$VALUES:[Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,true,r[0]); pc = 13; continue; }
case 13: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_36fa9ddc7f815067dcad8e7a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/requests/Route$Method;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route$Method;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8eaa42db6e67004469ffd45d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(2); pc = 1; continue; }
case 1: { r[0] = rt.newArray("[Lapp/revanced/extension/shared/requests/Route$Method;",r[0].i()); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/requests/Route$Method;->GET:Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,true); pc = 3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/requests/Route$Method;->POST:Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,true); pc = 6; continue; }
case 6: { r[2] = Value.i32(1); pc = 7; continue; }
case 7: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 8; continue; }
case 8: { return rt.check(r[0],"[Lapp/revanced/extension/shared/requests/Route$Method;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
