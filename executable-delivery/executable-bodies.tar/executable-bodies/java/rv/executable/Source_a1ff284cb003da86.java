package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_a1ff284cb003da86 extends RuntimeForeign.SourceProxy {
Source_a1ff284cb003da86(RuntimeForeign owner,Instance source){super(owner,source);}

}
