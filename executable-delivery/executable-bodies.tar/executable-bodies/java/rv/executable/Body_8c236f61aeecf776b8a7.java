package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_8c236f61aeecf776b8a7 {
static Value m_f66ad308dd69b9d9b16a251e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ID:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = Value.ref("revanced_search_view"); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_REVANCED_SEARCH_VIEW:I",Value.NULL,true,r[1]); pc = 5; continue; }
case 5: { r[1] = Value.ref("revanced_search_view_container"); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_REVANCED_SEARCH_VIEW_CONTAINER:I",Value.NULL,true,r[1]); pc = 9; continue; }
case 9: { r[1] = Value.ref("action_search"); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 11; continue; }
case 11: { r[1] = result; pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_ACTION_SEARCH:I",Value.NULL,true,r[1]); pc = 13; continue; }
case 13: { r[1] = Value.ref("revanced_settings_fragments"); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 15; continue; }
case 15: { r[0] = result; pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_REVANCED_SETTINGS_FRAGMENTS:I",Value.NULL,true,r[0]); pc = 17; continue; }
case 17: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->DRAWABLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 18; continue; }
case 18: { r[1] = Value.ref("revanced_settings_search_icon"); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 20; continue; }
case 20: { r[1] = result; pc = 21; continue; }
case 21: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->DRAWABLE_REVANCED_SETTINGS_SEARCH_ICON:I",Value.NULL,true,r[1]); pc = 22; continue; }
case 22: { r[1] = Value.ref("revanced_settings_search_icon_bold"); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 24; continue; }
case 24: { r[0] = result; pc = 25; continue; }
case 25: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->DRAWABLE_REVANCED_SETTINGS_SEARCH_ICON_BOLD:I",Value.NULL,true,r[0]); pc = 26; continue; }
case 26: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->MENU:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 27; continue; }
case 27: { r[1] = Value.ref("revanced_search_menu"); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 29; continue; }
case 29: { r[0] = result; pc = 30; continue; }
case 30: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->MENU_REVANCED_SEARCH_MENU:I",Value.NULL,true,r[0]); pc = 31; continue; }
case 31: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_86c7667ce0d9f1cea1d51463(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->isSearchActive:Z",r[1],false); pc = 1; continue; }
case 1: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_54bc01521759370b7fb99628(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->isSearchActive:Z",r[3],false,r[0]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->isShowingSearchHistory:Z",r[3],false,r[0]); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchHistoryManager:Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;",r[3],false); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;->hideSearchHistoryContainer()V",r[1],new Value[]{}); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->overlayContainer:Landroid/widget/FrameLayout;",r[3],false); pc = 6; continue; }
case 6: { r[2] = Value.i32(8); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setVisibility(I)V",r[1],new Value[]{r[2]}); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->filteredSearchItems:Ljava/util/List;",r[3],false); pc = 9; continue; }
case 9: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Ljava/util/List;->clear()V",r[1],new Value[]{}); pc = 10; continue; }
case 10: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchContainer:Landroid/widget/FrameLayout;",r[3],false); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setVisibility(I)V",r[1],new Value[]{r[2]}); pc = 12; continue; }
case 12: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->toolbar:Landroid/widget/Toolbar;",r[3],false); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/Toolbar;->getMenu()Landroid/view/Menu;",r[1],new Value[]{}); pc = 14; continue; }
case 14: { r[1] = result; pc = 15; continue; }
case 15: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_ACTION_SEARCH:I",Value.NULL,true); pc = 16; continue; }
case 16: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;",r[1],new Value[]{r[2]}); pc = 17; continue; }
case 17: { r[1] = result; pc = 18; continue; }
case 18: { r[2] = Value.i32(1); pc = 19; continue; }
case 19: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;",r[1],new Value[]{r[2]}); pc = 20; continue; }
case 20: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->toolbar:Landroid/widget/Toolbar;",r[3],false); pc = 21; continue; }
case 21: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->originalTitle:Ljava/lang/CharSequence;",r[3],false); pc = 22; continue; }
case 22: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/Toolbar;->setTitle(Ljava/lang/CharSequence;)V",r[1],new Value[]{r[2]}); pc = 23; continue; }
case 23: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchView:Landroid/widget/SearchView;",r[3],false); pc = 24; continue; }
case 24: { r[2] = Value.ref(""); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/SearchView;->setQuery(Ljava/lang/CharSequence;Z)V",r[1],new Value[]{r[2], r[0]}); pc = 26; continue; }
case 26: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->inputMethodManager:Landroid/view/inputmethod/InputMethodManager;",r[3],false); pc = 27; continue; }
case 27: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchView:Landroid/widget/SearchView;",r[3],false); pc = 28; continue; }
case 28: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->getWindowToken()Landroid/os/IBinder;",r[2],new Value[]{}); pc = 29; continue; }
case 29: { r[2] = result; pc = 30; continue; }
case 30: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z",r[1],new Value[]{r[2], r[0]}); pc = 31; continue; }
case 31: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[3],false); pc = 32; continue; }
case 32: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/app/Activity;->getWindow()Landroid/view/Window;",r[0],new Value[]{}); pc = 33; continue; }
case 33: { r[0] = result; pc = 34; continue; }
case 34: { r[1] = Value.i32(32); pc = 35; continue; }
case 35: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/Window;->setSoftInputMode(I)V",r[0],new Value[]{r[1]}); pc = 36; continue; }
case 36: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->allSearchItems:Ljava/util/List;",r[3],false); pc = 37; continue; }
case 37: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Ljava/util/List;->iterator()Ljava/util/Iterator;",r[0],new Value[]{}); pc = 38; continue; }
case 38: { r[0] = result; pc = 39; continue; }
case 39: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Ljava/util/Iterator;->hasNext()Z",r[0],new Value[]{}); pc = 40; continue; }
case 40: { r[1] = result; pc = 41; continue; }
case 41: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?47:42; continue; }
case 42: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[0],new Value[]{}); pc = 43; continue; }
case 43: { r[1] = result; pc = 44; continue; }
case 44: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/shared/settings/search/BaseSearchResultItem;"); pc = 45; continue; }
case 45: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchResultItem;->clearHighlighting()V",r[1],new Value[]{}); pc = 46; continue; }
case 46: { pc=39; continue; }
case 47: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchResultsAdapter:Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;",r[3],false); pc = 48; continue; }
case 48: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/BaseAdapter;->notifyDataSetChanged()V",r[0],new Value[]{}); pc = 49; continue; }
case 49: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4c3d0ef310114c2f1a98a279(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
r[1] = rt.check(arguments[0], "Landroid/app/Activity;");
r[2] = rt.check(arguments[1], "Landroid/widget/Toolbar;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[0],false,r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->toolbar:Landroid/widget/Toolbar;",r[0],false,r[2]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->fragment:Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;",r[0],false,r[3]); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/Toolbar;->getTitle()Ljava/lang/CharSequence;",r[2],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->originalTitle:Ljava/lang/CharSequence;",r[0],false,r[2]); pc = 7; continue; }
case 7: { r[2] = rt.allocate("Ljava/util/ArrayList;"); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Ljava/util/ArrayList;-><init>()V",r[2],new Value[]{}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->allSearchItems:Ljava/util/List;",r[0],false,r[2]); pc = 10; continue; }
case 10: { r[2] = rt.allocate("Ljava/util/ArrayList;"); pc = 11; continue; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Ljava/util/ArrayList;-><init>()V",r[2],new Value[]{}); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->filteredSearchItems:Ljava/util/List;",r[0],false,r[2]); pc = 13; continue; }
case 13: { r[2] = rt.allocate("Ljava/util/HashMap;"); pc = 14; continue; }
case 14: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Ljava/util/HashMap;-><init>()V",r[2],new Value[]{}); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->keyToSearchItem:Ljava/util/Map;",r[0],false,r[2]); pc = 16; continue; }
case 16: { r[2] = Value.ref("input_method"); pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;",r[1],new Value[]{r[2]}); pc = 18; continue; }
case 18: { r[1] = result; pc = 19; continue; }
case 19: { r[1] = rt.cast(r[1],"Landroid/view/inputmethod/InputMethodManager;"); pc = 20; continue; }
case 20: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->inputMethodManager:Landroid/view/inputmethod/InputMethodManager;",r[0],false,r[1]); pc = 21; continue; }
case 21: { r[1] = Value.i32(0); pc = 22; continue; }
case 22: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->isShowingSearchHistory:Z",r[0],false,r[1]); pc = 23; continue; }
case 23: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->initializeSearchView()V",r[0],new Value[]{}); pc = 24; continue; }
case 24: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->initializeOverlayContainer()V",r[0],new Value[]{}); pc = 25; continue; }
case 25: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->initializeSearchHistoryManager()V",r[0],new Value[]{}); pc = 26; continue; }
case 26: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->setupToolbarMenu()V",r[0],new Value[]{}); pc = 27; continue; }
case 27: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->setupListeners()V",r[0],new Value[]{}); pc = 28; continue; }
case 28: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_aa667ee9207794d8229d0a71(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[3],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_REVANCED_SEARCH_VIEW:I",Value.NULL,true); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/app/Activity;->findViewById(I)Landroid/view/View;",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[0] = rt.cast(r[0],"Landroid/widget/SearchView;"); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchView:Landroid/widget/SearchView;",r[3],false,r[0]); pc = 6; continue; }
case 6: { r[1] = Value.i32(0); pc = 7; continue; }
case 7: { r[2] = Value.ref("android:id/search_src_text"); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->findViewById(I)Landroid/view/View;",r[0],new Value[]{r[1]}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { r[0] = rt.cast(r[0],"Landroid/widget/EditText;"); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/TextView;->getImeOptions()I",r[0],new Value[]{}); pc = 14; continue; }
case 14: { r[1] = result; pc = 15; continue; }
case 15: { r[2] = Value.i32(268435456); pc = 16; continue; }
case 16: { r[1] = Value.i32((r[1].i()) | (r[2].i())); pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/TextView;->setImeOptions(I)V",r[0],new Value[]{r[1]}); pc = 18; continue; }
case 18: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[3],false); pc = 19; continue; }
case 19: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_REVANCED_SEARCH_VIEW_CONTAINER:I",Value.NULL,true); pc = 20; continue; }
case 20: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/app/Activity;->findViewById(I)Landroid/view/View;",r[1],new Value[]{r[2]}); pc = 21; continue; }
case 21: { r[1] = result; pc = 22; continue; }
case 22: { r[1] = rt.cast(r[1],"Landroid/widget/FrameLayout;"); pc = 23; continue; }
case 23: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchContainer:Landroid/widget/FrameLayout;",r[3],false,r[1]); pc = 24; continue; }
case 24: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchView:Landroid/widget/SearchView;",r[3],false); pc = 25; continue; }
case 25: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->createBackgroundDrawable()Landroid/graphics/drawable/GradientDrawable;",Value.NULL,new Value[]{}); pc = 26; continue; }
case 26: { r[2] = result; pc = 27; continue; }
case 27: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V",r[1],new Value[]{r[2]}); pc = 28; continue; }
case 28: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchView:Landroid/widget/SearchView;",r[3],false); pc = 29; continue; }
case 29: { r[2] = Value.ref("revanced_settings_search_hint"); pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/StringRef;->str(Ljava/lang/String;)Ljava/lang/String;",Value.NULL,new Value[]{r[2]}); pc = 31; continue; }
case 31: { r[2] = result; pc = 32; continue; }
case 32: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/SearchView;->setQueryHint(Ljava/lang/CharSequence;)V",r[1],new Value[]{r[2]}); pc = 33; continue; }
case 33: { r[1] = Value.i32(1098907648); pc = 34; continue; }
case 34: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/TextView;->setTextSize(F)V",r[0],new Value[]{r[1]}); pc = 35; continue; }
case 35: { r[1] = rt.readField("Landroid/os/Build$VERSION;->SDK_INT:I",Value.NULL,true); pc = 36; continue; }
case 36: { r[2] = Value.i32(29); pc = 37; continue; }
case 37: { pc=(r[1].i() < r[2].i())?39:38; continue; }
case 38: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->setCursorColor(Landroid/widget/EditText;)V",r[3],new Value[]{r[0]}); pc = 39; continue; }
case 39: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->REVANCED_LANGUAGE:Lapp/revanced/extension/shared/settings/EnumSetting;",Value.NULL,true); pc = 40; continue; }
case 40: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;",r[0],new Value[]{}); pc = 41; continue; }
case 41: { r[0] = result; pc = 42; continue; }
case 42: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 43; continue; }
case 43: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/AppLanguage;->getLocale()Ljava/util/Locale;",r[0],new Value[]{}); pc = 44; continue; }
case 44: { r[0] = result; pc = 45; continue; }
case 45: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->isRightToLeftLocale(Ljava/util/Locale;)Z",Value.NULL,new Value[]{r[0]}); pc = 46; continue; }
case 46: { r[0] = result; pc = 47; continue; }
case 47: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?54:48; continue; }
case 48: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchView:Landroid/widget/SearchView;",r[3],false); pc = 49; continue; }
case 49: { r[1] = Value.i32(4); pc = 50; continue; }
case 50: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setTextDirection(I)V",r[0],new Value[]{r[1]}); pc = 51; continue; }
case 51: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchView:Landroid/widget/SearchView;",r[3],false); pc = 52; continue; }
case 52: { r[1] = Value.i32(6); pc = 53; continue; }
case 53: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setTextAlignment(I)V",r[0],new Value[]{r[1]}); pc = 54; continue; }
case 54: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_bfb2ae0198d64c1630129790(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[4] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Landroid/widget/FrameLayout;"); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[4],false); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->overlayContainer:Landroid/widget/FrameLayout;",r[4],false,r[0]); pc = 4; continue; }
case 4: { r[1] = Value.i32(8); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setVisibility(I)V",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->overlayContainer:Landroid/widget/FrameLayout;",r[4],false); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getAppBackgroundColor()I",Value.NULL,new Value[]{}); pc = 8; continue; }
case 8: { r[1] = result; pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setBackgroundColor(I)V",r[0],new Value[]{r[1]}); pc = 10; continue; }
case 10: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->overlayContainer:Landroid/widget/FrameLayout;",r[4],false); pc = 11; continue; }
case 11: { r[1] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp8:I",Value.NULL,true); pc = 12; continue; }
case 12: { r[1] = Value.f32((float)(r[1].i())); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setElevation(F)V",r[0],new Value[]{r[1]}); pc = 14; continue; }
case 14: { r[0] = rt.allocate("Landroid/widget/FrameLayout;"); pc = 15; continue; }
case 15: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[4],false); pc = 16; continue; }
case 16: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V",r[0],new Value[]{r[1]}); pc = 17; continue; }
case 17: { r[1] = Value.i32(0); pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/View;->setVisibility(I)V",r[0],new Value[]{r[1]}); pc = 19; continue; }
case 19: { r[2] = rt.allocate("Landroid/widget/ListView;"); pc = 20; continue; }
case 20: { r[3] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[4],false); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/ListView;-><init>(Landroid/content/Context;)V",r[2],new Value[]{r[3]}); pc = 22; continue; }
case 22: { r[3] = Value.i32(0); pc = 23; continue; }
case 23: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/ListView;->setDivider(Landroid/graphics/drawable/Drawable;)V",r[2],new Value[]{r[3]}); pc = 24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/ListView;->setDividerHeight(I)V",r[2],new Value[]{r[1]}); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->createSearchResultsAdapter()Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;",r[4],new Value[]{}); pc = 26; continue; }
case 26: { r[1] = result; pc = 27; continue; }
case 27: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchResultsAdapter:Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;",r[4],false,r[1]); pc = 28; continue; }
case 28: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V",r[2],new Value[]{r[1]}); pc = 29; continue; }
case 29: { r[1] = rt.allocate("Landroid/widget/FrameLayout$LayoutParams;"); pc = 30; continue; }
case 30: { r[3] = Value.i32(-1); pc = 31; continue; }
case 31: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V",r[1],new Value[]{r[3], r[3]}); pc = 32; continue; }
case 32: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V",r[0],new Value[]{r[2], r[1]}); pc = 33; continue; }
case 33: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->overlayContainer:Landroid/widget/FrameLayout;",r[4],false); pc = 34; continue; }
case 34: { r[2] = rt.allocate("Landroid/widget/FrameLayout$LayoutParams;"); pc = 35; continue; }
case 35: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V",r[2],new Value[]{r[3], r[3]}); pc = 36; continue; }
case 36: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V",r[1],new Value[]{r[0], r[2]}); pc = 37; continue; }
case 37: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[4],false); pc = 38; continue; }
case 38: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_REVANCED_SETTINGS_FRAGMENTS:I",Value.NULL,true); pc = 39; continue; }
case 39: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/app/Activity;->findViewById(I)Landroid/view/View;",r[0],new Value[]{r[1]}); pc = 40; continue; }
case 40: { r[0] = result; pc = 41; continue; }
case 41: { r[0] = rt.cast(r[0],"Landroid/widget/FrameLayout;"); pc = 42; continue; }
case 42: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?49:43; continue; }
case 43: { r[1] = rt.allocate("Landroid/widget/FrameLayout$LayoutParams;"); pc = 44; continue; }
case 44: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V",r[1],new Value[]{r[3], r[3]}); pc = 45; continue; }
case 45: { r[2] = Value.i32(48); pc = 46; continue; }
case 46: { rt.writeField("Landroid/widget/FrameLayout$LayoutParams;->gravity:I",r[1],false,r[2]); pc = 47; continue; }
case 47: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->overlayContainer:Landroid/widget/FrameLayout;",r[4],false); pc = 48; continue; }
case 48: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V",r[0],new Value[]{r[2], r[1]}); pc = 49; continue; }
case 49: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b26eef8cf00e75f0a7994bfc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[4] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;"); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->activity:Landroid/app/Activity;",r[4],false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->overlayContainer:Landroid/widget/FrameLayout;",r[4],false); pc = 3; continue; }
case 3: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$$ExternalSyntheticLambda4;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$$ExternalSyntheticLambda4;-><init>(Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;)V",r[3],new Value[]{r[4]}); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;-><init>(Landroid/app/Activity;Landroid/widget/FrameLayout;Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$OnSelectHistoryItemListener;)V",r[0],new Value[]{r[1], r[2], r[3]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchHistoryManager:Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;",r[4],false,r[0]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f3f52c133fc7d7c0ba8e49e1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->toolbar:Landroid/widget/Toolbar;",r[2],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->MENU_REVANCED_SEARCH_MENU:I",Value.NULL,true); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/Toolbar;->inflateMenu(I)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->toolbar:Landroid/widget/Toolbar;",r[2],false); pc = 4; continue; }
case 4: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$$ExternalSyntheticLambda8;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$$ExternalSyntheticLambda8;-><init>(Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;)V",r[1],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/Toolbar;->setOnMenuItemClickListener(Landroid/widget/Toolbar$OnMenuItemClickListener;)V",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->toolbar:Landroid/widget/Toolbar;",r[2],false); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/Toolbar;->getMenu()Landroid/view/Menu;",r[0],new Value[]{}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->ID_ACTION_SEARCH:I",Value.NULL,true); pc = 11; continue; }
case 11: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;",r[0],new Value[]{r[1]}); pc = 12; continue; }
case 12: { r[0] = result; pc = 13; continue; }
case 13: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->getSearchIcon()I",Value.NULL,new Value[]{}); pc = 14; continue; }
case 14: { r[1] = result; pc = 15; continue; }
case 15: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;",r[0],new Value[]{r[1]}); pc = 16; continue; }
case 16: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8fc26962ee395c001ee70137(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->searchView:Landroid/widget/SearchView;",r[2],false); pc = 1; continue; }
case 1: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$1;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$1;-><init>(Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;)V",r[1],new Value[]{r[2]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/SearchView;->setOnQueryTextListener(Landroid/widget/SearchView$OnQueryTextListener;)V",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->toolbar:Landroid/widget/Toolbar;",r[2],false); pc = 5; continue; }
case 5: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$$ExternalSyntheticLambda5;"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$$ExternalSyntheticLambda5;-><init>(Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;)V",r[1],new Value[]{r[2]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/widget/Toolbar;->setNavigationOnClickListener(Landroid/view/View$OnClickListener;)V",r[0],new Value[]{r[1]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6b9dce936e6e06a5f11f90ab(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Landroid/graphics/drawable/GradientDrawable;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/graphics/drawable/GradientDrawable;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/graphics/drawable/GradientDrawable;->setShape(I)V",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp28:I",Value.NULL,true); pc = 5; continue; }
case 5: { r[1] = Value.f32((float)(r[1].i())); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->getSearchViewBackground()I",Value.NULL,new Value[]{}); pc = 8; continue; }
case 8: { r[1] = result; pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/graphics/drawable/GradientDrawable;->setColor(I)V",r[0],new Value[]{r[1]}); pc = 10; continue; }
case 10: { return rt.check(r[0],"Landroid/graphics/drawable/GradientDrawable;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_123e60d101fcd8dc46c62133(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[4] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
r[5] = rt.check(arguments[0], "Landroid/widget/EditText;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = Value.i32(-1); pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?6:4; continue; }
case 4: { r[0] = r[1]; pc = 5; continue; }
case 5: { pc=7; continue; }
case 6: { r[0] = Value.i32(-16777216); pc = 7; continue; }
case 7: { r[2] = rt.allocate("Landroid/graphics/drawable/GradientDrawable;"); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/graphics/drawable/GradientDrawable;-><init>()V",r[2],new Value[]{}); pc = 9; continue; }
case 9: { r[3] = Value.i32(0); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/graphics/drawable/GradientDrawable;->setShape(I)V",r[2],new Value[]{r[3]}); pc = 11; continue; }
case 11: { r[3] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp2:I",Value.NULL,true); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/graphics/drawable/GradientDrawable;->setSize(II)V",r[2],new Value[]{r[3], r[1]}); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Landroid/graphics/drawable/GradientDrawable;->setColor(I)V",r[2],new Value[]{r[0]}); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$$ExternalSyntheticApiModelOutline0;->m(Landroid/widget/EditText;Landroid/graphics/drawable/Drawable;)V",Value.NULL,new Value[]{r[5], r[2]}); pc = 15; continue; }
case 15: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_21b317cd55dee743086d9ca5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->appIsUsingBoldIcons()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->DRAWABLE_REVANCED_SETTINGS_SEARCH_ICON_BOLD:I",Value.NULL,true); pc = 4; continue; }
case 4: { return rt.check(r[0],"I"); }
case 5: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;->DRAWABLE_REVANCED_SETTINGS_SEARCH_ICON:I",Value.NULL,true); pc = 6; continue; }
case 6: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_784a8e1d87846ddd47199164(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->getDialogBackgroundColor()I",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled()Z",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?7:5; continue; }
case 5: { r[1] = Value.i32(1066275963); pc = 6; continue; }
case 6: { pc=8; continue; }
case 7: { r[1] = Value.i32(1064514355); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;","Lapp/revanced/extension/shared/Utils;->adjustColorBrightness(IF)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
