package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_55d067a69690dae1d1dc {
static Value m_28faf8c52b7b69a2ddd9e18e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;->f$0:Ljava/lang/String;", r[0], false, r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c419968278752926f172aef6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;->f$0:Ljava/lang/String;", r[1], false); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;", "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->$r8$lambda$TaTUnTQ4ROEHoqRdTtZFiKunst8(Ljava/lang/String;)Ljava/lang/String;", Value.NULL, new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
