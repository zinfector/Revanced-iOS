package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_f16e5c4b0bb912bd extends RuntimeForeign.SourceProxy {
Source_f16e5c4b0bb912bd(RuntimeForeign owner,Instance source){super(owner,source);}

}
