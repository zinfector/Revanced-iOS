package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_c454e2e008cd7727 extends RuntimeForeign.SourceProxy {
Source_c454e2e008cd7727(RuntimeForeign owner,Instance source){super(owner,source);}

}
