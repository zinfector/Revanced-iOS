package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_5b2f63edce0c9838 extends RuntimeForeign.SourceProxy implements java.util.concurrent.ThreadFactory {
Proxy_5b2f63edce0c9838(RuntimeForeign owner,Instance source){super(owner,source);}
public java.lang.Thread newThread(java.lang.Runnable a0) {Value result=owner.callback(source,"Ljava/util/concurrent/ThreadFactory;->newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;",new Value[]{owner.importValue(a0)}); return (java.lang.Thread)owner.exportObject(result.o(),"Ljava/lang/Thread;");}
}
