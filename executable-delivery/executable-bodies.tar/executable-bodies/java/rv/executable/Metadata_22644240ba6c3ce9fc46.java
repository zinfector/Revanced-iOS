package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_22644240ba6c3ce9fc46 {
static ClassInfo info_22644240ba6c3ce9fc46() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$$ExternalSyntheticLambda5;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$$ExternalSyntheticLambda5;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
