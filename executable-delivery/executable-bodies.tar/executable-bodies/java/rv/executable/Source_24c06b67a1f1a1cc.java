package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_24c06b67a1f1a1cc extends RuntimeForeign.SourceProxy {
Source_24c06b67a1f1a1cc(RuntimeForeign owner,Instance source){super(owner,source);}

}
