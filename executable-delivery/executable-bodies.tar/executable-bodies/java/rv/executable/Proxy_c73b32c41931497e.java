package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_c73b32c41931497e extends RuntimeForeign.SourceProxy implements java.util.Collection {
Proxy_c73b32c41931497e(RuntimeForeign owner,Instance source){super(owner,source);}
public int size() {Value result=owner.callback(source,"Ljava/util/Collection;->size()I",new Value[]{}); return result.i();}
public boolean isEmpty() {Value result=owner.callback(source,"Ljava/util/Collection;->isEmpty()Z",new Value[]{}); return result.z();}
public boolean contains(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Collection;->contains(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public java.util.Iterator iterator() {Value result=owner.callback(source,"Ljava/util/Collection;->iterator()Ljava/util/Iterator;",new Value[]{}); return (java.util.Iterator)owner.exportObject(result.o(),"Ljava/util/Iterator;");}
public java.lang.Object[] toArray() {Value result=owner.callback(source,"Ljava/util/Collection;->toArray()[Ljava/lang/Object;",new Value[]{}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public java.lang.Object[] toArray(java.lang.Object[] a0) {Value result=owner.callback(source,"Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;",new Value[]{owner.importValue(a0)}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public boolean add(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Collection;->add(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean remove(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Collection;->remove(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean containsAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Collection;->containsAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean addAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Collection;->addAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean removeAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Collection;->removeAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean retainAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Collection;->retainAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public void clear() {Value result=owner.callback(source,"Ljava/util/Collection;->clear()V",new Value[]{}); return;}
public boolean equals(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Collection;->equals(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int hashCode() {Value result=owner.callback(source,"Ljava/util/Collection;->hashCode()I",new Value[]{}); return result.i();}
}
