package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_31b0215b66df1ed705fa {
static ClassInfo info_31b0215b66df1ed705fa() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda17;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda17;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SBRequester$$ExternalSyntheticLambda17");}
}
