package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_715fc229dc756e51ec43 {
static Value m_1b83784d5b7822522fdf8df2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda17;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda17;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda17;->f$0:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_204b9f535f2f4577dbb746f1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda17;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda17;->f$0:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda17;","Lapp/revanced/extension/youtube/patches/VideoInformation;->$r8$lambda$kle8-nBAtQOfXwvhLjsiNjSFWTQ(Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;)Ljava/lang/String;",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
