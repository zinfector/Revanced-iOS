package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_0e50c99aa12a39bb extends RuntimeForeign.SourceProxy {
Source_0e50c99aa12a39bb(RuntimeForeign owner,Instance source){super(owner,source);}

}
