package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_601eeda7c3b711805ad1 {
static Value m_c857be1760d3b002f1b03766(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->Companion:Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/ShortsPlayerState;","Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;->isOpen()Z",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_42f7325cc8c944723e0340b8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/ShortsPlayerState;","Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->Companion:Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/Event;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/ShortsPlayerState;","Lapp/revanced/extension/youtube/shared/Event;-><init>()V",r[0],new Value[]{}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->onChange:Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,true,r[0]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_66cfa29a3f11fea6063e2baf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->isOpen:Z",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
