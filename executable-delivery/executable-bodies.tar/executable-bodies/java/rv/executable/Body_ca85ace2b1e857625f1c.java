package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_ca85ace2b1e857625f1c {
static Value m_4a5414d67130ced201cb695e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType$Companion;");
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[2],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType;->access$getNameToPlayerType$cp()Ljava/util/Map;",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 6; continue; }
case 6: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?11:7; continue; }
case 7: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType$Companion$$ExternalSyntheticLambda1;"); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[2]}); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 10; continue; }
case 10: { return Value.VOID; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;->setCurrent(Lapp/revanced/extension/youtube/shared/PlayerType;)V",r[1],new Value[]{r[0]}); pc = 12; continue; }
case 12: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_bebe1db1419420bee8a4427c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType;->access$getCurrentPlayerType$cp()Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/PlayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_641045d70fc0ae533714fbc3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType$Companion;");
r[1] = rt.check(arguments[0], "Lkotlin/jvm/internal/DefaultConstructorMarker;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_91b9f842b5816e83f848ba00(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType$Companion;");
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType;->access$getCurrentPlayerType$cp()Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],r[2]))?10:3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType$Companion$$ExternalSyntheticLambda0;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion$$ExternalSyntheticLambda0;-><init>(Lapp/revanced/extension/youtube/shared/PlayerType;)V",r[0],new Value[]{r[2]}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType;->access$setCurrentPlayerType$cp(Lapp/revanced/extension/youtube/shared/PlayerType;)V",Value.NULL,new Value[]{r[2]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;->getOnChange()Lapp/revanced/extension/youtube/shared/Event;",r[1],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/Event;->invoke(Ljava/lang/Object;)V",r[0],new Value[]{r[2]}); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ee64030f1593141156d309ea(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Lapp/revanced/extension/youtube/shared/PlayerType;->access$getOnChange$cp()Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/Event;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fd987beaf8e51d6e093c045e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType$Companion;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c6066564604c83d451d85726(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Unknown PlayerType encountered: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ba72a2fac744367e3a030f9e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Changed to: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
