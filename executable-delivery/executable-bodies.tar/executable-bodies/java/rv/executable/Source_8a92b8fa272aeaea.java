package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_8a92b8fa272aeaea extends RuntimeForeign.SourceProxy {
Source_8a92b8fa272aeaea(RuntimeForeign owner,Instance source){super(owner,source);}

}
