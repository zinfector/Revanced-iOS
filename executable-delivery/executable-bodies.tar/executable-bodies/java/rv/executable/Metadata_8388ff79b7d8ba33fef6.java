package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8388ff79b7d8ba33fef6 {
static ClassInfo info_8388ff79b7d8ba33fef6() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda16;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "VideoInformation$$ExternalSyntheticLambda16");}
}
