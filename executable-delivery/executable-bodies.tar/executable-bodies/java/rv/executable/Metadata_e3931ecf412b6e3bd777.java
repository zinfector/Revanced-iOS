package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_e3931ecf412b6e3bd777 {
static ClassInfo info_e3931ecf412b6e3bd777() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideOverlayButtonsAvailability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)}, "MiniplayerHideOverlayButtonsAvailability");}
}
