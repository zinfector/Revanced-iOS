package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_a9a39826e36285a90453 {
static Value m_065c30b82a24bfe384c9c60f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$1;");
r[1] = rt.check(arguments[0], "Landroid/app/Dialog;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$1;->val$dialog:Landroid/app/Dialog;",r[0],false,r[1]); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$1;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
