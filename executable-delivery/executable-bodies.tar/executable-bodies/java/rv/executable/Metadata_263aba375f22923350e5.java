package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_263aba375f22923350e5 {
static ClassInfo info_263aba375f22923350e5() {return new ClassInfo("Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;", "Ljava/lang/Object;", new String[]{}, 5121, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("m([Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/String;", 4105)}, "YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0");}
}
