package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_79fca6e2406693dea28a {
static Value m_ecd47e61d4c8e691f9c6eea4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/settings/preference/AbstractPreferenceFragment;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_42cb5bacfdc68faa2e464617(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Landroid/view/Window;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?5:1; continue; }
case 1: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticLambda12;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticLambda12;-><init>()V",r[2],new Value[]{}); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 4; continue; }
case 4: { return Value.VOID; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/Utils;->getAppBackgroundColor()I",Value.NULL,new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Landroid/view/Window;->setNavigationBarColor(I)V",r[2],new Value[]{r[0]}); pc = 8; continue; }
case 8: { r[0] = rt.readField("Landroid/os/Build$VERSION;->SDK_INT:I",Value.NULL,true); pc = 9; continue; }
case 9: { r[1] = Value.i32(29); pc = 10; continue; }
case 10: { pc=(r[0].i() < r[1].i())?13:11; continue; }
case 11: { r[0] = Value.i32(1); pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticApiModelOutline0;->m(Landroid/view/Window;Z)V",Value.NULL,new Value[]{r[2], r[0]}); pc = 13; continue; }
case 13: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_78534704bc285f69e3719d5f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->DRAWABLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/Utils;->appIsUsingBoldIcons()Z",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?6:4; continue; }
case 4: { r[1] = Value.ref("revanced_settings_toolbar_arrow_left_bold"); pc = 5; continue; }
case 5: { pc=7; continue; }
case 6: { r[1] = Value.ref("revanced_settings_toolbar_arrow_left"); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 10; continue; }
case 10: { r[1] = result; pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Landroid/content/Context;->getResources()Landroid/content/res/Resources;",r[1],new Value[]{}); pc = 12; continue; }
case 12: { r[1] = result; pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;",r[1],new Value[]{r[0]}); pc = 14; continue; }
case 14: { r[0] = result; pc = 15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;->customizeBackButtonDrawable(Landroid/graphics/drawable/Drawable;)V",Value.NULL,new Value[]{r[0]}); pc = 16; continue; }
case 16: { return rt.check(r[0],"Landroid/graphics/drawable/Drawable;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ed6ff88d28cc3628c34d9e1d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Cannot set navigation bar color, window is null"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f81205e9dde25e4c3a1ff463(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Landroid/graphics/drawable/Drawable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Lapp/revanced/extension/shared/Utils;->getAppForegroundColor()I",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;","Landroid/graphics/drawable/Drawable;->setTint(I)V",r[1],new Value[]{r[0]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
