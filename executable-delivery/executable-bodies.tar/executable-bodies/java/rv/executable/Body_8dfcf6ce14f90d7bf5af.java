package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_8dfcf6ce14f90d7bf5af {
static Value m_32b4b48ea2feb9c64c410733(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Integer;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/IntegerSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_32e56a35d52bf01f4e1f2e9f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Integer;");
r[3] = rt.check(arguments[2], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/IntegerSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;Z)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4e1c253719eee305492940b3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Integer;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/IntegerSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[1], r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d87f4c356cbb82c3ae03e8a4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Integer;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/IntegerSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZ)V", r[0], new Value[]{r[1], r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c64101dc150f0d2de55984b9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Integer;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/IntegerSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fac52611b4be9c259f34314e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->preferences:Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;", r[3], false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;", r[3], false); pc = 3; continue; }
case 3: { r[2] = rt.cast(r[2], "Ljava/lang/Integer;"); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/IntegerSetting;", "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->saveIntegerString(Ljava/lang/String;Ljava/lang/Integer;)V", r[0], new Value[]{r[1], r[2]}); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_409dfe89f0614e4f7fac0759(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->preferences:Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;", r[3], false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->defaultValue:Ljava/lang/Object;", r[3], false); pc = 3; continue; }
case 3: { r[2] = rt.cast(r[2], "Ljava/lang/Integer;"); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/IntegerSetting;", "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->getIntegerString(Ljava/lang/String;Ljava/lang/Integer;)Ljava/lang/Integer;", r[0], new Value[]{r[1], r[2]}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;", r[3], false, r[0]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f878f3871fbe247ffb50060f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/IntegerSetting;", "Lapp/revanced/extension/shared/settings/IntegerSetting;->get()Ljava/lang/Integer;", r[1], new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0], "Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_731bdcf94bcc0d1e9222d660(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/IntegerSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;", r[1], false); pc = 1; continue; }
case 1: { r[0] = rt.cast(r[0], "Ljava/lang/Integer;"); pc = 2; continue; }
case 2: { return rt.check(r[0], "Ljava/lang/Integer;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
