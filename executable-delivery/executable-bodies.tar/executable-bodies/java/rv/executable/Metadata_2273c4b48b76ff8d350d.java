package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_2273c4b48b76ff8d350d {
static ClassInfo info_2273c4b48b76ff8d350d() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda7;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda7;->f$0:J", "J", 4113, ExecutableRuntime.zero("J"))}, new MethodInfo[]{new MethodInfo("<init>(J)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda7");}
}
