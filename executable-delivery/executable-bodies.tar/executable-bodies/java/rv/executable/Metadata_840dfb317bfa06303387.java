package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_840dfb317bfa06303387 {
static ClassInfo info_840dfb317bfa06303387() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda46;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda46;->f$0:I", "I", 4113, ExecutableRuntime.zero("I"))}, new MethodInfo[]{new MethodInfo("<init>(I)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda46");}
}
