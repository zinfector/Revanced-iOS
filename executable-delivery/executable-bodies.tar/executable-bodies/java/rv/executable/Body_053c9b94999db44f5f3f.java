package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_053c9b94999db44f5f3f {
static Value m_dec0a2193999d405a973fe3a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;", r[1], false); pc = 1; continue; }
case 1: { r[0] = rt.cast(r[0], "Ljava/lang/Boolean;"); pc = 2; continue; }
case 2: { return rt.check(r[0], "Ljava/lang/Boolean;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_27421a5bc5bff4da9301cf2a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Boolean;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cfb2c02b8faadc29b0f2ce79(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Boolean;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ba498f2de62b56c91d234306(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Boolean;");
r[3] = rt.check(arguments[2], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_259edde27be316a199bc2203(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Boolean;");
r[3] = rt.check(arguments[2], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;Z)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d502a05b41a8bc8f3bd5ab14(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Boolean;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZLjava/lang/String;)V", r[0], new Value[]{r[1], r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_509930e8ee36b24061ab289e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Boolean;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZ)V", r[0], new Value[]{r[1], r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_137e751d524997c351184850(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Boolean;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[1], r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fda5f9d1da74176a9413a42e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 5) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Boolean;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Ljava/lang/String;");
r[5] = rt.check(arguments[4], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[1], r[2], r[3], r[4], r[5]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1077ff65980e8c64139fcd53(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/BooleanSetting;");
r[1] = rt.check(arguments[1], "Ljava/lang/Boolean;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[1]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;", r[0], false, r[1]); pc = 2; continue; }
case 2: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;->isSetToDefault()Z", r[0], new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { pc = (ExecutableRuntime.equal(r[1], Value.i32(0))) ? 6 : 5; continue; }
case 5: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/Setting;->removeFromPreferences()V", r[0], new Value[]{}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c79b5f46764bcbd12b7c3311(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->preferences:Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;", r[3], false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;", r[3], false); pc = 3; continue; }
case 3: { r[2] = rt.cast(r[2], "Ljava/lang/Boolean;"); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Ljava/lang/Boolean;->booleanValue()Z", r[2], new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->saveBoolean(Ljava/lang/String;Z)V", r[0], new Value[]{r[1], r[2]}); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7f1d38069d8547683c1a5260(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->preferences:Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;", r[3], false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->defaultValue:Ljava/lang/Object;", r[3], false); pc = 3; continue; }
case 3: { r[2] = rt.cast(r[2], "Ljava/lang/Boolean;"); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Ljava/lang/Boolean;->booleanValue()Z", r[2], new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->getBoolean(Ljava/lang/String;Z)Z", r[0], new Value[]{r[1], r[2]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;", Value.NULL, new Value[]{r[0]}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;", r[3], false, r[0]); pc = 11; continue; }
case 11: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_22d1474343710878592dc2ec(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BooleanSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/BooleanSetting;", "Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;", r[1], new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0], "Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
