package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_3128856f4aab9eea6d20 {
static ClassInfo info_3128856f4aab9eea6d20() {return new ClassInfo("Lkotlin/collections/ArraysKt___ArraysJvmKt;", "Lkotlin/collections/ArraysKt__ArraysKt;", new String[]{}, 1025, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("asList([Ljava/lang/Object;)Ljava/util/List;", 25)}, "ArraysKt___ArraysJvmKt");}
}
