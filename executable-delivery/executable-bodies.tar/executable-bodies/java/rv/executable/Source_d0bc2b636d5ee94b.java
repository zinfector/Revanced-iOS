package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_d0bc2b636d5ee94b extends RuntimeForeign.SourceProxy {
Source_d0bc2b636d5ee94b(RuntimeForeign owner,Instance source){super(owner,source);}

}
