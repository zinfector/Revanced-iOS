package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_3d005dcb509889365424 {
static Value m_25f2237483d98ae982f351d0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/requests/Route;");
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/shared/requests/Route$Method;");
r[3] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/Object;-><init>()V",r[1],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/requests/Route;->method:Lapp/revanced/extension/shared/requests/Route$Method;",r[1],false,r[2]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/requests/Route;->route:Ljava/lang/String;",r[1],false,r[3]); pc = 3; continue; }
case 3: { r[2] = Value.i32(123); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route;","Lapp/revanced/extension/shared/requests/Route;->countMatches(Ljava/lang/CharSequence;C)I",r[1],new Value[]{r[3], r[2]}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/requests/Route;->paramCount:I",r[1],false,r[2]); pc = 7; continue; }
case 7: { r[0] = Value.i32(125); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route;","Lapp/revanced/extension/shared/requests/Route;->countMatches(Ljava/lang/CharSequence;C)I",r[1],new Value[]{r[3], r[0]}); pc = 9; continue; }
case 9: { r[3] = result; pc = 10; continue; }
case 10: { pc=(!ExecutableRuntime.equal(r[2],r[3]))?12:11; continue; }
case 11: { return Value.VOID; }
case 12: { r[2] = Value.ref("Not enough parameters"); pc = 13; continue; }
case 13: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Route;","Lapp/revanced/com/google/protobuf/Syntax$$ExternalSyntheticBUOutline0;->m(Ljava/lang/String;)V",Value.NULL,new Value[]{r[2]}); pc = 14; continue; }
case 14: { r[2] = Value.i32(0); pc = 15; continue; }
case 15: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9579327c0d51a5c89531c6e8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[4] = rt.check(receiver, "Lapp/revanced/extension/shared/requests/Route;");
r[5] = rt.check(arguments[0], "Ljava/lang/CharSequence;");
r[6] = rt.check(arguments[1], "C");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("interface","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/CharSequence;->length()I",r[5],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { r[2] = r[1]; pc = 4; continue; }
case 4: { pc=(r[1].i() >= r[0].i())?11:5; continue; }
case 5: { result=rt.invoke("interface","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/CharSequence;->charAt(I)C",r[5],new Value[]{r[1]}); pc = 6; continue; }
case 6: { r[3] = result; pc = 7; continue; }
case 7: { pc=(!ExecutableRuntime.equal(r[3],r[6]))?9:8; continue; }
case 8: { r[2] = Value.i32((r[2].i()) + (1)); pc = 9; continue; }
case 9: { r[1] = Value.i32((r[1].i()) + (1)); pc = 10; continue; }
case 10: { pc=4; continue; }
case 11: { return rt.check(r[2],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4cb32d4b1c74289161a7dcf8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[5] = rt.check(receiver, "Lapp/revanced/extension/shared/requests/Route;");
r[6] = rt.check(arguments[0], "[Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(rt.length(r[6])); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/requests/Route;->paramCount:I",r[5],false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/requests/Route;->route:Ljava/lang/String;",r[5],false); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?26:4; continue; }
case 4: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { r[1] = Value.i32(0); pc = 7; continue; }
case 7: { r[2] = rt.readField("Lapp/revanced/extension/shared/requests/Route;->paramCount:I",r[5],false); pc = 8; continue; }
case 8: { pc=(r[1].i() >= r[2].i())?20:9; continue; }
case 9: { r[2] = Value.ref("{"); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I",r[0],new Value[]{r[2]}); pc = 11; continue; }
case 11: { r[2] = result; pc = 12; continue; }
case 12: { r[3] = Value.ref("}"); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I",r[0],new Value[]{r[3]}); pc = 14; continue; }
case 14: { r[3] = result; pc = 15; continue; }
case 15: { r[3] = Value.i32((r[3].i()) + (1)); pc = 16; continue; }
case 16: { r[4] = rt.arrayGet(r[6],r[1].i()); pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->replace(IILjava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2], r[3], r[4]}); pc = 18; continue; }
case 18: { r[1] = Value.i32((r[1].i()) + (1)); pc = 19; continue; }
case 19: { pc=7; continue; }
case 20: { r[6] = rt.allocate("Lapp/revanced/extension/shared/requests/Route$CompiledRoute;"); pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 22; continue; }
case 22: { r[0] = result; pc = 23; continue; }
case 23: { r[1] = Value.i32(0); pc = 24; continue; }
case 24: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route;","Lapp/revanced/extension/shared/requests/Route$CompiledRoute;-><init>(Lapp/revanced/extension/shared/requests/Route;Ljava/lang/String;Lapp/revanced/extension/shared/requests/Route-IA;)V",r[6],new Value[]{r[5], r[0], r[1]}); pc = 25; continue; }
case 25: { return rt.check(r[6],"Lapp/revanced/extension/shared/requests/Route$CompiledRoute;"); }
case 26: { r[0] = rt.allocate("Ljava/lang/IllegalArgumentException;"); pc = 27; continue; }
case 27: { r[1] = rt.readField("Lapp/revanced/extension/shared/requests/Route;->paramCount:I",r[5],false); pc = 28; continue; }
case 28: { r[6] = Value.i32(rt.length(r[6])); pc = 29; continue; }
case 29: { r[3] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 30; continue; }
case 30: { r[4] = Value.ref("Error compiling route ["); pc = 31; continue; }
case 31: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[3],new Value[]{r[4]}); pc = 32; continue; }
case 32: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[3],new Value[]{r[2]}); pc = 33; continue; }
case 33: { r[2] = Value.ref("], incorrect amount of parameters provided. Expected: "); pc = 34; continue; }
case 34: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[3],new Value[]{r[2]}); pc = 35; continue; }
case 35: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;",r[3],new Value[]{r[1]}); pc = 36; continue; }
case 36: { r[1] = Value.ref(", provided: "); pc = 37; continue; }
case 37: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[3],new Value[]{r[1]}); pc = 38; continue; }
case 38: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;",r[3],new Value[]{r[6]}); pc = 39; continue; }
case 39: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[3],new Value[]{}); pc = 40; continue; }
case 40: { r[6] = result; pc = 41; continue; }
case 41: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Route;","Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[6]}); pc = 42; continue; }
case 42: { ExecutableRuntime.raise(r[0].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1917eed1066b279ccdc75f98(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/shared/requests/Route;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/requests/Route;->method:Lapp/revanced/extension/shared/requests/Route$Method;",r[0],false); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lapp/revanced/extension/shared/requests/Route$Method;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
