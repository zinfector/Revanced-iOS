package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8e77a2e76f16f7da9490 {
static ClassInfo info_8e77a2e76f16f7da9490() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda32;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda32;->f$0:Landroid/util/Range;", "Landroid/util/Range;", 4113, ExecutableRuntime.zero("Landroid/util/Range;"))}, new MethodInfo[]{new MethodInfo("<init>(Landroid/util/Range;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda32");}
}
