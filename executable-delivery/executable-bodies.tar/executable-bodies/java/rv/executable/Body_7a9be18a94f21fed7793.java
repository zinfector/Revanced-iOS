package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_7a9be18a94f21fed7793 {
static Value m_ec2263c91c2c5314ef70f01b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[1] = rt.check(arguments[0], "I");
r[2] = rt.check(arguments[1], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[1] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[2] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[1].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_524a5144703144ba7291fe30(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[1] = rt.check(arguments[0], "I");
r[2] = rt.check(arguments[1], "Ljava/util/Collection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[1] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[2] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[1].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_feedf7b8a683122115e6bf15(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList;","Lkotlin/collections/AbstractList$Companion;->orderedHashCode$kotlin_stdlib(Ljava/util/Collection;)I",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_86d9d5819c3764b53a79840f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[3] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[4] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("interface","Lkotlin/collections/AbstractList;","Ljava/util/List;->iterator()Ljava/util/Iterator;",r[3],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lkotlin/collections/AbstractList;","Ljava/util/Iterator;->hasNext()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?14:6; continue; }
case 6: { result=rt.invoke("interface","Lkotlin/collections/AbstractList;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[2] = result; pc = 8; continue; }
case 8: { result=rt.invoke("static","Lkotlin/collections/AbstractList;","Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z",Value.NULL,new Value[]{r[2], r[4]}); pc = 9; continue; }
case 9: { r[2] = result; pc = 10; continue; }
case 10: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?12:11; continue; }
case 11: { return rt.check(r[1],"I"); }
case 12: { r[1] = Value.i32((r[1].i()) + (1)); pc = 13; continue; }
case 13: { pc=3; continue; }
case 14: { r[4] = Value.i32(-1); pc = 15; continue; }
case 15: { return rt.check(r[4],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_96f869e023c47163e3bd3433(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[3] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("interface","Lkotlin/collections/AbstractList;","Ljava/util/List;->size()I",r[2],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("interface","Lkotlin/collections/AbstractList;","Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { result=rt.invoke("interface","Lkotlin/collections/AbstractList;","Ljava/util/ListIterator;->hasPrevious()Z",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?15:7; continue; }
case 7: { result=rt.invoke("interface","Lkotlin/collections/AbstractList;","Ljava/util/ListIterator;->previous()Ljava/lang/Object;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[1] = result; pc = 9; continue; }
case 9: { result=rt.invoke("static","Lkotlin/collections/AbstractList;","Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z",Value.NULL,new Value[]{r[1], r[3]}); pc = 10; continue; }
case 10: { r[1] = result; pc = 11; continue; }
case 11: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?4:12; continue; }
case 12: { result=rt.invoke("interface","Lkotlin/collections/AbstractList;","Ljava/util/ListIterator;->nextIndex()I",r[0],new Value[]{}); pc = 13; continue; }
case 13: { r[3] = result; pc = 14; continue; }
case 14: { return rt.check(r[3],"I"); }
case 15: { r[3] = Value.i32(-1); pc = 16; continue; }
case 16: { return rt.check(r[3],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_bfb83c61718819a4a6a3b899(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lkotlin/collections/AbstractList$ListIteratorImpl;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Lkotlin/collections/AbstractList$ListIteratorImpl;-><init>(Lkotlin/collections/AbstractList;I)V",r[0],new Value[]{r[2], r[1]}); pc = 3; continue; }
case 3: { return rt.check(r[0],"Ljava/util/ListIterator;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c5ca2930cb1acf7b201c2cc8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[2] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lkotlin/collections/AbstractList$ListIteratorImpl;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Lkotlin/collections/AbstractList$ListIteratorImpl;-><init>(Lkotlin/collections/AbstractList;I)V",r[0],new Value[]{r[1], r[2]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/util/ListIterator;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d60492872cd155bcea468a0a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[2] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[2] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[0] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d88bf31c891178cd22f1aa8d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[1] = rt.check(arguments[0], "I");
r[2] = rt.check(arguments[1], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[1] = rt.allocate("Ljava/lang/UnsupportedOperationException;"); pc = 1; continue; }
case 1: { r[2] = Value.ref("Operation is not supported for read-only collection"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 3; continue; }
case 3: { ExecutableRuntime.raise(r[1].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_935d4986811f13bf552dc842(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[2] = rt.check(arguments[0], "I");
r[3] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lkotlin/collections/AbstractList$SubList;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Lkotlin/collections/AbstractList$SubList;-><init>(Lkotlin/collections/AbstractList;II)V",r[0],new Value[]{r[1], r[2], r[3]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/util/List;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a571601f106c679f0a8ae061(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lkotlin/collections/AbstractList$Companion;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Lkotlin/collections/AbstractList$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { rt.writeField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_162a35adad6f5060acc899bf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lkotlin/collections/AbstractList$IteratorImpl;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Lkotlin/collections/AbstractList$IteratorImpl;-><init>(Lkotlin/collections/AbstractList;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/util/Iterator;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_616784f4200eeff4cec9906b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[2],r[1]))?3:1; continue; }
case 1: { r[2] = Value.i32(1); pc = 2; continue; }
case 2: { return rt.check(r[2],"Z"); }
case 3: { r[0] = Value.i32(rt.isInstance(r[2].o(),"Ljava/util/List;")?1:0); pc = 4; continue; }
case 4: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?7:5; continue; }
case 5: { r[2] = Value.i32(0); pc = 6; continue; }
case 6: { return rt.check(r[2],"Z"); }
case 7: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;",Value.NULL,true); pc = 8; continue; }
case 8: { r[2] = rt.cast(r[2],"Ljava/util/Collection;"); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList;","Lkotlin/collections/AbstractList$Companion;->orderedEquals$kotlin_stdlib(Ljava/util/Collection;Ljava/util/Collection;)Z",r[0],new Value[]{r[1], r[2]}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { return rt.check(r[2],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9a7021487c4bd24cdb002f53(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lkotlin/collections/AbstractList;","Lkotlin/collections/AbstractCollection;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
