package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_7a9be18a94f21fed7793 {
static Value m_a571601f106c679f0a8ae061(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lkotlin/collections/AbstractList$Companion;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result = rt.invoke("direct", "Lkotlin/collections/AbstractList;", "Lkotlin/collections/AbstractList$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V", r[0], new Value[]{r[1]}); pc = 3; continue; }
case 3: { rt.writeField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;", Value.NULL, true, r[0]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9a7021487c4bd24cdb002f53(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lkotlin/collections/AbstractList;", "Lkotlin/collections/AbstractCollection;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_616784f4200eeff4cec9906b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc = (!ExecutableRuntime.equal(r[2], r[1])) ? 3 : 1; continue; }
case 1: { r[2] = Value.i32(1); pc = 2; continue; }
case 2: { return rt.check(r[2], "Z"); }
case 3: { r[0] = Value.i32(rt.isInstance(r[2].o(), "Ljava/util/List;") ? 1 : 0); pc = 4; continue; }
case 4: { pc = (!ExecutableRuntime.equal(r[0], Value.i32(0))) ? 7 : 5; continue; }
case 5: { r[2] = Value.i32(0); pc = 6; continue; }
case 6: { return rt.check(r[2], "Z"); }
case 7: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;", Value.NULL, true); pc = 8; continue; }
case 8: { r[2] = rt.cast(r[2], "Ljava/util/Collection;"); pc = 9; continue; }
case 9: { result = rt.invoke("virtual", "Lkotlin/collections/AbstractList;", "Lkotlin/collections/AbstractList$Companion;->orderedEquals$kotlin_stdlib(Ljava/util/Collection;Ljava/util/Collection;)Z", r[0], new Value[]{r[1], r[2]}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { return rt.check(r[2], "Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_162a35adad6f5060acc899bf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lkotlin/collections/AbstractList$IteratorImpl;"); pc = 1; continue; }
case 1: { result = rt.invoke("direct", "Lkotlin/collections/AbstractList;", "Lkotlin/collections/AbstractList$IteratorImpl;-><init>(Lkotlin/collections/AbstractList;)V", r[0], new Value[]{r[1]}); pc = 2; continue; }
case 2: { return rt.check(r[0], "Ljava/util/Iterator;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
