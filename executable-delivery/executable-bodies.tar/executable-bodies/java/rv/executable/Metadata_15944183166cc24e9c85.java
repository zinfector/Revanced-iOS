package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_15944183166cc24e9c85 {
static ClassInfo info_15944183166cc24e9c85() {return new ClassInfo("Lapp/revanced/extension/shared/settings/Setting$4;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 0, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/settings/Setting$4;->val$parents:[Lapp/revanced/extension/shared/settings/BooleanSetting;", "[Lapp/revanced/extension/shared/settings/BooleanSetting;", 4112, ExecutableRuntime.zero("[Lapp/revanced/extension/shared/settings/BooleanSetting;"))}, new MethodInfo[]{new MethodInfo("<init>([Lapp/revanced/extension/shared/settings/BooleanSetting;)V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
