package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_1f41297eafbfd83c62e5 {
static ClassInfo info_1f41297eafbfd83c62e5() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "PlayerControlsPatch$$ExternalSyntheticLambda0");}
}
