package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_8b4c4cadf0482b15 extends RuntimeForeign.SourceProxy {
Source_8b4c4cadf0482b15(RuntimeForeign owner,Instance source){super(owner,source);}

}
