package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_09a57fc3e8a1cc0bfeb8 {
static ClassInfo info_09a57fc3e8a1cc0bfeb8() {return new ClassInfo("Lkotlin/collections/MapsKt__MapsJVMKt;", "Lkotlin/collections/MapsKt__MapWithDefaultKt;", new String[]{}, 1025, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("mapCapacity(I)I", 9), new MethodInfo("mapOf(Lkotlin/Pair;)Ljava/util/Map;", 25), new MethodInfo("toSingletonMap(Ljava/util/Map;)Ljava/util/Map;", 25)});}
}
