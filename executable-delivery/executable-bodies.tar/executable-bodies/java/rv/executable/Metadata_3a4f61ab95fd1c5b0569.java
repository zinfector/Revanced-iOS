package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_3a4f61ab95fd1c5b0569 {
static ClassInfo info_3a4f61ab95fd1c5b0569() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideRewindOrOverlayOpacityAvailability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)}, "MiniplayerHideRewindOrOverlayOpacityAvailability");}
}
