package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_f3397e9af69ec3c2ce6f {
static Value m_e5d31290a522168125ccb476(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->$VALUES:[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;","[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fed0e29c26a45af524730fc7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("ORIGINAL"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;-><init>(Ljava/lang/String;IZZ)V",r[0],new Value[]{r[1], r[2], r[2], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->ORIGINAL:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("DEARROW"); pc = 7; continue; }
case 7: { r[3] = Value.i32(1); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;-><init>(Ljava/lang/String;IZZ)V",r[0],new Value[]{r[1], r[3], r[3], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->DEARROW:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("DEARROW_STILL_IMAGES"); pc = 12; continue; }
case 12: { r[4] = Value.i32(2); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;-><init>(Ljava/lang/String;IZZ)V",r[0],new Value[]{r[1], r[4], r[3], r[3]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->DEARROW_STILL_IMAGES:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true,r[0]); pc = 15; continue; }
case 15: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;"); pc = 16; continue; }
case 16: { r[1] = Value.ref("STILL_IMAGES"); pc = 17; continue; }
case 17: { r[4] = Value.i32(3); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;-><init>(Ljava/lang/String;IZZ)V",r[0],new Value[]{r[1], r[4], r[2], r[3]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->STILL_IMAGES:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true,r[0]); pc = 20; continue; }
case 20: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->$values()[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,new Value[]{}); pc = 21; continue; }
case 21: { r[0] = result; pc = 22; continue; }
case 22: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->$VALUES:[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true,r[0]); pc = 23; continue; }
case 23: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_289279b472124d1369ea51c9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->useDeArrow:Z",r[0],false,r[3]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->useStillImages:Z",r[0],false,r[4]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d79624eca478d7d94711f1af(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->ORIGINAL:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->DEARROW:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->DEARROW_STILL_IMAGES:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->STILL_IMAGES:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.filledArray("[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;",new Value[]{r[0], r[1], r[2], r[3]}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
