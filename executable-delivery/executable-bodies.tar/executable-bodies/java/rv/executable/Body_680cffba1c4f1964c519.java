package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_680cffba1c4f1964c519 {
static Value m_a5cb3b154172f9e80eeb4a97(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->$VALUES:[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_624f8d1d08c893589f8e7471(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { r[3] = Value.ref("DEFAULT"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V",r[0],new Value[]{r[3], r[1], r[2], r[2]}); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[0]); pc = 6; continue; }
case 6: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 7; continue; }
case 7: { r[1] = Value.ref("ytWordmarkHeader"); pc = 8; continue; }
case 8: { r[2] = Value.ref("yt_ringo2_wordmark_header"); pc = 9; continue; }
case 9: { r[3] = Value.ref("REGULAR"); pc = 10; continue; }
case 10: { r[4] = Value.i32(1); pc = 11; continue; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V",r[0],new Value[]{r[3], r[4], r[1], r[2]}); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->REGULAR:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[0]); pc = 13; continue; }
case 13: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 14; continue; }
case 14: { r[1] = Value.ref("ytPremiumWordmarkHeader"); pc = 15; continue; }
case 15: { r[2] = Value.ref("yt_ringo2_premium_wordmark_header"); pc = 16; continue; }
case 16: { r[3] = Value.ref("PREMIUM"); pc = 17; continue; }
case 17: { r[4] = Value.i32(2); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V",r[0],new Value[]{r[3], r[4], r[1], r[2]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->PREMIUM:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 21; continue; }
case 21: { r[1] = Value.i32(3); pc = 22; continue; }
case 22: { r[2] = Value.ref("revanced_header_rounded"); pc = 23; continue; }
case 23: { r[3] = Value.ref("ROUNDED"); pc = 24; continue; }
case 24: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[3], r[1], r[2]}); pc = 25; continue; }
case 25: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->ROUNDED:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[0]); pc = 26; continue; }
case 26: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 27; continue; }
case 27: { r[2] = Value.i32(4); pc = 28; continue; }
case 28: { r[3] = Value.ref("revanced_header_minimal"); pc = 29; continue; }
case 29: { r[4] = Value.ref("MINIMAL"); pc = 30; continue; }
case 30: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[1],new Value[]{r[4], r[2], r[3]}); pc = 31; continue; }
case 31: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->MINIMAL:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[1]); pc = 32; continue; }
case 32: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 33; continue; }
case 33: { r[3] = Value.i32(5); pc = 34; continue; }
case 34: { r[4] = Value.ref("revanced_header_custom"); pc = 35; continue; }
case 35: { r[5] = Value.ref("CUSTOM"); pc = 36; continue; }
case 36: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[2],new Value[]{r[5], r[3], r[4]}); pc = 37; continue; }
case 37: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->CUSTOM:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[2]); pc = 38; continue; }
case 38: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 39; continue; }
case 39: { r[3] = Value.i32(6); pc = 40; continue; }
case 40: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->attributeName:Ljava/lang/String;",r[0],false); pc = 41; continue; }
case 41: { r[4] = Value.ref("REVANCED"); pc = 42; continue; }
case 42: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[2],new Value[]{r[4], r[3], r[0]}); pc = 43; continue; }
case 43: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->REVANCED:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[2]); pc = 44; continue; }
case 44: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); pc = 45; continue; }
case 45: { r[2] = Value.i32(7); pc = 46; continue; }
case 46: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->attributeName:Ljava/lang/String;",r[1],false); pc = 47; continue; }
case 47: { r[3] = Value.ref("REVANCED_MINIMAL"); pc = 48; continue; }
case 48: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[3], r[2], r[1]}); pc = 49; continue; }
case 49: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->REVANCED_MINIMAL:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[0]); pc = 50; continue; }
case 50: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->$values()[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,new Value[]{}); pc = 51; continue; }
case 51: { r[0] = result; pc = 52; continue; }
case 52: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->$VALUES:[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true,r[0]); pc = 53; continue; }
case 53: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_44fddde53edc25d1ca9b11fe(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Ljava/lang/String;");
r[4] = rt.check(arguments[3], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->attributeName:Ljava/lang/String;",r[0],false,r[3]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->drawableName:Ljava/lang/String;",r[0],false,r[4]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d3dcbb7ea8124967b1745d36(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[3]}); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;","Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V",r[0],new Value[]{r[1], r[2], r[3], r[3]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_998ab0fbb4feab1170eeb7f4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->REGULAR:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->PREMIUM:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->ROUNDED:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->MINIMAL:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->CUSTOM:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 6; continue; }
case 6: { r[6] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->REVANCED:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 7; continue; }
case 7: { r[7] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->REVANCED_MINIMAL:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",Value.NULL,true); pc = 8; continue; }
case 8: { result=rt.filledArray("[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;",new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7]}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
