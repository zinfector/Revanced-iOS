package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_eb39b0fde092ed998280 {
static ClassInfo info_eb39b0fde092ed998280() {return new ClassInfo("Lapp/revanced/extension/shared/Logger$LogMessage;", "Ljava/lang/Object;", new String[]{}, 1537, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("buildMessageString()Ljava/lang/String;", 1025)});}
}
