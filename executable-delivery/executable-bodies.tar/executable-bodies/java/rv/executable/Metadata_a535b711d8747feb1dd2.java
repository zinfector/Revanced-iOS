package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_a535b711d8747feb1dd2 {
static ClassInfo info_a535b711d8747feb1dd2() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;->f$0:I", "I", 4113, ExecutableRuntime.zero("I"))}, new MethodInfo[]{new MethodInfo("<init>(I)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "Utils$$ExternalSyntheticLambda9");}
}
