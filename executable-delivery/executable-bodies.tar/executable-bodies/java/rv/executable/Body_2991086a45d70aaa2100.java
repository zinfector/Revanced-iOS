package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_2991086a45d70aaa2100 {
static Value m_e49c901bc63c09958714a294(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("fade_duration_fast"); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->getResourceInteger(Ljava/lang/String;)I",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->fadeInDuration:I",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { r[0] = Value.ref("fade_duration_scheduled"); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->getResourceInteger(Ljava/lang/String;)I",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->fadeOutDuration:I",Value.NULL,true,r[0]); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_76947374d35f37fd6837e22d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 6) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[15];
r[8] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[9] = rt.check(arguments[0], "Landroid/view/View;");
r[10] = rt.check(arguments[1], "Ljava/lang/String;");
r[11] = rt.check(arguments[2], "Ljava/lang/String;");
r[12] = rt.check(arguments[3], "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;");
r[13] = rt.check(arguments[4], "Landroid/view/View$OnClickListener;");
r[14] = rt.check(arguments[5], "Landroid/view/View$OnLongClickListener;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[3] = r[10]; pc = 1; continue; }
case 1: { r[0] = r[8]; pc = 2; continue; }
case 2: { r[1] = r[9]; pc = 3; continue; }
case 3: { r[2] = r[10]; pc = 4; continue; }
case 4: { r[4] = r[11]; pc = 5; continue; }
case 5: { r[5] = r[12]; pc = 6; continue; }
case 6: { r[6] = r[13]; pc = 7; continue; }
case 7: { r[7] = r[14]; pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;-><init>(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;Landroid/view/View$OnClickListener;Landroid/view/View$OnLongClickListener;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6], r[7]}); pc = 9; continue; }
case 9: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_14a99ce61d3324099974f284(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[1] = rt.check(arguments[0], "Z");
r[2] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?3:1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?3:2; continue; }
case 2: { return Value.VOID; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->privateSetVisibility(ZZ)V",r[0],new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_11dd04650c3e36a040630e81(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[1] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?5:1; continue; }
case 1: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda4;-><init>(Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;)V",r[1],new Value[]{r[0]}); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->runOnMainThread(Ljava/lang/Runnable;)V",Value.NULL,new Value[]{r[1]}); pc = 4; continue; }
case 4: { return Value.VOID; }
case 5: { r[1] = Value.i32(0); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->privateSetVisibility(ZZ)V",r[0],new Value[]{r[1], r[1]}); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8f037a8ecc599c87352f2688(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
r[8] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->getCurrent()Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_HIDDEN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],r[1]))?6:5; continue; }
case 5: { pc=16; continue; }
case 6: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->enabledStatus:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;",r[8],false); pc = 7; continue; }
case 7: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;->buttonEnabled()Z",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?11:10; continue; }
case 10: { pc=16; continue; }
case 11: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->containerRef:Ljava/lang/ref/WeakReference;",r[8],false); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[0],new Value[]{}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { r[0] = rt.cast(r[0],"Landroid/view/View;"); pc = 15; continue; }
case 15: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?17:16; continue; }
case 16: { return Value.VOID; }
case 17: { r[1] = Value.i32(0); pc = 18; continue; }
case 18: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->isVisible:Z",r[8],false,r[1]); pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;",r[0],new Value[]{}); pc = 20; continue; }
case 20: { r[1] = result; pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->cancel()V",r[1],new Value[]{}); pc = 22; continue; }
case 22: { r[2] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->fadeInDuration:I",Value.NULL,true); pc = 23; continue; }
case 23: { r[2] = Value.i64((long)(r[2].i())); r[3] = r[2]; pc = 24; continue; }
case 24: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 25; continue; }
case 25: { r[4] = result; r[5] = r[4]; pc = 26; continue; }
case 26: { r[6] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->lastTimeSetVisible:J",r[8],false); r[7] = r[6]; pc = 27; continue; }
case 27: { r[4] = Value.i64((r[4].j()) - (r[6].j())); r[5] = r[4]; pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/Math;->min(JJ)J",Value.NULL,new Value[]{r[2], r[4]}); pc = 29; continue; }
case 29: { r[2] = result; r[3] = r[2]; pc = 30; continue; }
case 30: { r[4] = Value.i64(0L); r[5] = r[4]; pc = 31; continue; }
case 31: { r[4] = Value.i32(ExecutableRuntime.compareLong(r[2].j(), r[4].j())); pc = 32; continue; }
case 32: { pc=(r[4].i() > 0)?38:33; continue; }
case 33: { r[1] = Value.i32(8); pc = 34; continue; }
case 34: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setVisibility(I)V",r[0],new Value[]{r[1]}); pc = 35; continue; }
case 35: { return Value.VOID; }
case 36: { r[0] = Value.ref(exception); exception=null; pc = 37; continue; }
case 37: { pc=49; continue; }
case 38: { r[4] = Value.i32(0); pc = 39; continue; }
case 39: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;",r[1],new Value[]{r[4]}); pc = 40; continue; }
case 40: { r[1] = result; pc = 41; continue; }
case 41: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;",r[1],new Value[]{r[2]}); pc = 42; continue; }
case 42: { r[1] = result; pc = 43; continue; }
case 43: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda5;"); pc = 44; continue; }
case 44: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda5;-><init>(Landroid/view/View;)V",r[2],new Value[]{r[0]}); pc = 45; continue; }
case 45: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;",r[1],new Value[]{r[2]}); pc = 46; continue; }
case 46: { r[0] = result; pc = 47; continue; }
case 47: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->start()V",r[0],new Value[]{}); pc = 48; continue; }
case 48: { return Value.VOID; }
case 49: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda6;"); pc = 50; continue; }
case 50: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda6;-><init>()V",r[1],new Value[]{}); pc = 51; continue; }
case 51: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 52; continue; }
case 52: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 48) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=36; continue; } }
throw error;
}
}

}

static Value m_c5b67eb4e04fe8ddadc67cd3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 7) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[2] = rt.check(arguments[0], "Landroid/view/View;");
r[3] = rt.check(arguments[1], "Ljava/lang/String;");
r[4] = rt.check(arguments[2], "Ljava/lang/String;");
r[5] = rt.check(arguments[3], "Ljava/lang/String;");
r[6] = rt.check(arguments[4], "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;");
r[7] = rt.check(arguments[5], "Landroid/view/View$OnClickListener;");
r[8] = rt.check(arguments[6], "Landroid/view/View$OnLongClickListener;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/Object;-><init>()V",r[1],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->getChildViewByResourceName(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;",Value.NULL,new Value[]{r[2], r[3]}); pc = 2; continue; }
case 2: { r[3] = result; pc = 3; continue; }
case 3: { r[0] = Value.i32(8); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setVisibility(I)V",r[3],new Value[]{r[0]}); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[3]}); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->containerRef:Ljava/lang/ref/WeakReference;",r[1],false,r[0]); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->getChildViewByResourceName(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;",Value.NULL,new Value[]{r[2], r[4]}); pc = 9; continue; }
case 9: { r[3] = result; pc = 10; continue; }
case 10: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda0;"); pc = 11; continue; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda0;-><init>(Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;Landroid/view/View$OnClickListener;)V",r[4],new Value[]{r[1], r[7]}); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V",r[3],new Value[]{r[4]}); pc = 13; continue; }
case 13: { pc=(ExecutableRuntime.equal(r[8],Value.i32(0)))?17:14; continue; }
case 14: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda1;"); pc = 15; continue; }
case 15: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda1;-><init>(Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;Landroid/view/View$OnLongClickListener;)V",r[4],new Value[]{r[1], r[8]}); pc = 16; continue; }
case 16: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V",r[3],new Value[]{r[4]}); pc = 17; continue; }
case 17: { r[4] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[4],new Value[]{r[3]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->buttonRef:Ljava/lang/ref/WeakReference;",r[1],false,r[4]); pc = 20; continue; }
case 20: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?25:21; continue; }
case 21: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->getChildViewByResourceName(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;",Value.NULL,new Value[]{r[2], r[5]}); pc = 22; continue; }
case 22: { r[2] = result; pc = 23; continue; }
case 23: { r[2] = rt.cast(r[2],"Landroid/widget/TextView;"); pc = 24; continue; }
case 24: { pc=26; continue; }
case 25: { r[2] = Value.i32(0); pc = 26; continue; }
case 26: { r[3] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 27; continue; }
case 27: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[3],new Value[]{r[2]}); pc = 28; continue; }
case 28: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->textOverlayRef:Ljava/lang/ref/WeakReference;",r[1],false,r[3]); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->enabledStatus:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;",r[1],false,r[6]); pc = 30; continue; }
case 30: { r[2] = Value.i32(0); pc = 31; continue; }
case 31: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->isVisible:Z",r[1],false,r[2]); pc = 32; continue; }
case 32: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/shared/PlayerType;->getOnChange()Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,new Value[]{}); pc = 33; continue; }
case 33: { r[2] = result; pc = 34; continue; }
case 34: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;"); pc = 35; continue; }
case 35: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;-><init>(Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;)V",r[3],new Value[]{r[1]}); pc = 36; continue; }
case 36: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/shared/Event;->addObserver(Lkotlin/jvm/functions/Function1;)V",r[2],new Value[]{r[3]}); pc = 37; continue; }
case 37: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f736a482a37a3c1d9e285269(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[3] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[4] = rt.check(arguments[0], "Z");
r[5] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->isVisible:Z",r[3],false); pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],r[4]))?4:3; continue; }
case 3: { pc=63; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->isVisible:Z",r[3],false,r[4]); pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[4],Value.i32(0)))?12:6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; r[1] = r[0]; pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->lastTimeSetVisible:J",r[3],false,r[0]); pc = 9; continue; }
case 9: { pc=12; continue; }
case 10: { r[4] = Value.ref(exception); exception=null; pc = 11; continue; }
case 11: { pc=64; continue; }
case 12: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->containerRef:Ljava/lang/ref/WeakReference;",r[3],false); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[0],new Value[]{}); pc = 14; continue; }
case 14: { r[0] = result; pc = 15; continue; }
case 15: { r[0] = rt.cast(r[0],"Landroid/view/View;"); pc = 16; continue; }
case 16: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?18:17; continue; }
case 17: { pc=63; continue; }
case 18: { r[1] = Value.i32(0); pc = 19; continue; }
case 19: { pc=(ExecutableRuntime.equal(r[4],Value.i32(0)))?42:20; continue; }
case 20: { r[4] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->enabledStatus:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;",r[3],false); pc = 21; continue; }
case 21: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;->buttonEnabled()Z",r[4],new Value[]{}); pc = 22; continue; }
case 22: { r[4] = result; pc = 23; continue; }
case 23: { pc=(ExecutableRuntime.equal(r[4],Value.i32(0)))?42:24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;",r[0],new Value[]{}); pc = 25; continue; }
case 25: { r[4] = result; pc = 26; continue; }
case 26: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->cancel()V",r[4],new Value[]{}); pc = 27; continue; }
case 27: { r[2] = Value.i32(0); pc = 28; continue; }
case 28: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setVisibility(I)V",r[0],new Value[]{r[2]}); pc = 29; continue; }
case 29: { r[2] = Value.i32(1065353216); pc = 30; continue; }
case 30: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?40:31; continue; }
case 31: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setAlpha(F)V",r[0],new Value[]{r[1]}); pc = 32; continue; }
case 32: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;",r[4],new Value[]{r[2]}); pc = 33; continue; }
case 33: { r[4] = result; pc = 34; continue; }
case 34: { r[5] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->fadeInDuration:I",Value.NULL,true); pc = 35; continue; }
case 35: { r[0] = Value.i64((long)(r[5].i())); r[1] = r[0]; pc = 36; continue; }
case 36: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;",r[4],new Value[]{r[0]}); pc = 37; continue; }
case 37: { r[4] = result; pc = 38; continue; }
case 38: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->start()V",r[4],new Value[]{}); pc = 39; continue; }
case 39: { return Value.VOID; }
case 40: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setAlpha(F)V",r[0],new Value[]{r[2]}); pc = 41; continue; }
case 41: { return Value.VOID; }
case 42: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->getVisibility()I",r[0],new Value[]{}); pc = 43; continue; }
case 43: { r[4] = result; pc = 44; continue; }
case 44: { pc=(!ExecutableRuntime.equal(r[4],Value.i32(0)))?63:45; continue; }
case 45: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;",r[0],new Value[]{}); pc = 46; continue; }
case 46: { r[4] = result; pc = 47; continue; }
case 47: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->cancel()V",r[4],new Value[]{}); pc = 48; continue; }
case 48: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?61:49; continue; }
case 49: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;",r[4],new Value[]{r[1]}); pc = 50; continue; }
case 50: { r[4] = result; pc = 51; continue; }
case 51: { r[5] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->fadeOutDuration:I",Value.NULL,true); pc = 52; continue; }
case 52: { r[1] = Value.i64((long)(r[5].i())); r[2] = r[1]; pc = 53; continue; }
case 53: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;",r[4],new Value[]{r[1]}); pc = 54; continue; }
case 54: { r[4] = result; pc = 55; continue; }
case 55: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda7;"); pc = 56; continue; }
case 56: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda7;-><init>(Landroid/view/View;)V",r[5],new Value[]{r[0]}); pc = 57; continue; }
case 57: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;",r[4],new Value[]{r[5]}); pc = 58; continue; }
case 58: { r[4] = result; pc = 59; continue; }
case 59: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->start()V",r[4],new Value[]{}); pc = 60; continue; }
case 60: { return Value.VOID; }
case 61: { r[4] = Value.i32(8); pc = 62; continue; }
case 62: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setVisibility(I)V",r[0],new Value[]{r[4]}); pc = 63; continue; }
case 63: { return Value.VOID; }
case 64: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda8;"); pc = 65; continue; }
case 65: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda8;-><init>()V",r[5],new Value[]{}); pc = 66; continue; }
case 66: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[5], r[4]}); pc = 67; continue; }
case 67: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 63) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=10; continue; } }
throw error;
}
}

}

static Value m_145dfd54be7584c2eaffe7f9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("setVisibilityNegatedImmediate failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1ae885289b004e02d30d47f3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[1] = rt.check(arguments[1], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->lambda$new$2(Lapp/revanced/extension/youtube/shared/PlayerType;)Lkotlin/Unit;",r[0],new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Lkotlin/Unit;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0b54c7b59162e08185235965(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("privateSetVisibility failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3b379531f6a86c2bf7e4ad23(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->playerTypeChanged(Lapp/revanced/extension/youtube/shared/PlayerType;)V",r[0],new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;",Value.NULL,true); pc = 2; continue; }
case 2: { return rt.check(r[1],"Lkotlin/Unit;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_749e497cc64a2421ca527502(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_MINIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[2],r[0]))?7:3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/shared/PlayerType;->isMaximizedOrFullscreen()Z",r[2],new Value[]{}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?7:6; continue; }
case 6: { pc=12; continue; }
case 7: { r[2] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->containerRef:Ljava/lang/ref/WeakReference;",r[1],false); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[2],new Value[]{}); pc = 9; continue; }
case 9: { r[2] = result; pc = 10; continue; }
case 10: { r[2] = rt.cast(r[2],"Landroid/view/View;"); pc = 11; continue; }
case 11: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?13:12; continue; }
case 12: { return Value.VOID; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;",r[2],new Value[]{}); pc = 14; continue; }
case 14: { r[0] = result; pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/ViewPropertyAnimator;->cancel()V",r[0],new Value[]{}); pc = 16; continue; }
case 16: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->isVisible:Z",r[1],false); pc = 17; continue; }
case 17: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?27:18; continue; }
case 18: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->enabledStatus:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;",r[1],false); pc = 19; continue; }
case 19: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;->buttonEnabled()Z",r[0],new Value[]{}); pc = 20; continue; }
case 20: { r[0] = result; pc = 21; continue; }
case 21: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?27:22; continue; }
case 22: { r[0] = Value.i32(0); pc = 23; continue; }
case 23: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setVisibility(I)V",r[2],new Value[]{r[0]}); pc = 24; continue; }
case 24: { r[0] = Value.i32(1065353216); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setAlpha(F)V",r[2],new Value[]{r[0]}); pc = 26; continue; }
case 26: { return Value.VOID; }
case 27: { r[0] = Value.i32(8); pc = 28; continue; }
case 28: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setVisibility(I)V",r[2],new Value[]{r[0]}); pc = 29; continue; }
case 29: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fb1f746cc2a364f76a0f87bf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->lambda$setVisibilityImmediate$6()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c6caf7893af65e8bec4ccda9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(8); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setVisibility(I)V",r[1],new Value[]{r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3be06a31b93002c67d6fdf86(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(8); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Landroid/view/View;->setVisibility(I)V",r[1],new Value[]{r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5baf3f0276df5f11c66dec9c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(1); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->privateSetVisibility(ZZ)V",r[2],new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
