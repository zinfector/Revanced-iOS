package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_81ce4dc8068c063f2aaa {
static Value m_846f769e11f199e6c357ab7e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;");
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;->segment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",r[1],false,r[2]); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->getSkipButtonText()Ljava/lang/String;",r[2],new Value[]{}); pc = 2; continue; }
case 2: { r[2] = result; pc = 3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;->skipSponsorTextView:Landroid/widget/TextView;",r[1],false); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;","Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;","Ljava/lang/Object;->equals(Ljava/lang/Object;)Z",r[2],new Value[]{r[0]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?10:9; continue; }
case 9: { return Value.VOID; }
case 10: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;->skipSponsorTextView:Landroid/widget/TextView;",r[1],false); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;","Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V",r[0],new Value[]{r[2]}); pc = 12; continue; }
case 12: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
