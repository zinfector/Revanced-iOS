package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_708b212a719b1f174ea7 {
static ClassInfo info_708b212a719b1f174ea7() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;", "Ljava/lang/Object;", new String[]{}, 1537, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("patch_seekTo(J)Z", 1025), new MethodInfo("patch_seekToRelative(J)V", 1025)}, "PlaybackController");}
}
