package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_44fc827439bc76fd30d9 {
static ClassInfo info_44fc827439bc76fd30d9() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda14;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda14;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
