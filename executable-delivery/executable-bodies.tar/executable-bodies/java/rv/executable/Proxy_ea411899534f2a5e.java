package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_ea411899534f2a5e extends RuntimeForeign.SourceProxy implements java.util.Map {
Proxy_ea411899534f2a5e(RuntimeForeign owner,Instance source){super(owner,source);}
public int size() {Value result=owner.callback(source,"Ljava/util/Map;->size()I",new Value[]{}); return result.i();}
public boolean isEmpty() {Value result=owner.callback(source,"Ljava/util/Map;->isEmpty()Z",new Value[]{}); return result.z();}
public boolean containsKey(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean containsValue(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Map;->containsValue(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public java.lang.Object get(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;",new Value[]{owner.importValue(a0)}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object put(java.lang.Object a0,java.lang.Object a1) {Value result=owner.callback(source,"Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",new Value[]{owner.importValue(a0),owner.importValue(a1)}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object remove(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;",new Value[]{owner.importValue(a0)}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public void putAll(java.util.Map a0) {Value result=owner.callback(source,"Ljava/util/Map;->putAll(Ljava/util/Map;)V",new Value[]{owner.importValue(a0)}); return;}
public void clear() {Value result=owner.callback(source,"Ljava/util/Map;->clear()V",new Value[]{}); return;}
public java.util.Set keySet() {Value result=owner.callback(source,"Ljava/util/Map;->keySet()Ljava/util/Set;",new Value[]{}); return (java.util.Set)owner.exportObject(result.o(),"Ljava/util/Set;");}
public java.util.Collection values() {Value result=owner.callback(source,"Ljava/util/Map;->values()Ljava/util/Collection;",new Value[]{}); return (java.util.Collection)owner.exportObject(result.o(),"Ljava/util/Collection;");}
public java.util.Set entrySet() {Value result=owner.callback(source,"Ljava/util/Map;->entrySet()Ljava/util/Set;",new Value[]{}); return (java.util.Set)owner.exportObject(result.o(),"Ljava/util/Set;");}
public boolean equals(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Map;->equals(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int hashCode() {Value result=owner.callback(source,"Ljava/util/Map;->hashCode()I",new Value[]{}); return result.i();}
}
