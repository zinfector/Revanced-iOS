package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_a535b711d8747feb1dd2 {
static Value m_5ad37e88dadef86662ca8a5f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;");
r[1] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;->f$0:I", r[0], false, r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c277a07c241de387fe277f08(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;->f$0:I", r[1], false); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;", "Lapp/revanced/extension/shared/Utils;->$r8$lambda$JEXV0LovJfDG6Pvi8w0tedwPLwA(I)Ljava/lang/String;", Value.NULL, new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
