package rv.executable;

import java.util.*;
import java.util.concurrent.locks.ReentrantLock;
import java.lang.ref.WeakReference;

/** Runtime for compiled shared bodies. No DEX loader, instruction interpreter,
 * reflection invocation, or application-specific patch algorithm is present. */
public final class ExecutableRuntime {
    /** Compiler/provider contract failure, distinct from an application exception.
     * J2ObjC has LinkageError but does not supply the JVM VerifyError class. */
    public static final class InvalidProgram extends LinkageError {
        public InvalidProgram(String message) { super(message); }
    }
    public static final class MissingOperation extends UnsupportedOperationException {
        public final String operation;
        public MissingOperation(String operation) { super("Unadmitted operation: " + operation); this.operation = operation; }
    }
    public static final class Value {
        public final long bits;
        public final Object reference;
        public final int kind; // 0=void, 1=32-bit bits, 2=64-bit bits, 3=reference
        private Value(int kind, long bits, Object reference) { this.kind=kind; this.bits=bits; this.reference=reference; }
        public static final Value VOID=new Value(0,0,null), NULL=new Value(3,0,null);
        public static Value i32(int value) { return new Value(1,value,null); }
        public static Value i64(long value) { return new Value(2,value,null); }
        public static Value f32(float value) { return i32(Float.floatToRawIntBits(value)); }
        public static Value f64(double value) { return i64(Double.doubleToRawLongBits(value)); }
        public static Value ref(Object value) { return value==null ? NULL : new Value(3,0,value); }
        public int i() { if(kind!=1) throw new InvalidProgram("Expected 32-bit value"); return (int)bits; }
        public long j() { if(kind!=2) throw new InvalidProgram("Expected 64-bit value"); return bits; }
        public float f() { return Float.intBitsToFloat(i()); }
        public double d() { return Double.longBitsToDouble(j()); }
        public Object o() { if(kind==1 && bits==0) return null; if(kind!=3) throw new InvalidProgram("Expected reference"); return reference; }
        public boolean z() { int v=i(); if(v!=0 && v!=1) throw new InvalidProgram("Invalid Boolean value"); return v!=0; }
    }
    public static Value zero(String type) {
        if(type.startsWith("L") || type.startsWith("[")) return Value.NULL;
        return type.equals("J") || type.equals("D") ? Value.i64(0) : type.equals("V") ? Value.VOID : Value.i32(0);
    }
    public static boolean equal(Value a, Value b) {
        if(a.kind==3 || b.kind==3) return a.o()==b.o();
        if(a.kind!=b.kind) throw new InvalidProgram("Equality width differs");
        return a.bits==b.bits;
    }
    public static int compareLong(long a,long b) { return a<b?-1:a>b?1:0; }
    public static int compareFloat(float a,float b,int nan) { return Float.isNaN(a)||Float.isNaN(b)?nan:a<b?-1:a>b?1:0; }
    public static int compareDouble(double a,double b,int nan) { return Double.isNaN(a)||Double.isNaN(b)?nan:a<b?-1:a>b?1:0; }

    public interface Program {
        ClassInfo describe(String type);
        Value execute(ExecutableRuntime runtime,String method,Value receiver,Value[] arguments) throws Throwable;
        boolean hasBody(String method);
    }
    public interface Foreign {
        Value call(ExecutableRuntime runtime,String dispatch,String caller,String method,Value receiver,Value[] args) throws Throwable;
        Object allocate(String type) throws Throwable;
        Value readField(String field,Value receiver) throws Throwable;
        void writeField(String field,Value receiver,Value value) throws Throwable;
        void initializeClass(String type) throws Throwable;
        boolean isInstance(Object value,String type);
        boolean isAssignable(String source,String target);
    }
    /** Optional lifecycle contracts for providers with a reviewed type model. */
    public interface ForeignLifecycle extends Foreign {
        void bind(ExecutableRuntime runtime);
        void prepareSuperclass(Instance instance,String type) throws Throwable;
        void initializeDefaults(String type) throws Throwable;
        void validateField(String field,boolean isStatic);
    }
    public static class UnadmittedForeign implements Foreign {
        public Value call(ExecutableRuntime rt,String dispatch,String caller,String method,Value receiver,Value[] args) { throw new MissingOperation(method); }
        public Object allocate(String type) { throw new MissingOperation("allocate:"+type); }
        public Value readField(String field,Value receiver) { throw new MissingOperation("read:"+field); }
        public void writeField(String field,Value receiver,Value value) { throw new MissingOperation("write:"+field); }
        public void initializeClass(String type) { throw new MissingOperation("initialize:"+type); }
        public boolean isInstance(Object value,String type) { throw new MissingOperation("type:"+type); }
        public boolean isAssignable(String source,String target) { throw new MissingOperation("type-relation:"+source+":"+target); }
    }
    public static final class FieldInfo {
        public final String descriptor,type;
        public final int flags;
        public final Value initial;
        public FieldInfo(String descriptor,String type,int flags,Value initial) { this.descriptor=descriptor;this.type=type;this.flags=flags;this.initial=initial; }
        public boolean isStatic() { return (flags&8)!=0; }
    }
    public static final class MethodInfo {
        public final String signature;
        public final int flags;
        public MethodInfo(String signature,int flags) {this.signature=signature;this.flags=flags;}
    }
    public static final class ClassInfo {
        public final String type,parent;
        public final String simpleName;
        public final String[] interfaces;
        public final int flags;
        public final FieldInfo[] fields;
        public final MethodInfo[] methods;
        public ClassInfo(String type,String parent,String[] interfaces,int flags,FieldInfo[] fields,MethodInfo[] methods) {
            this(type,parent,interfaces,flags,fields,methods,type.substring(type.lastIndexOf('/')+1,type.length()-1));
        }
        public ClassInfo(String type,String parent,String[] interfaces,int flags,FieldInfo[] fields,MethodInfo[] methods,String simpleName) {
            this.type=type;this.parent=parent;this.interfaces=interfaces;this.flags=flags;this.fields=fields;this.methods=methods;
            this.simpleName=simpleName;
        }
        public boolean isInterface() {return (flags&0x200)!=0;}
    }
    private static final class Cell {
        private Value ordinary;
        private volatile Value ordered;
        private final boolean isVolatile;
        Cell(Value initial,boolean isVolatile) {this.isVolatile=isVolatile;ordinary=initial;ordered=initial;}
        Value get() {return isVolatile?ordered:ordinary;}
        void put(Value value) {if(isVolatile)ordered=value;else ordinary=value;}
    }
    public static final class Instance {
        public final String type;
        /** Provider-owned superclass state, kept on the same original object. */
        public final Map<String,Object> foreignState=new HashMap<>();
        private final Map<String,Cell> fields=new HashMap<>();
        private Instance(String type) {this.type=type;}
    }
    public static final class ArrayValue {
        public final String type;
        public final Value[] values;
        private ArrayValue(String type,int size) {
            if(size<0)throw new NegativeArraySizeException();this.type=type;values=new Value[size];
            Arrays.fill(values,zero(type.substring(1)));
        }
    }
    public static final class ClassToken {
        public final String type;
        private ClassToken(String type) {this.type=type;}
    }
    public static final class Raised extends RuntimeException {
        public final Object value;
        Raised(Object value) {super("Translated throwable",null);this.value=value;}
    }
    public static Object caught(Throwable error) {return error instanceof Raised?((Raised)error).value:error;}
    public static void raise(Object object) throws Throwable {
        if(object==null)throw new NullPointerException();
        if(object instanceof Throwable)throw (Throwable)object;
        throw new Raised(object);
    }
    private static final class ClassState {
        final Map<String,Cell> fields=new HashMap<>();
        final ClassToken token;
        int state; // 0=prepared, 1=initializing, 2=initialized, 3=erroneous
        Thread initializer;
        Throwable failure;
        ClassState(ClassInfo cls) {
            token=new ClassToken(cls.type);
            for(FieldInfo field:cls.fields)if(field.isStatic())fields.put(field.descriptor,new Cell(field.initial,(field.flags&0x40)!=0));
        }
    }
    private final Program program;
    private final Foreign foreign;
    private final Map<String,ClassState> states=new HashMap<>();
    private final Map<String,ClassToken> foreignTokens=new HashMap<>();
    private static final class Monitor {
        final WeakReference<Object> owner;
        final ReentrantLock lock=new ReentrantLock();
        Monitor(Object value){owner=new WeakReference<>(value);}
    }
    private final List<Monitor> monitors=new ArrayList<>();
    public ExecutableRuntime(Program program,Foreign foreign) {
        this.program=Objects.requireNonNull(program);this.foreign=Objects.requireNonNull(foreign);
        if(foreign instanceof ForeignLifecycle)((ForeignLifecycle)foreign).bind(this);
    }
    public ClassInfo describe(String type) {return program.describe(type);}
    public boolean hasBody(String method) {return program.hasBody(method);}
    public String method(String type,String signature) {return resolveMethod(type,signature,new HashSet<>());}
    public boolean isAssignable(String source,String target) {return assignable(source,target);}
    public Value cloneArray(Value value) {
        ArrayValue original=array(value);Value copy=newArray(original.type,original.values.length);
        System.arraycopy(original.values,0,((ArrayValue)copy.o()).values,0,original.values.length);return copy;
    }
    private ClassState state(ClassInfo cls) {
        synchronized(states) {ClassState state=states.get(cls.type);if(state==null){state=new ClassState(cls);states.put(cls.type,state);}return state;}
    }
    public ClassToken classToken(String type) {
        ClassInfo cls=program.describe(type);if(cls!=null)return state(cls).token;
        synchronized(foreignTokens) {ClassToken token=foreignTokens.get(type);if(token==null){token=new ClassToken(type);foreignTokens.put(type,token);}return token;}
    }
    public void initialize(String type) throws Throwable {
        ClassInfo cls=program.describe(type);
        if(cls==null){foreign.initializeClass(type);return;}
        ClassState state=state(cls);boolean interrupted=false;
        synchronized(state) {
            while(state.state==1 && state.initializer!=Thread.currentThread()) {
                try{state.wait();}catch(InterruptedException ignored){interrupted=true;}
            }
            if(interrupted)Thread.currentThread().interrupt();
            if(state.state==2 || state.state==1)return;
            if(state.state==3){NoClassDefFoundError error=new NoClassDefFoundError(type);error.initCause(state.failure);throw error;}
            state.state=1;state.initializer=Thread.currentThread();
        }
        try {
            if(!cls.isInterface()) {
                if(cls.parent!=null)initialize(cls.parent);
                Set<String> seen=new HashSet<>();for(String iface:cls.interfaces)initializeDefaults(iface,seen);
            }
            String method=type+"-><clinit>()V";
            if(program.hasBody(method))program.execute(this,method,Value.NULL,new Value[0]);
            synchronized(state){state.state=2;state.initializer=null;state.notifyAll();}
        } catch(Throwable error) {
            Throwable propagated=error instanceof Error?error:new ExceptionInInitializerError(error);
            synchronized(state){state.state=3;state.failure=propagated;state.initializer=null;state.notifyAll();}
            throw propagated;
        }
    }
    private void initializeDefaults(String type,Set<String> seen) throws Throwable {
        if(!seen.add(type))return;ClassInfo cls=program.describe(type);
        if(cls==null) {
            if(foreign instanceof ForeignLifecycle){((ForeignLifecycle)foreign).initializeDefaults(type);return;}
            throw new MissingOperation("default-interface-initialization:"+type);
        }
        for(String parent:cls.interfaces)initializeDefaults(parent,seen);
        for(MethodInfo method:cls.methods)if((method.flags&(8|2|0x400))==0 && !method.signature.startsWith("<")){initialize(type);return;}
    }
    public Value allocate(String type) throws Throwable {
        initialize(type);ClassInfo cls=program.describe(type);
        if(cls==null)return Value.ref(foreign.allocate(type));
        if((cls.flags&(0x200|0x400))!=0)throw new InstantiationError(type);
        Instance instance=new Instance(type);Set<String> seen=new HashSet<>();
        for(ClassInfo current=cls;current!=null;current=program.describe(current.parent)) {
            if(!seen.add(current.type))throw new InvalidProgram("Hierarchy cycle");
            for(FieldInfo field:current.fields)if(!field.isStatic())instance.fields.put(field.descriptor,new Cell(zero(field.type),(field.flags&0x40)!=0));
            // Foreign superclass allocation/field preparation needs an explicit
            // provider. No native object masquerades as an internal instance.
            if(current.parent!=null && program.describe(current.parent)==null && !current.parent.equals("Ljava/lang/Object;")) {
                if(foreign instanceof ForeignLifecycle)((ForeignLifecycle)foreign).prepareSuperclass(instance,current.parent);
                else throw new MissingOperation("foreign-superclass-allocation:"+current.parent);
            }
        }
        return Value.ref(instance);
    }
    private boolean subtype(String child,String parent,Set<String> seen) {
        if(child.equals(parent))return true;if(!seen.add(child))return false;
        ClassInfo cls=program.describe(child);if(cls==null)return false;
        if(cls.parent!=null && subtype(cls.parent,parent,seen))return true;
        for(String iface:cls.interfaces)if(subtype(iface,parent,seen))return true;
        return false;
    }
    private boolean assignable(String child,String parent) {
        if(child.equals(parent))return true;
        if(parent.equals("Ljava/lang/Object;") && (child.startsWith("L")||child.startsWith("[")))return true;
        if(child.startsWith("[")) {
            if(parent.equals("Ljava/lang/Cloneable;")||parent.equals("Ljava/io/Serializable;"))return true;
            if(!parent.startsWith("["))return false;
            String a=child.substring(1),b=parent.substring(1);
            if(!a.startsWith("L")&&!a.startsWith("["))return a.equals(b);
            if(!b.startsWith("L")&&!b.startsWith("["))return false;
            return assignable(a,b);
        }
        if(subtype(child,parent,new HashSet<>()))return true;
        if(program.describe(child)!=null && program.describe(parent)!=null)return false;
        return foreign.isAssignable(child,parent);
    }
    public boolean isInstance(Object value,String type) {
        if(value==null)return false;
        if(type.equals("Ljava/lang/Object;"))return true;
        if(value instanceof Instance)return assignable(((Instance)value).type,type);
        if(value instanceof ArrayValue) {
            String actual=((ArrayValue)value).type;
            if(actual.equals(type) || type.equals("Ljava/lang/Cloneable;") || type.equals("Ljava/io/Serializable;"))return true;
            if(!type.startsWith("["))return false;
            return assignable(actual,type);
        }
        if(value instanceof ClassToken && type.equals("Ljava/lang/Class;"))return true;
        if(value instanceof String && type.equals("Ljava/lang/String;"))return true;
        if(value instanceof Throwable) {
            if(type.equals("Ljava/lang/Throwable;"))return true;
            if(type.equals("Ljava/lang/Exception;"))return value instanceof Exception;
            if(type.equals("Ljava/lang/RuntimeException;"))return value instanceof RuntimeException;
            if(type.equals("Ljava/lang/Error;"))return value instanceof Error;
            if(type.equals("Ljava/lang/ArithmeticException;"))return value instanceof ArithmeticException;
            if(type.equals("Ljava/lang/NullPointerException;"))return value instanceof NullPointerException;
            if(type.equals("Ljava/lang/ClassCastException;"))return value instanceof ClassCastException;
            if(type.equals("Ljava/lang/IndexOutOfBoundsException;"))return value instanceof IndexOutOfBoundsException;
            if(type.equals("Ljava/lang/ArrayIndexOutOfBoundsException;"))return value instanceof ArrayIndexOutOfBoundsException;
            if(type.equals("Ljava/lang/ArrayStoreException;"))return value instanceof ArrayStoreException;
            if(type.equals("Ljava/lang/NegativeArraySizeException;"))return value instanceof NegativeArraySizeException;
        }
        if(program.describe(type)!=null)return false;
        return foreign.isInstance(value,type);
    }
    public Value cast(Value value,String type) {Object object=value.o();if(object!=null && !isInstance(object,type))throw new ClassCastException(type);return Value.ref(object);}
    public Value check(Value value,String type) {
        if(type.startsWith("L") || type.startsWith("["))return cast(value,type);
        if(type.equals("V")){if(value.kind!=0)throw new InvalidProgram("Nonvoid return");return value;}
        if(type.equals("J") || type.equals("D")){value.j();return value;}
        int bits=value.i();
        if(type.equals("Z")){value.z();return value;}
        if(type.equals("B"))return Value.i32((byte)bits);
        if(type.equals("S"))return Value.i32((short)bits);
        if(type.equals("C"))return Value.i32((char)bits);
        return value;
    }
    public Value newArray(String type,int size) {if(!type.startsWith("["))throw new InvalidProgram("Not an array type");return Value.ref(new ArrayValue(type,size));}
    private ArrayValue array(Value value) {Object object=value.o();if(object==null)throw new NullPointerException();if(!(object instanceof ArrayValue))throw new InvalidProgram("Array boundary needs a provider");return (ArrayValue)object;}
    public int length(Value value) {return array(value).values.length;}
    public Value arrayGet(Value value,int index) {return array(value).values[index];}
    public void arrayPut(Value value,int index,Value element) {
        ArrayValue array=array(value);if(index<0 || index>=array.values.length)throw new ArrayIndexOutOfBoundsException(index);
        String component=array.type.substring(1);
        if((component.startsWith("L") || component.startsWith("[")) && element.o()!=null && !isInstance(element.o(),component))throw new ArrayStoreException(component);
        array.values[index]=check(element,component);
    }
    public Value filledArray(String type,Value[] values) {Value result=newArray(type,values.length);for(int i=0;i<values.length;i++)arrayPut(result,i,values[i]);return result;}
    public void fillArray(Value value,int width,long[] bits) {
        ArrayValue array=array(value);String component=array.type.substring(1);
        int expected=component.equals("J")||component.equals("D")?8:component.equals("I")||component.equals("F")?4:component.equals("S")||component.equals("C")?2:component.equals("B")||component.equals("Z")?1:0;
        if(width!=expected)throw new InvalidProgram("Array payload width mismatch");
        if(bits.length>array.values.length)throw new ArrayIndexOutOfBoundsException();
        for(int i=0;i<bits.length;i++)array.values[i]=check(width==8?Value.i64(bits[i]):Value.i32((int)bits[i]),component);
    }
    private FieldInfo field(String descriptor,Set<String> seen) {
        int split=descriptor.indexOf("->");String owner=descriptor.substring(0,split),tail=descriptor.substring(split);
        if(!seen.add(owner))return null;ClassInfo cls=program.describe(owner);if(cls==null)return null;
        for(FieldInfo field:cls.fields)if(field.descriptor.equals(descriptor))return field;
        List<FieldInfo> candidates=new ArrayList<>();
        for(String iface:cls.interfaces){FieldInfo match=field(iface+tail,new HashSet<>(seen));if(match!=null) {
            boolean duplicate=false;for(FieldInfo prior:candidates)if(prior.descriptor.equals(match.descriptor))duplicate=true;
            if(!duplicate)candidates.add(match);
        }}
        if(candidates.size()>1)throw new IncompatibleClassChangeError("Ambiguous interface field: "+descriptor);
        if(candidates.size()==1)return candidates.get(0);
        if(cls.parent!=null){FieldInfo match=field(cls.parent+tail,seen);if(match!=null)return match;}
        return null;
    }
    public Value readField(String descriptor,Value receiver,boolean isStatic) throws Throwable {
        FieldInfo field=field(descriptor,new HashSet<>());
        if(field==null){
            if(foreign instanceof ForeignLifecycle)((ForeignLifecycle)foreign).validateField(descriptor,isStatic);
            if(!isStatic && receiver.o()==null)throw new NullPointerException();
            return check(foreign.readField(descriptor,receiver),descriptor.substring(descriptor.indexOf(':')+1));
        }
        if(field.isStatic()!=isStatic)throw new IncompatibleClassChangeError(descriptor);
        if(isStatic){String owner=field.descriptor.split("->",2)[0];initialize(owner);return state(program.describe(owner)).fields.get(field.descriptor).get();}
        Object object=receiver.o();if(object==null)throw new NullPointerException();
        if(!(object instanceof Instance))return foreign.readField(descriptor,receiver);
        Cell cell=((Instance)object).fields.get(field.descriptor);if(cell==null)throw new IncompatibleClassChangeError(descriptor);return cell.get();
    }
    public void writeField(String descriptor,Value receiver,boolean isStatic,Value value) throws Throwable {
        FieldInfo field=field(descriptor,new HashSet<>());
        if(field==null){foreign.writeField(descriptor,receiver,value);return;}
        if(field.isStatic()!=isStatic)throw new IncompatibleClassChangeError(descriptor);
        Value checked=check(value,field.type);
        if(isStatic){String owner=field.descriptor.split("->",2)[0];initialize(owner);state(program.describe(owner)).fields.get(field.descriptor).put(checked);return;}
        Object object=receiver.o();if(object==null)throw new NullPointerException();
        if(!(object instanceof Instance)){foreign.writeField(descriptor,receiver,checked);return;}
        Cell cell=((Instance)object).fields.get(field.descriptor);if(cell==null)throw new IncompatibleClassChangeError(descriptor);cell.put(checked);
    }
    private String resolveMethod(String type,String signature,Set<String> seen) {
        if(!seen.add(type))return null;ClassInfo cls=program.describe(type);if(cls==null)return null;
        for(MethodInfo method:cls.methods)if(method.signature.equals(signature))return cls.type+"->"+signature;
        if(!signature.startsWith("<") && cls.parent!=null){String match=resolveMethod(cls.parent,signature,seen);if(match!=null)return match;}
        List<String> candidates=new ArrayList<>();
        if(!signature.startsWith("<"))for(String iface:cls.interfaces){String match=resolveMethod(iface,signature,new HashSet<>(seen));if(match!=null && !candidates.contains(match))candidates.add(match);}
        List<String> maximal=new ArrayList<>(candidates);
        for(String first:candidates)for(String second:candidates)if(!first.equals(second) &&
            subtype(second.substring(0,second.indexOf("->")),first.substring(0,first.indexOf("->")),new HashSet<>()))maximal.remove(first);
        candidates=maximal;
        if(candidates.size()==1)return candidates.get(0);
        if(candidates.size()>1)throw new IncompatibleClassChangeError("Ambiguous interface method: "+signature);
        return null;
    }
    private Value foreignCall(String dispatch,String caller,String descriptor,Value receiver,Value[] args) throws Throwable {
        Value result=foreign.call(this,dispatch,caller,descriptor,receiver,args);
        if(result==null)throw new InvalidProgram("Foreign call returned no typed value: "+descriptor);
        return check(result,descriptor.substring(descriptor.indexOf(')')+1));
    }
    public Value invoke(String dispatch,String caller,String descriptor,Value receiver,Value[] args) throws Throwable {
        int split=descriptor.indexOf("->");String owner=descriptor.substring(0,split),signature=descriptor.substring(split+2),method=descriptor;
        if(!dispatch.equals("static")) {
            Object object=receiver.o();if(object==null)throw new NullPointerException();
            if(dispatch.equals("virtual") || dispatch.equals("interface")) {
                if(!(object instanceof Instance))return foreignCall(dispatch,caller,descriptor,receiver,args);
                if(!isInstance(object,owner))throw new IncompatibleClassChangeError(descriptor);
                String resolved=resolveMethod(((Instance)object).type,signature,new HashSet<>());if(resolved!=null)method=resolved;
            } else if(dispatch.equals("super")) {
                ClassInfo lexical=program.describe(caller);
                if(lexical==null)throw new InvalidProgram("Unknown lexical caller");
                ClassInfo target=program.describe(owner);
                String start=target!=null && target.isInterface()?owner:lexical.parent;
                String resolved=start==null?null:resolveMethod(start,signature,new HashSet<>());if(resolved!=null)method=resolved;
            }
        } else {
            String resolved=resolveMethod(owner,signature,new HashSet<>());if(resolved!=null)method=resolved;
        }
        if(!program.hasBody(method)) {
            ClassInfo internal=program.describe(method.substring(0,method.indexOf("->")));
            if(internal!=null) {
                for(MethodInfo declaration:internal.methods)if(declaration.signature.equals(signature) && (declaration.flags&0x400)!=0)
                    throw new AbstractMethodError(method);
            }
            return foreignCall(dispatch,caller,method,receiver,args);
        }
        ClassInfo declaring=program.describe(method.substring(0,method.indexOf("->")));
        for(MethodInfo declaration:declaring.methods)if(declaration.signature.equals(signature)) {
            if(((declaration.flags&8)!=0)!=dispatch.equals("static"))throw new IncompatibleClassChangeError(method);
            if((dispatch.equals("virtual")||dispatch.equals("interface")) && (declaration.flags&2)!=0)throw new IncompatibleClassChangeError("Private virtual target: "+method);
        }
        if(dispatch.equals("static") && !signature.startsWith("<clinit>"))initialize(method.substring(0,method.indexOf("->")));
        return program.execute(this,method,receiver,args);
    }
    private ReentrantLock monitor(Object object) {
        if(object==null)throw new NullPointerException();
        synchronized(monitors) {
            for(Iterator<Monitor> it=monitors.iterator();it.hasNext();) {
                Monitor entry=it.next();Object owner=entry.owner.get();
                if(owner==object)return entry.lock;
                if(owner==null)it.remove();
            }
            Monitor entry=new Monitor(object);monitors.add(entry);return entry.lock;
        }
    }
    public void enter(Value value) {monitor(value.o()).lock();}
    public void exit(Value value) {ReentrantLock lock=monitor(value.o());if(!lock.isHeldByCurrentThread())throw new IllegalMonitorStateException();lock.unlock();}
}
