package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_f5e92441ef86c060 extends RuntimeForeign.SourceProxy {
Source_f5e92441ef86c060(RuntimeForeign owner,Instance source){super(owner,source);}

}
