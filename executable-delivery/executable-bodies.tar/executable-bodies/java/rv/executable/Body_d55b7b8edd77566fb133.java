package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_d55b7b8edd77566fb133 {
static Value m_3246650b51cf4e144d17a853(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->$VALUES:[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d75f155e4f81c6e042e8cdd5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[25];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("revanced_sb_segments_sponsor"); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[4] = result; pc = 4; continue; }
case 4: { r[1] = Value.ref("revanced_sb_segments_sponsor_sum"); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[1]}); pc = 6; continue; }
case 6: { r[5] = result; pc = 7; continue; }
case 7: { r[1] = Value.ref("revanced_sb_skip_button_sponsor"); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[1]}); pc = 9; continue; }
case 9: { r[6] = result; pc = 10; continue; }
case 10: { r[1] = Value.ref("revanced_sb_skipped_sponsor"); pc = 11; continue; }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[1]}); pc = 12; continue; }
case 12: { r[7] = result; pc = 13; continue; }
case 13: { r[8] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SPONSOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 14; continue; }
case 14: { r[9] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SPONSOR_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 15; continue; }
case 15: { r[1] = Value.ref("SPONSOR"); pc = 16; continue; }
case 16: { r[2] = Value.i32(0); pc = 17; continue; }
case 17: { r[3] = Value.ref("sponsor"); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->SPONSOR:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[0]); pc = 20; continue; }
case 20: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 21; continue; }
case 21: { r[2] = Value.ref("revanced_sb_segments_selfpromo"); pc = 22; continue; }
case 22: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[2]}); pc = 23; continue; }
case 23: { r[5] = result; pc = 24; continue; }
case 24: { r[2] = Value.ref("revanced_sb_segments_selfpromo_sum"); pc = 25; continue; }
case 25: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[2]}); pc = 26; continue; }
case 26: { r[6] = result; pc = 27; continue; }
case 27: { r[2] = Value.ref("revanced_sb_skip_button_selfpromo"); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[2]}); pc = 29; continue; }
case 29: { r[7] = result; pc = 30; continue; }
case 30: { r[2] = Value.ref("revanced_sb_skipped_selfpromo"); pc = 31; continue; }
case 31: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[2]}); pc = 32; continue; }
case 32: { r[8] = result; pc = 33; continue; }
case 33: { r[9] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SELF_PROMO:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 34; continue; }
case 34: { r[10] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SELF_PROMO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 35; continue; }
case 35: { r[2] = Value.ref("SELF_PROMO"); pc = 36; continue; }
case 36: { r[3] = Value.i32(1); pc = 37; continue; }
case 37: { r[4] = Value.ref("selfpromo"); pc = 38; continue; }
case 38: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[1],new Value[]{r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10]}); pc = 39; continue; }
case 39: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->SELF_PROMO:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[1]); pc = 40; continue; }
case 40: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 41; continue; }
case 41: { r[3] = Value.ref("revanced_sb_segments_interaction"); pc = 42; continue; }
case 42: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[3]}); pc = 43; continue; }
case 43: { r[6] = result; pc = 44; continue; }
case 44: { r[3] = Value.ref("revanced_sb_segments_interaction_sum"); pc = 45; continue; }
case 45: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[3]}); pc = 46; continue; }
case 46: { r[7] = result; pc = 47; continue; }
case 47: { r[3] = Value.ref("revanced_sb_skip_button_interaction"); pc = 48; continue; }
case 48: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[3]}); pc = 49; continue; }
case 49: { r[8] = result; pc = 50; continue; }
case 50: { r[3] = Value.ref("revanced_sb_skipped_interaction"); pc = 51; continue; }
case 51: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[3]}); pc = 52; continue; }
case 52: { r[9] = result; pc = 53; continue; }
case 53: { r[10] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTERACTION:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 54; continue; }
case 54: { r[11] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTERACTION_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 55; continue; }
case 55: { r[3] = Value.ref("INTERACTION"); pc = 56; continue; }
case 56: { r[4] = Value.i32(2); pc = 57; continue; }
case 57: { r[5] = Value.ref("interaction"); pc = 58; continue; }
case 58: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[2],new Value[]{r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11]}); pc = 59; continue; }
case 59: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->INTERACTION:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[2]); pc = 60; continue; }
case 60: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 61; continue; }
case 61: { r[4] = Value.ref("revanced_sb_segments_highlight"); pc = 62; continue; }
case 62: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 63; continue; }
case 63: { r[7] = result; pc = 64; continue; }
case 64: { r[4] = Value.ref("revanced_sb_segments_highlight_sum"); pc = 65; continue; }
case 65: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 66; continue; }
case 66: { r[8] = result; pc = 67; continue; }
case 67: { r[4] = Value.ref("revanced_sb_skip_button_highlight"); pc = 68; continue; }
case 68: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 69; continue; }
case 69: { r[9] = result; pc = 70; continue; }
case 70: { r[4] = Value.ref("revanced_sb_skipped_highlight"); pc = 71; continue; }
case 71: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 72; continue; }
case 72: { r[10] = result; pc = 73; continue; }
case 73: { r[11] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HIGHLIGHT:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 74; continue; }
case 74: { r[12] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HIGHLIGHT_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 75; continue; }
case 75: { r[4] = Value.ref("HIGHLIGHT"); pc = 76; continue; }
case 76: { r[5] = Value.i32(3); pc = 77; continue; }
case 77: { r[6] = Value.ref("poi_highlight"); pc = 78; continue; }
case 78: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[3],new Value[]{r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12]}); pc = 79; continue; }
case 79: { r[9] = r[3]; pc = 80; continue; }
case 80: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[9]); pc = 81; continue; }
case 81: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 82; continue; }
case 82: { r[4] = Value.ref("revanced_sb_segments_intro"); pc = 83; continue; }
case 83: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 84; continue; }
case 84: { r[14] = result; pc = 85; continue; }
case 85: { r[4] = Value.ref("revanced_sb_segments_intro_sum"); pc = 86; continue; }
case 86: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 87; continue; }
case 87: { r[15] = result; pc = 88; continue; }
case 88: { r[4] = Value.ref("revanced_sb_skip_button_intro_beginning"); pc = 89; continue; }
case 89: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 90; continue; }
case 90: { r[16] = result; pc = 91; continue; }
case 91: { r[4] = Value.ref("revanced_sb_skip_button_intro_middle"); pc = 92; continue; }
case 92: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 93; continue; }
case 93: { r[17] = result; pc = 94; continue; }
case 94: { r[4] = Value.ref("revanced_sb_skip_button_intro_end"); pc = 95; continue; }
case 95: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 96; continue; }
case 96: { r[18] = result; pc = 97; continue; }
case 97: { r[4] = Value.ref("revanced_sb_skipped_intro_beginning"); pc = 98; continue; }
case 98: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 99; continue; }
case 99: { r[19] = result; pc = 100; continue; }
case 100: { r[4] = Value.ref("revanced_sb_skipped_intro_middle"); pc = 101; continue; }
case 101: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 102; continue; }
case 102: { r[20] = result; pc = 103; continue; }
case 103: { r[4] = Value.ref("revanced_sb_skipped_intro_end"); pc = 104; continue; }
case 104: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[4]}); pc = 105; continue; }
case 105: { r[21] = result; pc = 106; continue; }
case 106: { r[22] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTRO:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 107; continue; }
case 107: { r[23] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTRO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 108; continue; }
case 108: { r[11] = Value.ref("INTRO"); pc = 109; continue; }
case 109: { r[12] = Value.i32(4); pc = 110; continue; }
case 110: { r[13] = Value.ref("intro"); pc = 111; continue; }
case 111: { r[10] = r[3]; pc = 112; continue; }
case 112: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[10],new Value[]{r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19], r[20], r[21], r[22], r[23]}); pc = 113; continue; }
case 113: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->INTRO:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[3]); pc = 114; continue; }
case 114: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 115; continue; }
case 115: { r[5] = Value.ref("revanced_sb_segments_outro"); pc = 116; continue; }
case 116: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[5]}); pc = 117; continue; }
case 117: { r[14] = result; pc = 118; continue; }
case 118: { r[5] = Value.ref("revanced_sb_segments_outro_sum"); pc = 119; continue; }
case 119: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[5]}); pc = 120; continue; }
case 120: { r[15] = result; pc = 121; continue; }
case 121: { r[5] = Value.ref("revanced_sb_skip_button_outro"); pc = 122; continue; }
case 122: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[5]}); pc = 123; continue; }
case 123: { r[16] = result; pc = 124; continue; }
case 124: { r[5] = Value.ref("revanced_sb_skipped_outro"); pc = 125; continue; }
case 125: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[5]}); pc = 126; continue; }
case 126: { r[17] = result; pc = 127; continue; }
case 127: { r[18] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_OUTRO:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 128; continue; }
case 128: { r[19] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_OUTRO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 129; continue; }
case 129: { r[11] = Value.ref("OUTRO"); pc = 130; continue; }
case 130: { r[12] = Value.i32(5); pc = 131; continue; }
case 131: { r[13] = Value.ref("outro"); pc = 132; continue; }
case 132: { r[10] = r[4]; pc = 133; continue; }
case 133: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[10],new Value[]{r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19]}); pc = 134; continue; }
case 134: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->OUTRO:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[4]); pc = 135; continue; }
case 135: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 136; continue; }
case 136: { r[6] = Value.ref("revanced_sb_segments_preview"); pc = 137; continue; }
case 137: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[6]}); pc = 138; continue; }
case 138: { r[14] = result; pc = 139; continue; }
case 139: { r[6] = Value.ref("revanced_sb_segments_preview_sum"); pc = 140; continue; }
case 140: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[6]}); pc = 141; continue; }
case 141: { r[15] = result; pc = 142; continue; }
case 142: { r[6] = Value.ref("revanced_sb_skip_button_preview_beginning"); pc = 143; continue; }
case 143: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[6]}); pc = 144; continue; }
case 144: { r[16] = result; pc = 145; continue; }
case 145: { r[6] = Value.ref("revanced_sb_skip_button_preview_middle"); pc = 146; continue; }
case 146: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[6]}); pc = 147; continue; }
case 147: { r[17] = result; pc = 148; continue; }
case 148: { r[6] = Value.ref("revanced_sb_skip_button_preview_end"); pc = 149; continue; }
case 149: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[6]}); pc = 150; continue; }
case 150: { r[18] = result; pc = 151; continue; }
case 151: { r[6] = Value.ref("revanced_sb_skipped_preview_beginning"); pc = 152; continue; }
case 152: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[6]}); pc = 153; continue; }
case 153: { r[19] = result; pc = 154; continue; }
case 154: { r[6] = Value.ref("revanced_sb_skipped_preview_middle"); pc = 155; continue; }
case 155: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[6]}); pc = 156; continue; }
case 156: { r[20] = result; pc = 157; continue; }
case 157: { r[6] = Value.ref("revanced_sb_skipped_preview_end"); pc = 158; continue; }
case 158: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[6]}); pc = 159; continue; }
case 159: { r[21] = result; pc = 160; continue; }
case 160: { r[22] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_PREVIEW:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 161; continue; }
case 161: { r[23] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_PREVIEW_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 162; continue; }
case 162: { r[11] = Value.ref("PREVIEW"); pc = 163; continue; }
case 163: { r[12] = Value.i32(6); pc = 164; continue; }
case 164: { r[13] = Value.ref("preview"); pc = 165; continue; }
case 165: { r[10] = r[5]; pc = 166; continue; }
case 166: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[10],new Value[]{r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19], r[20], r[21], r[22], r[23]}); pc = 167; continue; }
case 167: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->PREVIEW:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[5]); pc = 168; continue; }
case 168: { r[6] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 169; continue; }
case 169: { r[7] = Value.ref("revanced_sb_segments_hook"); pc = 170; continue; }
case 170: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[7]}); pc = 171; continue; }
case 171: { r[14] = result; pc = 172; continue; }
case 172: { r[7] = Value.ref("revanced_sb_segments_hook_sum"); pc = 173; continue; }
case 173: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[7]}); pc = 174; continue; }
case 174: { r[15] = result; pc = 175; continue; }
case 175: { r[7] = Value.ref("revanced_sb_skip_button_hook"); pc = 176; continue; }
case 176: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[7]}); pc = 177; continue; }
case 177: { r[16] = result; pc = 178; continue; }
case 178: { r[7] = Value.ref("revanced_sb_skipped_hook"); pc = 179; continue; }
case 179: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[7]}); pc = 180; continue; }
case 180: { r[17] = result; pc = 181; continue; }
case 181: { r[18] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HOOK:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 182; continue; }
case 182: { r[19] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HOOK_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 183; continue; }
case 183: { r[11] = Value.ref("HOOK"); pc = 184; continue; }
case 184: { r[12] = Value.i32(7); pc = 185; continue; }
case 185: { r[13] = Value.ref("hook"); pc = 186; continue; }
case 186: { r[10] = r[6]; pc = 187; continue; }
case 187: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[10],new Value[]{r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19]}); pc = 188; continue; }
case 188: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HOOK:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[6]); pc = 189; continue; }
case 189: { r[7] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 190; continue; }
case 190: { r[8] = Value.ref("revanced_sb_segments_filler"); pc = 191; continue; }
case 191: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[8]}); pc = 192; continue; }
case 192: { r[14] = result; pc = 193; continue; }
case 193: { r[8] = Value.ref("revanced_sb_segments_filler_sum"); pc = 194; continue; }
case 194: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[8]}); pc = 195; continue; }
case 195: { r[15] = result; pc = 196; continue; }
case 196: { r[8] = Value.ref("revanced_sb_skip_button_filler"); pc = 197; continue; }
case 197: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[8]}); pc = 198; continue; }
case 198: { r[16] = result; pc = 199; continue; }
case 199: { r[8] = Value.ref("revanced_sb_skipped_filler"); pc = 200; continue; }
case 200: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[8]}); pc = 201; continue; }
case 201: { r[17] = result; pc = 202; continue; }
case 202: { r[18] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_FILLER:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 203; continue; }
case 203: { r[19] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_FILLER_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 204; continue; }
case 204: { r[11] = Value.ref("FILLER"); pc = 205; continue; }
case 205: { r[12] = Value.i32(8); pc = 206; continue; }
case 206: { r[13] = Value.ref("filler"); pc = 207; continue; }
case 207: { r[10] = r[7]; pc = 208; continue; }
case 208: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[10],new Value[]{r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19]}); pc = 209; continue; }
case 209: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->FILLER:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[7]); pc = 210; continue; }
case 210: { r[8] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 211; continue; }
case 211: { r[10] = Value.ref("revanced_sb_segments_nomusic"); pc = 212; continue; }
case 212: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[10]}); pc = 213; continue; }
case 213: { r[14] = result; pc = 214; continue; }
case 214: { r[10] = Value.ref("revanced_sb_segments_nomusic_sum"); pc = 215; continue; }
case 215: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[10]}); pc = 216; continue; }
case 216: { r[15] = result; pc = 217; continue; }
case 217: { r[10] = Value.ref("revanced_sb_skip_button_nomusic"); pc = 218; continue; }
case 218: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[10]}); pc = 219; continue; }
case 219: { r[16] = result; pc = 220; continue; }
case 220: { r[10] = Value.ref("revanced_sb_skipped_nomusic"); pc = 221; continue; }
case 221: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[10]}); pc = 222; continue; }
case 222: { r[17] = result; pc = 223; continue; }
case 223: { r[18] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_MUSIC_OFFTOPIC:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 224; continue; }
case 224: { r[19] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_MUSIC_OFFTOPIC_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 225; continue; }
case 225: { r[11] = Value.ref("MUSIC_OFFTOPIC"); pc = 226; continue; }
case 226: { r[12] = Value.i32(9); pc = 227; continue; }
case 227: { r[13] = Value.ref("music_offtopic"); pc = 228; continue; }
case 228: { r[10] = r[8]; pc = 229; continue; }
case 229: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[10],new Value[]{r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19]}); pc = 230; continue; }
case 230: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->MUSIC_OFFTOPIC:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[8]); pc = 231; continue; }
case 231: { r[10] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 232; continue; }
case 232: { r[14] = rt.readField("Lapp/revanced/extension/shared/StringRef;->empty:Lapp/revanced/extension/shared/StringRef;",Value.NULL,true); pc = 233; continue; }
case 233: { r[11] = Value.ref("revanced_sb_skip_button_unsubmitted"); pc = 234; continue; }
case 234: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[11]}); pc = 235; continue; }
case 235: { r[16] = result; pc = 236; continue; }
case 236: { r[11] = Value.ref("revanced_sb_skipped_unsubmitted"); pc = 237; continue; }
case 237: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[11]}); pc = 238; continue; }
case 238: { r[17] = result; pc = 239; continue; }
case 239: { r[18] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_UNSUBMITTED:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 240; continue; }
case 240: { r[19] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_UNSUBMITTED_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 241; continue; }
case 241: { r[11] = Value.ref("UNSUBMITTED"); pc = 242; continue; }
case 242: { r[12] = Value.i32(10); pc = 243; continue; }
case 243: { r[13] = Value.ref("unsubmitted"); pc = 244; continue; }
case 244: { r[15] = r[14]; pc = 245; continue; }
case 245: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[10],new Value[]{r[11], r[12], r[13], r[14], r[15], r[16], r[17], r[18], r[19]}); pc = 246; continue; }
case 246: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->UNSUBMITTED:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[10]); pc = 247; continue; }
case 247: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->$values()[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,new Value[]{}); pc = 248; continue; }
case 248: { r[10] = result; pc = 249; continue; }
case 249: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->$VALUES:[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[10]); pc = 250; continue; }
case 250: { r[10] = Value.ref("revanced_sb_skip_button_compact"); pc = 251; continue; }
case 251: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[10]}); pc = 252; continue; }
case 252: { r[10] = result; pc = 253; continue; }
case 253: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipSponsorTextCompact:Lapp/revanced/extension/shared/StringRef;",Value.NULL,true,r[10]); pc = 254; continue; }
case 254: { r[10] = Value.ref("revanced_sb_skip_button_compact_highlight"); pc = 255; continue; }
case 255: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;",Value.NULL,new Value[]{r[10]}); pc = 256; continue; }
case 256: { r[10] = result; pc = 257; continue; }
case 257: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipSponsorTextCompactHighlight:Lapp/revanced/extension/shared/StringRef;",Value.NULL,true,r[10]); pc = 258; continue; }
case 258: { result=rt.filledArray("[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8]}); pc = 259; continue; }
case 259: { r[10] = result; pc = 260; continue; }
case 260: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->categoriesWithoutHighlights:[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[10]); pc = 261; continue; }
case 261: { r[24] = r[4]; pc = 262; continue; }
case 262: { r[4] = r[3]; pc = 263; continue; }
case 263: { r[3] = r[9]; pc = 264; continue; }
case 264: { r[9] = r[8]; pc = 265; continue; }
case 265: { r[8] = r[7]; pc = 266; continue; }
case 266: { r[7] = r[6]; pc = 267; continue; }
case 267: { r[6] = r[5]; pc = 268; continue; }
case 268: { r[5] = r[24]; pc = 269; continue; }
case 269: { result=rt.filledArray("[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]}); pc = 270; continue; }
case 270: { r[0] = result; pc = 271; continue; }
case 271: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->categoriesWithoutUnsubmitted:[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true,r[0]); pc = 272; continue; }
case 272: { r[1] = rt.allocate("Ljava/util/HashMap;"); pc = 273; continue; }
case 273: { r[2] = Value.i32(rt.length(r[0])); pc = 274; continue; }
case 274: { r[2] = Value.i32((r[2].i()) * (2)); pc = 275; continue; }
case 275: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/HashMap;-><init>(I)V",r[1],new Value[]{r[2]}); pc = 276; continue; }
case 276: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->mValuesMap:Ljava/util/Map;",Value.NULL,true,r[1]); pc = 277; continue; }
case 277: { r[1] = Value.ref("[]"); pc = 278; continue; }
case 278: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->sponsorBlockAPIFetchCategories:Ljava/lang/String;",Value.NULL,true,r[1]); pc = 279; continue; }
case 279: { r[1] = Value.i32(rt.length(r[0])); pc = 280; continue; }
case 280: { r[2] = Value.i32(0); pc = 281; continue; }
case 281: { pc=(r[2].i() >= r[1].i())?288:282; continue; }
case 282: { r[3] = rt.arrayGet(r[0],r[2].i()); pc = 283; continue; }
case 283: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->mValuesMap:Ljava/util/Map;",Value.NULL,true); pc = 284; continue; }
case 284: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->keyValue:Ljava/lang/String;",r[3],false); pc = 285; continue; }
case 285: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",r[4],new Value[]{r[5], r[3]}); pc = 286; continue; }
case 286: { r[2] = Value.i32((r[2].i()) + (1)); pc = 287; continue; }
case 287: { pc=281; continue; }
case 288: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_246bdde157eed01c26071b22(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 9) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[24];
r[14] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;");
r[15] = rt.check(arguments[0], "Ljava/lang/String;");
r[16] = rt.check(arguments[1], "I");
r[17] = rt.check(arguments[2], "Ljava/lang/String;");
r[18] = rt.check(arguments[3], "Lapp/revanced/extension/shared/StringRef;");
r[19] = rt.check(arguments[4], "Lapp/revanced/extension/shared/StringRef;");
r[20] = rt.check(arguments[5], "Lapp/revanced/extension/shared/StringRef;");
r[21] = rt.check(arguments[6], "Lapp/revanced/extension/shared/StringRef;");
r[22] = rt.check(arguments[7], "Lapp/revanced/extension/shared/settings/StringSetting;");
r[23] = rt.check(arguments[8], "Lapp/revanced/extension/shared/settings/StringSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[7] = r[20]; pc = 1; continue; }
case 1: { r[8] = r[20]; pc = 2; continue; }
case 2: { r[10] = r[21]; pc = 3; continue; }
case 3: { r[11] = r[21]; pc = 4; continue; }
case 4: { r[0] = r[14]; pc = 5; continue; }
case 5: { r[1] = r[15]; pc = 6; continue; }
case 6: { r[2] = r[16]; pc = 7; continue; }
case 7: { r[3] = r[17]; pc = 8; continue; }
case 8: { r[4] = r[18]; pc = 9; continue; }
case 9: { r[5] = r[19]; pc = 10; continue; }
case 10: { r[6] = r[20]; pc = 11; continue; }
case 11: { r[9] = r[21]; pc = 12; continue; }
case 12: { r[12] = r[22]; pc = 13; continue; }
case 13: { r[13] = r[23]; pc = 14; continue; }
case 14: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;-><init>(Ljava/lang/String;ILjava/lang/String;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/StringRef;Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/StringSetting;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11], r[12], r[13]}); pc = 15; continue; }
case 15: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_413954508bb9dabc0db20152(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 13) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[14];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Ljava/lang/String;");
r[4] = rt.check(arguments[3], "Lapp/revanced/extension/shared/StringRef;");
r[5] = rt.check(arguments[4], "Lapp/revanced/extension/shared/StringRef;");
r[6] = rt.check(arguments[5], "Lapp/revanced/extension/shared/StringRef;");
r[7] = rt.check(arguments[6], "Lapp/revanced/extension/shared/StringRef;");
r[8] = rt.check(arguments[7], "Lapp/revanced/extension/shared/StringRef;");
r[9] = rt.check(arguments[8], "Lapp/revanced/extension/shared/StringRef;");
r[10] = rt.check(arguments[9], "Lapp/revanced/extension/shared/StringRef;");
r[11] = rt.check(arguments[10], "Lapp/revanced/extension/shared/StringRef;");
r[12] = rt.check(arguments[11], "Lapp/revanced/extension/shared/settings/StringSetting;");
r[13] = rt.check(arguments[12], "Lapp/revanced/extension/shared/settings/StringSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->IGNORE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",Value.NULL,true); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviour:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",r[0],false,r[1]); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[3]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->keyValue:Ljava/lang/String;",r[0],false,r[3]); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[4]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->title:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[4]); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[5]}); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->description:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[5]); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[6]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipButtonTextBeginning:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[6]); pc = 11; continue; }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[7]}); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipButtonTextMiddle:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[7]); pc = 13; continue; }
case 13: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[8]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipButtonTextEnd:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[8]); pc = 15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[9]}); pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skippedToastBeginning:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[9]); pc = 17; continue; }
case 17: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[10]}); pc = 18; continue; }
case 18: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skippedToastMiddle:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[10]); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[11]}); pc = 20; continue; }
case 20: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skippedToastEnd:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[11]); pc = 21; continue; }
case 21: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[12]}); pc = 22; continue; }
case 22: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviorSetting:Lapp/revanced/extension/shared/settings/StringSetting;",r[0],false,r[12]); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[13]}); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->colorSetting:Lapp/revanced/extension/shared/settings/StringSetting;",r[0],false,r[13]); pc = 25; continue; }
case 25: { r[1] = rt.allocate("Landroid/graphics/Paint;"); pc = 26; continue; }
case 26: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Landroid/graphics/Paint;-><init>()V",r[1],new Value[]{}); pc = 27; continue; }
case 27: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->paint:Landroid/graphics/Paint;",r[0],false,r[1]); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->loadFromSettings()V",r[0],new Value[]{}); pc = 29; continue; }
case 29: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9bb72c88e2b36c8d9046e80a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[11];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->SPONSOR:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->SELF_PROMO:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->INTERACTION:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->INTRO:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->OUTRO:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 6; continue; }
case 6: { r[6] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->PREVIEW:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 7; continue; }
case 7: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HOOK:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 8; continue; }
case 8: { r[8] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->FILLER:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 9; continue; }
case 9: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->MUSIC_OFFTOPIC:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 10; continue; }
case 10: { r[10] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->UNSUBMITTED:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 11; continue; }
case 11: { result=rt.filledArray("[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10]}); pc = 12; continue; }
case 12: { r[0] = result; pc = 13; continue; }
case 13: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_40109eb5b4a22032a53c363d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda2;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda2;-><init>()V",r[0],new Value[]{}); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->categoriesWithoutUnsubmitted()[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,new Value[]{}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { r[1] = rt.allocate("Ljava/util/ArrayList;"); pc = 7; continue; }
case 7: { r[2] = Value.i32(rt.length(r[0])); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/ArrayList;-><init>(I)V",r[1],new Value[]{r[2]}); pc = 9; continue; }
case 9: { r[2] = Value.i32(rt.length(r[0])); pc = 10; continue; }
case 10: { r[3] = Value.i32(0); pc = 11; continue; }
case 11: { pc=(r[3].i() >= r[2].i())?20:12; continue; }
case 12: { r[4] = rt.arrayGet(r[0],r[3].i()); pc = 13; continue; }
case 13: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviour:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",r[4],false); pc = 14; continue; }
case 14: { r[6] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->IGNORE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",Value.NULL,true); pc = 15; continue; }
case 15: { pc=(ExecutableRuntime.equal(r[5],r[6]))?18:16; continue; }
case 16: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->keyValue:Ljava/lang/String;",r[4],false); pc = 17; continue; }
case 17: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/List;->add(Ljava/lang/Object;)Z",r[1],new Value[]{r[4]}); pc = 18; continue; }
case 18: { r[3] = Value.i32((r[3].i()) + (1)); pc = 19; continue; }
case 19: { pc=11; continue; }
case 20: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/List;->isEmpty()Z",r[1],new Value[]{}); pc = 21; continue; }
case 21: { r[0] = result; pc = 22; continue; }
case 22: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?26:23; continue; }
case 23: { r[0] = Value.ref("[]"); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->sponsorBlockAPIFetchCategories:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 25; continue; }
case 25: { return Value.VOID; }
case 26: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 27; continue; }
case 27: { r[2] = Value.ref("[%22"); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[2]}); pc = 29; continue; }
case 29: { r[2] = Value.ref("%22,%22"); pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;",Value.NULL,new Value[]{r[2], r[1]}); pc = 31; continue; }
case 31: { r[1] = result; pc = 32; continue; }
case 32: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 33; continue; }
case 33: { r[1] = Value.ref("%22]"); pc = 34; continue; }
case 34: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 35; continue; }
case 35: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 36; continue; }
case 36: { r[0] = result; pc = 37; continue; }
case 37: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->sponsorBlockAPIFetchCategories:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 38; continue; }
case 38: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_383a548b22f203a6218f1a0a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviorSetting:Lapp/revanced/extension/shared/settings/StringSetting;",r[3],false); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->byReVancedKeyValue(Ljava/lang/String;)Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",Value.NULL,new Value[]{r[0]}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?13:6; continue; }
case 6: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda0;"); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[0]}); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 9; continue; }
case 9: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviorSetting:Lapp/revanced/extension/shared/settings/StringSetting;",r[3],false); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/settings/StringSetting;->resetToDefault()Ljava/lang/Object;",r[0],new Value[]{}); pc = 11; continue; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->loadFromSettings()V",r[3],new Value[]{}); pc = 12; continue; }
case 12: { return Value.VOID; }
case 13: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviour:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",r[3],false,r[1]); pc = 14; continue; }
case 14: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->colorSetting:Lapp/revanced/extension/shared/settings/StringSetting;",r[3],false); pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;",r[0],new Value[]{}); pc = 16; continue; }
case 16: { r[0] = result; pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->setColorWithOpacity(Ljava/lang/String;)V",r[3],new Value[]{r[0]}); pc = 18; continue; }
case 18: { return Value.VOID; }
case 19: { r[1] = Value.ref(exception); exception=null; pc = 20; continue; }
case 20: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda1;"); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 22; continue; }
case 22: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[2], r[1]}); pc = 23; continue; }
case 23: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->colorSetting:Lapp/revanced/extension/shared/settings/StringSetting;",r[3],false); pc = 24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/settings/StringSetting;->resetToDefault()Ljava/lang/Object;",r[0],new Value[]{}); pc = 25; continue; }
case 25: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->loadFromSettings()V",r[3],new Value[]{}); pc = 26; continue; }
case 26: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 17 && pc < 18) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=19; continue; } }
throw error;
}
}

}

static Value m_e5c529d5fefe69098f67f3c0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->categoriesWithoutUnsubmitted:[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_39abcaca48e93a55d9b75ddd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[4] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;");
r[5] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I",Value.NULL,new Value[]{r[5]}); pc = 1; continue; }
case 1: { r[5] = result; pc = 2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->colorSetting:Lapp/revanced/extension/shared/settings/StringSetting;",r[4],false); pc = 3; continue; }
case 3: { r[1] = rt.readField("Ljava/util/Locale;->US:Ljava/util/Locale;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[5]}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { result=rt.filledArray("[Ljava/lang/Object;",new Value[]{r[2]}); pc = 7; continue; }
case 7: { r[2] = result; pc = 8; continue; }
case 8: { r[3] = Value.ref("#%08X"); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[1], r[3], r[2]}); pc = 10; continue; }
case 10: { r[1] = result; pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/settings/StringSetting;->save(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->color:I",r[4],false,r[5]); pc = 13; continue; }
case 13: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->paint:Landroid/graphics/Paint;",r[4],false); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Landroid/graphics/Paint;->setColor(I)V",r[0],new Value[]{r[5]}); pc = 15; continue; }
case 15: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7b1b2b5cdce522b697bdcf67(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("updateEnabledCategories"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e9c0988ec650522ffa9563be(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Invalid color: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cc49de72caeb56d90b50a6c3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Invalid behavior: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f1834e0e33c7536748f9ceb8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;");
r[3] = rt.check(arguments[0], "J"); r[4] = r[3];
r[5] = rt.check(arguments[1], "J"); r[6] = r[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_COMPACT_SKIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?12:6; continue; }
case 6: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 7; continue; }
case 7: { pc=(!ExecutableRuntime.equal(r[2],r[3]))?10:8; continue; }
case 8: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipSponsorTextCompactHighlight:Lapp/revanced/extension/shared/StringRef;",Value.NULL,true); pc = 9; continue; }
case 9: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
case 10: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipSponsorTextCompact:Lapp/revanced/extension/shared/StringRef;",Value.NULL,true); pc = 11; continue; }
case 11: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
case 12: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 13; continue; }
case 13: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[5].j(), r[0].j())); pc = 14; continue; }
case 14: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?17:15; continue; }
case 15: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipButtonTextBeginning:Lapp/revanced/extension/shared/StringRef;",r[2],false); pc = 16; continue; }
case 16: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
case 17: { r[3] = Value.f32((float)(r[3].j())); pc = 18; continue; }
case 18: { r[4] = Value.f32((float)(r[5].j())); pc = 19; continue; }
case 19: { r[3] = Value.f32((r[3].f()) / (r[4].f())); pc = 20; continue; }
case 20: { r[4] = Value.i32(1048576000); pc = 21; continue; }
case 21: { r[4] = Value.i32(ExecutableRuntime.compareFloat(r[3].f(), r[4].f(), 1)); pc = 22; continue; }
case 22: { pc=(r[4].i() >= 0)?25:23; continue; }
case 23: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipButtonTextBeginning:Lapp/revanced/extension/shared/StringRef;",r[2],false); pc = 24; continue; }
case 24: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
case 25: { r[4] = Value.i32(1061158912); pc = 26; continue; }
case 26: { r[3] = Value.i32(ExecutableRuntime.compareFloat(r[3].f(), r[4].f(), 1)); pc = 27; continue; }
case 27: { pc=(r[3].i() >= 0)?30:28; continue; }
case 28: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipButtonTextMiddle:Lapp/revanced/extension/shared/StringRef;",r[2],false); pc = 29; continue; }
case 29: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
case 30: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skipButtonTextEnd:Lapp/revanced/extension/shared/StringRef;",r[2],false); pc = 31; continue; }
case 31: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7a803a0bc1bf2c19f9099666(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;");
r[3] = rt.check(arguments[0], "J"); r[4] = r[3];
r[5] = rt.check(arguments[1], "J"); r[6] = r[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 1; continue; }
case 1: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[5].j(), r[0].j())); pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?5:3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skippedToastBeginning:Lapp/revanced/extension/shared/StringRef;",r[2],false); pc = 4; continue; }
case 4: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
case 5: { r[3] = Value.f32((float)(r[3].j())); pc = 6; continue; }
case 6: { r[4] = Value.f32((float)(r[5].j())); pc = 7; continue; }
case 7: { r[3] = Value.f32((r[3].f()) / (r[4].f())); pc = 8; continue; }
case 8: { r[4] = Value.i32(1048576000); pc = 9; continue; }
case 9: { r[4] = Value.i32(ExecutableRuntime.compareFloat(r[3].f(), r[4].f(), 1)); pc = 10; continue; }
case 10: { pc=(r[4].i() >= 0)?13:11; continue; }
case 11: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skippedToastBeginning:Lapp/revanced/extension/shared/StringRef;",r[2],false); pc = 12; continue; }
case 12: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
case 13: { r[4] = Value.i32(1061158912); pc = 14; continue; }
case 14: { r[3] = Value.i32(ExecutableRuntime.compareFloat(r[3].f(), r[4].f(), 1)); pc = 15; continue; }
case 15: { pc=(r[3].i() >= 0)?18:16; continue; }
case 16: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skippedToastMiddle:Lapp/revanced/extension/shared/StringRef;",r[2],false); pc = 17; continue; }
case 17: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
case 18: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->skippedToastEnd:Lapp/revanced/extension/shared/StringRef;",r[2],false); pc = 19; continue; }
case 19: { return rt.check(r[3],"Lapp/revanced/extension/shared/StringRef;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fa4199a31cb56850f861b82b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->mValuesMap:Ljava/util/Map;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;","Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); pc = 4; continue; }
case 4: { return rt.check(r[1],"Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
