package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_e5e8adc2cba94d2c extends RuntimeForeign.SourceProxy {
Source_e5e8adc2cba94d2c(RuntimeForeign owner,Instance source){super(owner,source);}

}
