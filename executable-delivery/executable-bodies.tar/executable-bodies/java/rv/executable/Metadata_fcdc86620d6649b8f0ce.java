package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_fcdc86620d6649b8f0ce {
static ClassInfo info_fcdc86620d6649b8f0ce() {return new ClassInfo("Lapp/revanced/extension/shared/Logger$1;", "Ljava/lang/Object;", new String[]{}, 4096, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Logger$1;->$SwitchMap$app$revanced$extension$shared$Logger$LogLevel:[I", "[I", 4120, ExecutableRuntime.zero("[I"))}, new MethodInfo[]{new MethodInfo("<clinit>()V", 65544)}, "");}
}
