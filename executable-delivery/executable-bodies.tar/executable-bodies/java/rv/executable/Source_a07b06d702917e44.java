package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_a07b06d702917e44 extends RuntimeForeign.SourceProxy {
Source_a07b06d702917e44(RuntimeForeign owner,Instance source){super(owner,source);}

}
