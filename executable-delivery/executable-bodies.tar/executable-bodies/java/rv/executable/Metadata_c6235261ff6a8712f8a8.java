package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_c6235261ff6a8712f8a8 {
static ClassInfo info_c6235261ff6a8712f8a8() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideSubtextsAvailability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
