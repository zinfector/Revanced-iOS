package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_6ea2e06564ab182f extends RuntimeForeign.SourceProxy implements java.util.Iterator {
Source_6ea2e06564ab182f(RuntimeForeign owner,Instance source){super(owner,source);}
public boolean hasNext() {Value result=owner.callback(source,"Ljava/util/Iterator;->hasNext()Z",new Value[]{}); return result.z();}
public java.lang.Object next() {Value result=owner.callback(source,"Ljava/util/Iterator;->next()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public void remove() {Value result=owner.callback(source,"Ljava/util/Iterator;->remove()V",new Value[]{}); return;}
}
