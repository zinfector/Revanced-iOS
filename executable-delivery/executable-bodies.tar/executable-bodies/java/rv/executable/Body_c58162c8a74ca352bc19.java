package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_c58162c8a74ca352bc19 {
static Value m_3985cbf57e3057254bb48dc1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils-IA;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7a2f55c9788b3a411c27169b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;","Ljava/lang/Object;-><init>()V",r[2],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;->editTextRef:Ljava/lang/ref/WeakReference;",r[2],false,r[0]); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
