package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_661148493da5bfdbf78e {
static ClassInfo info_661148493da5bfdbf78e() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda22;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda22");}
}
