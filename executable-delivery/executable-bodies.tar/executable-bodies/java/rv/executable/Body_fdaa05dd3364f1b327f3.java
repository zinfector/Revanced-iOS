package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_fdaa05dd3364f1b327f3 {
static Value m_2aa5e2b52fd903f7a3479327(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/ui/Dim;","Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->METRICS:Landroid/util/DisplayMetrics;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Landroid/util/DisplayMetrics;->widthPixels:I",r[0],false); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->SCREEN_WIDTH:I",Value.NULL,true,r[1]); pc = 7; continue; }
case 7: { r[0] = rt.readField("Landroid/util/DisplayMetrics;->heightPixels:I",r[0],false); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->SCREEN_HEIGHT:I",Value.NULL,true,r[0]); pc = 9; continue; }
case 9: { r[0] = Value.i32(1065353216); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp1:I",Value.NULL,true,r[0]); pc = 13; continue; }
case 13: { r[0] = Value.i32(1073741824); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 15; continue; }
case 15: { r[0] = result; pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp2:I",Value.NULL,true,r[0]); pc = 17; continue; }
case 17: { r[0] = Value.i32(1082130432); pc = 18; continue; }
case 18: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 19; continue; }
case 19: { r[0] = result; pc = 20; continue; }
case 20: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp4:I",Value.NULL,true,r[0]); pc = 21; continue; }
case 21: { r[0] = Value.i32(1086324736); pc = 22; continue; }
case 22: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 23; continue; }
case 23: { r[0] = result; pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp6:I",Value.NULL,true,r[0]); pc = 25; continue; }
case 25: { r[0] = Value.i32(1088421888); pc = 26; continue; }
case 26: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 27; continue; }
case 27: { r[0] = result; pc = 28; continue; }
case 28: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp7:I",Value.NULL,true,r[0]); pc = 29; continue; }
case 29: { r[0] = Value.i32(1090519040); pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 31; continue; }
case 31: { r[0] = result; pc = 32; continue; }
case 32: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp8:I",Value.NULL,true,r[0]); pc = 33; continue; }
case 33: { r[0] = Value.i32(1092616192); pc = 34; continue; }
case 34: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 35; continue; }
case 35: { r[0] = result; pc = 36; continue; }
case 36: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp10:I",Value.NULL,true,r[0]); pc = 37; continue; }
case 37: { r[0] = Value.i32(1094713344); pc = 38; continue; }
case 38: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 39; continue; }
case 39: { r[0] = result; pc = 40; continue; }
case 40: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp12:I",Value.NULL,true,r[0]); pc = 41; continue; }
case 41: { r[0] = Value.i32(1098907648); pc = 42; continue; }
case 42: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 43; continue; }
case 43: { r[0] = result; pc = 44; continue; }
case 44: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp16:I",Value.NULL,true,r[0]); pc = 45; continue; }
case 45: { r[0] = Value.i32(1101004800); pc = 46; continue; }
case 46: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 47; continue; }
case 47: { r[0] = result; pc = 48; continue; }
case 48: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp20:I",Value.NULL,true,r[0]); pc = 49; continue; }
case 49: { r[0] = Value.i32(1103101952); pc = 50; continue; }
case 50: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 51; continue; }
case 51: { r[0] = result; pc = 52; continue; }
case 52: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp24:I",Value.NULL,true,r[0]); pc = 53; continue; }
case 53: { r[0] = Value.i32(1105199104); pc = 54; continue; }
case 54: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 55; continue; }
case 55: { r[0] = result; pc = 56; continue; }
case 56: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp28:I",Value.NULL,true,r[0]); pc = 57; continue; }
case 57: { r[0] = Value.i32(1107296256); pc = 58; continue; }
case 58: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 59; continue; }
case 59: { r[0] = result; pc = 60; continue; }
case 60: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp32:I",Value.NULL,true,r[0]); pc = 61; continue; }
case 61: { r[0] = Value.i32(1108344832); pc = 62; continue; }
case 62: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 63; continue; }
case 63: { r[0] = result; pc = 64; continue; }
case 64: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp36:I",Value.NULL,true,r[0]); pc = 65; continue; }
case 65: { r[0] = Value.i32(1109393408); pc = 66; continue; }
case 66: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 67; continue; }
case 67: { r[0] = result; pc = 68; continue; }
case 68: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp40:I",Value.NULL,true,r[0]); pc = 69; continue; }
case 69: { r[0] = Value.i32(1111490560); pc = 70; continue; }
case 70: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[0]}); pc = 71; continue; }
case 71: { r[0] = result; pc = 72; continue; }
case 72: { rt.writeField("Lapp/revanced/extension/shared/ui/Dim;->dp48:I",Value.NULL,true,r[0]); pc = 73; continue; }
case 73: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_442dd6d7570dbb28039d16cf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(1); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->METRICS:Landroid/util/DisplayMetrics;",Value.NULL,true); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F",Value.NULL,new Value[]{r[0], r[2], r[1]}); pc = 3; continue; }
case 3: { r[2] = result; pc = 4; continue; }
case 4: { r[2] = Value.i32((int)(r[2].f())); pc = 5; continue; }
case 5: { return rt.check(r[2],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9cee2a9222b226f246bbe5e0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[2]}); pc = 1; continue; }
case 1: { r[2] = result; pc = 2; continue; }
case 2: { r[2] = Value.f32((float)(r[2].i())); pc = 3; continue; }
case 3: { r[0] = Value.i32(8); pc = 4; continue; }
case 4: { r[0] = rt.newArray("[F",r[0].i()); pc = 5; continue; }
case 5: { r[1] = Value.i32(0); pc = 6; continue; }
case 6: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 7; continue; }
case 7: { r[1] = Value.i32(1); pc = 8; continue; }
case 8: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 9; continue; }
case 9: { r[1] = Value.i32(2); pc = 10; continue; }
case 10: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 11; continue; }
case 11: { r[1] = Value.i32(3); pc = 12; continue; }
case 12: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 13; continue; }
case 13: { r[1] = Value.i32(4); pc = 14; continue; }
case 14: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 15; continue; }
case 15: { r[1] = Value.i32(5); pc = 16; continue; }
case 16: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 17; continue; }
case 17: { r[1] = Value.i32(6); pc = 18; continue; }
case 18: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 19; continue; }
case 19: { r[1] = Value.i32(7); pc = 20; continue; }
case 20: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 21; continue; }
case 21: { return rt.check(r[0],"[F"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b78cad86578845b7ae39f936(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->SCREEN_WIDTH:I",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->SCREEN_HEIGHT:I",Value.NULL,true); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/ui/Dim;","Ljava/lang/Math;->min(II)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[0] = Value.f32((float)(r[0].i())); pc = 5; continue; }
case 5: { r[2] = Value.f32((float)(r[2].i())); pc = 6; continue; }
case 6: { r[1] = Value.i32(1120403456); pc = 7; continue; }
case 7: { r[2] = Value.f32((r[2].f()) / (r[1].f())); pc = 8; continue; }
case 8: { r[0] = Value.f32((r[0].f()) * (r[2].f())); pc = 9; continue; }
case 9: { r[2] = Value.i32((int)(r[0].f())); pc = 10; continue; }
case 10: { return rt.check(r[2],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
