package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_d90a50d3fc476f348f8d {
static Value m_ef6c964cdf661b97f2ab644a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoAdsPatch;->SHOW_VIDEO_ADS:Z", Value.NULL, true); pc = 1; continue; }
case 1: { return rt.check(r[0], "Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9de03b18d12e068fa3774d01(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_VIDEO_ADS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true); pc = 1; continue; }
case 1: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/patches/VideoAdsPatch;", "Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;", r[0], new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/patches/VideoAdsPatch;", "Ljava/lang/Boolean;->booleanValue()Z", r[0], new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[0] = Value.i32((r[0].i()) ^ (1)); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoAdsPatch;->SHOW_VIDEO_ADS:Z", Value.NULL, true, r[0]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
