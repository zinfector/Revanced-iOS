package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_6b11fb290c93eaba128b {
static Value m_468bebed00f20df235620cc5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->$VALUES:[Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Ljava/lang/Object;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9ac6d986946cef412f00094d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->Companion:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion;->setFromString(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4838e5efd0e7e4ace0652e4d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("PLAYER_CONTROLS_VISIBILITY_UNKNOWN"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_UNKNOWN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("PLAYER_CONTROLS_VISIBILITY_WILL_HIDE"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_WILL_HIDE:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("PLAYER_CONTROLS_VISIBILITY_HIDDEN"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_HIDDEN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true,r[0]); pc = 15; continue; }
case 15: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); pc = 16; continue; }
case 16: { r[1] = Value.ref("PLAYER_CONTROLS_VISIBILITY_WILL_SHOW"); pc = 17; continue; }
case 17: { r[2] = Value.i32(3); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_WILL_SHOW:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true,r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); pc = 21; continue; }
case 21: { r[1] = Value.ref("PLAYER_CONTROLS_VISIBILITY_SHOWN"); pc = 22; continue; }
case 22: { r[2] = Value.i32(4); pc = 23; continue; }
case 23: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_SHOWN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true,r[0]); pc = 25; continue; }
case 25: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->$values()[Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,new Value[]{}); pc = 26; continue; }
case 26: { r[0] = result; pc = 27; continue; }
case 27: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->$VALUES:[Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true,r[0]); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;",Value.NULL,new Value[]{r[0]}); pc = 29; continue; }
case 29: { r[0] = result; pc = 30; continue; }
case 30: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->$ENTRIES:Lkotlin/enums/EnumEntries;",Value.NULL,true,r[0]); pc = 31; continue; }
case 31: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion;"); pc = 32; continue; }
case 32: { r[1] = Value.i32(0); pc = 33; continue; }
case 33: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V",r[0],new Value[]{r[1]}); pc = 34; continue; }
case 34: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->Companion:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion;",Value.NULL,true,r[0]); pc = 35; continue; }
case 35: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->getEntries()Lkotlin/enums/EnumEntries;",Value.NULL,new Value[]{}); pc = 36; continue; }
case 36: { r[0] = result; pc = 37; continue; }
case 37: { r[1] = Value.i32(10); pc = 38; continue; }
case 38: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 39; continue; }
case 39: { r[1] = result; pc = 40; continue; }
case 40: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lkotlin/collections/MapsKt__MapsJVMKt;->mapCapacity(I)I",Value.NULL,new Value[]{r[1]}); pc = 41; continue; }
case 41: { r[1] = result; pc = 42; continue; }
case 42: { r[2] = Value.i32(16); pc = 43; continue; }
case 43: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lkotlin/ranges/RangesKt___RangesKt;->coerceAtLeast(II)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 44; continue; }
case 44: { r[1] = result; pc = 45; continue; }
case 45: { r[2] = rt.allocate("Ljava/util/LinkedHashMap;"); pc = 46; continue; }
case 46: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Ljava/util/LinkedHashMap;-><init>(I)V",r[2],new Value[]{r[1]}); pc = 47; continue; }
case 47: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;",r[0],new Value[]{}); pc = 48; continue; }
case 48: { r[0] = result; pc = 49; continue; }
case 49: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Ljava/util/Iterator;->hasNext()Z",r[0],new Value[]{}); pc = 50; continue; }
case 50: { r[1] = result; pc = 51; continue; }
case 51: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?60:52; continue; }
case 52: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[0],new Value[]{}); pc = 53; continue; }
case 53: { r[1] = result; pc = 54; continue; }
case 54: { r[3] = r[1]; pc = 55; continue; }
case 55: { r[3] = rt.cast(r[3],"Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); pc = 56; continue; }
case 56: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Ljava/lang/Enum;->name()Ljava/lang/String;",r[3],new Value[]{}); pc = 57; continue; }
case 57: { r[3] = result; pc = 58; continue; }
case 58: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",r[2],new Value[]{r[3], r[1]}); pc = 59; continue; }
case 59: { pc=49; continue; }
case 60: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->nameToPlayerControlsVisibility:Ljava/util/Map;",Value.NULL,true,r[2]); pc = 61; continue; }
case 61: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_UNKNOWN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 62; continue; }
case 62: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->currentPlayerControlsVisibility:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true,r[0]); pc = 63; continue; }
case 63: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/Event;"); pc = 64; continue; }
case 64: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/Event;-><init>()V",r[0],new Value[]{}); pc = 65; continue; }
case 65: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->onChange:Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,true,r[0]); pc = 66; continue; }
case 66: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_67f3716b4a7fd999755ef47a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->Companion:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility$Companion;->getCurrent()Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7e44c038c4a1b0a4137d0e3e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_84c6595e4baff4d51c5f29a9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_UNKNOWN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_WILL_HIDE:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_HIDDEN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_WILL_SHOW:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_SHOWN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 5; continue; }
case 5: { result=rt.filledArray("[Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",new Value[]{r[0], r[1], r[2], r[3], r[4]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1e7ad84418d878a4b529abef(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->$ENTRIES:Lkotlin/enums/EnumEntries;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lkotlin/enums/EnumEntries;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9ec229778c04692c2d77c434(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->nameToPlayerControlsVisibility:Ljava/util/Map;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/util/Map;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2972b8e9a33e3984a7269d99(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->currentPlayerControlsVisibility:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3c978428f97339c2d3d2edaa(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->currentPlayerControlsVisibility:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true,r[0]); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5208a03dd71e5320553ee8f6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->onChange:Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/Event;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
