package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_30b7a0d747f1430f72fe {
static Value m_5bcc8d3797e59842bd326a82(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("anim"); pc = 2; continue; }
case 2: { r[2] = Value.ref("ANIM"); pc = 3; continue; }
case 3: { r[3] = Value.i32(0); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[2], r[3], r[1]}); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->ANIM:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 6; continue; }
case 6: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 7; continue; }
case 7: { r[1] = Value.i32(1); pc = 8; continue; }
case 8: { r[2] = Value.ref("animator"); pc = 9; continue; }
case 9: { r[4] = Value.ref("ANIMATOR"); pc = 10; continue; }
case 10: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[4], r[1], r[2]}); pc = 11; continue; }
case 11: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->ANIMATOR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 12; continue; }
case 12: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 13; continue; }
case 13: { r[1] = Value.ref("array"); pc = 14; continue; }
case 14: { r[2] = Value.ref("ARRAY"); pc = 15; continue; }
case 15: { r[4] = Value.i32(2); pc = 16; continue; }
case 16: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[2], r[4], r[1]}); pc = 17; continue; }
case 17: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->ARRAY:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 18; continue; }
case 18: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 19; continue; }
case 19: { r[1] = Value.i32(3); pc = 20; continue; }
case 20: { r[2] = Value.ref("attr"); pc = 21; continue; }
case 21: { r[5] = Value.ref("ATTR"); pc = 22; continue; }
case 22: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 23; continue; }
case 23: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->ATTR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 24; continue; }
case 24: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 25; continue; }
case 25: { r[1] = Value.i32(4); pc = 26; continue; }
case 26: { r[2] = Value.ref("bool"); pc = 27; continue; }
case 27: { r[5] = Value.ref("BOOL"); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->BOOL:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 30; continue; }
case 30: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 31; continue; }
case 31: { r[1] = Value.i32(5); pc = 32; continue; }
case 32: { r[2] = Value.ref("color"); pc = 33; continue; }
case 33: { r[5] = Value.ref("COLOR"); pc = 34; continue; }
case 34: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 35; continue; }
case 35: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->COLOR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 36; continue; }
case 36: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 37; continue; }
case 37: { r[1] = Value.i32(6); pc = 38; continue; }
case 38: { r[2] = Value.ref("dimen"); pc = 39; continue; }
case 39: { r[5] = Value.ref("DIMEN"); pc = 40; continue; }
case 40: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 41; continue; }
case 41: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->DIMEN:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 42; continue; }
case 42: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 43; continue; }
case 43: { r[1] = Value.i32(7); pc = 44; continue; }
case 44: { r[2] = Value.ref("drawable"); pc = 45; continue; }
case 45: { r[5] = Value.ref("DRAWABLE"); pc = 46; continue; }
case 46: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 47; continue; }
case 47: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->DRAWABLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 48; continue; }
case 48: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 49; continue; }
case 49: { r[1] = Value.i32(8); pc = 50; continue; }
case 50: { r[2] = Value.ref("font"); pc = 51; continue; }
case 51: { r[5] = Value.ref("FONT"); pc = 52; continue; }
case 52: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 53; continue; }
case 53: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->FONT:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 54; continue; }
case 54: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 55; continue; }
case 55: { r[1] = Value.i32(9); pc = 56; continue; }
case 56: { r[2] = Value.ref("fraction"); pc = 57; continue; }
case 57: { r[5] = Value.ref("FRACTION"); pc = 58; continue; }
case 58: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 59; continue; }
case 59: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->FRACTION:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 60; continue; }
case 60: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 61; continue; }
case 61: { r[1] = Value.i32(10); pc = 62; continue; }
case 62: { r[2] = Value.ref("id"); pc = 63; continue; }
case 63: { r[5] = Value.ref("ID"); pc = 64; continue; }
case 64: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 65; continue; }
case 65: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->ID:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 66; continue; }
case 66: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 67; continue; }
case 67: { r[1] = Value.i32(11); pc = 68; continue; }
case 68: { r[2] = Value.ref("integer"); pc = 69; continue; }
case 69: { r[5] = Value.ref("INTEGER"); pc = 70; continue; }
case 70: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 71; continue; }
case 71: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->INTEGER:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 72; continue; }
case 72: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 73; continue; }
case 73: { r[1] = Value.i32(12); pc = 74; continue; }
case 74: { r[2] = Value.ref("interpolator"); pc = 75; continue; }
case 75: { r[5] = Value.ref("INTERPOLATOR"); pc = 76; continue; }
case 76: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 77; continue; }
case 77: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->INTERPOLATOR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 78; continue; }
case 78: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 79; continue; }
case 79: { r[1] = Value.i32(13); pc = 80; continue; }
case 80: { r[2] = Value.ref("layout"); pc = 81; continue; }
case 81: { r[5] = Value.ref("LAYOUT"); pc = 82; continue; }
case 82: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 83; continue; }
case 83: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->LAYOUT:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 84; continue; }
case 84: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 85; continue; }
case 85: { r[1] = Value.i32(14); pc = 86; continue; }
case 86: { r[2] = Value.ref("menu"); pc = 87; continue; }
case 87: { r[5] = Value.ref("MENU"); pc = 88; continue; }
case 88: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 89; continue; }
case 89: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->MENU:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 90; continue; }
case 90: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 91; continue; }
case 91: { r[1] = Value.i32(15); pc = 92; continue; }
case 92: { r[2] = Value.ref("mipmap"); pc = 93; continue; }
case 93: { r[5] = Value.ref("MIPMAP"); pc = 94; continue; }
case 94: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 95; continue; }
case 95: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->MIPMAP:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 96; continue; }
case 96: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 97; continue; }
case 97: { r[1] = Value.i32(16); pc = 98; continue; }
case 98: { r[2] = Value.ref("navigation"); pc = 99; continue; }
case 99: { r[5] = Value.ref("NAVIGATION"); pc = 100; continue; }
case 100: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 101; continue; }
case 101: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->NAVIGATION:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 102; continue; }
case 102: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 103; continue; }
case 103: { r[1] = Value.i32(17); pc = 104; continue; }
case 104: { r[2] = Value.ref("plurals"); pc = 105; continue; }
case 105: { r[5] = Value.ref("PLURALS"); pc = 106; continue; }
case 106: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 107; continue; }
case 107: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->PLURALS:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 108; continue; }
case 108: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 109; continue; }
case 109: { r[1] = Value.i32(18); pc = 110; continue; }
case 110: { r[2] = Value.ref("raw"); pc = 111; continue; }
case 111: { r[5] = Value.ref("RAW"); pc = 112; continue; }
case 112: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 113; continue; }
case 113: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->RAW:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 114; continue; }
case 114: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 115; continue; }
case 115: { r[1] = Value.i32(19); pc = 116; continue; }
case 116: { r[2] = Value.ref("string"); pc = 117; continue; }
case 117: { r[5] = Value.ref("STRING"); pc = 118; continue; }
case 118: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 119; continue; }
case 119: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->STRING:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 120; continue; }
case 120: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 121; continue; }
case 121: { r[1] = Value.i32(20); pc = 122; continue; }
case 122: { r[2] = Value.ref("style"); pc = 123; continue; }
case 123: { r[5] = Value.ref("STYLE"); pc = 124; continue; }
case 124: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 125; continue; }
case 125: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->STYLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 126; continue; }
case 126: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 127; continue; }
case 127: { r[1] = Value.i32(21); pc = 128; continue; }
case 128: { r[2] = Value.ref("styleable"); pc = 129; continue; }
case 129: { r[5] = Value.ref("STYLEABLE"); pc = 130; continue; }
case 130: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 131; continue; }
case 131: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->STYLEABLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 132; continue; }
case 132: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 133; continue; }
case 133: { r[1] = Value.i32(22); pc = 134; continue; }
case 134: { r[2] = Value.ref("transition"); pc = 135; continue; }
case 135: { r[5] = Value.ref("TRANSITION"); pc = 136; continue; }
case 136: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 137; continue; }
case 137: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->TRANSITION:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 138; continue; }
case 138: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 139; continue; }
case 139: { r[1] = Value.i32(23); pc = 140; continue; }
case 140: { r[2] = Value.ref("values"); pc = 141; continue; }
case 141: { r[5] = Value.ref("VALUES"); pc = 142; continue; }
case 142: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 143; continue; }
case 143: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->VALUES:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 144; continue; }
case 144: { r[0] = rt.allocate("Lapp/revanced/extension/shared/ResourceType;"); pc = 145; continue; }
case 145: { r[1] = Value.i32(24); pc = 146; continue; }
case 146: { r[2] = Value.ref("xml"); pc = 147; continue; }
case 147: { r[5] = Value.ref("XML"); pc = 148; continue; }
case 148: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;-><init>(Ljava/lang/String;ILjava/lang/String;)V",r[0],new Value[]{r[5], r[1], r[2]}); pc = 149; continue; }
case 149: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->XML:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 150; continue; }
case 150: { result=rt.invoke("static","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;->$values()[Lapp/revanced/extension/shared/ResourceType;",Value.NULL,new Value[]{}); pc = 151; continue; }
case 151: { r[0] = result; pc = 152; continue; }
case 152: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->$VALUES:[Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true,r[0]); pc = 153; continue; }
case 153: { result=rt.invoke("static","Lapp/revanced/extension/shared/ResourceType;","Lapp/revanced/extension/shared/ResourceType;->values()[Lapp/revanced/extension/shared/ResourceType;",Value.NULL,new Value[]{}); pc = 154; continue; }
case 154: { r[0] = result; pc = 155; continue; }
case 155: { r[1] = rt.allocate("Ljava/util/HashMap;"); pc = 156; continue; }
case 156: { r[2] = Value.i32(rt.length(r[0])); pc = 157; continue; }
case 157: { r[2] = Value.i32((r[2].i()) * (r[4].i())); pc = 158; continue; }
case 158: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Ljava/util/HashMap;-><init>(I)V",r[1],new Value[]{r[2]}); pc = 159; continue; }
case 159: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->VALUE_MAP:Ljava/util/Map;",Value.NULL,true,r[1]); pc = 160; continue; }
case 160: { r[1] = Value.i32(rt.length(r[0])); pc = 161; continue; }
case 161: { pc=(r[3].i() >= r[1].i())?168:162; continue; }
case 162: { r[2] = rt.arrayGet(r[0],r[3].i()); pc = 163; continue; }
case 163: { r[4] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->VALUE_MAP:Ljava/util/Map;",Value.NULL,true); pc = 164; continue; }
case 164: { r[5] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->value:Ljava/lang/String;",r[2],false); pc = 165; continue; }
case 165: { result=rt.invoke("interface","Lapp/revanced/extension/shared/ResourceType;","Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",r[4],new Value[]{r[5], r[2]}); pc = 166; continue; }
case 166: { r[3] = Value.i32((r[3].i()) + (1)); pc = 167; continue; }
case 167: { pc=161; continue; }
case 168: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fff727a6e94e7e649a44e31f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/ResourceType;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/ResourceType;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/ResourceType;->value:Ljava/lang/String;",r[0],false,r[3]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f00f0056328aceca5f92538a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(25); pc = 1; continue; }
case 1: { r[0] = rt.newArray("[Lapp/revanced/extension/shared/ResourceType;",r[0].i()); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ANIM:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ANIMATOR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 6; continue; }
case 6: { r[2] = Value.i32(1); pc = 7; continue; }
case 7: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ARRAY:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 9; continue; }
case 9: { r[2] = Value.i32(2); pc = 10; continue; }
case 10: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 11; continue; }
case 11: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ATTR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 12; continue; }
case 12: { r[2] = Value.i32(3); pc = 13; continue; }
case 13: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 14; continue; }
case 14: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->BOOL:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 15; continue; }
case 15: { r[2] = Value.i32(4); pc = 16; continue; }
case 16: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 17; continue; }
case 17: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->COLOR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 18; continue; }
case 18: { r[2] = Value.i32(5); pc = 19; continue; }
case 19: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 20; continue; }
case 20: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->DIMEN:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 21; continue; }
case 21: { r[2] = Value.i32(6); pc = 22; continue; }
case 22: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 23; continue; }
case 23: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->DRAWABLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 24; continue; }
case 24: { r[2] = Value.i32(7); pc = 25; continue; }
case 25: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 26; continue; }
case 26: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->FONT:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 27; continue; }
case 27: { r[2] = Value.i32(8); pc = 28; continue; }
case 28: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 29; continue; }
case 29: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->FRACTION:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 30; continue; }
case 30: { r[2] = Value.i32(9); pc = 31; continue; }
case 31: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 32; continue; }
case 32: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ID:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 33; continue; }
case 33: { r[2] = Value.i32(10); pc = 34; continue; }
case 34: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 35; continue; }
case 35: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->INTEGER:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 36; continue; }
case 36: { r[2] = Value.i32(11); pc = 37; continue; }
case 37: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 38; continue; }
case 38: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->INTERPOLATOR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 39; continue; }
case 39: { r[2] = Value.i32(12); pc = 40; continue; }
case 40: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 41; continue; }
case 41: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->LAYOUT:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 42; continue; }
case 42: { r[2] = Value.i32(13); pc = 43; continue; }
case 43: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 44; continue; }
case 44: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->MENU:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 45; continue; }
case 45: { r[2] = Value.i32(14); pc = 46; continue; }
case 46: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 47; continue; }
case 47: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->MIPMAP:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 48; continue; }
case 48: { r[2] = Value.i32(15); pc = 49; continue; }
case 49: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 50; continue; }
case 50: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->NAVIGATION:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 51; continue; }
case 51: { r[2] = Value.i32(16); pc = 52; continue; }
case 52: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 53; continue; }
case 53: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->PLURALS:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 54; continue; }
case 54: { r[2] = Value.i32(17); pc = 55; continue; }
case 55: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 56; continue; }
case 56: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->RAW:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 57; continue; }
case 57: { r[2] = Value.i32(18); pc = 58; continue; }
case 58: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 59; continue; }
case 59: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->STRING:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 60; continue; }
case 60: { r[2] = Value.i32(19); pc = 61; continue; }
case 61: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 62; continue; }
case 62: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->STYLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 63; continue; }
case 63: { r[2] = Value.i32(20); pc = 64; continue; }
case 64: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 65; continue; }
case 65: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->STYLEABLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 66; continue; }
case 66: { r[2] = Value.i32(21); pc = 67; continue; }
case 67: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 68; continue; }
case 68: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->TRANSITION:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 69; continue; }
case 69: { r[2] = Value.i32(22); pc = 70; continue; }
case 70: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 71; continue; }
case 71: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->VALUES:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 72; continue; }
case 72: { r[2] = Value.i32(23); pc = 73; continue; }
case 73: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 74; continue; }
case 74: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->XML:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 75; continue; }
case 75: { r[2] = Value.i32(24); pc = 76; continue; }
case 76: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 77; continue; }
case 77: { return rt.check(r[0],"[Lapp/revanced/extension/shared/ResourceType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_acfa5b24247b066f11edd3ab(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->$VALUES:[Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/ResourceType;","[Lapp/revanced/extension/shared/ResourceType;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/shared/ResourceType;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/shared/ResourceType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
