package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_217e64d14e2ac510941f {
static ClassInfo info_217e64d14e2ac510941f() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda5;", "Ljava/lang/Object;", new String[]{"Ljava/lang/Runnable;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda5;->f$0:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;", "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V", 69633), new MethodInfo("run()V", 17)}, "SponsorBlockUtils$$ExternalSyntheticLambda5");}
}
