package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_fca4c8a4dba2495da985 {
static ClassInfo info_fca4c8a4dba2495da985() {return new ClassInfo("Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
