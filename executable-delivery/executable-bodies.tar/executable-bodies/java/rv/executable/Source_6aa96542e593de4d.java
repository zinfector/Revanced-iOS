package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_6aa96542e593de4d extends RuntimeForeign.SourceProxy {
Source_6aa96542e593de4d(RuntimeForeign owner,Instance source){super(owner,source);}

}
