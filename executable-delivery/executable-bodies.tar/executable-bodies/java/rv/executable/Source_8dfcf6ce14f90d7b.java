package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_8dfcf6ce14f90d7b extends RuntimeForeign.SourceProxy {
Source_8dfcf6ce14f90d7b(RuntimeForeign owner,Instance source){super(owner,source);}

}
