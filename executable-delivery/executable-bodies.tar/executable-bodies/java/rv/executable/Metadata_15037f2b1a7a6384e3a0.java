package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_15037f2b1a7a6384e3a0 {
static ClassInfo info_15037f2b1a7a6384e3a0() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHorizontalDragAvailability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)}, "MiniplayerHorizontalDragAvailability");}
}
