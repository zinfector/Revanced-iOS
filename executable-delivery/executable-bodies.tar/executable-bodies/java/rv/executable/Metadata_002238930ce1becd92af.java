package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_002238930ce1becd92af {
static ClassInfo info_002238930ce1becd92af() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda51;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda51;->f$0:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;", "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda51");}
}
