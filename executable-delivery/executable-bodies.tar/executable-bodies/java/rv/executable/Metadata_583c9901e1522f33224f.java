package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_583c9901e1522f33224f {
static ClassInfo info_583c9901e1522f33224f() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;->f$0:Ljava/lang/Runnable;", "Ljava/lang/Runnable;", 4113, ExecutableRuntime.zero("Ljava/lang/Runnable;")), new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;->f$1:Ljava/lang/Exception;", "Ljava/lang/Exception;", 4113, ExecutableRuntime.zero("Ljava/lang/Exception;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/Runnable;Ljava/lang/Exception;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "Utils$$ExternalSyntheticLambda7");}
}
