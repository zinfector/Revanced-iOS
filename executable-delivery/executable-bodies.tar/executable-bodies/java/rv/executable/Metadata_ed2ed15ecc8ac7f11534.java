package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_ed2ed15ecc8ac7f11534 {
static ClassInfo info_ed2ed15ecc8ac7f11534() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda22;", "Ljava/lang/Object;", new String[]{"Ljava/lang/Runnable;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda22;->f$0:Ljava/lang/Runnable;", "Ljava/lang/Runnable;", 4113, ExecutableRuntime.zero("Ljava/lang/Runnable;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/Runnable;)V", 69633), new MethodInfo("run()V", 17)}, "Utils$$ExternalSyntheticLambda22");}
}
