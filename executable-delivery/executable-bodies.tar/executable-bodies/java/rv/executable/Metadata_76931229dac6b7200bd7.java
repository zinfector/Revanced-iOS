package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_76931229dac6b7200bd7 {
static ClassInfo info_76931229dac6b7200bd7() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda48;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda48;->f$0:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;", "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda48");}
}
