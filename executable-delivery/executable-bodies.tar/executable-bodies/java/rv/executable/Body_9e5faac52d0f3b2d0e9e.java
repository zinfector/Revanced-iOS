package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_9e5faac52d0f3b2d0e9e {
static Value m_4d067097717fb6da07cba1ac(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?2:1; continue; }
case 1: { return Value.VOID; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/PlayerControlsVisibilityHookPatch;","Ljava/lang/Enum;->name()Ljava/lang/String;",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/PlayerControlsVisibilityHookPatch;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->setFromString(Ljava/lang/String;)V",Value.NULL,new Value[]{r[0]}); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
