package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_ccccd60ae8b41a166cfb {
static Value m_91541c2d67c2014fbf11c5b6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/spoof/ClientType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;->f$0:Lapp/revanced/extension/shared/spoof/ClientType;", r[0], false, r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_dc9bf69b4ea73b8d01e6d220(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;->f$0:Lapp/revanced/extension/shared/spoof/ClientType;", r[1], false); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/shared/spoof/ClientType$$ExternalSyntheticLambda0;", "Lapp/revanced/extension/shared/spoof/ClientType;->$r8$lambda$F-X1mwj8GCxmQsBF9IroXdzEu98(Lapp/revanced/extension/shared/spoof/ClientType;)Ljava/lang/String;", Value.NULL, new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
