package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_657f5443de9fd185ba13 {
static ClassInfo info_657f5443de9fd185ba13() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda47;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda47;->f$0:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;", "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda47");}
}
