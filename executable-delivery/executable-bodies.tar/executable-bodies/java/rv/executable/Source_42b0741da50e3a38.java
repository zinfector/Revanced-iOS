package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_42b0741da50e3a38 extends RuntimeForeign.SourceProxy {
Source_42b0741da50e3a38(RuntimeForeign owner,Instance source){super(owner,source);}

}
