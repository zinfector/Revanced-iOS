package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_38271caea0437b5e6b05 {
static Value m_612fccd49e28e9c5f834ab3b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->$VALUES:[Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType;","Ljava/lang/Object;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/shared/PlayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5809fd4b801f810fddfd4c6c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->Companion:Lapp/revanced/extension/youtube/shared/PlayerType$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;->setFromString(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_01dfbe372110d07196266921(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->Companion:Lapp/revanced/extension/youtube/shared/PlayerType$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;->getCurrent()Lapp/revanced/extension/youtube/shared/PlayerType;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/PlayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_143a9361ac28ee50dddccb80(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->NONE:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[1],r[0]))?7:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->HIDDEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[1],r[0]))?5:4; continue; }
case 4: { pc=7; continue; }
case 5: { r[0] = Value.i32(0); pc = 6; continue; }
case 6: { return rt.check(r[0],"Z"); }
case 7: { r[0] = Value.i32(1); pc = 8; continue; }
case 8: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_142fbd588bae98b0609e01a9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("NONE"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->NONE:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("HIDDEN"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->HIDDEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("WATCH_WHILE_MINIMIZED"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_MINIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 15; continue; }
case 15: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 16; continue; }
case 16: { r[1] = Value.ref("WATCH_WHILE_MAXIMIZED"); pc = 17; continue; }
case 17: { r[2] = Value.i32(3); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_MAXIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 21; continue; }
case 21: { r[1] = Value.ref("WATCH_WHILE_FULLSCREEN"); pc = 22; continue; }
case 22: { r[2] = Value.i32(4); pc = 23; continue; }
case 23: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_FULLSCREEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 25; continue; }
case 25: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 26; continue; }
case 26: { r[1] = Value.ref("WATCH_WHILE_SLIDING_MAXIMIZED_FULLSCREEN"); pc = 27; continue; }
case 27: { r[2] = Value.i32(5); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_SLIDING_MAXIMIZED_FULLSCREEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 30; continue; }
case 30: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 31; continue; }
case 31: { r[1] = Value.ref("WATCH_WHILE_SLIDING_MINIMIZED_MAXIMIZED"); pc = 32; continue; }
case 32: { r[2] = Value.i32(6); pc = 33; continue; }
case 33: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 34; continue; }
case 34: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_SLIDING_MINIMIZED_MAXIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 35; continue; }
case 35: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 36; continue; }
case 36: { r[1] = Value.ref("WATCH_WHILE_SLIDING_MINIMIZED_DISMISSED"); pc = 37; continue; }
case 37: { r[2] = Value.i32(7); pc = 38; continue; }
case 38: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 39; continue; }
case 39: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_SLIDING_MINIMIZED_DISMISSED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 40; continue; }
case 40: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 41; continue; }
case 41: { r[1] = Value.ref("WATCH_WHILE_SLIDING_FULLSCREEN_DISMISSED"); pc = 42; continue; }
case 42: { r[2] = Value.i32(8); pc = 43; continue; }
case 43: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 44; continue; }
case 44: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_SLIDING_FULLSCREEN_DISMISSED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 45; continue; }
case 45: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 46; continue; }
case 46: { r[1] = Value.ref("INLINE_MINIMAL"); pc = 47; continue; }
case 47: { r[2] = Value.i32(9); pc = 48; continue; }
case 48: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 49; continue; }
case 49: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->INLINE_MINIMAL:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 50; continue; }
case 50: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 51; continue; }
case 51: { r[1] = Value.ref("VIRTUAL_REALITY_FULLSCREEN"); pc = 52; continue; }
case 52: { r[2] = Value.i32(10); pc = 53; continue; }
case 53: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 54; continue; }
case 54: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->VIRTUAL_REALITY_FULLSCREEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 55; continue; }
case 55: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 56; continue; }
case 56: { r[1] = Value.ref("WATCH_WHILE_PICTURE_IN_PICTURE"); pc = 57; continue; }
case 57: { r[3] = Value.i32(11); pc = 58; continue; }
case 58: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[3]}); pc = 59; continue; }
case 59: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_PICTURE_IN_PICTURE:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 60; continue; }
case 60: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;->$values()[Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,new Value[]{}); pc = 61; continue; }
case 61: { r[0] = result; pc = 62; continue; }
case 62: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->$VALUES:[Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 63; continue; }
case 63: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType;","Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;",Value.NULL,new Value[]{r[0]}); pc = 64; continue; }
case 64: { r[0] = result; pc = 65; continue; }
case 65: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->$ENTRIES:Lkotlin/enums/EnumEntries;",Value.NULL,true,r[0]); pc = 66; continue; }
case 66: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/PlayerType$Companion;"); pc = 67; continue; }
case 67: { r[1] = Value.i32(0); pc = 68; continue; }
case 68: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V",r[0],new Value[]{r[1]}); pc = 69; continue; }
case 69: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->Companion:Lapp/revanced/extension/youtube/shared/PlayerType$Companion;",Value.NULL,true,r[0]); pc = 70; continue; }
case 70: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType;->getEntries()Lkotlin/enums/EnumEntries;",Value.NULL,new Value[]{}); pc = 71; continue; }
case 71: { r[0] = result; pc = 72; continue; }
case 72: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType;","Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I",Value.NULL,new Value[]{r[0], r[2]}); pc = 73; continue; }
case 73: { r[1] = result; pc = 74; continue; }
case 74: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType;","Lkotlin/collections/MapsKt__MapsJVMKt;->mapCapacity(I)I",Value.NULL,new Value[]{r[1]}); pc = 75; continue; }
case 75: { r[1] = result; pc = 76; continue; }
case 76: { r[2] = Value.i32(16); pc = 77; continue; }
case 77: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/PlayerType;","Lkotlin/ranges/RangesKt___RangesKt;->coerceAtLeast(II)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 78; continue; }
case 78: { r[1] = result; pc = 79; continue; }
case 79: { r[2] = rt.allocate("Ljava/util/LinkedHashMap;"); pc = 80; continue; }
case 80: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Ljava/util/LinkedHashMap;-><init>(I)V",r[2],new Value[]{r[1]}); pc = 81; continue; }
case 81: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerType;","Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;",r[0],new Value[]{}); pc = 82; continue; }
case 82: { r[0] = result; pc = 83; continue; }
case 83: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerType;","Ljava/util/Iterator;->hasNext()Z",r[0],new Value[]{}); pc = 84; continue; }
case 84: { r[1] = result; pc = 85; continue; }
case 85: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?94:86; continue; }
case 86: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerType;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[0],new Value[]{}); pc = 87; continue; }
case 87: { r[1] = result; pc = 88; continue; }
case 88: { r[3] = r[1]; pc = 89; continue; }
case 89: { r[3] = rt.cast(r[3],"Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 90; continue; }
case 90: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType;","Ljava/lang/Enum;->name()Ljava/lang/String;",r[3],new Value[]{}); pc = 91; continue; }
case 91: { r[3] = result; pc = 92; continue; }
case 92: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/shared/PlayerType;","Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",r[2],new Value[]{r[3], r[1]}); pc = 93; continue; }
case 93: { pc=83; continue; }
case 94: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->nameToPlayerType:Ljava/util/Map;",Value.NULL,true,r[2]); pc = 95; continue; }
case 95: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->NONE:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 96; continue; }
case 96: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->currentPlayerType:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 97; continue; }
case 97: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/Event;"); pc = 98; continue; }
case 98: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/Event;-><init>()V",r[0],new Value[]{}); pc = 99; continue; }
case 99: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->onChange:Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,true,r[0]); pc = 100; continue; }
case 100: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_367e25f73175df7634dfc445(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->Companion:Lapp/revanced/extension/youtube/shared/PlayerType$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/shared/PlayerType;","Lapp/revanced/extension/youtube/shared/PlayerType$Companion;->getOnChange()Lapp/revanced/extension/youtube/shared/Event;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/Event;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e0e41eb4ce7db024e555d865(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/PlayerType;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9cca820e936db22faa27b341(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[12];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->NONE:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->HIDDEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_MINIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_MAXIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_FULLSCREEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_SLIDING_MAXIMIZED_FULLSCREEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 6; continue; }
case 6: { r[6] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_SLIDING_MINIMIZED_MAXIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 7; continue; }
case 7: { r[7] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_SLIDING_MINIMIZED_DISMISSED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 8; continue; }
case 8: { r[8] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_SLIDING_FULLSCREEN_DISMISSED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 9; continue; }
case 9: { r[9] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->INLINE_MINIMAL:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 10; continue; }
case 10: { r[10] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->VIRTUAL_REALITY_FULLSCREEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 11; continue; }
case 11: { r[11] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_PICTURE_IN_PICTURE:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 12; continue; }
case 12: { result=rt.filledArray("[Lapp/revanced/extension/youtube/shared/PlayerType;",new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11]}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/shared/PlayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4c82aae061f9bae330943212(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->$ENTRIES:Lkotlin/enums/EnumEntries;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lkotlin/enums/EnumEntries;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5adcace3c63009428cf30f0d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->nameToPlayerType:Ljava/util/Map;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/util/Map;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fecd506dc843bfaf3ca5848b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->currentPlayerType:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/PlayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9775d838fb1c652b42e35d2e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/youtube/shared/PlayerType;->currentPlayerType:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true,r[0]); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e2e8781a0fdb847562931c6e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->onChange:Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Lapp/revanced/extension/youtube/shared/Event;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5ea8b7f77948610b90f0d84c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_MAXIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[1],r[0]))?7:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_FULLSCREEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[1],r[0]))?5:4; continue; }
case 4: { pc=7; continue; }
case 5: { r[0] = Value.i32(0); pc = 6; continue; }
case 6: { return rt.check(r[0],"Z"); }
case 7: { r[0] = Value.i32(1); pc = 8; continue; }
case 8: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
