package rv.executable;

import java.util.*;
import rv.executable.ExecutableRuntime.MissingOperation;

/*-[
#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonDigest.h>
#import <QuartzCore/QuartzCore.h>
#include <stdio.h>
#include <limits.h>
#include "java/lang/NullPointerException.h"
#include "java/lang/Runnable.h"
#include "java/lang/Throwable.h"
#include "java/util/Map.h"
#include "java/util/Set.h"
#include "java/util/Iterator.h"
#include "rv/executable/ExecutableRuntime.h"

static NSURL *RVEPreferenceURL(NSString *namespace) {
  NSData *data=[namespace dataUsingEncoding:NSUTF8StringEncoding];
  unsigned char digest[CC_SHA256_DIGEST_LENGTH];CC_SHA256(data.bytes,(CC_LONG)data.length,digest);
  NSMutableString *name=[NSMutableString string];
  for(unsigned i=0;i<sizeof(digest);i++)[name appendFormat:@"%02x",digest[i]];
  NSURL *root=[[[NSFileManager defaultManager] URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask] firstObject];
  return [[root URLByAppendingPathComponent:@"ReVancedGeneratedPreferences" isDirectory:YES] URLByAppendingPathComponent:[name stringByAppendingString:@".plist"]];
}
static NSMutableDictionary *RVEReadPreferences(NSURL *url) {
  NSData *data=[NSData dataWithContentsOfURL:url];
  id decoded=data?[NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainers format:NULL error:NULL]:nil;
  return [decoded isKindOfClass:[NSDictionary class]]?[decoded mutableCopy]:[NSMutableDictionary dictionary];
}
]-*/

/** Fresh iOS services. Environment compatibility and resource facts are explicit
 * inputs. No Android SDK level or source-app version is invented from iOS values. */
public final class IOSPlatformServices implements PlatformServices {
    private final Map<String,String> profile;
    private final Map<String,Integer> resourceIds;
    private final Map<Integer,String> resourceStrings;
    private final boolean resourcesConfigured;
    private volatile Object toastAnchor;
    public IOSPlatformServices(Map<String,String> profile,Map<String,Integer> ids,Map<Integer,String> strings) {
        this.profile=Collections.unmodifiableMap(new LinkedHashMap<>(Objects.requireNonNull(profile)));
        resourcesConfigured=ids!=null && strings!=null;
        resourceIds=ids==null?Collections.emptyMap():Collections.unmodifiableMap(new LinkedHashMap<>(ids));
        resourceStrings=strings==null?Collections.emptyMap():Collections.unmodifiableMap(new LinkedHashMap<>(strings));
    }
    /** Bootstrap must provide the admitted live presentation view. */
    public void setToastAnchor(Object view){toastAnchor=view;}
    public String metadata(String key){return key.startsWith("host.")?hostMetadata(key):profile.get(key);}
    public int resourceIdentifier(String name,String type,String packageName){
        if(!resourcesConfigured)throw new MissingOperation("resource-catalog");
        Integer value=resourceIds.get(packageName+":"+type+"/"+name);return value==null?0:value;
    }
    public String resourceString(int identifier){
        String value=resourceStrings.get(identifier);if(value==null)throw new MissingOperation("resource-string:"+identifier);return value;
    }
    public void toast(String message,int duration){Object anchor=toastAnchor;if(anchor==null)throw new MissingOperation("toast-presentation-anchor");presentToast(anchor,message,duration);}
    public native boolean isMainThread() /*-[ return [NSThread isMainThread]; ]-*/;
    public native boolean postMain(Runnable task,long delayMillis) /*-[
      if(!task)@throw create_JavaLangNullPointerException_init();
      int64_t delta=delayMillis>INT64_MAX/NSEC_PER_MSEC?INT64_MAX:delayMillis*NSEC_PER_MSEC;
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW,delta),dispatch_get_main_queue(),^{[task run];});
      return true;
    ]-*/;
    public synchronized native String preference(String preferenceNamespace,String key) /*-[
      id value=RVEReadPreferences(RVEPreferenceURL(preferenceNamespace))[key];
      return [value isKindOfClass:[NSString class]]?value:nil;
    ]-*/;
    public synchronized native boolean commitPreferences(String preferenceNamespace,Map<String,String> changes) /*-[
      NSURL *url=RVEPreferenceURL(preferenceNamespace);NSMutableDictionary *values=RVEReadPreferences(url);
      id<JavaUtilIterator> keys=[[changes keySet] iterator];
      while([keys hasNext]){NSString *key=[keys next];NSString *value=[changes getWithId:key];if(value)values[key]=value;else [values removeObjectForKey:key];}
      NSError *error=nil;
      if(![[NSFileManager defaultManager] createDirectoryAtURL:[url URLByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:&error])return false;
      NSData *data=[NSPropertyListSerialization dataWithPropertyList:values format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];
      return data && [data writeToURL:url options:NSDataWritingAtomic error:&error];
    ]-*/;
    public native int log(int level,String tag,String message,Throwable error) /*-[
      NSString *line=[NSString stringWithFormat:@"[RV %d %@] %@\n",level,tag,message];
      NSData *data=[line dataUsingEncoding:NSUTF8StringEncoding];size_t written=fwrite(data.bytes,1,data.length,stderr);
      if(error)[error printStackTrace];return (jint)MIN(written,(size_t)INT_MAX);
    ]-*/;
    private native String hostMetadata(String key) /*-[
      if([key isEqual:@"host.bundle_id"])return [[NSBundle mainBundle] bundleIdentifier];
      if([key isEqual:@"host.version"])return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
      if([key isEqual:@"host.os_version"])return [[UIDevice currentDevice] systemVersion];
      return nil;
    ]-*/;
    private native void presentToast(Object anchor,String message,int duration) /*-[
      if(![NSThread isMainThread] || ![anchor isKindOfClass:[UIView class]] || ![(UIView *)anchor window])
        @throw create_RVEExecutableRuntime_MissingOperation_initWithNSString_(@"toast-live-main-view");
      UIView *view=(UIView *)anchor;UILabel *label=[[UILabel alloc] init];
      label.text=message;label.numberOfLines=0;label.textAlignment=NSTextAlignmentCenter;
      label.font=[UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];label.textColor=UIColor.whiteColor;
      label.backgroundColor=[UIColor.blackColor colorWithAlphaComponent:0.85];label.layer.cornerRadius=9;label.clipsToBounds=YES;
      CGFloat width=MAX(0,MIN(340,view.bounds.size.width-32));CGSize size=[label sizeThatFits:CGSizeMake(MAX(0,width-20),CGFLOAT_MAX)];
      label.frame=CGRectMake((view.bounds.size.width-width)/2,MAX(0,view.bounds.size.height-view.safeAreaInsets.bottom-size.height-56),width,size.height+20);
      label.accessibilityTraits=UIAccessibilityTraitStaticText;[view addSubview:label];
      UIAccessibilityPostNotification(UIAccessibilityAnnouncementNotification,message);
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(duration==1?3500:2000)*NSEC_PER_MSEC),dispatch_get_main_queue(),^{[label removeFromSuperview];});
    ]-*/;
}
