package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_fcdc86620d6649b8f0ce {
static Value m_dc1e15cd5861d1d494b86465(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger$1;","Lapp/revanced/extension/shared/Logger$LogLevel;->values()[Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[0] = Value.i32(rt.length(r[0])); pc = 3; continue; }
case 3: { r[0] = rt.newArray("[I",r[0].i()); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/Logger$1;->$SwitchMap$app$revanced$extension$shared$Logger$LogLevel:[I",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->DEBUG:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger$1;","Ljava/lang/Enum;->ordinal()I",r[1],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { r[2] = Value.i32(1); pc = 9; continue; }
case 9: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 10; continue; }
case 10: { r[0] = rt.readField("Lapp/revanced/extension/shared/Logger$1;->$SwitchMap$app$revanced$extension$shared$Logger$LogLevel:[I",Value.NULL,true); pc = 11; continue; }
case 11: { r[1] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->INFO:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger$1;","Ljava/lang/Enum;->ordinal()I",r[1],new Value[]{}); pc = 13; continue; }
case 13: { r[1] = result; pc = 14; continue; }
case 14: { r[2] = Value.i32(2); pc = 15; continue; }
case 15: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 16; continue; }
case 16: { r[0] = rt.readField("Lapp/revanced/extension/shared/Logger$1;->$SwitchMap$app$revanced$extension$shared$Logger$LogLevel:[I",Value.NULL,true); pc = 17; continue; }
case 17: { r[1] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->ERROR:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger$1;","Ljava/lang/Enum;->ordinal()I",r[1],new Value[]{}); pc = 19; continue; }
case 19: { r[1] = result; pc = 20; continue; }
case 20: { r[2] = Value.i32(3); pc = 21; continue; }
case 21: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 22; continue; }
case 22: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 5 && pc < 10) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/NoSuchFieldError;")) { exception=ExecutableRuntime.caught(error); pc=10; continue; } }
if(pc >= 10 && pc < 16) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/NoSuchFieldError;")) { exception=ExecutableRuntime.caught(error); pc=16; continue; } }
if(pc >= 16 && pc < 22) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/NoSuchFieldError;")) { exception=ExecutableRuntime.caught(error); pc=22; continue; } }
throw error;
}
}

}
}
