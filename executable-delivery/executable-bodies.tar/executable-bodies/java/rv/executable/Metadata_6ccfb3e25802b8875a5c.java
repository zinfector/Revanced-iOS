package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_6ccfb3e25802b8875a5c {
static ClassInfo info_6ccfb3e25802b8875a5c() {return new ClassInfo("Lapp/revanced/extension/youtube/shared/Event;", "Ljava/lang/Object;", new String[]{}, 17, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/shared/Event;->eventListeners:Ljava/util/Set;", "Ljava/util/Set;", 18, ExecutableRuntime.zero("Ljava/util/Set;"))}, new MethodInfo[]{new MethodInfo("$r8$lambda$bOvmNWqHEmoEwMNqdnZVvSVmTyk(Lkotlin/jvm/functions/Function1;)Ljava/lang/String;", 9), new MethodInfo("<init>()V", 65537), new MethodInfo("addObserver(Lkotlin/jvm/functions/Function1;)V", 17), new MethodInfo("invoke(Ljava/lang/Object;)V", 17), new MethodInfo("minusAssign(Lkotlin/jvm/functions/Function1;)V", 17), new MethodInfo("plusAssign(Lkotlin/jvm/functions/Function1;)V", 17), new MethodInfo("removeObserver(Lkotlin/jvm/functions/Function1;)V", 17)});}
}
