package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_931efadc9226c870 extends RuntimeForeign.SourceProxy implements java.lang.Comparable {
Proxy_931efadc9226c870(RuntimeForeign owner,Instance source){super(owner,source);}
public int compareTo(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I",new Value[]{owner.importValue(a0)}); return result.i();}
}
