package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_b1b54795e7b5f92318e4 {
static ClassInfo info_b1b54795e7b5f92318e4() {return new ClassInfo("Lkotlin/collections/AbstractList$ListIteratorImpl;", "Lkotlin/collections/AbstractList$IteratorImpl;", new String[]{"Ljava/util/ListIterator;"}, 1, new FieldInfo[]{new FieldInfo("Lkotlin/collections/AbstractList$ListIteratorImpl;->this$0:Lkotlin/collections/AbstractList;", "Lkotlin/collections/AbstractList;", 4113, ExecutableRuntime.zero("Lkotlin/collections/AbstractList;"))}, new MethodInfo[]{new MethodInfo("<init>(Lkotlin/collections/AbstractList;I)V", 65537), new MethodInfo("add(Ljava/lang/Object;)V", 1), new MethodInfo("hasPrevious()Z", 1), new MethodInfo("nextIndex()I", 1), new MethodInfo("previous()Ljava/lang/Object;", 1), new MethodInfo("previousIndex()I", 1), new MethodInfo("set(Ljava/lang/Object;)V", 1)}, "ListIteratorImpl");}
}
