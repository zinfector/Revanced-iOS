package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_5a01d8379456639c3382 {
static Value m_1c84b72ffd7109ce34ffbde4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->$VALUES:[Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils$NetworkType;","[Lapp/revanced/extension/shared/Utils$NetworkType;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/shared/Utils$NetworkType;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/shared/Utils$NetworkType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ac6ee8e488adc5fa389d34cf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$NetworkType;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("NONE"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils$NetworkType;","Lapp/revanced/extension/shared/Utils$NetworkType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/Utils$NetworkType;->NONE:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$NetworkType;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("MOBILE"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils$NetworkType;","Lapp/revanced/extension/shared/Utils$NetworkType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/Utils$NetworkType;->MOBILE:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$NetworkType;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("OTHER"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils$NetworkType;","Lapp/revanced/extension/shared/Utils$NetworkType;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/shared/Utils$NetworkType;->OTHER:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true,r[0]); pc = 15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils$NetworkType;","Lapp/revanced/extension/shared/Utils$NetworkType;->$values()[Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,new Value[]{}); pc = 16; continue; }
case 16: { r[0] = result; pc = 17; continue; }
case 17: { rt.writeField("Lapp/revanced/extension/shared/Utils$NetworkType;->$VALUES:[Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true,r[0]); pc = 18; continue; }
case 18: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c82bf5361998f730b5b1e50a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$NetworkType;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils$NetworkType;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f31da5b1ec1fbb246d3fb29d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(3); pc = 1; continue; }
case 1: { r[0] = rt.newArray("[Lapp/revanced/extension/shared/Utils$NetworkType;",r[0].i()); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->NONE:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->MOBILE:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 6; continue; }
case 6: { r[2] = Value.i32(1); pc = 7; continue; }
case 7: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->OTHER:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 9; continue; }
case 9: { r[2] = Value.i32(2); pc = 10; continue; }
case 10: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 11; continue; }
case 11: { return rt.check(r[0],"[Lapp/revanced/extension/shared/Utils$NetworkType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
