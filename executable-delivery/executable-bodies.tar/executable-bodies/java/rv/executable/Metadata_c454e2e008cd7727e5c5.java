package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_c454e2e008cd7727e5c5 {
static ClassInfo info_c454e2e008cd7727e5c5() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$ChangeStartPageTypeAvailability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 1, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
