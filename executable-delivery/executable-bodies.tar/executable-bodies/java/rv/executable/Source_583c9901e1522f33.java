package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_583c9901e1522f33 extends RuntimeForeign.SourceProxy {
Source_583c9901e1522f33(RuntimeForeign owner,Instance source){super(owner,source);}

}
