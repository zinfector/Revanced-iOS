package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_ef6ace58a01c915f extends RuntimeForeign.SourceProxy {
Source_ef6ace58a01c915f(RuntimeForeign owner,Instance source){super(owner,source);}

}
