package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_2df84d76ede30468bcef {
static ClassInfo info_2df84d76ede30468bcef() {return new ClassInfo("Lkotlin/collections/AbstractList$SubList;", "Lkotlin/collections/AbstractList;", new String[]{"Ljava/util/RandomAccess;"}, 17, new FieldInfo[]{new FieldInfo("Lkotlin/collections/AbstractList$SubList;->_size:I", "I", 1, ExecutableRuntime.zero("I")), new FieldInfo("Lkotlin/collections/AbstractList$SubList;->fromIndex:I", "I", 17, ExecutableRuntime.zero("I")), new FieldInfo("Lkotlin/collections/AbstractList$SubList;->list:Lkotlin/collections/AbstractList;", "Lkotlin/collections/AbstractList;", 17, ExecutableRuntime.zero("Lkotlin/collections/AbstractList;"))}, new MethodInfo[]{new MethodInfo("<init>(Lkotlin/collections/AbstractList;II)V", 65537), new MethodInfo("get(I)Ljava/lang/Object;", 1), new MethodInfo("getSize()I", 1), new MethodInfo("subList(II)Ljava/util/List;", 1)}, "SubList");}
}
