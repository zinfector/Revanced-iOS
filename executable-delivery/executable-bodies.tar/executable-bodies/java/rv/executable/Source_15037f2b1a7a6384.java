package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_15037f2b1a7a6384 extends RuntimeForeign.SourceProxy {
Source_15037f2b1a7a6384(RuntimeForeign owner,Instance source){super(owner,source);}

}
