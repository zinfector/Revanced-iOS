package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_032c8aea1835c09cf26c {
static Value m_57406a3a5896ce4aed1e472f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("\u202d"); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_ENABLED:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[1],new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[1],new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?30:7; continue; }
case 7: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_VIDEO_LENGTH_WITHOUT_SEGMENTS:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[1],new Value[]{}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[1],new Value[]{}); pc = 11; continue; }
case 11: { r[1] = result; pc = 12; continue; }
case 12: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?30:13; continue; }
case 13: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z",Value.NULL,new Value[]{r[2]}); pc = 14; continue; }
case 14: { r[1] = result; pc = 15; continue; }
case 15: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?30:16; continue; }
case 16: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->timeWithoutSegments:Ljava/lang/String;",Value.NULL,true); pc = 17; continue; }
case 17: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z",Value.NULL,new Value[]{r[1]}); pc = 18; continue; }
case 18: { r[1] = result; pc = 19; continue; }
case 19: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?30:20; continue; }
case 20: { r[1] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[0]}); pc = 22; continue; }
case 22: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[2]}); pc = 23; continue; }
case 23: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->timeWithoutSegments:Ljava/lang/String;",Value.NULL,true); pc = 24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[0]}); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[1],new Value[]{}); pc = 26; continue; }
case 26: { r[2] = result; pc = 27; continue; }
case 27: { return rt.check(r[2],"Ljava/lang/String;"); }
case 28: { r[0] = Value.ref(exception); exception=null; pc = 29; continue; }
case 29: { pc=31; continue; }
case 30: { return rt.check(r[2],"Ljava/lang/String;"); }
case 31: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda44;"); pc = 32; continue; }
case 32: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda44;-><init>()V",r[1],new Value[]{}); pc = 33; continue; }
case 33: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 34; continue; }
case 34: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 1 && pc < 27) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=28; continue; } }
throw error;
}
}

}

static Value m_007f2eb8e1daf09ec0f5c2a2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[13];
r[11] = rt.check(arguments[0], "Landroid/graphics/Canvas;");
r[12] = rt.check(arguments[1], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?55:2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->isAdProgressTextVisible()Z",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?6:5; continue; }
case 5: { pc=55; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoLength()J",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; r[1] = r[0]; pc = 8; continue; }
case 8: { r[2] = Value.i64(0L); r[3] = r[2]; pc = 9; continue; }
case 9: { r[2] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[2].j())); pc = 10; continue; }
case 10: { pc=(r[2].i() > 0)?12:11; continue; }
case 11: { pc=55; continue; }
case 12: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->seekbarThickness:I",Value.NULL,true); pc = 13; continue; }
case 13: { r[3] = Value.i32((r[2].i()) / (2)); pc = 14; continue; }
case 14: { r[2] = Value.i32((r[2].i()) - (r[3].i())); pc = 15; continue; }
case 15: { r[2] = Value.f32((float)(r[2].i())); pc = 16; continue; }
case 16: { r[6] = Value.f32((r[12].f()) - (r[2].f())); pc = 17; continue; }
case 17: { r[2] = Value.f32((float)(r[3].i())); pc = 18; continue; }
case 18: { r[8] = Value.f32((r[12].f()) + (r[2].f())); pc = 19; continue; }
case 19: { r[12] = Value.i32(1065353216); pc = 20; continue; }
case 20: { r[0] = Value.f32((float)(r[0].j())); pc = 21; continue; }
case 21: { r[12] = Value.f32((r[12].f()) / (r[0].f())); pc = 22; continue; }
case 22: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->seekbarAbsoluteRight:I",Value.NULL,true); pc = 23; continue; }
case 23: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->seekbarAbsoluteLeft:I",Value.NULL,true); pc = 24; continue; }
case 24: { r[0] = Value.i32((r[0].i()) - (r[1].i())); pc = 25; continue; }
case 25: { r[0] = Value.f32((float)(r[0].i())); pc = 26; continue; }
case 26: { r[12] = Value.f32((r[12].f()) * (r[0].f())); pc = 27; continue; }
case 27: { r[0] = Value.f32((float)(r[1].i())); pc = 28; continue; }
case 28: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 29; continue; }
case 29: { r[2] = Value.i32(rt.length(r[1])); pc = 30; continue; }
case 30: { r[3] = Value.i32(0); pc = 31; continue; }
case 31: { pc=(r[3].i() >= r[2].i())?55:32; continue; }
case 32: { r[4] = rt.arrayGet(r[1],r[3].i()); pc = 33; continue; }
case 33: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[4],false); r[10] = r[9]; pc = 34; continue; }
case 34: { r[5] = Value.f32((float)(r[9].j())); pc = 35; continue; }
case 35: { r[5] = Value.f32((r[5].f()) * (r[12].f())); pc = 36; continue; }
case 36: { r[5] = Value.f32((r[5].f()) + (r[0].f())); pc = 37; continue; }
case 37: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[4],false); pc = 38; continue; }
case 38: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 39; continue; }
case 39: { pc=(!ExecutableRuntime.equal(r[7],r[9]))?44:40; continue; }
case 40: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->HIGHLIGHT_SEGMENT_DRAW_BAR_WIDTH:I",Value.NULL,true); pc = 41; continue; }
case 41: { r[4] = Value.f32((float)(r[4].i())); pc = 42; continue; }
case 42: { r[4] = Value.f32((r[4].f()) + (r[5].f())); pc = 43; continue; }
case 43: { pc=48; continue; }
case 44: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[4],false); r[10] = r[9]; pc = 45; continue; }
case 45: { r[4] = Value.f32((float)(r[9].j())); pc = 46; continue; }
case 46: { r[4] = Value.f32((r[4].f()) * (r[12].f())); pc = 47; continue; }
case 47: { r[4] = Value.f32((r[4].f()) + (r[0].f())); pc = 48; continue; }
case 48: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->paint:Landroid/graphics/Paint;",r[7],false); pc = 49; continue; }
case 49: { r[7] = r[4]; pc = 50; continue; }
case 50: { r[4] = r[11]; pc = 51; continue; }
case 51: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V",r[4],new Value[]{r[5], r[6], r[7], r[8], r[9]}); pc = 52; continue; }
case 52: { r[3] = Value.i32((r[3].i()) + (1)); pc = 53; continue; }
case 53: { r[11] = r[4]; pc = 54; continue; }
case 54: { pc=31; continue; }
case 55: { return Value.VOID; }
case 56: { r[0] = Value.ref(exception); exception=null; pc = 57; continue; }
case 57: { r[11] = r[0]; pc = 58; continue; }
case 58: { r[12] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda22;"); pc = 59; continue; }
case 59: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda22;-><init>()V",r[12],new Value[]{}); pc = 60; continue; }
case 60: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[12], r[11]}); pc = 61; continue; }
case 61: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 52) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=56; continue; } }
throw error;
}
}

}

static Value m_c988dc3f3b826da939e28a25(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;->initialize()V",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->clearData()V",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideAll()V",Value.NULL,new Value[]{}); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->clearUnsubmittedSegmentTimes()V",Value.NULL,new Value[]{}); pc = 5; continue; }
case 5: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda57;"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda57;-><init>()V",r[1],new Value[]{}); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 8; continue; }
case 8: { return Value.VOID; }
case 9: { r[1] = Value.ref(exception); exception=null; pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda58;"); pc = 11; continue; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda58;-><init>()V",r[0],new Value[]{}); pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[1]}); pc = 13; continue; }
case 13: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 8) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=9; continue; } }
throw error;
}
}

}

static Value m_b73d29b993faaf15e3c7d6e8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->adProgressTextVisibility:I",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],r[1]))?6:2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->adProgressTextVisibility:I",Value.NULL,true,r[1]); pc = 3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda46;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda46;-><init>(I)V",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1f79b61fe3fc144498d6ba1f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->currentVideoId:Ljava/lang/String;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z",Value.NULL,new Value[]{r[0], r[1]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:4; continue; }
case 4: { pc=35; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->clearData()V",Value.NULL,new Value[]{}); pc = 6; continue; }
case 6: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?35:7; continue; }
case 7: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_ENABLED:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?14:13; continue; }
case 13: { pc=35; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->isOpen()Z",Value.NULL,new Value[]{}); pc = 15; continue; }
case 15: { r[0] = result; pc = 16; continue; }
case 16: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?21:17; continue; }
case 17: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda1;"); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda1;-><init>()V",r[1],new Value[]{}); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 20; continue; }
case 20: { return Value.VOID; }
case 21: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->isNetworkConnected()Z",Value.NULL,new Value[]{}); pc = 22; continue; }
case 22: { r[0] = result; pc = 23; continue; }
case 23: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?28:24; continue; }
case 24: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda2;"); pc = 25; continue; }
case 25: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda2;-><init>()V",r[1],new Value[]{}); pc = 26; continue; }
case 26: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 27; continue; }
case 27: { return Value.VOID; }
case 28: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->currentVideoId:Ljava/lang/String;",Value.NULL,true,r[1]); pc = 29; continue; }
case 29: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda3;"); pc = 30; continue; }
case 30: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda3;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 31; continue; }
case 31: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 32; continue; }
case 32: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;"); pc = 33; continue; }
case 33: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 34; continue; }
case 34: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->runOnBackgroundThread(Ljava/lang/Runnable;)V",Value.NULL,new Value[]{r[0]}); pc = 35; continue; }
case 35: { return Value.VOID; }
case 36: { r[1] = Value.ref(exception); exception=null; pc = 37; continue; }
case 37: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda5;"); pc = 38; continue; }
case 38: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda5;-><init>()V",r[0],new Value[]{}); pc = 39; continue; }
case 39: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[1]}); pc = 40; continue; }
case 40: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 35) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=36; continue; } }
throw error;
}
}

}

static Value m_14abb653c457370e3aaf52f5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Landroid/graphics/Rect;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Landroid/graphics/Rect;->left:I",r[2],false); pc = 1; continue; }
case 1: { r[2] = rt.readField("Landroid/graphics/Rect;->right:I",r[2],false); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->seekbarAbsoluteLeft:I",Value.NULL,true); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[1],r[0]))?8:4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->seekbarAbsoluteRight:I",Value.NULL,true); pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[1],r[2]))?7:6; continue; }
case 6: { pc=8; continue; }
case 7: { return Value.VOID; }
case 8: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda28;"); pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda28;-><init>(II)V",r[1],new Value[]{r[0], r[2]}); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 11; continue; }
case 11: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->seekbarAbsoluteLeft:I",Value.NULL,true,r[0]); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->seekbarAbsoluteRight:I",Value.NULL,true,r[2]); pc = 13; continue; }
case 13: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6bac81266edc71f0dfafc74d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->seekbarThickness:I",Value.NULL,true,r[0]); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8378b2dd73c96b026804ed9e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[21];
r[19] = rt.check(arguments[0], "J"); r[20] = r[19];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = r[19]; r[1] = r[0]; pc = 1; continue; }
case 1: { r[2] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_ENABLED:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[2],new Value[]{}); pc = 3; continue; }
case 3: { r[2] = result; pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[2],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?214:7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/PlayerType;->getCurrent()Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/PlayerType;->isNoneOrHidden()Z",r[2],new Value[]{}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?214:12; continue; }
case 12: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 13; continue; }
case 13: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?214:14; continue; }
case 14: { r[2] = Value.i32(rt.length(r[2])); pc = 15; continue; }
case 15: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?214:16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->isAdProgressTextVisible()Z",Value.NULL,new Value[]{}); pc = 17; continue; }
case 17: { r[2] = result; pc = 18; continue; }
case 18: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?20:19; continue; }
case 19: { pc=214; continue; }
case 20: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda7;"); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda7;-><init>(J)V",r[2],new Value[]{r[0]}); pc = 22; continue; }
case 22: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->updateHiddenSegments(J)V",Value.NULL,new Value[]{r[0]}); pc = 24; continue; }
case 24: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getPlaybackSpeed()F",Value.NULL,new Value[]{}); pc = 25; continue; }
case 25: { r[2] = result; pc = 26; continue; }
case 26: { r[3] = Value.i32(1150681088); pc = 27; continue; }
case 27: { r[3] = Value.f32((r[3].f()) * (r[2].f())); pc = 28; continue; }
case 28: { r[3] = Value.i64((long)(r[3].f())); r[4] = r[3]; pc = 29; continue; }
case 29: { r[5] = Value.i64((r[0].j()) + (r[3].j())); r[6] = r[5]; pc = 30; continue; }
case 30: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 31; continue; }
case 31: { r[8] = Value.i32(rt.length(r[7])); pc = 32; continue; }
case 32: { r[11] = Value.i32(0); pc = 33; continue; }
case 33: { r[12] = Value.i32(0); pc = 34; continue; }
case 34: { r[13] = Value.i32(0); pc = 35; continue; }
case 35: { pc=(r[11].i() >= r[8].i())?113:36; continue; }
case 36: { r[14] = rt.arrayGet(r[7],r[11].i()); pc = 37; continue; }
case 37: { r[15] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[14],false); pc = 38; continue; }
case 38: { r[16] = Value.i32(0); pc = 39; continue; }
case 39: { r[10] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviour:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",r[15],false); pc = 40; continue; }
case 40: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SHOW_IN_SEEKBAR:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",Value.NULL,true); pc = 41; continue; }
case 41: { pc=(ExecutableRuntime.equal(r[10],r[9]))?46:42; continue; }
case 42: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->IGNORE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",Value.NULL,true); pc = 43; continue; }
case 43: { pc=(ExecutableRuntime.equal(r[10],r[9]))?46:44; continue; }
case 44: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 45; continue; }
case 45: { pc=(!ExecutableRuntime.equal(r[15],r[9]))?48:46; continue; }
case 46: { r[17] = r[5]; r[18] = r[17]; pc = 47; continue; }
case 47: { pc=79; continue; }
case 48: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[14],false); r[10] = r[9]; pc = 49; continue; }
case 49: { r[9] = Value.i32(ExecutableRuntime.compareLong(r[9].j(), r[0].j())); pc = 50; continue; }
case 50: { pc=(r[9].i() > 0)?52:51; continue; }
case 51: { pc=46; continue; }
case 52: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->shouldAutoSkipAndUndoSkipNotActive(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;J)Z",Value.NULL,new Value[]{r[14], r[0]}); pc = 53; continue; }
case 53: { r[9] = result; pc = 54; continue; }
case 54: { r[17] = r[5]; r[18] = r[17]; pc = 55; continue; }
case 55: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[14],false); r[6] = r[5]; pc = 56; continue; }
case 56: { r[10] = Value.i32(ExecutableRuntime.compareLong(r[5].j(), r[0].j())); pc = 57; continue; }
case 57: { pc=(r[10].i() > 0)?81:58; continue; }
case 58: { pc=(ExecutableRuntime.equal(r[9],Value.i32(0)))?62:59; continue; }
case 59: { r[10] = Value.i32(0); pc = 60; continue; }
case 60: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegment(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;Z)V",Value.NULL,new Value[]{r[14], r[10]}); pc = 61; continue; }
case 61: { return Value.VOID; }
case 62: { r[10] = Value.i32(0); pc = 63; continue; }
case 63: { pc=(ExecutableRuntime.equal(r[12],Value.i32(0)))?67:64; continue; }
case 64: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->containsSegment(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)Z",r[12],new Value[]{r[14]}); pc = 65; continue; }
case 65: { r[5] = result; pc = 66; continue; }
case 66: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?79:67; continue; }
case 67: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 68; continue; }
case 68: { pc=(ExecutableRuntime.equal(r[5],r[14]))?78:69; continue; }
case 69: { r[5] = Value.i64(800L); r[6] = r[5]; pc = 70; continue; }
case 70: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->endIsNear(JJ)Z",r[14],new Value[]{r[0], r[5]}); pc = 71; continue; }
case 71: { r[5] = result; pc = 72; continue; }
case 72: { pc=(!ExecutableRuntime.equal(r[5],Value.i32(0)))?74:73; continue; }
case 73: { pc=78; continue; }
case 74: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda10;"); pc = 75; continue; }
case 75: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda10;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[5],new Value[]{r[14]}); pc = 76; continue; }
case 76: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[5]}); pc = 77; continue; }
case 77: { pc=79; continue; }
case 78: { r[12] = r[14]; pc = 79; continue; }
case 79: { r[9] = r[11]; pc = 80; continue; }
case 80: { pc=110; continue; }
case 81: { r[10] = Value.i32(0); pc = 82; continue; }
case 82: { r[5] = Value.i32(ExecutableRuntime.compareLong(r[17].j(), r[5].j())); pc = 83; continue; }
case 83: { pc=(r[5].i() >= 0)?85:84; continue; }
case 84: { pc=114; continue; }
case 85: { pc=(ExecutableRuntime.equal(r[9],Value.i32(0)))?88:86; continue; }
case 86: { r[13] = r[14]; pc = 87; continue; }
case 87: { pc=114; continue; }
case 88: { pc=(ExecutableRuntime.equal(r[12],Value.i32(0)))?92:89; continue; }
case 89: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->containsSegment(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)Z",r[12],new Value[]{r[14]}); pc = 90; continue; }
case 90: { r[5] = result; pc = 91; continue; }
case 91: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?79:92; continue; }
case 92: { pc=(ExecutableRuntime.equal(r[13],Value.i32(0)))?96:93; continue; }
case 93: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->containsSegment(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)Z",r[13],new Value[]{r[14]}); pc = 94; continue; }
case 94: { r[5] = result; pc = 95; continue; }
case 95: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?79:96; continue; }
case 96: { pc=(ExecutableRuntime.equal(r[12],Value.i32(0)))?108:97; continue; }
case 97: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[14],false); r[6] = r[5]; pc = 98; continue; }
case 98: { r[9] = r[11]; pc = 99; continue; }
case 99: { r[10] = Value.i64(1000L); r[11] = r[10]; pc = 100; continue; }
case 100: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->endIsNear(JJ)Z",r[12],new Value[]{r[5], r[10]}); pc = 101; continue; }
case 101: { r[5] = result; pc = 102; continue; }
case 102: { pc=(!ExecutableRuntime.equal(r[5],Value.i32(0)))?104:103; continue; }
case 103: { pc=109; continue; }
case 104: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda11;"); pc = 105; continue; }
case 105: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda11;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[5],new Value[]{r[14]}); pc = 106; continue; }
case 106: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[5]}); pc = 107; continue; }
case 107: { pc=110; continue; }
case 108: { r[9] = r[11]; pc = 109; continue; }
case 109: { r[13] = r[14]; pc = 110; continue; }
case 110: { r[11] = Value.i32((r[9].i()) + (1)); pc = 111; continue; }
case 111: { r[5] = r[17]; r[6] = r[5]; pc = 112; continue; }
case 112: { pc=35; continue; }
case 113: { r[16] = Value.i32(0); pc = 114; continue; }
case 114: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 115; continue; }
case 115: { r[6] = Value.i64(0L); r[7] = r[6]; pc = 116; continue; }
case 116: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?135:117; continue; }
case 117: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->getSkipButtonDuration()J",Value.NULL,new Value[]{}); pc = 118; continue; }
case 118: { r[8] = result; r[9] = r[8]; pc = 119; continue; }
case 119: { r[5] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[8].j())); pc = 120; continue; }
case 120: { pc=(r[5].i() < 0)?133:121; continue; }
case 121: { r[8] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegmentInitialShowEndTime:J",Value.NULL,true); r[9] = r[8]; pc = 122; continue; }
case 122: { r[5] = Value.i32(ExecutableRuntime.compareLong(r[8].j(), r[6].j())); pc = 123; continue; }
case 123: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?130:124; continue; }
case 124: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 125; continue; }
case 125: { r[8] = result; r[9] = r[8]; pc = 126; continue; }
case 126: { r[10] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegmentInitialShowEndTime:J",Value.NULL,true); r[11] = r[10]; pc = 127; continue; }
case 127: { r[5] = Value.i32(ExecutableRuntime.compareLong(r[8].j(), r[10].j())); pc = 128; continue; }
case 128: { pc=(r[5].i() >= 0)?130:129; continue; }
case 129: { pc=133; continue; }
case 130: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegmentInitialShowEndTime:J",Value.NULL,true,r[6]); pc = 131; continue; }
case 131: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideSkipHighlightButton()V",Value.NULL,new Value[]{}); pc = 132; continue; }
case 132: { pc=135; continue; }
case 133: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 134; continue; }
case 134: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->showSkipHighlightButton(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[5]}); pc = 135; continue; }
case 135: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 136; continue; }
case 136: { pc=(ExecutableRuntime.equal(r[5],r[12]))?139:137; continue; }
case 137: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->setSegmentCurrentlyPlaying(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[12]}); pc = 138; continue; }
case 138: { pc=157; continue; }
case 139: { pc=(ExecutableRuntime.equal(r[12],Value.i32(0)))?157:140; continue; }
case 140: { r[8] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegmentButtonEndTime:J",Value.NULL,true); r[9] = r[8]; pc = 141; continue; }
case 141: { r[5] = Value.i32(ExecutableRuntime.compareLong(r[8].j(), r[6].j())); pc = 142; continue; }
case 142: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?157:143; continue; }
case 143: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 144; continue; }
case 144: { r[10] = result; r[11] = r[10]; pc = 145; continue; }
case 145: { r[5] = Value.i32(ExecutableRuntime.compareLong(r[8].j(), r[10].j())); pc = 146; continue; }
case 146: { pc=(r[5].i() > 0)?157:147; continue; }
case 147: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda12;"); pc = 148; continue; }
case 148: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda12;-><init>()V",r[5],new Value[]{}); pc = 149; continue; }
case 149: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[5]}); pc = 150; continue; }
case 150: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegmentButtonEndTime:J",Value.NULL,true,r[6]); pc = 151; continue; }
case 151: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->hiddenSkipSegmentsForCurrentVideoTime:Ljava/util/List;",Value.NULL,true); pc = 152; continue; }
case 152: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/List;->add(Ljava/lang/Object;)Z",r[5],new Value[]{r[12]}); pc = 153; continue; }
case 153: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->autoSkipIsEnabledAndPlayerOverlayIsActive()Z",Value.NULL,new Value[]{}); pc = 154; continue; }
case 154: { r[5] = result; pc = 155; continue; }
case 155: { pc=(!ExecutableRuntime.equal(r[5],Value.i32(0)))?157:156; continue; }
case 156: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideSkipSegmentButton()V",Value.NULL,new Value[]{}); pc = 157; continue; }
case 157: { pc=(ExecutableRuntime.equal(r[12],Value.i32(0)))?162:158; continue; }
case 158: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->endIsNear(JJ)Z",r[12],new Value[]{r[0], r[3]}); pc = 159; continue; }
case 159: { r[5] = result; pc = 160; continue; }
case 160: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?162:161; continue; }
case 161: { pc=163; continue; }
case 162: { r[12] = r[16]; pc = 163; continue; }
case 163: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledHideSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 164; continue; }
case 164: { pc=(ExecutableRuntime.equal(r[5],r[12]))?183:165; continue; }
case 165: { pc=(!ExecutableRuntime.equal(r[12],Value.i32(0)))?171:166; continue; }
case 166: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda13;"); pc = 167; continue; }
case 167: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda13;-><init>()V",r[5],new Value[]{}); pc = 168; continue; }
case 168: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[5]}); pc = 169; continue; }
case 169: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledHideSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[16]); pc = 170; continue; }
case 170: { pc=183; continue; }
case 171: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledHideSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[12]); pc = 172; continue; }
case 172: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda14;"); pc = 173; continue; }
case 173: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda14;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;F)V",r[5],new Value[]{r[12], r[2]}); pc = 174; continue; }
case 174: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[5]}); pc = 175; continue; }
case 175: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[12],false); r[6] = r[5]; pc = 176; continue; }
case 176: { r[5] = Value.i64((r[5].j()) - (r[0].j())); r[6] = r[5]; pc = 177; continue; }
case 177: { r[5] = Value.f32((float)(r[5].j())); pc = 178; continue; }
case 178: { r[5] = Value.f32((r[5].f()) / (r[2].f())); pc = 179; continue; }
case 179: { r[5] = Value.i64((long)(r[5].f())); r[6] = r[5]; pc = 180; continue; }
case 180: { r[7] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda15;"); pc = 181; continue; }
case 181: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda15;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;J)V",r[7],new Value[]{r[12], r[3]}); pc = 182; continue; }
case 182: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->runOnMainThreadDelayed(Ljava/lang/Runnable;J)V",Value.NULL,new Value[]{r[7], r[5]}); pc = 183; continue; }
case 183: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledUpcomingSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 184; continue; }
case 184: { pc=(ExecutableRuntime.equal(r[5],r[13]))?214:185; continue; }
case 185: { pc=(!ExecutableRuntime.equal(r[13],Value.i32(0)))?191:186; continue; }
case 186: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda16;"); pc = 187; continue; }
case 187: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda16;-><init>()V",r[2],new Value[]{}); pc = 188; continue; }
case 188: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 189; continue; }
case 189: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledUpcomingSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[16]); pc = 190; continue; }
case 190: { pc=203; continue; }
case 191: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledUpcomingSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[13]); pc = 192; continue; }
case 192: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda17;"); pc = 193; continue; }
case 193: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda17;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;F)V",r[5],new Value[]{r[13], r[2]}); pc = 194; continue; }
case 194: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[5]}); pc = 195; continue; }
case 195: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[13],false); r[6] = r[5]; pc = 196; continue; }
case 196: { r[5] = Value.i64((r[5].j()) - (r[0].j())); r[6] = r[5]; pc = 197; continue; }
case 197: { r[5] = Value.f32((float)(r[5].j())); pc = 198; continue; }
case 198: { r[5] = Value.f32((r[5].f()) / (r[2].f())); pc = 199; continue; }
case 199: { r[5] = Value.i64((long)(r[5].f())); r[6] = r[5]; pc = 200; continue; }
case 200: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda18;"); pc = 201; continue; }
case 201: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda18;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;J)V",r[2],new Value[]{r[13], r[3]}); pc = 202; continue; }
case 202: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->runOnMainThreadDelayed(Ljava/lang/Runnable;J)V",Value.NULL,new Value[]{r[2], r[5]}); pc = 203; continue; }
case 203: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true); pc = 204; continue; }
case 204: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?214:205; continue; }
case 205: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[0]}); pc = 206; continue; }
case 206: { r[0] = result; pc = 207; continue; }
case 207: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/util/Range;->contains(Ljava/lang/Comparable;)Z",r[2],new Value[]{r[0]}); pc = 208; continue; }
case 208: { r[0] = result; pc = 209; continue; }
case 209: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?214:210; continue; }
case 210: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda8;"); pc = 211; continue; }
case 211: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda8;-><init>()V",r[0],new Value[]{}); pc = 212; continue; }
case 212: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 213; continue; }
case 213: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true,r[16]); pc = 214; continue; }
case 214: { return Value.VOID; }
case 215: { r[0] = Value.ref(exception); exception=null; pc = 216; continue; }
case 216: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda9;"); pc = 217; continue; }
case 217: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda9;-><init>()V",r[1],new Value[]{}); pc = 218; continue; }
case 218: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 219; continue; }
case 219: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 1 && pc < 214) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=215; continue; } }
throw error;
}
}

}

static Value m_d4ea897211a815ea19ed6d6c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp7:I",Value.NULL,true); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->HIGHLIGHT_SEGMENT_DRAW_BAR_WIDTH:I",Value.NULL,true,r[0]); pc = 2; continue; }
case 2: { r[0] = rt.allocate("Ljava/util/ArrayList;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/ArrayList;-><init>()V",r[0],new Value[]{}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->hiddenSkipSegmentsForCurrentVideoTime:Ljava/util/List;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 6; continue; }
case 6: { r[1] = Value.i32(0); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastDialogRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 9; continue; }
case 9: { r[0] = Value.i32(-1); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->adProgressTextVisibility:I",Value.NULL,true,r[0]); pc = 11; continue; }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/PlayerType;->getOnChange()Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,new Value[]{}); pc = 12; continue; }
case 12: { r[0] = result; pc = 13; continue; }
case 13: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda29;"); pc = 14; continue; }
case 14: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda29;-><init>()V",r[1],new Value[]{}); pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/Event;->addObserver(Lkotlin/jvm/functions/Function1;)V",r[0],new Value[]{r[1]}); pc = 16; continue; }
case 16: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_97c14185bf9535f9b60c0d1e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->adProgressTextVisibility:I",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?4:2; continue; }
case 2: { r[0] = Value.i32(1); pc = 3; continue; }
case 3: { return rt.check(r[0],"Z"); }
case 4: { r[0] = Value.i32(0); pc = 5; continue; }
case 5: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_696e0b8d3d5379ec29ebca14(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->currentVideoId:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { r[1] = Value.i64(0L); r[2] = r[1]; pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegmentInitialShowEndTime:J",Value.NULL,true,r[1]); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->timeWithoutSegments:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledUpcomingSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledHideSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegmentButtonEndTime:J",Value.NULL,true,r[1]); pc = 11; continue; }
case 11: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastSegmentSkipped:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 12; continue; }
case 12: { r[1] = Value.i32(0); pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastNumberOfSegmentsSkipped:I",Value.NULL,true,r[1]); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true,r[0]); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRangeToast:Landroid/util/Range;",Value.NULL,true,r[0]); pc = 16; continue; }
case 16: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->hiddenSkipSegmentsForCurrentVideoTime:Ljava/util/List;",Value.NULL,true); pc = 17; continue; }
case 17: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/List;->clear()V",r[0],new Value[]{}); pc = 18; continue; }
case 18: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b4d3396eb6633947a3ea3845(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "J"); r[3] = r[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->hiddenSkipSegmentsForCurrentVideoTime:Ljava/util/List;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda42;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda42;-><init>(J)V",r[1],new Value[]{r[2]}); pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5fc830f4b0a868aa730516ea(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[1] = rt.check(arguments[1], "J"); r[2] = r[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->shouldAutoSkip()Z",r[0],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?12:3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true); pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?10:5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[1]}); pc = 6; continue; }
case 6: { r[1] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/util/Range;->contains(Ljava/lang/Comparable;)Z",r[0],new Value[]{r[1]}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?12:10; continue; }
case 10: { r[0] = Value.i32(1); pc = 11; continue; }
case 11: { return rt.check(r[0],"Z"); }
case 12: { r[0] = Value.i32(0); pc = 13; continue; }
case 13: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_14736840c4a2938b529532de(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[10];
r[8] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[9] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideSkipHighlightButton()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideSkipSegmentButton()V",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; r[1] = r[0]; pc = 4; continue; }
case 4: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->lastSegmentSkipped:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[2],r[8]))?22:6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getPlaybackSpeed()F",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[2] = result; pc = 8; continue; }
case 8: { r[3] = Value.i32(1140457472); pc = 9; continue; }
case 9: { r[3] = Value.f32((r[3].f()) / (r[2].f())); pc = 10; continue; }
case 10: { r[2] = Value.i64((long)(r[3].f())); r[3] = r[2]; pc = 11; continue; }
case 11: { r[4] = Value.i64(500L); r[5] = r[4]; pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Math;->max(JJ)J",Value.NULL,new Value[]{r[4], r[2]}); pc = 13; continue; }
case 13: { r[2] = result; r[3] = r[2]; pc = 14; continue; }
case 14: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->lastSegmentSkippedTime:J",Value.NULL,true); r[5] = r[4]; pc = 15; continue; }
case 15: { r[4] = Value.i64((r[0].j()) - (r[4].j())); r[5] = r[4]; pc = 16; continue; }
case 16: { r[2] = Value.i32(ExecutableRuntime.compareLong(r[4].j(), r[2].j())); pc = 17; continue; }
case 17: { pc=(r[2].i() >= 0)?22:18; continue; }
case 18: { r[9] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda30;"); pc = 19; continue; }
case 19: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda30;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[9],new Value[]{r[8]}); pc = 20; continue; }
case 20: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[9]}); pc = 21; continue; }
case 21: { return Value.VOID; }
case 22: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda31;"); pc = 23; continue; }
case 23: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda31;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[2],new Value[]{r[8]}); pc = 24; continue; }
case 24: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 25; continue; }
case 25: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->lastSegmentSkipped:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[8]); pc = 26; continue; }
case 26: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->lastSegmentSkippedTime:J",Value.NULL,true,r[0]); pc = 27; continue; }
case 27: { r[0] = Value.i32(0); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->setSegmentCurrentlyPlaying(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[0]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledHideSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 30; continue; }
case 30: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledUpcomingSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 31; continue; }
case 31: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 32; continue; }
case 32: { pc=(!ExecutableRuntime.equal(r[8],r[0]))?35:33; continue; }
case 33: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 34; continue; }
case 34: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegmentInitialShowEndTime:J",Value.NULL,true,r[0]); pc = 35; continue; }
case 35: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->getUndoRange()Landroid/util/Range;",r[8],new Value[]{}); pc = 36; continue; }
case 36: { r[0] = result; pc = 37; continue; }
case 37: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true); pc = 38; continue; }
case 38: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?44:39; continue; }
case 39: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda32;"); pc = 40; continue; }
case 40: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda32;-><init>(Landroid/util/Range;)V",r[1],new Value[]{r[0]}); pc = 41; continue; }
case 41: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 42; continue; }
case 42: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true,r[0]); pc = 43; continue; }
case 43: { pc=50; continue; }
case 44: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/util/Range;->extend(Landroid/util/Range;)Landroid/util/Range;",r[1],new Value[]{r[0]}); pc = 45; continue; }
case 45: { r[0] = result; pc = 46; continue; }
case 46: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda33;"); pc = 47; continue; }
case 47: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda33;-><init>(Landroid/util/Range;)V",r[1],new Value[]{r[0]}); pc = 48; continue; }
case 48: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 49; continue; }
case 49: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true,r[0]); pc = 50; continue; }
case 50: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true); pc = 51; continue; }
case 51: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRangeToast:Landroid/util/Range;",Value.NULL,true,r[0]); pc = 52; continue; }
case 52: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[8],false); r[1] = r[0]; pc = 53; continue; }
case 53: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->seekTo(J)Z",Value.NULL,new Value[]{r[0]}); pc = 54; continue; }
case 54: { r[0] = result; pc = 55; continue; }
case 55: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?60:56; continue; }
case 56: { r[9] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda34;"); pc = 57; continue; }
case 57: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda34;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[9],new Value[]{r[8]}); pc = 58; continue; }
case 58: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[9]}); pc = 59; continue; }
case 59: { return Value.VOID; }
case 60: { pc=(!ExecutableRuntime.equal(r[9],Value.i32(0)))?96:61; continue; }
case 61: { r[9] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_TOAST_ON_SKIP:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 62; continue; }
case 62: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[9],new Value[]{}); pc = 63; continue; }
case 63: { r[9] = result; pc = 64; continue; }
case 64: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[9],new Value[]{}); pc = 65; continue; }
case 65: { r[9] = result; pc = 66; continue; }
case 66: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 67; continue; }
case 67: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[0]}); pc = 68; continue; }
case 68: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"); pc = 69; continue; }
case 69: { r[1] = Value.i32(rt.length(r[0])); pc = 70; continue; }
case 70: { r[2] = Value.i32(0); pc = 71; continue; }
case 71: { pc=(r[2].i() >= r[1].i())?96:72; continue; }
case 72: { r[3] = rt.arrayGet(r[0],r[2].i()); pc = 73; continue; }
case 73: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[3],false); r[5] = r[4]; pc = 74; continue; }
case 74: { r[6] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[8],false); r[7] = r[6]; pc = 75; continue; }
case 75: { r[4] = Value.i32(ExecutableRuntime.compareLong(r[4].j(), r[6].j())); pc = 76; continue; }
case 76: { pc=(r[4].i() > 0)?78:77; continue; }
case 77: { pc=94; continue; }
case 78: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[8],false); r[5] = r[4]; pc = 79; continue; }
case 79: { r[6] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[3],false); r[7] = r[6]; pc = 80; continue; }
case 80: { r[4] = Value.i32(ExecutableRuntime.compareLong(r[4].j(), r[6].j())); pc = 81; continue; }
case 81: { pc=(r[4].i() > 0)?83:82; continue; }
case 82: { pc=96; continue; }
case 83: { pc=(ExecutableRuntime.equal(r[3],r[8]))?90:84; continue; }
case 84: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[3],false); pc = 85; continue; }
case 85: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 86; continue; }
case 86: { pc=(ExecutableRuntime.equal(r[4],r[5]))?94:87; continue; }
case 87: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->containsSegment(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)Z",r[8],new Value[]{r[3]}); pc = 88; continue; }
case 88: { r[4] = result; pc = 89; continue; }
case 89: { pc=(ExecutableRuntime.equal(r[4],Value.i32(0)))?94:90; continue; }
case 90: { r[4] = Value.i32(1); pc = 91; continue; }
case 91: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->didAutoSkipped:Z",r[3],false,r[4]); pc = 92; continue; }
case 92: { pc=(ExecutableRuntime.equal(r[9],Value.i32(0)))?94:93; continue; }
case 93: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->showSkippedSegmentToast(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[3]}); pc = 94; continue; }
case 94: { r[2] = Value.i32((r[2].i()) + (1)); pc = 95; continue; }
case 95: { pc=71; continue; }
case 96: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[8],false); pc = 97; continue; }
case 97: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->UNSUBMITTED:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 98; continue; }
case 98: { pc=(!ExecutableRuntime.equal(r[9],r[0]))?102:99; continue; }
case 99: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->removeUnsubmittedSegments()V",Value.NULL,new Value[]{}); pc = 100; continue; }
case 100: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->setNewSponsorSegmentPreviewed()V",Value.NULL,new Value[]{}); pc = 101; continue; }
case 101: { return Value.VOID; }
case 102: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/VideoState;->getCurrent()Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,new Value[]{}); pc = 103; continue; }
case 103: { r[9] = result; pc = 104; continue; }
case 104: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->PAUSED:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 105; continue; }
case 105: { pc=(ExecutableRuntime.equal(r[9],r[0]))?107:106; continue; }
case 106: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->sendViewRequestAsync(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[8]}); pc = 107; continue; }
case 107: { return Value.VOID; }
case 108: { r[8] = Value.ref(exception); exception=null; pc = 109; continue; }
case 109: { r[9] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda35;"); pc = 110; continue; }
case 110: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda35;-><init>()V",r[9],new Value[]{}); pc = 111; continue; }
case 111: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[9], r[8]}); pc = 112; continue; }
case 112: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 107) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=108; continue; } }
throw error;
}
}

}

static Value m_a396137d4b0a01462439774f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_AUTO_HIDE_SKIP_BUTTON_DURATION:Lapp/revanced/extension/shared/settings/EnumSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->-$$Nest$fgetadjustedDuration(Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;)J",Value.NULL,new Value[]{r[0]}); pc = 5; continue; }
case 5: { r[0] = result; r[1] = r[0]; pc = 6; continue; }
case 6: { return rt.check(r[0],"J"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_96b6a5b1f870ecdc8a76697f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[4] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[4],Value.i32(0)))?12:2; continue; }
case 2: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[4],Value.i32(0)))?7:4; continue; }
case 4: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda19;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda19;-><init>()V",r[4],new Value[]{}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[4]}); pc = 7; continue; }
case 7: { r[4] = Value.i32(0); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[4]); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegmentButtonEndTime:J",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideSkipSegmentButton()V",Value.NULL,new Value[]{}); pc = 11; continue; }
case 11: { return Value.VOID; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[4]); pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegmentButtonEndTime:J",Value.NULL,true,r[0]); pc = 14; continue; }
case 14: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_AUTO_HIDE_SKIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 16; continue; }
case 16: { r[0] = result; pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 18; continue; }
case 18: { r[0] = result; pc = 19; continue; }
case 19: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?39:20; continue; }
case 20: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->hiddenSkipSegmentsForCurrentVideoTime:Ljava/util/List;",Value.NULL,true); pc = 21; continue; }
case 21: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/List;->contains(Ljava/lang/Object;)Z",r[0],new Value[]{r[4]}); pc = 22; continue; }
case 22: { r[0] = result; pc = 23; continue; }
case 23: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?33:24; continue; }
case 24: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda20;"); pc = 25; continue; }
case 25: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda20;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[0],new Value[]{r[4]}); pc = 26; continue; }
case 26: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 27; continue; }
case 27: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setSkipSegment(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[4]}); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->autoSkipIsEnabledAndPlayerOverlayIsActive()Z",Value.NULL,new Value[]{}); pc = 29; continue; }
case 29: { r[4] = result; pc = 30; continue; }
case 30: { pc=(!ExecutableRuntime.equal(r[4],Value.i32(0)))?32:31; continue; }
case 31: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideSkipSegmentButton()V",Value.NULL,new Value[]{}); pc = 32; continue; }
case 32: { return Value.VOID; }
case 33: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 34; continue; }
case 34: { r[0] = result; r[1] = r[0]; pc = 35; continue; }
case 35: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->getSkipButtonDuration()J",Value.NULL,new Value[]{}); pc = 36; continue; }
case 36: { r[2] = result; r[3] = r[2]; pc = 37; continue; }
case 37: { r[0] = Value.i64((r[0].j()) + (r[2].j())); r[1] = r[0]; pc = 38; continue; }
case 38: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegmentButtonEndTime:J",Value.NULL,true,r[0]); pc = 39; continue; }
case 39: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda21;"); pc = 40; continue; }
case 40: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda21;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[0],new Value[]{r[4]}); pc = 41; continue; }
case 41: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 42; continue; }
case 42: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->showSkipSegmentButton(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[4]}); pc = 43; continue; }
case 43: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c919fb2d616bce9a8a002b3c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_AUTO_HIDE_SKIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?12:6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->getCurrent()Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;->PLAYER_CONTROLS_VISIBILITY_HIDDEN:Lapp/revanced/extension/youtube/shared/PlayerControlsVisibility;",Value.NULL,true); pc = 9; continue; }
case 9: { pc=(ExecutableRuntime.equal(r[0],r[1]))?12:10; continue; }
case 10: { r[0] = Value.i32(1); pc = 11; continue; }
case 11: { return rt.check(r[0],"Z"); }
case 12: { r[0] = Value.i32(0); pc = 13; continue; }
case 13: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_67106631f2b7abd4568ae683(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(arguments[0], "J"); r[1] = r[0];
r[2] = rt.check(arguments[1], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->containsTime(J)Z",r[2],new Value[]{r[0]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?8:3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda27;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda27;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[0],new Value[]{r[2]}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[0] = Value.i32(1); pc = 7; continue; }
case 7: { return rt.check(r[0],"Z"); }
case 8: { r[0] = Value.i32(0); pc = 9; continue; }
case 9: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c8b948a9578a95031af38f13(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastSegmentSkipped:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[2]); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastNumberOfSegmentsSkipped:I",Value.NULL,true); pc = 3; continue; }
case 3: { r[0] = Value.i32((r[2].i()) + (1)); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastNumberOfSegmentsSkipped:I",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { pc=(r[2].i() <= 0)?7:6; continue; }
case 6: { return Value.VOID; }
case 7: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda6;"); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda6;-><init>()V",r[2],new Value[]{}); pc = 9; continue; }
case 9: { r[0] = Value.i64(250L); r[1] = r[0]; pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->runOnMainThreadDelayed(Ljava/lang/Runnable;J)V",Value.NULL,new Value[]{r[2], r[0]}); pc = 11; continue; }
case 11: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_aaf9e638c43722c6694c61ee(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?29:2; continue; }
case 2: { r[0] = Value.i32(rt.length(r[0])); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?5:4; continue; }
case 4: { pc=29; continue; }
case 5: { r[0] = rt.allocate("Ljava/util/ArrayList;"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/ArrayList;-><init>()V",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 8; continue; }
case 8: { r[2] = Value.i32(rt.length(r[1])); pc = 9; continue; }
case 9: { r[3] = Value.i32(0); pc = 10; continue; }
case 10: { r[4] = r[3]; pc = 11; continue; }
case 11: { pc=(r[4].i() >= r[2].i())?19:12; continue; }
case 12: { r[5] = rt.arrayGet(r[1],r[4].i()); pc = 13; continue; }
case 13: { r[6] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[5],false); pc = 14; continue; }
case 14: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->UNSUBMITTED:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 15; continue; }
case 15: { pc=(ExecutableRuntime.equal(r[6],r[7]))?17:16; continue; }
case 16: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/List;->add(Ljava/lang/Object;)Z",r[0],new Value[]{r[5]}); pc = 17; continue; }
case 17: { r[4] = Value.i32((r[4].i()) + (1)); pc = 18; continue; }
case 18: { pc=11; continue; }
case 19: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/List;->size()I",r[0],new Value[]{}); pc = 20; continue; }
case 20: { r[1] = result; pc = 21; continue; }
case 21: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 22; continue; }
case 22: { r[2] = Value.i32(rt.length(r[2])); pc = 23; continue; }
case 23: { pc=(ExecutableRuntime.equal(r[1],r[2]))?29:24; continue; }
case 24: { r[1] = rt.newArray("[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",r[3].i()); pc = 25; continue; }
case 25: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;",r[0],new Value[]{r[1]}); pc = 26; continue; }
case 26: { r[0] = result; pc = 27; continue; }
case 27: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->setSegments([Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[0]}); pc = 29; continue; }
case 29: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_63aab97e8906dc2dc2511d8d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[5] = rt.check(arguments[0], "[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/Arrays;->sort([Ljava/lang/Object;)V",Value.NULL,new Value[]{r[5]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[5]); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->calculateTimeWithoutSegments()V",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 4; continue; }
case 4: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->behaviour:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",r[0],false); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SKIP_AUTOMATICALLY:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",Value.NULL,true); pc = 6; continue; }
case 6: { pc=(ExecutableRuntime.equal(r[0],r[1]))?9:7; continue; }
case 7: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->MANUAL_SKIP:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;",Value.NULL,true); pc = 8; continue; }
case 8: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?20:9; continue; }
case 9: { r[0] = Value.i32(rt.length(r[5])); pc = 10; continue; }
case 10: { r[1] = Value.i32(0); pc = 11; continue; }
case 11: { pc=(r[1].i() >= r[0].i())?20:12; continue; }
case 12: { r[2] = rt.arrayGet(r[5],r[1].i()); pc = 13; continue; }
case 13: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[2],false); pc = 14; continue; }
case 14: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 15; continue; }
case 15: { pc=(!ExecutableRuntime.equal(r[3],r[4]))?18:16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[2]); pc = 17; continue; }
case 17: { return Value.VOID; }
case 18: { r[1] = Value.i32((r[1].i()) + (1)); pc = 19; continue; }
case 19: { pc=11; continue; }
case 20: { r[5] = Value.i32(0); pc = 21; continue; }
case 21: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[5]); pc = 22; continue; }
case 22: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7fa0f9c02e1c5630bd3b1424(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Showing segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_869c5111ab665506006cdafc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Landroid/util/Range;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Setting new undo range to: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_95d0efd4be68660cb07e1cce(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Landroid/util/Range;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Extending undo range from: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { r[1] = Value.ref(" to: "); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 9; continue; }
case 9: { r[2] = result; pc = 10; continue; }
case 10: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_dd16d597c701846b0058e5ed(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[1], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Scheduling hide segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = Value.ref(" playbackSpeed: "); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_31c47124ea0ff1a50709507b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Clearing scheduled hide: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledHideSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_84677026665c45ff5b16806a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring segment that ends very soon: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9243a2e62954097f9fadfbc0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?11:1; continue; }
case 1: { r[0] = Value.i32(4); pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[1],r[0]))?9:3; continue; }
case 3: { r[0] = Value.i32(8); pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[1],r[0]))?7:5; continue; }
case 5: { r[1] = Value.ref("UNKNOWN"); pc = 6; continue; }
case 6: { pc=12; continue; }
case 7: { r[1] = Value.ref("GONE"); pc = 8; continue; }
case 8: { pc=12; continue; }
case 9: { r[1] = Value.ref("INVISIBLE"); pc = 10; continue; }
case 10: { pc=12; continue; }
case 11: { r[1] = Value.ref("VISIBLE"); pc = 12; continue; }
case 12: { r[0] = Value.ref("AdProgressText visibility changed to: "); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;",r[0],new Value[]{r[1]}); pc = 14; continue; }
case 14: { r[1] = result; pc = 15; continue; }
case 15: { return rt.check(r[1],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c132e58f36f85724ee4118cf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("drawSponsorTimeBars failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_05e8431b56df90129f7fc016(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("skipSegment failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_709d7ff2ad80282ff10ae8d8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Ignoring Short"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_17075b8f019e437538fee01f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Clearing undo range as current time is now outside range: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRange:Landroid/util/Range;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3badab1f25c7c2ae5d475482(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Clearing scheduled segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledUpcomingSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7defde83f94798ff36138e41(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Initialized SponsorBlock"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e1d97f7ea2f8fbafd58b5383(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Hiding segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_af1cf9c133602c234c7370b3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("appendTimeWithoutSegments failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3d146197a2ea21e6de8aabe3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Auto hiding skip button for segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d24e42facdd9985ed3a58d2a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Could not skip segment (seek unsuccessful): "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fccffd2255ea920bbb671da8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Skipping segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = Value.ref(" videoState: "); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/VideoState;->getCurrent()Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[2] = result; pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_118c32d5a1add7eba05546f9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("setVideoTime failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1dbd28b4a824fecab2a54c90(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring skip segment request (already skipped as close as possible): "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ecdfcedb27e242581f05f153(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Not scheduling segment (start time is near end of current segment): "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_033b3fcbfe45802794293e75(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[1], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Scheduling segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = Value.ref(" playbackSpeed: "); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ce9e8bbdfbef2dbba5d1c43c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("setCurrentVideoId failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_351402bf9f87a8efb251304e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "I");
r[3] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("setSeekbarRectangle left: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = Value.ref(" right: "); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c47a6afb6e49ce325225718e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("initialize failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7d70cafa35d0b370481c31b5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Network not connected, ignoring video"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ee14f49818dd45aa75fc718c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("New video ID: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1f8cdf0edac19dc69edb1502(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Resetting hide skip button: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_78390e0471ae358fb95bbd0b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "J"); r[3] = r[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("setVideoTime: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f8675b34ade3d407bdc2b7c4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring previously auto-hidden segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_56514bd3a30d88843ed481e0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_PICTURE_IN_PICTURE:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[1],r[0]))?8:2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->dismissUndoToast()Z",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?8:5; continue; }
case 5: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda45;"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda45;-><init>()V",r[1],new Value[]{}); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;",Value.NULL,true); pc = 9; continue; }
case 9: { return rt.check(r[1],"Lkotlin/Unit;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e82ec6a28f89a84942a79c5d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[15];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoLength()J",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; r[1] = r[0]; pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_VIDEO_LENGTH_WITHOUT_SEGMENTS:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[2],new Value[]{}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[2],new Value[]{}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { r[3] = Value.i32(0); pc = 8; continue; }
case 8: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?87:9; continue; }
case 9: { r[4] = Value.i64(0L); r[5] = r[4]; pc = 10; continue; }
case 10: { r[2] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[4].j())); pc = 11; continue; }
case 11: { pc=(r[2].i() <= 0)?87:12; continue; }
case 12: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 13; continue; }
case 13: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?87:14; continue; }
case 14: { r[6] = Value.i32(rt.length(r[2])); pc = 15; continue; }
case 15: { pc=(!ExecutableRuntime.equal(r[6],Value.i32(0)))?17:16; continue; }
case 16: { pc=87; continue; }
case 17: { r[2] = Value.i32(rt.length(r[2])); pc = 18; continue; }
case 18: { r[6] = Value.i32(0); pc = 19; continue; }
case 19: { r[7] = r[6]; pc = 20; continue; }
case 20: { r[8] = r[7]; pc = 21; continue; }
case 21: { pc=(r[7].i() >= r[2].i())?47:22; continue; }
case 22: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 23; continue; }
case 23: { r[9] = rt.arrayGet(r[9],r[7].i()); pc = 24; continue; }
case 24: { r[10] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[9],false); pc = 25; continue; }
case 25: { r[11] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 26; continue; }
case 26: { pc=(!ExecutableRuntime.equal(r[10],r[11]))?28:27; continue; }
case 27: { pc=45; continue; }
case 28: { r[10] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[9],false); r[11] = r[10]; pc = 29; continue; }
case 29: { r[8] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[9],false); r[9] = r[8]; pc = 30; continue; }
case 30: { r[12] = r[6]; pc = 31; continue; }
case 31: { pc=(r[12].i() >= r[7].i())?39:32; continue; }
case 32: { r[13] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 33; continue; }
case 33: { r[13] = rt.arrayGet(r[13],r[12].i()); pc = 34; continue; }
case 34: { r[13] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[13],false); r[14] = r[13]; pc = 35; continue; }
case 35: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Math;->max(JJ)J",Value.NULL,new Value[]{r[10], r[13]}); pc = 36; continue; }
case 36: { r[10] = result; r[11] = r[10]; pc = 37; continue; }
case 37: { r[12] = Value.i32((r[12].i()) + (1)); pc = 38; continue; }
case 38: { pc=31; continue; }
case 39: { r[12] = Value.i32(ExecutableRuntime.compareLong(r[10].j(), r[8].j())); pc = 40; continue; }
case 40: { r[13] = Value.i32(1); pc = 41; continue; }
case 41: { pc=(r[12].i() >= 0)?44:42; continue; }
case 42: { r[8] = Value.i64((r[8].j()) - (r[10].j())); r[9] = r[8]; pc = 43; continue; }
case 43: { r[0] = Value.i64((r[0].j()) - (r[8].j())); r[1] = r[0]; pc = 44; continue; }
case 44: { r[8] = r[13]; pc = 45; continue; }
case 45: { r[7] = Value.i32((r[7].i()) + (1)); pc = 46; continue; }
case 46: { pc=21; continue; }
case 47: { pc=(!ExecutableRuntime.equal(r[8],Value.i32(0)))?50:48; continue; }
case 48: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->timeWithoutSegments:Ljava/lang/String;",Value.NULL,true,r[3]); pc = 49; continue; }
case 49: { return Value.VOID; }
case 50: { r[2] = Value.i64(3600000L); r[3] = r[2]; pc = 51; continue; }
case 51: { r[2] = Value.i64((r[0].j()) / (r[2].j())); r[3] = r[2]; pc = 52; continue; }
case 52: { r[6] = Value.i64(60000L); r[7] = r[6]; pc = 53; continue; }
case 53: { r[6] = Value.i64((r[0].j()) / (r[6].j())); r[7] = r[6]; pc = 54; continue; }
case 54: { r[8] = Value.i64(60L); r[9] = r[8]; pc = 55; continue; }
case 55: { r[6] = Value.i64((r[6].j()) % (r[8].j())); r[7] = r[6]; pc = 56; continue; }
case 56: { r[10] = Value.i64(1000L); r[11] = r[10]; pc = 57; continue; }
case 57: { r[0] = Value.i64((r[0].j()) / (r[10].j())); r[1] = r[0]; pc = 58; continue; }
case 58: { r[0] = Value.i64((r[0].j()) % (r[8].j())); r[1] = r[0]; pc = 59; continue; }
case 59: { r[4] = Value.i32(ExecutableRuntime.compareLong(r[2].j(), r[4].j())); pc = 60; continue; }
case 60: { pc=(r[4].i() <= 0)?75:61; continue; }
case 61: { r[4] = rt.readField("Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;",Value.NULL,true); pc = 62; continue; }
case 62: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[2]}); pc = 63; continue; }
case 63: { r[2] = result; pc = 64; continue; }
case 64: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[6]}); pc = 65; continue; }
case 65: { r[3] = result; pc = 66; continue; }
case 66: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[0]}); pc = 67; continue; }
case 67: { r[0] = result; pc = 68; continue; }
case 68: { result=rt.filledArray("[Ljava/lang/Object;",new Value[]{r[2], r[3], r[0]}); pc = 69; continue; }
case 69: { r[0] = result; pc = 70; continue; }
case 70: { r[1] = Value.ref("\u2009(%d:%02d:%02d)"); pc = 71; continue; }
case 71: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[4], r[1], r[0]}); pc = 72; continue; }
case 72: { r[0] = result; pc = 73; continue; }
case 73: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->timeWithoutSegments:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 74; continue; }
case 74: { return Value.VOID; }
case 75: { r[2] = rt.readField("Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;",Value.NULL,true); pc = 76; continue; }
case 76: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[6]}); pc = 77; continue; }
case 77: { r[3] = result; pc = 78; continue; }
case 78: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[0]}); pc = 79; continue; }
case 79: { r[0] = result; pc = 80; continue; }
case 80: { result=rt.filledArray("[Ljava/lang/Object;",new Value[]{r[3], r[0]}); pc = 81; continue; }
case 81: { r[0] = result; pc = 82; continue; }
case 82: { r[1] = Value.ref("\u2009(%d:%02d)"); pc = 83; continue; }
case 83: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[2], r[1], r[0]}); pc = 84; continue; }
case 84: { r[0] = result; pc = 85; continue; }
case 85: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->timeWithoutSegments:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 86; continue; }
case 86: { return Value.VOID; }
case 87: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->timeWithoutSegments:Ljava/lang/String;",Value.NULL,true,r[3]); pc = 88; continue; }
case 88: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6d97105d3a15ce009ff66796(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegmentButtonEndTime:J",Value.NULL,true); r[1] = r[0]; pc = 1; continue; }
case 1: { r[2] = Value.i64(0L); r[3] = r[2]; pc = 2; continue; }
case 2: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[2].j())); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?13:4; continue; }
case 4: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_AUTO_HIDE_SKIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?11:10; continue; }
case 10: { pc=13; continue; }
case 11: { r[0] = Value.i32(0); pc = 12; continue; }
case 12: { return rt.check(r[0],"Z"); }
case 13: { r[0] = Value.i32(1); pc = 14; continue; }
case 14: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0c515e72b94cf319ca84faa7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segmentCurrentlyPlaying:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?9:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->hiddenSkipSegmentsForCurrentVideoTime:Ljava/util/List;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/List;->isEmpty()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?7:6; continue; }
case 6: { pc=9; continue; }
case 7: { r[0] = Value.i32(0); pc = 8; continue; }
case 8: { return rt.check(r[0],"Z"); }
case 9: { r[0] = Value.i32(1); pc = 10; continue; }
case 10: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2978fdad806da4057d47353e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastDialogRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"Landroid/app/Dialog;"); pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?11:5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;->isShowing()Z",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[1] = result; pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?11:8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;->dismiss()V",r[0],new Value[]{}); pc = 9; continue; }
case 9: { r[0] = Value.i32(1); pc = 10; continue; }
case 10: { return rt.check(r[0],"Z"); }
case 11: { r[0] = Value.i32(0); pc = 12; continue; }
case 12: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e1d6a9df5d44a211cd7d267b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->segments:[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?6:2; continue; }
case 2: { r[0] = Value.i32(rt.length(r[0])); pc = 3; continue; }
case 3: { pc=(r[0].i() <= 0)?6:4; continue; }
case 4: { r[0] = Value.i32(1); pc = 5; continue; }
case 5: { return rt.check(r[0],"Z"); }
case 6: { r[0] = Value.i32(0); pc = 7; continue; }
case 7: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ba417727c25312d92f999f31(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Dismissed undo toast as playback is PiP"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_239a08bb53dab098efafb90b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->executeDownloadSegments(Ljava/lang/String;)V",Value.NULL,new Value[]{r[1]}); pc = 1; continue; }
case 1: { return Value.VOID; }
case 2: { r[1] = Value.ref(exception); exception=null; pc = 3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda0;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda0;-><init>()V",r[0],new Value[]{}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[1]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 1) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=2; continue; } }
throw error;
}
}

}

static Value m_07ca7f33df98f2ef111fa1ed(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[3] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[4] = rt.check(arguments[1], "J"); r[5] = r[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledHideSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],r[3]))?6:2; continue; }
case 2: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda47;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda47;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[4],new Value[]{r[3]}); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[4]}); pc = 5; continue; }
case 5: { return Value.VOID; }
case 6: { r[0] = Value.i32(0); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledHideSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/VideoState;->getCurrent()Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,new Value[]{}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { r[2] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->PLAYING:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 11; continue; }
case 11: { pc=(ExecutableRuntime.equal(r[1],r[2]))?16:12; continue; }
case 12: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda48;"); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda48;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[4],new Value[]{r[3]}); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[4]}); pc = 15; continue; }
case 15: { return Value.VOID; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoTime()J",Value.NULL,new Value[]{}); pc = 17; continue; }
case 17: { r[1] = result; r[2] = r[1]; pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->endIsNear(JJ)Z",r[3],new Value[]{r[1], r[4]}); pc = 19; continue; }
case 19: { r[4] = result; pc = 20; continue; }
case 20: { pc=(!ExecutableRuntime.equal(r[4],Value.i32(0)))?25:21; continue; }
case 21: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda49;"); pc = 22; continue; }
case 22: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda49;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;J)V",r[4],new Value[]{r[3], r[1]}); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[4]}); pc = 24; continue; }
case 24: { return Value.VOID; }
case 25: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda50;"); pc = 26; continue; }
case 26: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda50;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[4],new Value[]{r[3]}); pc = 27; continue; }
case 27: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[4]}); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->setSegmentCurrentlyPlaying(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[0]}); pc = 29; continue; }
case 29: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->end:J",r[3],false); r[4] = r[3]; pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->setVideoTime(J)V",Value.NULL,new Value[]{r[3]}); pc = 31; continue; }
case 31: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0cfda73c48cb04b39673c257(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/VideoState;->getCurrent()Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[2] = result; pc = 4; continue; }
case 4: { r[3] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->PAUSED:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[2],r[3]))?14:6; continue; }
case 6: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda59;"); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda59;-><init>()V",r[2],new Value[]{}); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastNumberOfSegmentsSkipped:I",Value.NULL,true,r[1]); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastSegmentSkipped:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 11; continue; }
case 11: { return Value.VOID; }
case 12: { r[2] = Value.ref(exception); exception=null; pc = 13; continue; }
case 13: { pc=43; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/PlayerType;->getCurrent()Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,new Value[]{}); pc = 15; continue; }
case 15: { r[2] = result; pc = 16; continue; }
case 16: { r[3] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_PICTURE_IN_PICTURE:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 17; continue; }
case 17: { pc=(!ExecutableRuntime.equal(r[2],r[3]))?22:18; continue; }
case 18: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda60;"); pc = 19; continue; }
case 19: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda60;-><init>()V",r[2],new Value[]{}); pc = 20; continue; }
case 20: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 21; continue; }
case 21: { pc=9; continue; }
case 22: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastSegmentSkipped:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 23; continue; }
case 23: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?39:24; continue; }
case 24: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRangeToast:Landroid/util/Range;",Value.NULL,true); pc = 25; continue; }
case 25: { pc=(!ExecutableRuntime.equal(r[3],Value.i32(0)))?27:26; continue; }
case 26: { pc=39; continue; }
case 27: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastNumberOfSegmentsSkipped:I",Value.NULL,true); pc = 28; continue; }
case 28: { r[4] = Value.i32(1); pc = 29; continue; }
case 29: { pc=(!ExecutableRuntime.equal(r[3],r[4]))?33:30; continue; }
case 30: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->getSkippedToastText()Ljava/lang/String;",r[2],new Value[]{}); pc = 31; continue; }
case 31: { r[2] = result; pc = 32; continue; }
case 32: { pc=36; continue; }
case 33: { r[2] = Value.ref("revanced_sb_skipped_multiple_segments"); pc = 34; continue; }
case 34: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/StringRef;->str(Ljava/lang/String;)Ljava/lang/String;",Value.NULL,new Value[]{r[2]}); pc = 35; continue; }
case 35: { r[2] = result; pc = 36; continue; }
case 36: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->undoAutoSkipRangeToast:Landroid/util/Range;",Value.NULL,true); pc = 37; continue; }
case 37: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->showAutoSkipToast(Ljava/lang/String;Landroid/util/Range;)V",Value.NULL,new Value[]{r[2], r[3]}); pc = 38; continue; }
case 38: { pc=9; continue; }
case 39: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda61;"); pc = 40; continue; }
case 40: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda61;-><init>()V",r[2],new Value[]{}); pc = 41; continue; }
case 41: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 42; continue; }
case 42: { pc=9; continue; }
case 43: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastNumberOfSegmentsSkipped:I",Value.NULL,true,r[1]); pc = 44; continue; }
case 44: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastSegmentSkipped:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 45; continue; }
case 45: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 2 && pc < 9) { if(true) { exception=ExecutableRuntime.caught(error); pc=12; continue; } }
if(pc >= 14 && pc < 42) { if(true) { exception=ExecutableRuntime.caught(error); pc=12; continue; } }
throw error;
}
}

}

static Value m_4dabe84fa21cbff1d9025596(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[1], "J"); r[4] = r[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledUpcomingSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],r[2]))?6:2; continue; }
case 2: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda51;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda51;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[3],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[3]}); pc = 5; continue; }
case 5: { return Value.VOID; }
case 6: { r[0] = Value.i32(0); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->scheduledUpcomingSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/VideoState;->getCurrent()Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,new Value[]{}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { r[1] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState;->PLAYING:Lapp/revanced/extension/youtube/shared/VideoState;",Value.NULL,true); pc = 11; continue; }
case 11: { pc=(ExecutableRuntime.equal(r[0],r[1]))?16:12; continue; }
case 12: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda52;"); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda52;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[3],new Value[]{r[2]}); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[3]}); pc = 15; continue; }
case 15: { return Value.VOID; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoTime()J",Value.NULL,new Value[]{}); pc = 17; continue; }
case 17: { r[0] = result; r[1] = r[0]; pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->startIsNear(JJ)Z",r[2],new Value[]{r[0], r[3]}); pc = 19; continue; }
case 19: { r[3] = result; pc = 20; continue; }
case 20: { pc=(!ExecutableRuntime.equal(r[3],Value.i32(0)))?25:21; continue; }
case 21: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda53;"); pc = 22; continue; }
case 22: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda53;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;J)V",r[3],new Value[]{r[2], r[0]}); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[3]}); pc = 24; continue; }
case 24: { return Value.VOID; }
case 25: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->shouldAutoSkipAndUndoSkipNotActive(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;J)Z",Value.NULL,new Value[]{r[2], r[0]}); pc = 26; continue; }
case 26: { r[3] = result; pc = 27; continue; }
case 27: { pc=(ExecutableRuntime.equal(r[3],Value.i32(0)))?34:28; continue; }
case 28: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda54;"); pc = 29; continue; }
case 29: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda54;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[3],new Value[]{r[2]}); pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[3]}); pc = 31; continue; }
case 31: { r[3] = Value.i32(0); pc = 32; continue; }
case 32: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegment(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;Z)V",Value.NULL,new Value[]{r[2], r[3]}); pc = 33; continue; }
case 33: { return Value.VOID; }
case 34: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda55;"); pc = 35; continue; }
case 35: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda55;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[3],new Value[]{r[2]}); pc = 36; continue; }
case 36: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[3]}); pc = 37; continue; }
case 37: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->setSegmentCurrentlyPlaying(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[2]}); pc = 38; continue; }
case 38: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9a9c3c2abe277d8396539941(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[2]}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->verifyOffMainThread()V",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->getSegments(Ljava/lang/String;)[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,new Value[]{r[2]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda43;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda43;-><init>(Ljava/lang/String;[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[1],new Value[]{r[2], r[0]}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->runOnMainThread(Ljava/lang/Runnable;)V",Value.NULL,new Value[]{r[1]}); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_49014e06d9a7b8fea854ae90(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[12];
r[10] = rt.check(arguments[0], "Ljava/lang/String;");
r[11] = rt.check(arguments[1], "Landroid/util/Range;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[10]}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/shared/PlayerType;->getCurrent()Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->INLINE_MINIMAL:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?10:6; continue; }
case 6: { r[10] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda36;"); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda36;-><init>()V",r[10],new Value[]{}); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[10]}); pc = 9; continue; }
case 9: { return Value.VOID; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->getOverLaysViewGroupContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?17:13; continue; }
case 13: { r[11] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda37;"); pc = 14; continue; }
case 14: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda37;-><init>(Ljava/lang/String;)V",r[11],new Value[]{r[10]}); pc = 15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[11]}); pc = 16; continue; }
case 16: { return Value.VOID; }
case 17: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda38;"); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda38;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[10]}); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 20; continue; }
case 20: { r[1] = rt.allocate("Landroid/app/Dialog;"); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;-><init>(Landroid/content/Context;)V",r[1],new Value[]{r[0]}); pc = 22; continue; }
case 22: { r[2] = Value.i32(1); pc = 23; continue; }
case 23: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;->requestWindowFeature(I)Z",r[1],new Value[]{r[2]}); pc = 24; continue; }
case 24: { r[3] = Value.i32(0); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V",r[1],new Value[]{r[3]}); pc = 26; continue; }
case 26: { r[4] = rt.allocate("Landroid/widget/LinearLayout;"); pc = 27; continue; }
case 27: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V",r[4],new Value[]{r[0]}); pc = 28; continue; }
case 28: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/LinearLayout;->setOrientation(I)V",r[4],new Value[]{r[2]}); pc = 29; continue; }
case 29: { r[5] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp16:I",Value.NULL,true); pc = 30; continue; }
case 30: { r[6] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp8:I",Value.NULL,true); pc = 31; continue; }
case 31: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->setPadding(IIII)V",r[4],new Value[]{r[5], r[6], r[5], r[6]}); pc = 32; continue; }
case 32: { r[5] = Value.i32(17); pc = 33; continue; }
case 33: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/LinearLayout;->setGravity(I)V",r[4],new Value[]{r[5]}); pc = 34; continue; }
case 34: { r[6] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp48:I",Value.NULL,true); pc = 35; continue; }
case 35: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->setMinimumHeight(I)V",r[4],new Value[]{r[6]}); pc = 36; continue; }
case 36: { r[6] = rt.allocate("Landroid/graphics/drawable/ShapeDrawable;"); pc = 37; continue; }
case 37: { r[7] = rt.allocate("Landroid/graphics/drawable/shapes/RoundRectShape;"); pc = 38; continue; }
case 38: { r[8] = Value.i32(1101004800); pc = 39; continue; }
case 39: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/ui/Dim;->roundedCorners(F)[F",Value.NULL,new Value[]{r[8]}); pc = 40; continue; }
case 40: { r[8] = result; pc = 41; continue; }
case 41: { r[9] = Value.i32(0); pc = 42; continue; }
case 42: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/graphics/drawable/shapes/RoundRectShape;-><init>([FLandroid/graphics/RectF;[F)V",r[7],new Value[]{r[8], r[9], r[9]}); pc = 43; continue; }
case 43: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/graphics/drawable/ShapeDrawable;-><init>(Landroid/graphics/drawable/shapes/Shape;)V",r[6],new Value[]{r[7]}); pc = 44; continue; }
case 44: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/graphics/drawable/ShapeDrawable;->getPaint()Landroid/graphics/Paint;",r[6],new Value[]{}); pc = 45; continue; }
case 45: { r[7] = result; pc = 46; continue; }
case 46: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->getDialogBackgroundColor()I",Value.NULL,new Value[]{}); pc = 47; continue; }
case 47: { r[8] = result; pc = 48; continue; }
case 48: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/graphics/Paint;->setColor(I)V",r[7],new Value[]{r[8]}); pc = 49; continue; }
case 49: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V",r[4],new Value[]{r[6]}); pc = 50; continue; }
case 50: { r[6] = rt.allocate("Landroid/widget/TextView;"); pc = 51; continue; }
case 51: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/TextView;-><init>(Landroid/content/Context;)V",r[6],new Value[]{r[0]}); pc = 52; continue; }
case 52: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V",r[6],new Value[]{r[10]}); pc = 53; continue; }
case 53: { r[10] = Value.i32(1096810496); pc = 54; continue; }
case 54: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/TextView;->setTextSize(F)V",r[6],new Value[]{r[10]}); pc = 55; continue; }
case 55: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->getAppForegroundColor()I",Value.NULL,new Value[]{}); pc = 56; continue; }
case 56: { r[10] = result; pc = 57; continue; }
case 57: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/TextView;->setTextColor(I)V",r[6],new Value[]{r[10]}); pc = 58; continue; }
case 58: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/TextView;->setGravity(I)V",r[6],new Value[]{r[5]}); pc = 59; continue; }
case 59: { r[10] = rt.allocate("Landroid/widget/LinearLayout$LayoutParams;"); pc = 60; continue; }
case 60: { r[0] = Value.i32(-2); pc = 61; continue; }
case 61: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V",r[10],new Value[]{r[0], r[0]}); pc = 62; continue; }
case 62: { rt.writeField("Landroid/widget/LinearLayout$LayoutParams;->gravity:I",r[10],false,r[5]); pc = 63; continue; }
case 63: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V",r[6],new Value[]{r[10]}); pc = 64; continue; }
case 64: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/ViewGroup;->addView(Landroid/view/View;)V",r[4],new Value[]{r[6]}); pc = 65; continue; }
case 65: { r[10] = Value.i32(1061997773); pc = 66; continue; }
case 66: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->setAlpha(F)V",r[4],new Value[]{r[10]}); pc = 67; continue; }
case 67: { r[10] = Value.ref("fade_duration_fast"); pc = 68; continue; }
case 68: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->getResourceInteger(Ljava/lang/String;)I",Value.NULL,new Value[]{r[10]}); pc = 69; continue; }
case 69: { r[10] = result; pc = 70; continue; }
case 70: { r[0] = Value.ref("fade_in"); pc = 71; continue; }
case 71: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->getResourceAnimation(Ljava/lang/String;)Landroid/view/animation/Animation;",Value.NULL,new Value[]{r[0]}); pc = 72; continue; }
case 72: { r[0] = result; pc = 73; continue; }
case 73: { r[5] = Value.ref("fade_out"); pc = 74; continue; }
case 74: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->getResourceAnimation(Ljava/lang/String;)Landroid/view/animation/Animation;",Value.NULL,new Value[]{r[5]}); pc = 75; continue; }
case 75: { r[5] = result; pc = 76; continue; }
case 76: { r[6] = Value.i64((long)(r[10].i())); r[7] = r[6]; pc = 77; continue; }
case 77: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/animation/Animation;->setDuration(J)V",r[0],new Value[]{r[6]}); pc = 78; continue; }
case 78: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/animation/Animation;->setDuration(J)V",r[5],new Value[]{r[6]}); pc = 79; continue; }
case 79: { r[10] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$1;"); pc = 80; continue; }
case 80: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$1;-><init>(Landroid/app/Dialog;)V",r[10],new Value[]{r[1]}); pc = 81; continue; }
case 81: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/animation/Animation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V",r[5],new Value[]{r[10]}); pc = 82; continue; }
case 82: { r[10] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda39;"); pc = 83; continue; }
case 83: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda39;-><init>(Landroid/util/Range;Landroid/widget/LinearLayout;Landroid/view/animation/Animation;Landroid/app/Dialog;)V",r[10],new Value[]{r[11], r[4], r[5], r[1]}); pc = 84; continue; }
case 84: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V",r[4],new Value[]{r[10]}); pc = 85; continue; }
case 85: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->setClickable(Z)V",r[4],new Value[]{r[2]}); pc = 86; continue; }
case 86: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;->setContentView(Landroid/view/View;)V",r[1],new Value[]{r[4]}); pc = 87; continue; }
case 87: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;->getWindow()Landroid/view/Window;",r[1],new Value[]{}); pc = 88; continue; }
case 88: { r[10] = result; pc = 89; continue; }
case 89: { pc=(ExecutableRuntime.equal(r[10],Value.i32(0)))?99:90; continue; }
case 90: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/Window;->setWindowAnimations(I)V",r[10],new Value[]{r[3]}); pc = 91; continue; }
case 91: { r[11] = Value.i32(32); pc = 92; continue; }
case 92: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/Window;->addFlags(I)V",r[10],new Value[]{r[11]}); pc = 93; continue; }
case 93: { r[11] = Value.i32(262144); pc = 94; continue; }
case 94: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/Window;->addFlags(I)V",r[10],new Value[]{r[11]}); pc = 95; continue; }
case 95: { r[11] = Value.i32(72); pc = 96; continue; }
case 96: { r[3] = Value.i32(60); pc = 97; continue; }
case 97: { r[6] = Value.i32(80); pc = 98; continue; }
case 98: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->setDialogWindowParameters(Landroid/view/Window;IIIZ)V",Value.NULL,new Value[]{r[10], r[6], r[11], r[3], r[2]}); pc = 99; continue; }
case 99: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->dismissUndoToast()Z",Value.NULL,new Value[]{}); pc = 100; continue; }
case 100: { r[10] = result; pc = 101; continue; }
case 101: { pc=(ExecutableRuntime.equal(r[10],Value.i32(0)))?105:102; continue; }
case 102: { r[10] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda40;"); pc = 103; continue; }
case 103: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda40;-><init>()V",r[10],new Value[]{}); pc = 104; continue; }
case 104: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[10]}); pc = 105; continue; }
case 105: { r[10] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 106; continue; }
case 106: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[10],new Value[]{r[1]}); pc = 107; continue; }
case 107: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->toastDialogRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[10]); pc = 108; continue; }
case 108: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V",r[4],new Value[]{r[0]}); pc = 109; continue; }
case 109: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;->show()V",r[1],new Value[]{}); pc = 110; continue; }
case 110: { r[10] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;"); pc = 111; continue; }
case 111: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda41;-><init>(Landroid/app/Dialog;Landroid/widget/LinearLayout;Landroid/view/animation/Animation;)V",r[10],new Value[]{r[1], r[4], r[5]}); pc = 112; continue; }
case 112: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->getToastDuration()J",Value.NULL,new Value[]{}); pc = 113; continue; }
case 113: { r[0] = result; r[1] = r[0]; pc = 114; continue; }
case 114: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Utils;->runOnMainThreadDelayed(Ljava/lang/Runnable;J)V",Value.NULL,new Value[]{r[10], r[0]}); pc = 115; continue; }
case 115: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_adf994754ded3229009978f4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Failed to download segments"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f52855a08c8480ed7680eda4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring scheduled hide segment as video is paused: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_626ec9ad589409f29450809e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Running scheduled hide segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2befff33f0e1418e327d6266(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[1], "J"); r[4] = r[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring outdated scheduled hide: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = Value.ref(" videoInformation time: "); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0ac4285e7227fd9428c2aacd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring old scheduled hide segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_86acb2a57f4cd461a006bad8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_TOAST_ON_SKIP_DURATION:Lapp/revanced/extension/shared/settings/EnumSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->-$$Nest$fgetadjustedDuration(Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;)J",Value.NULL,new Value[]{r[0]}); pc = 5; continue; }
case 5: { r[0] = result; r[1] = r[0]; pc = 6; continue; }
case 6: { return rt.check(r[0],"J"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4067bd31e977389932231cf7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Ignoring scheduled toast as video state is paused"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e4dfeaf2314c86e27786656c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Ignoring old scheduled show toast"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_041975a810b15b384b097eeb(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Not showing autoskip toast as playback is PiP"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b9666bb5658bc0a14dcdf65e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Running scheduled skip segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5eca14f77aa6433d98b2c5a0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Running scheduled show segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_dfceeb3c11167b241e4d4037(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[1], "J"); r[4] = r[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring outdated scheduled segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = Value.ref(" videoInformation time: "); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b83d6daeb042448bf6688946(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring scheduled hide segment as video is paused: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d2014e7dab6a8d28068c9a16(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring old scheduled segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_086f04a345d73009cdd59eea(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
r[7] = rt.check(arguments[0], "Ljava/lang/String;");
r[8] = rt.check(arguments[1], "[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->currentVideoId:Ljava/lang/String;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/String;->equals(Ljava/lang/Object;)Z",r[7],new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?8:4; continue; }
case 4: { r[8] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda56;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda56;-><init>(Ljava/lang/String;)V",r[8],new Value[]{r[7]}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[8]}); pc = 7; continue; }
case 7: { return Value.VOID; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->setSegments([Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[8]}); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoTime()J",Value.NULL,new Value[]{}); pc = 10; continue; }
case 10: { r[7] = result; r[8] = r[7]; pc = 11; continue; }
case 11: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 12; continue; }
case 12: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?38:13; continue; }
case 13: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->start:J",r[0],false); r[2] = r[1]; pc = 14; continue; }
case 14: { r[1] = Value.i64((r[1].j()) - (r[7].j())); r[2] = r[1]; pc = 15; continue; }
case 15: { r[3] = Value.i64(0L); r[4] = r[3]; pc = 16; continue; }
case 16: { r[3] = Value.i32(ExecutableRuntime.compareLong(r[1].j(), r[3].j())); pc = 17; continue; }
case 17: { pc=(r[3].i() <= 0)?38:18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->shouldAutoSkip()Z",r[0],new Value[]{}); pc = 19; continue; }
case 19: { r[0] = result; pc = 20; continue; }
case 20: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?25:21; continue; }
case 21: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 22; continue; }
case 22: { r[8] = Value.i32(0); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->skipSegment(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;Z)V",Value.NULL,new Value[]{r[7], r[8]}); pc = 24; continue; }
case 24: { return Value.VOID; }
case 25: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 26; continue; }
case 26: { r[3] = result; r[4] = r[3]; pc = 27; continue; }
case 27: { r[0] = Value.f32((float)(r[1].j())); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getPlaybackSpeed()F",Value.NULL,new Value[]{}); pc = 29; continue; }
case 29: { r[1] = result; pc = 30; continue; }
case 30: { r[0] = Value.f32((r[0].f()) / (r[1].f())); pc = 31; continue; }
case 31: { r[0] = Value.i64((long)(r[0].f())); r[1] = r[0]; pc = 32; continue; }
case 32: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->getSkipButtonDuration()J",Value.NULL,new Value[]{}); pc = 33; continue; }
case 33: { r[5] = result; r[6] = r[5]; pc = 34; continue; }
case 34: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/Math;->min(JJ)J",Value.NULL,new Value[]{r[0], r[5]}); pc = 35; continue; }
case 35: { r[0] = result; r[1] = r[0]; pc = 36; continue; }
case 36: { r[3] = Value.i64((r[3].j()) + (r[0].j())); r[4] = r[3]; pc = 37; continue; }
case 37: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->highlightSegmentInitialShowEndTime:J",Value.NULL,true,r[3]); pc = 38; continue; }
case 38: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->setVideoTime(J)V",Value.NULL,new Value[]{r[7]}); pc = 39; continue; }
case 39: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e6fa52f0299225e135ac1a34(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Showing toast: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b006f370cfb1c6de194e8989(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Not showing undo toast for feed playback"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e0b39bd6b6c2ca472a682961(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Dismissed previous skip toast that was still on screen"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3fed07a0579b255efbbfd7e0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Cannot show toast (context is null): "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b95b2ac47162215197b2343f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(arguments[0], "Landroid/app/Dialog;");
r[1] = rt.check(arguments[1], "Landroid/widget/LinearLayout;");
r[2] = rt.check(arguments[2], "Landroid/view/animation/Animation;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/app/Dialog;->isShowing()Z",r[0],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?4:3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V",r[1],new Value[]{r[2]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6730a6aed175e8ece1c1e7d4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring segments for prior video: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
