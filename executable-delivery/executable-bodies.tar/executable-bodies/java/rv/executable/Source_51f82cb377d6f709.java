package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_51f82cb377d6f709 extends RuntimeForeign.SourceProxy {
Source_51f82cb377d6f709(RuntimeForeign owner,Instance source){super(owner,source);}

}
