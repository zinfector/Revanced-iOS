package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_b38af2590aa00986e693 {
static ClassInfo info_b38af2590aa00986e693() {return new ClassInfo("Lkotlin/collections/EmptyList$$ExternalSyntheticBUOutline0;", "Ljava/lang/Object;", new String[]{}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("m(Ljava/lang/String;ILjava/lang/Object;I)V", 4105)}, "EmptyList$$ExternalSyntheticBUOutline0");}
}
