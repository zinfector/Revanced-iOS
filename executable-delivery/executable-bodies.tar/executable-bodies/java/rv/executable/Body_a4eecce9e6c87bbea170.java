package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_a4eecce9e6c87bbea170 {
static Value m_650f7233dacacf37d5aca161(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda39;");
r[1] = rt.check(arguments[0], "Landroid/util/Range;");
r[2] = rt.check(arguments[1], "Landroid/widget/LinearLayout;");
r[3] = rt.check(arguments[2], "Landroid/view/animation/Animation;");
r[4] = rt.check(arguments[3], "Landroid/app/Dialog;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda39;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda39;->f$0:Landroid/util/Range;",r[0],false,r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda39;->f$1:Landroid/widget/LinearLayout;",r[0],false,r[2]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda39;->f$2:Landroid/view/animation/Animation;",r[0],false,r[3]); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda39;->f$3:Landroid/app/Dialog;",r[0],false,r[4]); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
