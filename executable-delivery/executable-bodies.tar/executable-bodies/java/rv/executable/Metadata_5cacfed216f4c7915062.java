package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_5cacfed216f4c7915062 {
static ClassInfo info_5cacfed216f4c7915062() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticApiModelOutline0;", "Ljava/lang/Object;", new String[]{}, 5121, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("m(J)Landroid/content/pm/PackageManager$PackageInfoFlags;", 4169)}, "Utils$$ExternalSyntheticApiModelOutline0");}
}
