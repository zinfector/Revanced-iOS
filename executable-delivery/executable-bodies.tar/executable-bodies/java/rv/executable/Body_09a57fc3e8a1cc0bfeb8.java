package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_09a57fc3e8a1cc0bfeb8 {
static Value m_5b366f9b3b6d73fcff80bb51(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc = (r[1].i() >= 0) ? 2 : 1; continue; }
case 1: { return rt.check(r[1], "I"); }
case 2: { r[0] = Value.i32(3); pc = 3; continue; }
case 3: { pc = (r[1].i() >= r[0].i()) ? 6 : 4; continue; }
case 4: { r[1] = Value.i32((r[1].i()) + (1)); pc = 5; continue; }
case 5: { return rt.check(r[1], "I"); }
case 6: { r[0] = Value.i32(1073741824); pc = 7; continue; }
case 7: { pc = (r[1].i() >= r[0].i()) ? 15 : 8; continue; }
case 8: { r[1] = Value.f32((float)(r[1].i())); pc = 9; continue; }
case 9: { r[0] = Value.i32(1061158912); pc = 10; continue; }
case 10: { r[1] = Value.f32((r[1].f()) / (r[0].f())); pc = 11; continue; }
case 11: { r[0] = Value.i32(1065353216); pc = 12; continue; }
case 12: { r[1] = Value.f32((r[1].f()) + (r[0].f())); pc = 13; continue; }
case 13: { r[1] = Value.i32((int)(r[1].f())); pc = 14; continue; }
case 14: { return rt.check(r[1], "I"); }
case 15: { r[1] = Value.i32(2147483647); pc = 16; continue; }
case 16: { return rt.check(r[1], "I"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
