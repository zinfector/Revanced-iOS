package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_832e7e3d77c140892476 {
static Value m_c817979a299a0fb5d62b0f10(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Landroid/content/Context;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->REVANCED_LANGUAGE:Lapp/revanced/extension/shared/settings/EnumSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->DEFAULT:Lapp/revanced/extension/shared/settings/AppLanguage;",Value.NULL,true); pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?7:6; continue; }
case 6: { return rt.check(r[2],"Landroid/content/Context;"); }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"Landroid/content/Context;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b6106800f8f039350147b263(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ID:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = Value.ref("revanced_settings_fragments"); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->ID_REVANCED_SETTINGS_FRAGMENTS:I",Value.NULL,true,r[1]); pc = 5; continue; }
case 5: { r[1] = Value.ref("revanced_toolbar_parent"); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->ID_REVANCED_TOOLBAR_PARENT:I",Value.NULL,true,r[0]); pc = 9; continue; }
case 9: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->LAYOUT:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 10; continue; }
case 10: { r[1] = Value.ref("revanced_settings_with_toolbar"); pc = 11; continue; }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 12; continue; }
case 12: { r[0] = result; pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->LAYOUT_REVANCED_SETTINGS_WITH_TOOLBAR:I",Value.NULL,true,r[0]); pc = 14; continue; }
case 14: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->STRING:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 15; continue; }
case 15: { r[1] = Value.ref("revanced_settings_title"); pc = 16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 17; continue; }
case 17: { r[0] = result; pc = 18; continue; }
case 18: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->STRING_REVANCED_SETTINGS_TITLE:I",Value.NULL,true,r[0]); pc = 19; continue; }
case 19: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6eab3b044a1dd230b4c609bf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/BaseActivityHook;");
r[3] = rt.check(arguments[1], "Landroid/app/Activity;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->customizeActivityTheme(Landroid/app/Activity;)V",r[2],new Value[]{r[3]}); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->getContentViewResourceId()I",r[2],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/Activity;->setContentView(I)V",r[3],new Value[]{r[0]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/Activity;->getIntent()Landroid/content/Intent;",r[3],new Value[]{}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/content/Intent;->getDataString()Ljava/lang/String;",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { r[1] = Value.ref("revanced_settings_intent"); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Ljava/lang/String;->equals(Ljava/lang/Object;)Z",r[1],new Value[]{r[0]}); pc = 10; continue; }
case 10: { r[1] = result; pc = 11; continue; }
case 11: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?16:12; continue; }
case 12: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda3;"); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda3;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[0]}); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 15; continue; }
case 15: { return Value.VOID; }
case 16: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->createPreferenceFragment()Landroid/preference/PreferenceFragment;",r[2],new Value[]{}); pc = 17; continue; }
case 17: { r[0] = result; pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->createToolbar(Landroid/app/Activity;Landroid/preference/PreferenceFragment;)V",r[2],new Value[]{r[3], r[0]}); pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;",r[3],new Value[]{}); pc = 20; continue; }
case 20: { r[2] = result; pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/FragmentManager;->beginTransaction()Landroid/app/FragmentTransaction;",r[2],new Value[]{}); pc = 22; continue; }
case 22: { r[2] = result; pc = 23; continue; }
case 23: { r[3] = rt.readField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->ID_REVANCED_SETTINGS_FRAGMENTS:I",Value.NULL,true); pc = 24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/FragmentTransaction;->replace(ILandroid/app/Fragment;)Landroid/app/FragmentTransaction;",r[2],new Value[]{r[3], r[0]}); pc = 25; continue; }
case 25: { r[2] = result; pc = 26; continue; }
case 26: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/FragmentTransaction;->commit()I",r[2],new Value[]{}); pc = 27; continue; }
case 27: { return Value.VOID; }
case 28: { r[2] = Value.ref(exception); exception=null; pc = 29; continue; }
case 29: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda4;"); pc = 30; continue; }
case 30: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda4;-><init>()V",r[3],new Value[]{}); pc = 31; continue; }
case 31: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[3], r[2]}); pc = 32; continue; }
case 32: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 27) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=28; continue; } }
throw error;
}
}

}

static Value m_2f169059a63c261af59c8859(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BaseActivityHook;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/Activity;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9ee304e824c4c4c6d71e0882(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BaseActivityHook;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->LAYOUT_REVANCED_SETTINGS_WITH_TOOLBAR:I",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_89ae72332ee58279be178ff1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BaseActivityHook;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Landroid/preference/PreferenceFragment;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_965142181181abf5ab67b41f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
r[5] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BaseActivityHook;");
r[6] = rt.check(arguments[0], "Landroid/app/Activity;");
r[7] = rt.check(arguments[1], "Landroid/preference/PreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->ID_REVANCED_TOOLBAR_PARENT:I",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/Activity;->findViewById(I)Landroid/view/View;",r[6],new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"Landroid/view/ViewGroup;"); pc = 4; continue; }
case 4: { r[1] = Value.ref("revanced_toolbar"); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Utils;->getChildViewByResourceName(Landroid/view/View;Ljava/lang/String;)Landroid/view/View;",Value.NULL,new Value[]{r[0], r[1]}); pc = 6; continue; }
case 6: { r[1] = result; pc = 7; continue; }
case 7: { r[1] = rt.cast(r[1],"Landroid/view/ViewGroup;"); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;",r[1],new Value[]{}); pc = 9; continue; }
case 9: { r[2] = result; pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->toolbarLayoutParams:Landroid/view/ViewGroup$LayoutParams;",Value.NULL,true,r[2]); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V",r[0],new Value[]{r[1]}); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/app/Activity;->getWindow()Landroid/view/Window;",r[6],new Value[]{}); pc = 13; continue; }
case 13: { r[1] = result; pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;->setNavigationBarColor(Landroid/view/Window;)V",Value.NULL,new Value[]{r[1]}); pc = 15; continue; }
case 15: { r[1] = rt.allocate("Landroid/widget/Toolbar;"); pc = 16; continue; }
case 16: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/view/View;->getContext()Landroid/content/Context;",r[0],new Value[]{}); pc = 17; continue; }
case 17: { r[2] = result; pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/widget/Toolbar;-><init>(Landroid/content/Context;)V",r[1],new Value[]{r[2]}); pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->getToolbarBackgroundColor()I",r[5],new Value[]{}); pc = 20; continue; }
case 20: { r[2] = result; pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/view/View;->setBackgroundColor(I)V",r[1],new Value[]{r[2]}); pc = 22; continue; }
case 22: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->getNavigationIcon()Landroid/graphics/drawable/Drawable;",r[5],new Value[]{}); pc = 23; continue; }
case 23: { r[2] = result; pc = 24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/widget/Toolbar;->setNavigationIcon(Landroid/graphics/drawable/Drawable;)V",r[1],new Value[]{r[2]}); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->getNavigationClickListener(Landroid/app/Activity;)Landroid/view/View$OnClickListener;",r[5],new Value[]{r[6]}); pc = 26; continue; }
case 26: { r[2] = result; pc = 27; continue; }
case 27: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/widget/Toolbar;->setNavigationOnClickListener(Landroid/view/View$OnClickListener;)V",r[1],new Value[]{r[2]}); pc = 28; continue; }
case 28: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->STRING_REVANCED_SETTINGS_TITLE:I",Value.NULL,true); pc = 29; continue; }
case 29: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/widget/Toolbar;->setTitle(I)V",r[1],new Value[]{r[2]}); pc = 30; continue; }
case 30: { r[2] = rt.readField("Lapp/revanced/extension/shared/ui/Dim;->dp16:I",Value.NULL,true); pc = 31; continue; }
case 31: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticApiModelOutline0;->m(Landroid/widget/Toolbar;I)V",Value.NULL,new Value[]{r[1], r[2]}); pc = 32; continue; }
case 32: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticApiModelOutline1;->m(Landroid/widget/Toolbar;I)V",Value.NULL,new Value[]{r[1], r[2]}); pc = 33; continue; }
case 33: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda2;"); pc = 34; continue; }
case 34: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda2;-><init>()V",r[2],new Value[]{}); pc = 35; continue; }
case 35: { r[3] = Value.i32(0); pc = 36; continue; }
case 36: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Utils;->getChildView(Landroid/view/ViewGroup;ZLapp/revanced/extension/shared/Utils$MatchFilter;)Landroid/view/View;",Value.NULL,new Value[]{r[1], r[3], r[2]}); pc = 37; continue; }
case 37: { r[2] = result; pc = 38; continue; }
case 38: { r[2] = rt.cast(r[2],"Landroid/widget/TextView;"); pc = 39; continue; }
case 39: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?45:40; continue; }
case 40: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/Utils;->getAppForegroundColor()I",Value.NULL,new Value[]{}); pc = 41; continue; }
case 41: { r[4] = result; pc = 42; continue; }
case 42: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/widget/TextView;->setTextColor(I)V",r[2],new Value[]{r[4]}); pc = 43; continue; }
case 43: { r[4] = Value.i32(1101004800); pc = 44; continue; }
case 44: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/widget/TextView;->setTextSize(F)V",r[2],new Value[]{r[4]}); pc = 45; continue; }
case 45: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->setToolbarLayoutParams(Landroid/widget/Toolbar;)V",Value.NULL,new Value[]{r[1]}); pc = 46; continue; }
case 46: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->onPostToolbarSetup(Landroid/app/Activity;Landroid/widget/Toolbar;Landroid/preference/PreferenceFragment;)V",r[5],new Value[]{r[6], r[1], r[7]}); pc = 47; continue; }
case 47: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V",r[0],new Value[]{r[1], r[3]}); pc = 48; continue; }
case 48: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0b18895270bd91b742ce5625(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Landroid/widget/Toolbar;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseActivityHook;->toolbarLayoutParams:Landroid/view/ViewGroup$LayoutParams;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?3:2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V",r[1],new Value[]{r[0]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d01bb5329c5f4f5265c973cd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/BaseActivityHook;");
r[1] = rt.check(arguments[0], "Landroid/app/Activity;");
r[2] = rt.check(arguments[1], "Landroid/widget/Toolbar;");
r[3] = rt.check(arguments[2], "Landroid/preference/PreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_554d6792c3d32eeb7cf88623(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Unknown intent: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_14051ca60ce8d5a3da49acf1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("initialize failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_deccf6cc769e767ffe33ae62(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(rt.isInstance(r[0].o(),"Landroid/widget/TextView;")?1:0); pc = 1; continue; }
case 1: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
