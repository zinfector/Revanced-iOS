package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_3fd6e167bd89e61d4343 {
static Value m_5c13469672ea5c94eb957074(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("BEGINNING"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { r[3] = Value.i32(1); pc = 4; continue; }
case 4: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->BEGINNING:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, true, r[0]); pc = 6; continue; }
case 6: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;"); pc = 7; continue; }
case 7: { r[1] = Value.ref("MIDDLE"); pc = 8; continue; }
case 8: { r[2] = Value.i32(2); pc = 9; continue; }
case 9: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[3], r[2]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->MIDDLE:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, true, r[0]); pc = 11; continue; }
case 11: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;"); pc = 12; continue; }
case 12: { r[1] = Value.ref("END"); pc = 13; continue; }
case 13: { r[3] = Value.i32(3); pc = 14; continue; }
case 14: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->END:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, true, r[0]); pc = 16; continue; }
case 16: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->$values()[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, new Value[]{}); pc = 17; continue; }
case 17: { r[0] = result; pc = 18; continue; }
case 18: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->$VALUES:[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, true, r[0]); pc = 19; continue; }
case 19: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2fb74b08ce1062feb7b8426f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new VerifyError("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->altImageNumber:I", r[0], false, r[3]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_39468ae08e8b56f995babfed(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->BEGINNING:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->MIDDLE:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->END:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, true); pc = 3; continue; }
case 3: { result = rt.filledArray("[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", new Value[]{r[0], r[1], r[2]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
