package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_84eef341956c52c2ec5c {
static ClassInfo info_84eef341956c52c2ec5c() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticApiModelOutline1;", "Ljava/lang/Object;", new String[]{}, 5121, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("m(Landroid/content/pm/PackageManager;Ljava/lang/String;Landroid/content/pm/PackageManager$PackageInfoFlags;)Landroid/content/pm/PackageInfo;", 4169)});}
}
