package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_1448d2d00bb3815cfa3a {
static Value m_c652a910685cd4f3db5b58af(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;->f$0:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_23d7a0dc211b9a485de0aadf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;->f$0:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",r[1],false); pc = 1; continue; }
case 1: { r[2] = rt.cast(r[2],"Lapp/revanced/extension/youtube/shared/PlayerType;"); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->$r8$lambda$sTzyEdzOzrnRAtKmQD176GAZH4o(Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;Lapp/revanced/extension/youtube/shared/PlayerType;)Lkotlin/Unit;",Value.NULL,new Value[]{r[0], r[2]}); pc = 3; continue; }
case 3: { r[2] = result; pc = 4; continue; }
case 4: { return rt.check(r[2],"Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
