package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_c6f73c647a22095c extends RuntimeForeign.SourceProxy {
Source_c6f73c647a22095c(RuntimeForeign owner,Instance source){super(owner,source);}

}
