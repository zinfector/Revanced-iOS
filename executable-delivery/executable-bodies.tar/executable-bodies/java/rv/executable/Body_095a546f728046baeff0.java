package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_095a546f728046baeff0 {
static Value m_8b218aaf23d0936d43a22e20(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda0;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda0;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7ebe11d26c74d19304afe156(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda0;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda0;","Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton;->$r8$lambda$W-AlA_XyP_gO-xw8R8GXXE_C-CI()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
