package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_297cb4519d0e35fa8b25 {
static Value m_75f059343a902b39c65cfbcd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda20;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda20;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
