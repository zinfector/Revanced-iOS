package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_c0c95fdb6790efb6a5aa {
static Value m_74c8d4bbb50575a89cdd51db(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch;->userProvidedCustomIcon()Z", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc = (ExecutableRuntime.equal(r[0], Value.i32(0))) ? 5 : 3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->CUSTOM:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true); pc = 4; continue; }
case 4: { return rt.check(r[0], "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); }
case 5: { r[0] = rt.readField("Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;->ROUNDED:Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;", Value.NULL, true); pc = 6; continue; }
case 6: { return rt.check(r[0], "Lapp/revanced/extension/shared/patches/CustomBrandingPatch$BrandingTheme;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6bea8cd733acc5bd46ce15ce(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch;->userProvidedCustomName()Z", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc = (ExecutableRuntime.equal(r[0], Value.i32(0))) ? 6 : 3; continue; }
case 3: { result = rt.invoke("static", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch;", "Lapp/revanced/extension/shared/patches/CustomBrandingPatch;->numberOfPresetAppNames()I", Value.NULL, new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { return rt.check(r[0], "I"); }
case 6: { r[0] = Value.i32(2); pc = 7; continue; }
case 7: { return rt.check(r[0], "I"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7bbadedb9db76395f16ded2b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { return rt.check(r[0], "Z"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6116dfd5c7d9e7a8795e38c2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { return rt.check(r[0], "Z"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_40140a8a5feb51d242dcb323(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(1); pc = 1; continue; }
case 1: { return rt.check(r[0], "I"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
