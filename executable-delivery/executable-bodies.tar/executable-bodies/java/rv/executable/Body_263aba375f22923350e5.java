package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_263aba375f22923350e5 {
static Value m_95870b2156c7e97d2d25d110(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(arguments[0], "[Ljava/lang/Object;");
r[3] = rt.check(arguments[1], "Ljava/lang/Class;");
r[4] = rt.check(arguments[2], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/String;->length()I",r[4],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?6:4; continue; }
case 4: { r[4] = rt.newArray("[Ljava/lang/String;",r[1].i()); pc = 5; continue; }
case 5: { pc=9; continue; }
case 6: { r[0] = Value.ref(";"); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;",r[4],new Value[]{r[0]}); pc = 8; continue; }
case 8: { r[4] = result; pc = 9; continue; }
case 9: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 10; continue; }
case 10: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;-><init>()V",r[0],new Value[]{}); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/Class;->getSimpleName()Ljava/lang/String;",r[3],new Value[]{}); pc = 12; continue; }
case 12: { r[3] = result; pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 14; continue; }
case 14: { r[3] = Value.ref("["); pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 16; continue; }
case 16: { r[3] = Value.i32(rt.length(r[4])); pc = 17; continue; }
case 17: { pc=(r[1].i() >= r[3].i())?31:18; continue; }
case 18: { r[3] = rt.arrayGet(r[4],r[1].i()); pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 20; continue; }
case 20: { r[3] = Value.ref("="); pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 22; continue; }
case 22: { r[3] = rt.arrayGet(r[2],r[1].i()); pc = 23; continue; }
case 23: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 24; continue; }
case 24: { r[3] = Value.i32(rt.length(r[4])); pc = 25; continue; }
case 25: { r[3] = Value.i32((r[3].i()) + (-1)); pc = 26; continue; }
case 26: { pc=(ExecutableRuntime.equal(r[1],r[3]))?29:27; continue; }
case 27: { r[3] = Value.ref(", "); pc = 28; continue; }
case 28: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 29; continue; }
case 29: { r[1] = Value.i32((r[1].i()) + (1)); pc = 30; continue; }
case 30: { pc=16; continue; }
case 31: { r[2] = Value.ref("]"); pc = 32; continue; }
case 32: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 33; continue; }
case 33: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController$PreferenceFragmentAdapter$$ExternalSyntheticRecord0;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 34; continue; }
case 34: { r[2] = result; pc = 35; continue; }
case 35: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
