package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8a25d632c7f7a92b3299 {
static ClassInfo info_8a25d632c7f7a92b3299() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda9;", "Ljava/lang/Object;", new String[]{"Landroid/content/DialogInterface$OnClickListener;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("onClick(Landroid/content/DialogInterface;I)V", 17)}, "SponsorBlockUtils$$ExternalSyntheticLambda9");}
}
