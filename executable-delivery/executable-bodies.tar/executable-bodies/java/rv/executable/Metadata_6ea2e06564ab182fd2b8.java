package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_6ea2e06564ab182fd2b8 {
static ClassInfo info_6ea2e06564ab182fd2b8() {return new ClassInfo("Lkotlin/collections/AbstractList$IteratorImpl;", "Ljava/lang/Object;", new String[]{"Ljava/util/Iterator;"}, 1, new FieldInfo[]{new FieldInfo("Lkotlin/collections/AbstractList$IteratorImpl;->index:I", "I", 1, ExecutableRuntime.zero("I")), new FieldInfo("Lkotlin/collections/AbstractList$IteratorImpl;->this$0:Lkotlin/collections/AbstractList;", "Lkotlin/collections/AbstractList;", 4113, ExecutableRuntime.zero("Lkotlin/collections/AbstractList;"))}, new MethodInfo[]{new MethodInfo("<init>(Lkotlin/collections/AbstractList;)V", 65537), new MethodInfo("getIndex()I", 17), new MethodInfo("hasNext()Z", 1), new MethodInfo("next()Ljava/lang/Object;", 1), new MethodInfo("remove()V", 1), new MethodInfo("setIndex(I)V", 17)}, "IteratorImpl");}
}
