package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_df03f95cc38a5c68 extends RuntimeForeign.SourceProxy {
Source_df03f95cc38a5c68(RuntimeForeign owner,Instance source){super(owner,source);}

}
