package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_223e5fe768737e7bf73b {
static ClassInfo info_223e5fe768737e7bf73b() {return new ClassInfo("Lapp/revanced/extension/shared/settings/BaseSettings$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
