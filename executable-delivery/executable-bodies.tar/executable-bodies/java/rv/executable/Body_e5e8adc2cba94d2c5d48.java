package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_e5e8adc2cba94d2c5d48 {
static Value m_5048067ebdfb04dd0449ec28(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
