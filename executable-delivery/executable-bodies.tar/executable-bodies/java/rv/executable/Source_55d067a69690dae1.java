package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_55d067a69690dae1 extends RuntimeForeign.SourceProxy {
Source_55d067a69690dae1(RuntimeForeign owner,Instance source){super(owner,source);}

}
