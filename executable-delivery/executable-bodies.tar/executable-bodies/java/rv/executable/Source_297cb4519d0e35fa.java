package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_297cb4519d0e35fa extends RuntimeForeign.SourceProxy implements java.util.concurrent.ThreadFactory {
Source_297cb4519d0e35fa(RuntimeForeign owner,Instance source){super(owner,source);}
public java.lang.Thread newThread(java.lang.Runnable a0) {Value result=owner.callback(source,"Ljava/util/concurrent/ThreadFactory;->newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;",new Value[]{owner.importValue(a0)}); return (java.lang.Thread)owner.exportObject(result.o(),"Ljava/lang/Thread;");}
}
