package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_fa6bd6672c69b3539a1b {
static Value m_e724c83849aefe208d5d7f56(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;->searchViewController:Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;->handleFinish(Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;)Z",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f6160e69850b16ade4a50f13(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Landroid/app/Activity;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;->initialize(Lapp/revanced/extension/shared/settings/BaseActivityHook;Landroid/app/Activity;)V",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fbe253309b941b93ba7d1375(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Ljava/lang/Enum;->ordinal()I",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[1] = result; pc = 2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;->currentThemeValueOrdinal:I",Value.NULL,true); pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],r[1]))?10:4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;->currentThemeValueOrdinal:I",Value.NULL,true,r[1]); pc = 5; continue; }
case 5: { r[0] = Value.i32(1); pc = 6; continue; }
case 6: { pc=(!ExecutableRuntime.equal(r[1],r[0]))?8:7; continue; }
case 7: { pc=9; continue; }
case 8: { r[0] = Value.i32(0); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/Utils;->setIsDarkModeEnabled(Z)V",Value.NULL,new Value[]{r[0]}); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7d8229405cc7fc1730d8fa73(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;->USE_BOLD_ICONS:Z",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_def2b13caf90da5db42a502e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_19_34_OR_GREATER:Z",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?4:3; continue; }
case 3: { return rt.check(r[1],"Z"); }
case 4: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->RESTORE_OLD_SETTINGS_MENUS:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?11:10; continue; }
case 10: { return rt.check(r[1],"Z"); }
case 11: { r[0] = Value.ref("19.35.36"); pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;->isSpoofingToLessThan(Ljava/lang/String;)Z",Value.NULL,new Value[]{r[0]}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?16:15; continue; }
case 15: { return rt.check(r[1],"Z"); }
case 16: { return rt.check(r[2],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_51116853d5797927242b51e5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_20_31_OR_GREATER:Z",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?27:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;->SETTINGS_DISABLE_BOLD_ICONS:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?27:8; continue; }
case 8: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->RESTORE_OLD_SETTINGS_MENUS:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 10; continue; }
case 10: { r[0] = result; pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 12; continue; }
case 12: { r[0] = result; pc = 13; continue; }
case 13: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?27:14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 15; continue; }
case 15: { r[0] = result; r[1] = r[0]; pc = 16; continue; }
case 16: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;->FIRST_TIME_APP_LAUNCHED:Lapp/revanced/extension/shared/settings/LongSetting;",Value.NULL,true); pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/settings/LongSetting;->get()Ljava/lang/Long;",r[2],new Value[]{}); pc = 18; continue; }
case 18: { r[2] = result; pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Ljava/lang/Long;->longValue()J",r[2],new Value[]{}); pc = 20; continue; }
case 20: { r[2] = result; r[3] = r[2]; pc = 21; continue; }
case 21: { r[0] = Value.i64((r[0].j()) - (r[2].j())); r[1] = r[0]; pc = 22; continue; }
case 22: { r[2] = Value.i64(30000L); r[3] = r[2]; pc = 23; continue; }
case 23: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[2].j())); pc = 24; continue; }
case 24: { pc=(r[0].i() <= 0)?27:25; continue; }
case 25: { r[0] = Value.i32(1); pc = 26; continue; }
case 26: { pc=28; continue; }
case 27: { r[0] = Value.i32(0); pc = 28; continue; }
case 28: { rt.writeField("Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;->USE_BOLD_ICONS:Z",Value.NULL,true,r[0]); pc = 29; continue; }
case 29: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/Utils;->setAppIsUsingBoldIcons(Z)V",Value.NULL,new Value[]{r[0]}); pc = 30; continue; }
case 30: { r[0] = Value.i32(-1); pc = 31; continue; }
case 31: { rt.writeField("Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;->currentThemeValueOrdinal:I",Value.NULL,true,r[0]); pc = 32; continue; }
case 32: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ed1e9393327988557c49c531(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/settings/BaseActivityHook;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_02a934267e3322b4af3d2433(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;");
r[3] = rt.check(arguments[0], "Landroid/app/Activity;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:3; continue; }
case 3: { r[0] = Value.ref("Theme.YouTube.Settings.Dark"); pc = 4; continue; }
case 4: { pc=6; continue; }
case 5: { r[0] = Value.ref("Theme.YouTube.Settings"); pc = 6; continue; }
case 6: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->STYLE:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[1], r[0]}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Landroid/app/Activity;->setTheme(I)V",r[3],new Value[]{r[0]}); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0bc2c5eaf7639d317728d017(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Landroid/preference/PreferenceFragment;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_64c9964eabb00e30fea271a2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:3; continue; }
case 3: { r[0] = Value.ref("yt_black3"); pc = 4; continue; }
case 4: { pc=6; continue; }
case 5: { r[0] = Value.ref("yt_white1"); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/Utils;->getColorFromString(Ljava/lang/String;)I",Value.NULL,new Value[]{r[0]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4cd7563e799db7807ffee48c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;->getBackButtonDrawable()Landroid/graphics/drawable/Drawable;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Landroid/graphics/drawable/Drawable;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fd98d83c89fcd077e72d8080(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;");
r[1] = rt.check(arguments[0], "Landroid/app/Activity;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[1] = Value.i32(0); pc = 1; continue; }
case 1: { return rt.check(r[1],"Landroid/view/View$OnClickListener;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ad962135a1b7b37180f6ba41(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;");
r[2] = rt.check(arguments[0], "Landroid/app/Activity;");
r[3] = rt.check(arguments[1], "Landroid/widget/Toolbar;");
r[4] = rt.check(arguments[2], "Landroid/preference/PreferenceFragment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(rt.isInstance(r[4].o(),"Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;")?1:0); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?6:2; continue; }
case 2: { r[4] = rt.cast(r[4],"Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;"); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;","Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;->addSearchViewComponents(Landroid/app/Activity;Landroid/widget/Toolbar;Lapp/revanced/extension/youtube/settings/preference/YouTubePreferenceFragment;)Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;",Value.NULL,new Value[]{r[2], r[3], r[4]}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/settings/YouTubeActivityHook;->searchViewController:Lapp/revanced/extension/youtube/settings/search/YouTubeSearchViewController;",Value.NULL,true,r[2]); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
