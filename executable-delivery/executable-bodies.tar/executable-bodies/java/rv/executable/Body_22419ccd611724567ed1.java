package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_22419ccd611724567ed1 {
static Value m_96664652decfe3fa5dfc4a48(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/Integer;->toString(I)Ljava/lang/String;",Value.NULL,new Value[]{r[3]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/String;->startsWith(Ljava/lang/String;)Z",r[2],new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?20:5; continue; }
case 5: { r[0] = Value.i32(112); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/String;->indexOf(I)I",r[2],new Value[]{r[0]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { pc=(r[0].i() <= 0)?20:9; continue; }
case 9: { r[1] = Value.i32(0); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/String;->substring(II)Ljava/lang/String;",r[2],new Value[]{r[1], r[0]}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I",Value.NULL,new Value[]{r[0]}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda0;"); pc = 15; continue; }
case 15: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;II)V",r[1],new Value[]{r[2], r[3], r[0]}); pc = 16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 17; continue; }
case 17: { return rt.check(r[0],"I"); }
case 18: { r[2] = Value.ref(exception); exception=null; pc = 19; continue; }
case 19: { pc=21; continue; }
case 20: { return rt.check(r[3],"I"); }
case 21: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda1;"); pc = 22; continue; }
case 22: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda1;-><init>()V",r[0],new Value[]{}); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[2]}); pc = 24; continue; }
case 24: { return rt.check(r[3],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 17) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=18; continue; } }
throw error;
}
}

}

static Value m_ea61c45aa6e83cdb4881e1ae(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda27;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda27;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[2]}); pc = 5; continue; }
case 5: { r[2] = rt.cast(r[2],"Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[2]}); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playerControllerRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 8; continue; }
case 8: { r[0] = Value.i64(-1L); r[1] = r[0]; pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoTime:J",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 11; continue; }
case 11: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoLength:J",Value.NULL,true,r[0]); pc = 12; continue; }
case 12: { r[2] = Value.i32(1065353216); pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playbackSpeed:F",Value.NULL,true,r[2]); pc = 14; continue; }
case 14: { r[2] = Value.i32(-2); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->desiredVideoResolution:I",Value.NULL,true,r[2]); pc = 16; continue; }
case 16: { r[2] = Value.i32(0); pc = 17; continue; }
case 17: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentQualities:[Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",Value.NULL,true,r[2]); pc = 18; continue; }
case 18: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentMenuInterface:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityMenuInterface;",Value.NULL,true,r[2]); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation;->setCurrentQuality(Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;)V",Value.NULL,new Value[]{r[2]}); pc = 20; continue; }
case 20: { return Value.VOID; }
case 21: { r[2] = Value.ref(exception); exception=null; pc = 22; continue; }
case 22: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda28;"); pc = 23; continue; }
case 23: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda28;-><init>()V",r[0],new Value[]{}); pc = 24; continue; }
case 24: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[2]}); pc = 25; continue; }
case 25: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 20) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=21; continue; } }
throw error;
}
}

}

static Value m_31225aab1bb216344ed62b1f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->mdxPlayerDirectorRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { return Value.VOID; }
case 6: { r[1] = Value.ref(exception); exception=null; pc = 7; continue; }
case 7: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda18;"); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda18;-><init>()V",r[0],new Value[]{}); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[1]}); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 5) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=6; continue; } }
throw error;
}
}

}

static Value m_7883068d0381abfef0fe6231(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoId:Ljava/lang/String;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/String;->equals(Ljava/lang/Object;)Z",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?8:4; continue; }
case 4: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda3;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda3;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoId:Ljava/lang/String;",Value.NULL,true,r[1]); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9990d8348626e8f179c5bee2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "J"); r[3] = r[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoLength:J",Value.NULL,true); r[1] = r[0]; pc = 1; continue; }
case 1: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[2].j())); pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?7:3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda4;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda4;-><init>(J)V",r[0],new Value[]{r[2]}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoLength:J",Value.NULL,true,r[2]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_35bce2899b63f75355e9c34d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[13];
r[10] = rt.check(arguments[0], "[Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
r[11] = rt.check(arguments[1], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityMenuInterface;");
r[12] = rt.check(arguments[2], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentMenuInterface:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityMenuInterface;",Value.NULL,true,r[11]); pc = 2; continue; }
case 2: { r[11] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentQualities:[Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",Value.NULL,true); pc = 3; continue; }
case 3: { r[0] = Value.i32(1); pc = 4; continue; }
case 4: { r[1] = Value.i32(0); pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[11],Value.i32(0)))?14:6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z",Value.NULL,new Value[]{r[11], r[10]}); pc = 7; continue; }
case 7: { r[11] = result; pc = 8; continue; }
case 8: { pc=(!ExecutableRuntime.equal(r[11],Value.i32(0)))?10:9; continue; }
case 9: { pc=14; continue; }
case 10: { r[11] = r[1]; pc = 11; continue; }
case 11: { pc=15; continue; }
case 12: { r[10] = Value.ref(exception); exception=null; pc = 13; continue; }
case 13: { pc=68; continue; }
case 14: { r[11] = r[0]; pc = 15; continue; }
case 15: { pc=(ExecutableRuntime.equal(r[11],Value.i32(0)))?20:16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentQualities:[Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",Value.NULL,true,r[10]); pc = 17; continue; }
case 17: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda6;"); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda6;-><init>()V",r[2],new Value[]{}); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 20; continue; }
case 20: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/Math;->max(II)I",Value.NULL,new Value[]{r[1], r[12]}); pc = 21; continue; }
case 21: { r[12] = result; pc = 22; continue; }
case 22: { r[2] = rt.arrayGet(r[10],r[12].i()); pc = 23; continue; }
case 23: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;->patch_getResolution()I",r[2],new Value[]{}); pc = 24; continue; }
case 24: { r[3] = result; pc = 25; continue; }
case 25: { r[4] = Value.i32(-2); pc = 26; continue; }
case 26: { pc=(ExecutableRuntime.equal(r[3],r[4]))?31:27; continue; }
case 27: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentQuality:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",Value.NULL,true); pc = 28; continue; }
case 28: { pc=(ExecutableRuntime.equal(r[3],Value.i32(0)))?30:29; continue; }
case 29: { pc=(ExecutableRuntime.equal(r[3],r[2]))?31:30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation;->setCurrentQuality(Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;)V",Value.NULL,new Value[]{r[2]}); pc = 31; continue; }
case 31: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->desiredVideoResolution:I",Value.NULL,true); pc = 32; continue; }
case 32: { pc=(!ExecutableRuntime.equal(r[3],r[4]))?34:33; continue; }
case 33: { pc=67; continue; }
case 34: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->qualityNeedsUpdating:Z",Value.NULL,true); pc = 35; continue; }
case 35: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?38:36; continue; }
case 36: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->qualityNeedsUpdating:Z",Value.NULL,true,r[1]); pc = 37; continue; }
case 37: { pc=40; continue; }
case 38: { pc=(!ExecutableRuntime.equal(r[11],Value.i32(0)))?40:39; continue; }
case 39: { pc=67; continue; }
case 40: { r[11] = Value.i32(rt.length(r[10])); pc = 41; continue; }
case 41: { r[11] = Value.i32((r[11].i()) - (r[0].i())); pc = 42; continue; }
case 42: { r[5] = Value.i32(rt.length(r[10])); pc = 43; continue; }
case 43: { r[6] = r[1]; pc = 44; continue; }
case 44: { r[7] = r[6]; pc = 45; continue; }
case 45: { pc=(r[6].i() >= r[5].i())?67:46; continue; }
case 46: { r[8] = rt.arrayGet(r[10],r[6].i()); pc = 47; continue; }
case 47: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;->patch_getResolution()I",r[8],new Value[]{}); pc = 48; continue; }
case 48: { r[9] = result; pc = 49; continue; }
case 49: { pc=(ExecutableRuntime.equal(r[9],r[4]))?51:50; continue; }
case 50: { pc=(r[9].i() <= r[3].i())?52:51; continue; }
case 51: { pc=(!ExecutableRuntime.equal(r[7],r[11]))?64:52; continue; }
case 52: { pc=(ExecutableRuntime.equal(r[7],r[12]))?54:53; continue; }
case 53: { pc=55; continue; }
case 54: { r[0] = r[1]; pc = 55; continue; }
case 55: { r[10] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;"); pc = 56; continue; }
case 56: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;-><init>(ZLapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;)V",r[10],new Value[]{r[0], r[2], r[8]}); pc = 57; continue; }
case 57: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[10]}); pc = 58; continue; }
case 58: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?62:59; continue; }
case 59: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/shared/ShortsPlayerState;->isOpen()Z",Value.NULL,new Value[]{}); pc = 60; continue; }
case 60: { r[10] = result; pc = 61; continue; }
case 61: { pc=(!ExecutableRuntime.equal(r[10],Value.i32(0)))?67:62; continue; }
case 62: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation;->changeQuality(Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;)V",Value.NULL,new Value[]{r[8]}); pc = 63; continue; }
case 63: { return rt.check(r[7],"I"); }
case 64: { r[7] = Value.i32((r[7].i()) + (1)); pc = 65; continue; }
case 65: { r[6] = Value.i32((r[6].i()) + (1)); pc = 66; continue; }
case 66: { pc=45; continue; }
case 67: { return rt.check(r[12],"I"); }
case 68: { r[11] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda8;"); pc = 69; continue; }
case 69: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda8;-><init>()V",r[11],new Value[]{}); pc = 70; continue; }
case 70: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[11], r[10]}); pc = 71; continue; }
case 71: { return rt.check(r[12],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 63) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=12; continue; } }
throw error;
}
}

}

static Value m_2c5ceffdae650d4b65065755(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "J"); r[1] = r[0];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoTime:J",Value.NULL,true,r[0]); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b6828621aa5a0c66ffac38a4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda9;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda9;-><init>(F)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playbackSpeed:F",Value.NULL,true,r[1]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_75735cc536af7348096860d2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playbackSpeed:F",Value.NULL,true); pc = 1; continue; }
case 1: { r[0] = Value.i32(ExecutableRuntime.compareFloat(r[0].f(), r[1].f(), -1)); pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?7:3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda15;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda15;-><init>(F)V",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playbackSpeed:F",Value.NULL,true,r[1]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ca49fd756e03fc8b4ceac3ec(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playerControllerRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->mdxPlayerDirectorRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 7; continue; }
case 7: { r[0] = Value.ref(""); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoId:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 9; continue; }
case 9: { r[1] = Value.i64(0L); r[2] = r[1]; pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoLength:J",Value.NULL,true,r[1]); pc = 11; continue; }
case 11: { r[1] = Value.i64(-1L); r[2] = r[1]; pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoTime:J",Value.NULL,true,r[1]); pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playerResponseVideoId:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 14; continue; }
case 14: { r[0] = Value.i32(1065353216); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playbackSpeed:F",Value.NULL,true,r[0]); pc = 16; continue; }
case 16: { r[0] = Value.i32(-2); pc = 17; continue; }
case 17: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->desiredVideoResolution:I",Value.NULL,true,r[0]); pc = 18; continue; }
case 18: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/shared/Event;"); pc = 19; continue; }
case 19: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/shared/Event;-><init>()V",r[0],new Value[]{}); pc = 20; continue; }
case 20: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->onQualityChange:Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,true,r[0]); pc = 21; continue; }
case 21: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9ca182616def5bb0eb65501c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentQuality:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",Value.NULL,true); pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],r[1]))?9:3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda17;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda17;-><init>(Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;)V",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentQuality:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",Value.NULL,true,r[1]); pc = 7; continue; }
case 7: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->onQualityChange:Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,true); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/shared/Event;->invoke(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 9; continue; }
case 9: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_dfd59c221c567394c28b3119(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentMenuInterface:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityMenuInterface;",Value.NULL,true); pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?7:3; continue; }
case 3: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda16;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda16;-><init>()V",r[1],new Value[]{}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 6; continue; }
case 6: { return Value.VOID; }
case 7: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityMenuInterface;->patch_setQuality(Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;)V",r[0],new Value[]{r[1]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4fbbf78cfee817096504f5c0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoLength:J",Value.NULL,true); r[1] = r[0]; pc = 1; continue; }
case 1: { return rt.check(r[0],"J"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f3b5a07799ed20326fda2c75(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playbackSpeed:F",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"F"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_dc441179a2ea4d4938490ff5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[11];
r[9] = rt.check(arguments[0], "J"); r[10] = r[9];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Utils;->verifyOnMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoTime()J",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[3] = result; r[4] = r[3]; pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation;->getVideoLength()J",Value.NULL,new Value[]{}); pc = 5; continue; }
case 5: { r[5] = result; r[6] = r[5]; pc = 6; continue; }
case 6: { r[7] = Value.i64(250L); r[8] = r[7]; pc = 7; continue; }
case 7: { r[7] = Value.i64((r[5].j()) - (r[7].j())); r[8] = r[7]; pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/Math;->min(JJ)J",Value.NULL,new Value[]{r[9], r[7]}); pc = 9; continue; }
case 9: { r[7] = result; r[8] = r[7]; pc = 10; continue; }
case 10: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[3].j(), r[9].j())); pc = 11; continue; }
case 11: { pc=(r[0].i() > 0)?22:12; continue; }
case 12: { r[0] = Value.i32(ExecutableRuntime.compareLong(r[3].j(), r[7].j())); pc = 13; continue; }
case 13: { pc=(r[0].i() < 0)?22:14; continue; }
case 14: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;"); pc = 15; continue; }
case 15: { r[7] = r[9]; r[8] = r[7]; pc = 16; continue; }
case 16: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda20;-><init>(JJJ)V",r[2],new Value[]{r[3], r[5], r[7]}); pc = 17; continue; }
case 17: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 18; continue; }
case 18: { return rt.check(r[1],"Z"); }
case 19: { r[0] = Value.ref(exception); exception=null; pc = 20; continue; }
case 20: { r[9] = r[0]; pc = 21; continue; }
case 21: { pc=63; continue; }
case 22: { r[9] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;"); pc = 23; continue; }
case 23: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda21;-><init>(J)V",r[9],new Value[]{r[7]}); pc = 24; continue; }
case 24: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[9]}); pc = 25; continue; }
case 25: { r[9] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->playerControllerRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 26; continue; }
case 26: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[9],new Value[]{}); pc = 27; continue; }
case 27: { r[9] = result; pc = 28; continue; }
case 28: { r[9] = rt.cast(r[9],"Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;"); pc = 29; continue; }
case 29: { pc=(!ExecutableRuntime.equal(r[9],Value.i32(0)))?34:30; continue; }
case 30: { r[9] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda22;"); pc = 31; continue; }
case 31: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda22;-><init>()V",r[9],new Value[]{}); pc = 32; continue; }
case 32: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[9]}); pc = 33; continue; }
case 33: { pc=42; continue; }
case 34: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;->patch_seekTo(J)Z",r[9],new Value[]{r[7]}); pc = 35; continue; }
case 35: { r[9] = result; pc = 36; continue; }
case 36: { pc=(ExecutableRuntime.equal(r[9],Value.i32(0)))?39:37; continue; }
case 37: { r[9] = Value.i32(1); pc = 38; continue; }
case 38: { return rt.check(r[9],"Z"); }
case 39: { r[9] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda23;"); pc = 40; continue; }
case 40: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda23;-><init>()V",r[9],new Value[]{}); pc = 41; continue; }
case 41: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[9]}); pc = 42; continue; }
case 42: { r[9] = Value.i64(1000L); r[10] = r[9]; pc = 43; continue; }
case 43: { r[5] = Value.i64((r[7].j()) / (r[9].j())); r[6] = r[5]; pc = 44; continue; }
case 44: { r[9] = Value.i64((r[3].j()) / (r[9].j())); r[10] = r[9]; pc = 45; continue; }
case 45: { r[9] = Value.i32(ExecutableRuntime.compareLong(r[5].j(), r[9].j())); pc = 46; continue; }
case 46: { pc=(!ExecutableRuntime.equal(r[9],Value.i32(0)))?51:47; continue; }
case 47: { r[9] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda24;"); pc = 48; continue; }
case 48: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda24;-><init>(JJ)V",r[9],new Value[]{r[7], r[3]}); pc = 49; continue; }
case 49: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[9]}); pc = 50; continue; }
case 50: { return rt.check(r[1],"Z"); }
case 51: { r[9] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->mdxPlayerDirectorRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 52; continue; }
case 52: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[9],new Value[]{}); pc = 53; continue; }
case 53: { r[9] = result; pc = 54; continue; }
case 54: { r[9] = rt.cast(r[9],"Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;"); pc = 55; continue; }
case 55: { pc=(!ExecutableRuntime.equal(r[9],Value.i32(0)))?60:56; continue; }
case 56: { r[9] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda25;"); pc = 57; continue; }
case 57: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda25;-><init>()V",r[9],new Value[]{}); pc = 58; continue; }
case 58: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[9]}); pc = 59; continue; }
case 59: { return rt.check(r[1],"Z"); }
case 60: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$PlaybackController;->patch_seekTo(J)Z",r[9],new Value[]{r[7]}); pc = 61; continue; }
case 61: { r[9] = result; pc = 62; continue; }
case 62: { return rt.check(r[9],"Z"); }
case 63: { r[10] = rt.allocate("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda26;"); pc = 64; continue; }
case 64: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda26;-><init>()V",r[10],new Value[]{}); pc = 65; continue; }
case 65: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[10], r[9]}); pc = 66; continue; }
case 66: { return rt.check(r[1],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 2 && pc < 62) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=19; continue; } }
throw error;
}
}

}

static Value m_dbc7f26124219e6f2afab863(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->videoTime:J",Value.NULL,true); r[1] = r[0]; pc = 1; continue; }
case 1: { return rt.check(r[0],"J"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c6a4829586116da876654858(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("fixVideoQualityResolution failed"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4257c2b6e04c74e0da65aeb5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Video speed changed: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1400d74e4e4ac64644e0a7ca(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Failed to initialize MDX"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_722c6996e0c1f9f20548de17(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "I");
r[4] = rt.check(arguments[2], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Fixing wrong quality resolution from: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[1] = Value.ref("("); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 7; continue; }
case 7: { r[3] = Value.ref(") to: "); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 10; continue; }
case 10: { r[2] = Value.ref(")"); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;",r[0],new Value[]{r[4]}); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 15; continue; }
case 15: { r[2] = result; pc = 16; continue; }
case 16: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_97d05fb0884ea212b880b5b7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("setVideoQuality failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_94cb4b1e310e3484485a172d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("New video ID: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7607046d8bc726c55a84db25(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Current quality changed to: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_541fdb841c2bddcd7e81779e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("User selected playback speed: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_06662967f2b71aa8e3ce0ca1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("VideoQualities: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation;->currentQualities:[Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[1]}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9031ed866adbee3208802367(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "J"); r[3] = r[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Current video length: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7fdd9b7c504c420344eca62a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("initialize failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5203449107581510830db8ce(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(arguments[0], "Z");
r[2] = rt.check(arguments[1], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?11:1; continue; }
case 1: { r[1] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 2; continue; }
case 2: { r[0] = Value.ref("Changing video quality from: "); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[0]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[2]}); pc = 5; continue; }
case 5: { r[2] = Value.ref(" to: "); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[2]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[3]}); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[1],new Value[]{}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { return rt.check(r[1],"Ljava/lang/String;"); }
case 11: { r[1] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 12; continue; }
case 12: { r[2] = Value.ref("Video is already the preferred quality: "); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[3]}); pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[1],new Value[]{}); pc = 16; continue; }
case 16: { r[1] = result; pc = 17; continue; }
case 17: { return rt.check(r[1],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_963f38e0f39f05e31ff682ea(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("newVideoStarted"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_97b3a0764b338e0cf5390823(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Cannot change quality, menu interface is null"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_218955cd24bf4a42bd106ace(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("seekTo did not succeeded. Trying MXD."); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_03f3046f22703e69b16b7276(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
r[2] = rt.check(arguments[0], "J"); r[3] = r[2];
r[4] = rt.check(arguments[1], "J"); r[5] = r[4];
r[6] = rt.check(arguments[2], "J"); r[7] = r[6];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Ignoring seekTo call as video playback is almost finished.  videoTime: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = Value.ref(" videoLength: "); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[4]}); pc = 7; continue; }
case 7: { r[2] = Value.ref(" seekTo: "); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[6]}); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 11; continue; }
case 11: { r[2] = result; pc = 12; continue; }
case 12: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_bc42a32b9be58f9ca5d0b3cd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Cannot seekTo MXD because player controller is null"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c3430b863fd8f6a7dfb68fbf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Cannot seekTo because player controller is null"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5a75a14aad4388e85890f840(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "J"); r[3] = r[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Seeking to: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_04756facef63189455fbfe24(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[2] = rt.check(arguments[0], "J"); r[3] = r[2];
r[4] = rt.check(arguments[1], "J"); r[5] = r[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Skipping seekTo for MDX because seek time is too small("); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[2] = Value.i64((r[2].j()) - (r[4].j())); r[3] = r[2]; pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 5; continue; }
case 5: { r[2] = Value.ref("ms)"); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/VideoInformation;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d545e65213ca9178f9da1343(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("seekTo failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
