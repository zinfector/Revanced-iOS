package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_85eed9251b8caaa294d2 {
static ClassInfo info_85eed9251b8caaa294d2() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda6;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SBRequester$$ExternalSyntheticLambda6");}
}
