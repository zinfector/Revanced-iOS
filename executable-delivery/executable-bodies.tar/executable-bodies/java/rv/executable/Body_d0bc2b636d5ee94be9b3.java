package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_d0bc2b636d5ee94be9b3 {
static Value m_39cf39921522ad08b82e9af6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d2b42154da99886da279a469(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;", "Lapp/revanced/extension/shared/Utils;->$r8$lambda$TI78B2nt8askVBEqF02vuLIkU5Y()Ljava/lang/String;", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
