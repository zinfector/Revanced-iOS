package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_08d0b272eb3c1d2557a6 {
static Value m_944554b06c31e9af9c2b5694(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route;"); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/requests/Route$Method;->GET:Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = Value.ref("/api/isUserVIP?userID={user_id}"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;","Lapp/revanced/extension/shared/requests/Route;-><init>(Lapp/revanced/extension/shared/requests/Route$Method;Ljava/lang/String;)V",r[0],new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->IS_USER_VIP:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route;"); pc = 6; continue; }
case 6: { r[2] = Value.ref("/api/skipSegments?videoID={video_id}&categories={categories}"); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;","Lapp/revanced/extension/shared/requests/Route;-><init>(Lapp/revanced/extension/shared/requests/Route$Method;Ljava/lang/String;)V",r[0],new Value[]{r[1], r[2]}); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->GET_SEGMENTS:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true,r[0]); pc = 9; continue; }
case 9: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route;"); pc = 10; continue; }
case 10: { r[2] = rt.readField("Lapp/revanced/extension/shared/requests/Route$Method;->POST:Lapp/revanced/extension/shared/requests/Route$Method;",Value.NULL,true); pc = 11; continue; }
case 11: { r[3] = Value.ref("/api/viewedVideoSponsorTime?UUID={segment_id}"); pc = 12; continue; }
case 12: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;","Lapp/revanced/extension/shared/requests/Route;-><init>(Lapp/revanced/extension/shared/requests/Route$Method;Ljava/lang/String;)V",r[0],new Value[]{r[2], r[3]}); pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->VIEWED_SEGMENT:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true,r[0]); pc = 14; continue; }
case 14: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route;"); pc = 15; continue; }
case 15: { r[3] = Value.ref("/api/userInfo?userID={user_id}&values=[\"userID\",\"userName\",\"reputation\",\"segmentCount\",\"ignoredSegmentCount\",\"viewCount\",\"minutesSaved\"]"); pc = 16; continue; }
case 16: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;","Lapp/revanced/extension/shared/requests/Route;-><init>(Lapp/revanced/extension/shared/requests/Route$Method;Ljava/lang/String;)V",r[0],new Value[]{r[1], r[3]}); pc = 17; continue; }
case 17: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->GET_USER_STATS:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true,r[0]); pc = 18; continue; }
case 18: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route;"); pc = 19; continue; }
case 19: { r[1] = Value.ref("/api/setUsername?userID={user_id}&username={username}"); pc = 20; continue; }
case 20: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;","Lapp/revanced/extension/shared/requests/Route;-><init>(Lapp/revanced/extension/shared/requests/Route$Method;Ljava/lang/String;)V",r[0],new Value[]{r[2], r[1]}); pc = 21; continue; }
case 21: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->CHANGE_USERNAME:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true,r[0]); pc = 22; continue; }
case 22: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route;"); pc = 23; continue; }
case 23: { r[1] = Value.ref("/api/skipSegments?userID={user_id}&videoID={video_id}&category={category}&startTime={start_time}&endTime={end_time}&videoDuration={duration}"); pc = 24; continue; }
case 24: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;","Lapp/revanced/extension/shared/requests/Route;-><init>(Lapp/revanced/extension/shared/requests/Route$Method;Ljava/lang/String;)V",r[0],new Value[]{r[2], r[1]}); pc = 25; continue; }
case 25: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->SUBMIT_SEGMENTS:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true,r[0]); pc = 26; continue; }
case 26: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route;"); pc = 27; continue; }
case 27: { r[1] = Value.ref("/api/voteOnSponsorTime?userID={user_id}&UUID={segment_id}&type={type}"); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;","Lapp/revanced/extension/shared/requests/Route;-><init>(Lapp/revanced/extension/shared/requests/Route$Method;Ljava/lang/String;)V",r[0],new Value[]{r[2], r[1]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->VOTE_ON_SEGMENT_QUALITY:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true,r[0]); pc = 30; continue; }
case 30: { r[0] = rt.allocate("Lapp/revanced/extension/shared/requests/Route;"); pc = 31; continue; }
case 31: { r[1] = Value.ref("/api/voteOnSponsorTime?userID={user_id}&UUID={segment_id}&category={category}"); pc = 32; continue; }
case 32: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;","Lapp/revanced/extension/shared/requests/Route;-><init>(Lapp/revanced/extension/shared/requests/Route$Method;Ljava/lang/String;)V",r[0],new Value[]{r[2], r[1]}); pc = 33; continue; }
case 33: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->VOTE_ON_SEGMENT_CATEGORY:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true,r[0]); pc = 34; continue; }
case 34: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
