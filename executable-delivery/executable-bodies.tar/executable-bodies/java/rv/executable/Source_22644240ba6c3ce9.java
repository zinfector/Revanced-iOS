package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_22644240ba6c3ce9 extends RuntimeForeign.SourceProxy {
Source_22644240ba6c3ce9(RuntimeForeign owner,Instance source){super(owner,source);}

}
