package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_3f3d5393350478ab3851 {
static Value m_8caa8624f18dc6984f2f67dc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/AppLanguage;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;", "Ljava/lang/Object;-><init>()V", r[0], new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;->f$0:Lapp/revanced/extension/shared/settings/AppLanguage;", r[0], false, r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_37e148a3b5a894a008acfd88(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;->f$0:Lapp/revanced/extension/shared/settings/AppLanguage;", r[1], false); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;", "Lapp/revanced/extension/shared/Utils;->$r8$lambda$OU30e5K0WcELhuqDF7wHZ4mridA(Lapp/revanced/extension/shared/settings/AppLanguage;)Ljava/lang/String;", Value.NULL, new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
