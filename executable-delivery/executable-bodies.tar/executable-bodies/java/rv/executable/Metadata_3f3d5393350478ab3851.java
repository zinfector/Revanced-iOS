package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_3f3d5393350478ab3851 {
static ClassInfo info_3f3d5393350478ab3851() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;->f$0:Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/shared/settings/AppLanguage;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/shared/settings/AppLanguage;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "Utils$$ExternalSyntheticLambda13");}
}
