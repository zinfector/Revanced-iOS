package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_777a0a0383a7f2c056d3 {
static ClassInfo info_777a0a0383a7f2c056d3() {return new ClassInfo("Lapp/revanced/extension/youtube/settings/search/YouTubeSearchResultsAdapter;", "Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;", new String[]{}, 1, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>(Landroid/content/Context;Ljava/util/List;Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;)V", 65537), new MethodInfo("getMainPreferenceScreen()Landroid/preference/PreferenceScreen;", 1)}, "YouTubeSearchResultsAdapter");}
}
