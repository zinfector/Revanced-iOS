package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_0a9ba93fb68bfd849f3f {
static Value m_d1caee47f20bd98d09c918c3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
r[7] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;"); pc = 1; continue; }
case 1: { r[2] = Value.ref("revanced_sb_voting_button"); pc = 2; continue; }
case 2: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton$$ExternalSyntheticLambda0;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton$$ExternalSyntheticLambda0;-><init>()V",r[4],new Value[]{}); pc = 4; continue; }
case 4: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton$$ExternalSyntheticLambda1;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton$$ExternalSyntheticLambda1;-><init>()V",r[5],new Value[]{}); pc = 6; continue; }
case 6: { r[6] = Value.i32(0); pc = 7; continue; }
case 7: { r[3] = Value.i32(0); pc = 8; continue; }
case 8: { r[1] = r[7]; pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;-><init>(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;Landroid/view/View$OnClickListener;Landroid/view/View$OnLongClickListener;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;->instance:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true,r[0]); pc = 11; continue; }
case 11: { return Value.VOID; }
case 12: { r[0] = Value.ref(exception); exception=null; pc = 13; continue; }
case 13: { r[7] = r[0]; pc = 14; continue; }
case 14: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton$$ExternalSyntheticLambda2;"); pc = 15; continue; }
case 15: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton$$ExternalSyntheticLambda2;-><init>()V",r[0],new Value[]{}); pc = 16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[7]}); pc = 17; continue; }
case 17: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 11) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=12; continue; } }
throw error;
}
}

}

static Value m_626f7a47cdec16f18c0661dc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Z");
r[2] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;->instance:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?3:2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->setVisibility(ZZ)V",r[0],new Value[]{r[1], r[2]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_dfb7e124873dced4a9f4311c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;->instance:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?3:2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->setVisibilityImmediate(Z)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b1f2756ef1f4f0fff6c03b00(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;->instance:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?3:2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->setVisibilityNegatedImmediate()V",r[0],new Value[]{}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ed1266a9c1ce3b2330f49926(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;->isButtonEnabled()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9b9d21c8e978d8558f757652(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("initialize failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_72022023da3b1770c0171e57(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_ENABLED:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?20:6; continue; }
case 6: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_VOTING_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 10; continue; }
case 10: { r[0] = result; pc = 11; continue; }
case 11: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?20:12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->videoHasSegments()Z",Value.NULL,new Value[]{}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?20:15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/VotingButton;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->isAdProgressTextVisible()Z",Value.NULL,new Value[]{}); pc = 16; continue; }
case 16: { r[0] = result; pc = 17; continue; }
case 17: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?20:18; continue; }
case 18: { r[0] = Value.i32(1); pc = 19; continue; }
case 19: { return rt.check(r[0],"Z"); }
case 20: { r[0] = Value.i32(0); pc = 21; continue; }
case 21: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
