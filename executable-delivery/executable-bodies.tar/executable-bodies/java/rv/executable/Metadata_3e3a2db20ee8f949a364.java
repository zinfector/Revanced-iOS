package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_3e3a2db20ee8f949a364 {
static ClassInfo info_3e3a2db20ee8f949a364() {return new ClassInfo("Lapp/revanced/extension/shared/patches/EnableDebuggingPatch$$ExternalSyntheticBackport0;", "Ljava/lang/Object;", new String[]{}, 5121, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("m(Ljava/lang/String;)Z", 4105)}, "EnableDebuggingPatch$$ExternalSyntheticBackport0");}
}
