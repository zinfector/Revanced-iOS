package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_37105ba2b891d304d2ae {
static Value m_6bd9bf91e3664e3d32318949(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/util/ArrayList;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/ArrayList;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->importExportCallbacks:Ljava/util/List;",Value.NULL,true,r[0]); pc = 3; continue; }
case 3: { r[0] = rt.allocate("Ljava/util/ArrayList;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/ArrayList;-><init>()V",r[0],new Value[]{}); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->SETTINGS:Ljava/util/List;",Value.NULL,true,r[0]); pc = 6; continue; }
case 6: { r[0] = rt.allocate("Ljava/util/HashMap;"); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/HashMap;-><init>()V",r[0],new Value[]{}); pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->PATH_TO_SETTINGS:Ljava/util/Map;",Value.NULL,true,r[0]); pc = 9; continue; }
case 9: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;"); pc = 10; continue; }
case 10: { r[1] = Value.ref("revanced_prefs"); pc = 11; continue; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->preferences:Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;",Value.NULL,true,r[0]); pc = 13; continue; }
case 13: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_11baf5ad4029ca34c01b21f0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/BooleanSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/Setting$1;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting$1;-><init>(Lapp/revanced/extension/shared/settings/BooleanSetting;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/shared/settings/Setting$Availability;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d994a4925d2895b6aac9df31(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/Object;->equals(Ljava/lang/Object;)Z",r[0],new Value[]{r[2]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:4; continue; }
case 4: { return Value.VOID; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[2]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;",r[1],false,r[2]); pc = 7; continue; }
case 7: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->defaultValue:Ljava/lang/Object;",r[1],false); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/Object;->equals(Ljava/lang/Object;)Z",r[0],new Value[]{r[2]}); pc = 9; continue; }
case 9: { r[2] = result; pc = 10; continue; }
case 10: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?13:11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;->removeFromPreferences()V",r[1],new Value[]{}); pc = 12; continue; }
case 12: { return Value.VOID; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;->saveToPreferences()V",r[1],new Value[]{}); pc = 14; continue; }
case 14: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e7cb2f9dfdee1ea50f1d409a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "[Lapp/revanced/extension/shared/settings/BooleanSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/Setting$4;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting$4;-><init>([Lapp/revanced/extension/shared/settings/BooleanSetting;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/shared/settings/Setting$Availability;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ec32b060f0c9e88fcf7ca579(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/BooleanSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/Setting$2;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting$2;-><init>(Lapp/revanced/extension/shared/settings/BooleanSetting;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/shared/settings/Setting$Availability;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e08b30b84168c245fd129c8d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "[Lapp/revanced/extension/shared/settings/BooleanSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/Setting$3;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting$3;-><init>([Lapp/revanced/extension/shared/settings/BooleanSetting;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return rt.check(r[0],"Lapp/revanced/extension/shared/settings/Setting$Availability;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b34174e66de8d42ec6ddf802(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->defaultValue:Ljava/lang/Object;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;->save(Ljava/lang/Object;)V",r[1],new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->defaultValue:Ljava/lang/Object;",r[1],false); pc = 3; continue; }
case 3: { return rt.check(r[0],"Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c49ceda47a7760f99f54edc0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;",r[2],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->defaultValue:Ljava/lang/Object;",r[2],false); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/Object;->equals(Ljava/lang/Object;)Z",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a2eb3f447976448560a9c941(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/Setting$ImportExportCallback;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->importExportCallbacks:Ljava/util/List;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/shared/settings/Setting$ImportExportCallback;"); pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/List;->add(Ljava/lang/Object;)Z",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5512bb8a233d58eb8e0547d5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[10];
r[7] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[8] = rt.check(arguments[0], "Ljava/lang/String;");
r[9] = rt.check(arguments[1], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[5] = Value.i32(0); pc = 1; continue; }
case 1: { r[6] = Value.i32(0); pc = 2; continue; }
case 2: { r[3] = Value.i32(0); pc = 3; continue; }
case 3: { r[4] = Value.i32(1); pc = 4; continue; }
case 4: { r[0] = r[7]; pc = 5; continue; }
case 5: { r[1] = r[8]; pc = 6; continue; }
case 6: { r[2] = r[9]; pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fa27cdb6aaf1b0be59a200ad(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[11];
r[7] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[8] = rt.check(arguments[0], "Ljava/lang/String;");
r[9] = rt.check(arguments[1], "Ljava/lang/Object;");
r[10] = rt.check(arguments[2], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[4] = Value.i32(1); pc = 1; continue; }
case 1: { r[5] = Value.i32(0); pc = 2; continue; }
case 2: { r[3] = Value.i32(0); pc = 3; continue; }
case 3: { r[0] = r[7]; pc = 4; continue; }
case 4: { r[1] = r[8]; pc = 5; continue; }
case 5: { r[2] = r[9]; pc = 6; continue; }
case 6: { r[6] = r[10]; pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_eeeaf6e86286bc924e74a006(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[11];
r[7] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[8] = rt.check(arguments[0], "Ljava/lang/String;");
r[9] = rt.check(arguments[1], "Ljava/lang/Object;");
r[10] = rt.check(arguments[2], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[4] = Value.i32(1); pc = 1; continue; }
case 1: { r[6] = Value.i32(0); pc = 2; continue; }
case 2: { r[3] = Value.i32(0); pc = 3; continue; }
case 3: { r[0] = r[7]; pc = 4; continue; }
case 4: { r[1] = r[8]; pc = 5; continue; }
case 5: { r[2] = r[9]; pc = 6; continue; }
case 6: { r[5] = r[10]; pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9c7a6ff99a1512210719e8f0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[12];
r[7] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[8] = rt.check(arguments[0], "Ljava/lang/String;");
r[9] = rt.check(arguments[1], "Ljava/lang/Object;");
r[10] = rt.check(arguments[2], "Z");
r[11] = rt.check(arguments[3], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[5] = Value.i32(0); pc = 1; continue; }
case 1: { r[6] = Value.i32(0); pc = 2; continue; }
case 2: { r[0] = r[7]; pc = 3; continue; }
case 3: { r[1] = r[8]; pc = 4; continue; }
case 4: { r[2] = r[9]; pc = 5; continue; }
case 5: { r[3] = r[10]; pc = 6; continue; }
case 6: { r[4] = r[11]; pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_160b1a858e0e0fc8e663407d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[12];
r[7] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[8] = rt.check(arguments[0], "Ljava/lang/String;");
r[9] = rt.check(arguments[1], "Ljava/lang/Object;");
r[10] = rt.check(arguments[2], "Z");
r[11] = rt.check(arguments[3], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[4] = Value.i32(1); pc = 1; continue; }
case 1: { r[6] = Value.i32(0); pc = 2; continue; }
case 2: { r[0] = r[7]; pc = 3; continue; }
case 3: { r[1] = r[8]; pc = 4; continue; }
case 4: { r[2] = r[9]; pc = 5; continue; }
case 5: { r[3] = r[10]; pc = 6; continue; }
case 6: { r[5] = r[11]; pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7d3f1e72abfc296b975ad5c7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[11];
r[7] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[8] = rt.check(arguments[0], "Ljava/lang/String;");
r[9] = rt.check(arguments[1], "Ljava/lang/Object;");
r[10] = rt.check(arguments[2], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[5] = Value.i32(0); pc = 1; continue; }
case 1: { r[6] = Value.i32(0); pc = 2; continue; }
case 2: { r[4] = Value.i32(1); pc = 3; continue; }
case 3: { r[0] = r[7]; pc = 4; continue; }
case 4: { r[1] = r[8]; pc = 5; continue; }
case 5: { r[2] = r[9]; pc = 6; continue; }
case 6: { r[3] = r[10]; pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b46e822af50e582d91903390(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[12];
r[7] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[8] = rt.check(arguments[0], "Ljava/lang/String;");
r[9] = rt.check(arguments[1], "Ljava/lang/Object;");
r[10] = rt.check(arguments[2], "Z");
r[11] = rt.check(arguments[3], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[4] = Value.i32(1); pc = 1; continue; }
case 1: { r[5] = Value.i32(0); pc = 2; continue; }
case 2: { r[0] = r[7]; pc = 3; continue; }
case 3: { r[1] = r[8]; pc = 4; continue; }
case 4: { r[2] = r[9]; pc = 5; continue; }
case 5: { r[3] = r[10]; pc = 6; continue; }
case 6: { r[6] = r[11]; pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_00b339e2d5d448a82707081d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda3;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda3;-><init>(Lapp/revanced/extension/shared/settings/Setting;)V",r[0],new Value[]{r[2]}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->preferences:Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;",Value.NULL,true); pc = 4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;",r[2],false); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->removeKey(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_71f95ee0f6d58ad7884273bb(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 5) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[13];
r[7] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[8] = rt.check(arguments[0], "Ljava/lang/String;");
r[9] = rt.check(arguments[1], "Ljava/lang/Object;");
r[10] = rt.check(arguments[2], "Z");
r[11] = rt.check(arguments[3], "Ljava/lang/String;");
r[12] = rt.check(arguments[4], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[4] = Value.i32(1); pc = 1; continue; }
case 1: { r[0] = r[7]; pc = 2; continue; }
case 2: { r[1] = r[8]; pc = 3; continue; }
case 3: { r[2] = r[9]; pc = 4; continue; }
case 4: { r[3] = r[10]; pc = 5; continue; }
case 5: { r[5] = r[11]; pc = 6; continue; }
case 6: { r[6] = r[12]; pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_75de5d0cb9b88d2726f99f28(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 6) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Object;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Z");
r[5] = rt.check(arguments[4], "Ljava/lang/String;");
r[6] = rt.check(arguments[5], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[1]}); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;",r[0],false,r[1]); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->defaultValue:Ljava/lang/Object;",r[0],false,r[2]); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;",r[0],false,r[2]); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->rebootApp:Z",r[0],false,r[3]); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->includeWithImportExport:Z",r[0],false,r[4]); pc = 8; continue; }
case 8: { pc=(!ExecutableRuntime.equal(r[5],Value.i32(0)))?11:9; continue; }
case 9: { r[2] = Value.i32(0); pc = 10; continue; }
case 10: { pc=13; continue; }
case 11: { r[2] = rt.allocate("Lapp/revanced/extension/shared/StringRef;"); pc = 12; continue; }
case 12: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/StringRef;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[5]}); pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->userDialogMessage:Lapp/revanced/extension/shared/StringRef;",r[0],false,r[2]); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->availability:Lapp/revanced/extension/shared/settings/Setting$Availability;",r[0],false,r[6]); pc = 15; continue; }
case 15: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->SETTINGS:Ljava/util/List;",Value.NULL,true); pc = 16; continue; }
case 16: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/List;->add(Ljava/lang/Object;)Z",r[2],new Value[]{r[0]}); pc = 17; continue; }
case 17: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->PATH_TO_SETTINGS:Ljava/util/Map;",Value.NULL,true); pc = 18; continue; }
case 18: { result=rt.invoke("interface","Lapp/revanced/extension/shared/settings/Setting;","Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",r[2],new Value[]{r[1], r[0]}); pc = 19; continue; }
case 19: { r[2] = result; pc = 20; continue; }
case 20: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?24:21; continue; }
case 21: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;"); pc = 22; continue; }
case 22: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda2;-><init>(Lapp/revanced/extension/shared/settings/Setting;Ljava/lang/String;)V",r[2],new Value[]{r[0], r[1]}); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[2]}); pc = 24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;->load()V",r[0],new Value[]{}); pc = 25; continue; }
case 25: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1ec2682a0cb120bcbfaa35c0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/Setting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;->lambda$removeFromPreferences$2()Ljava/lang/String;",r[0],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e72f1040478b780c85f0cef0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/Setting;");
r[1] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;->lambda$new$1(Ljava/lang/String;)Ljava/lang/String;",r[0],new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_33b9a55ca02606e0bfa828a2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Clearing stored preference value (reset to default): "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;",r[2],false); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8476194dac2365217c43ff3b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;",r[2],false); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { r[1] = Value.ref("="); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Lapp/revanced/extension/shared/settings/Setting;->get()Ljava/lang/Object;",r[2],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 10; continue; }
case 10: { r[0] = result; pc = 11; continue; }
case 11: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a99acf313964461327594b2f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/Setting;");
r[3] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[2],new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/Class;->getSimpleName()Ljava/lang/String;",r[1],new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { r[1] = Value.ref(" error: Duplicate Setting key found: "); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/Setting;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 11; continue; }
case 11: { r[3] = result; pc = 12; continue; }
case 12: { return rt.check(r[3],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
