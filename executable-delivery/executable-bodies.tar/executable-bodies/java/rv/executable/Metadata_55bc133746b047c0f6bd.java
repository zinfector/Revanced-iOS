package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_55bc133746b047c0f6bd {
static ClassInfo info_55bc133746b047c0f6bd() {return new ClassInfo("Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticApiModelOutline1;", "Ljava/lang/Object;", new String[]{}, 5121, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("m(Landroid/widget/Toolbar;I)V", 4169)}, "BaseActivityHook$$ExternalSyntheticApiModelOutline1");}
}
