package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_f8b2e462b46ee167bb4e {
static Value m_8f4b6e89a9c0b18aedb6f36e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->$VALUES:[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f0a45f6b56328d3112d727ad(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 1; continue; }
case 1: { r[1] = rt.readField("Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = Value.ref("DISABLED"); pc = 3; continue; }
case 3: { r[3] = Value.i32(0); pc = 4; continue; }
case 4: { r[4] = Value.i32(0); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[2], r[3], r[1], r[4]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->DISABLED:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 7; continue; }
case 7: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 8; continue; }
case 8: { r[2] = Value.ref("DEFAULT"); pc = 9; continue; }
case 9: { r[3] = Value.i32(1); pc = 10; continue; }
case 10: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[2], r[3], r[4], r[4]}); pc = 11; continue; }
case 11: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->DEFAULT:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 12; continue; }
case 12: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 13; continue; }
case 13: { r[2] = Value.ref("PHONE"); pc = 14; continue; }
case 14: { r[5] = Value.i32(2); pc = 15; continue; }
case 15: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[2], r[5], r[1], r[4]}); pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->PHONE:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 17; continue; }
case 17: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 18; continue; }
case 18: { r[2] = Value.ref("MINIMAL"); pc = 19; continue; }
case 19: { r[6] = Value.i32(3); pc = 20; continue; }
case 20: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[2], r[6], r[1], r[4]}); pc = 21; continue; }
case 21: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MINIMAL:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 22; continue; }
case 22: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 23; continue; }
case 23: { r[1] = rt.readField("Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;",Value.NULL,true); pc = 24; continue; }
case 24: { r[2] = Value.ref("TABLET"); pc = 25; continue; }
case 25: { r[7] = Value.i32(4); pc = 26; continue; }
case 26: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[2], r[7], r[1], r[4]}); pc = 27; continue; }
case 27: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->TABLET:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 28; continue; }
case 28: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 29; continue; }
case 29: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[3]}); pc = 30; continue; }
case 30: { r[1] = result; pc = 31; continue; }
case 31: { r[2] = Value.ref("MODERN_1"); pc = 32; continue; }
case 32: { r[3] = Value.i32(5); pc = 33; continue; }
case 33: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[2], r[3], r[4], r[1]}); pc = 34; continue; }
case 34: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_1:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 35; continue; }
case 35: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 36; continue; }
case 36: { r[1] = Value.i32(6); pc = 37; continue; }
case 37: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[5]}); pc = 38; continue; }
case 38: { r[2] = result; pc = 39; continue; }
case 39: { r[5] = Value.ref("MODERN_2"); pc = 40; continue; }
case 40: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[5], r[1], r[4], r[2]}); pc = 41; continue; }
case 41: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_2:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 42; continue; }
case 42: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 43; continue; }
case 43: { r[1] = Value.i32(7); pc = 44; continue; }
case 44: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[6]}); pc = 45; continue; }
case 45: { r[2] = result; pc = 46; continue; }
case 46: { r[5] = Value.ref("MODERN_3"); pc = 47; continue; }
case 47: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[5], r[1], r[4], r[2]}); pc = 48; continue; }
case 48: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_3:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 49; continue; }
case 49: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 50; continue; }
case 50: { r[1] = Value.i32(8); pc = 51; continue; }
case 51: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[7]}); pc = 52; continue; }
case 52: { r[2] = result; pc = 53; continue; }
case 53: { r[5] = Value.ref("MODERN_4"); pc = 54; continue; }
case 54: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[5], r[1], r[4], r[2]}); pc = 55; continue; }
case 55: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_4:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 56; continue; }
case 56: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); pc = 57; continue; }
case 57: { r[1] = Value.i32(9); pc = 58; continue; }
case 58: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[3]}); pc = 59; continue; }
case 59: { r[2] = result; pc = 60; continue; }
case 60: { r[3] = Value.ref("MODERN_5"); pc = 61; continue; }
case 61: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;-><init>(Ljava/lang/String;ILjava/lang/Boolean;Ljava/lang/Integer;)V",r[0],new Value[]{r[3], r[1], r[4], r[2]}); pc = 62; continue; }
case 62: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_5:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 63; continue; }
case 63: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->$values()[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,new Value[]{}); pc = 64; continue; }
case 64: { r[0] = result; pc = 65; continue; }
case 65: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->$VALUES:[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true,r[0]); pc = 66; continue; }
case 66: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4494664146902cf7f71db5be(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Ljava/lang/Boolean;");
r[4] = rt.check(arguments[3], "Ljava/lang/Integer;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->legacyTabletOverride:Ljava/lang/Boolean;",r[0],false,r[3]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->modernPlayerType:Ljava/lang/Integer;",r[0],false,r[4]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a679dc0c822434bb4ad9f3d5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[10];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->DISABLED:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->DEFAULT:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->PHONE:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MINIMAL:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->TABLET:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_1:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 6; continue; }
case 6: { r[6] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_2:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 7; continue; }
case 7: { r[7] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_3:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 8; continue; }
case 8: { r[8] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_4:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 9; continue; }
case 9: { r[9] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->MODERN_5:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",Value.NULL,true); pc = 10; continue; }
case 10: { result=rt.filledArray("[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;",new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
