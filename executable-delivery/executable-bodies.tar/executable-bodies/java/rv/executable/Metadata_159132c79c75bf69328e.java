package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_159132c79c75bf69328e {
static ClassInfo info_159132c79c75bf69328e() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/spoof/SpoofVideoStreamsPatch$SpoofClientAv1Availability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
