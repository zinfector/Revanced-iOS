package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_bef7506f9e5f2e949c3d {
static Value m_88d5992de059d1fbc209ea24(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->$VALUES:[Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 1; continue; }
case 1: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/AppLanguage;", "[Lapp/revanced/extension/shared/settings/AppLanguage;->clone()Ljava/lang/Object;", r[0], new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0], "[Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 4; continue; }
case 4: { return rt.check(r[0], "[Lapp/revanced/extension/shared/settings/AppLanguage;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f74f87e0bb5b6a4a52a88578(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("DEFAULT"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->DEFAULT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("GA"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->GA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("AF"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->AF:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 15; continue; }
case 15: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 16; continue; }
case 16: { r[1] = Value.ref("AM"); pc = 17; continue; }
case 17: { r[2] = Value.i32(3); pc = 18; continue; }
case 18: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->AM:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 21; continue; }
case 21: { r[1] = Value.ref("AR"); pc = 22; continue; }
case 22: { r[2] = Value.i32(4); pc = 23; continue; }
case 23: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->AR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 25; continue; }
case 25: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 26; continue; }
case 26: { r[1] = Value.ref("AS"); pc = 27; continue; }
case 27: { r[2] = Value.i32(5); pc = 28; continue; }
case 28: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->AS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 30; continue; }
case 30: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 31; continue; }
case 31: { r[1] = Value.ref("AZ"); pc = 32; continue; }
case 32: { r[2] = Value.i32(6); pc = 33; continue; }
case 33: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 34; continue; }
case 34: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->AZ:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 35; continue; }
case 35: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 36; continue; }
case 36: { r[1] = Value.ref("BE"); pc = 37; continue; }
case 37: { r[2] = Value.i32(7); pc = 38; continue; }
case 38: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 39; continue; }
case 39: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->BE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 40; continue; }
case 40: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 41; continue; }
case 41: { r[1] = Value.ref("BG"); pc = 42; continue; }
case 42: { r[2] = Value.i32(8); pc = 43; continue; }
case 43: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 44; continue; }
case 44: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->BG:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 45; continue; }
case 45: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 46; continue; }
case 46: { r[1] = Value.ref("BN"); pc = 47; continue; }
case 47: { r[2] = Value.i32(9); pc = 48; continue; }
case 48: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 49; continue; }
case 49: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->BN:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 50; continue; }
case 50: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 51; continue; }
case 51: { r[1] = Value.ref("BS"); pc = 52; continue; }
case 52: { r[2] = Value.i32(10); pc = 53; continue; }
case 53: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 54; continue; }
case 54: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->BS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 55; continue; }
case 55: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 56; continue; }
case 56: { r[1] = Value.ref("CA"); pc = 57; continue; }
case 57: { r[2] = Value.i32(11); pc = 58; continue; }
case 58: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 59; continue; }
case 59: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->CA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 60; continue; }
case 60: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 61; continue; }
case 61: { r[1] = Value.ref("CS"); pc = 62; continue; }
case 62: { r[2] = Value.i32(12); pc = 63; continue; }
case 63: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 64; continue; }
case 64: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->CS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 65; continue; }
case 65: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 66; continue; }
case 66: { r[1] = Value.ref("DA"); pc = 67; continue; }
case 67: { r[2] = Value.i32(13); pc = 68; continue; }
case 68: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 69; continue; }
case 69: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->DA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 70; continue; }
case 70: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 71; continue; }
case 71: { r[1] = Value.ref("DE"); pc = 72; continue; }
case 72: { r[2] = Value.i32(14); pc = 73; continue; }
case 73: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 74; continue; }
case 74: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->DE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 75; continue; }
case 75: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 76; continue; }
case 76: { r[1] = Value.ref("EL"); pc = 77; continue; }
case 77: { r[2] = Value.i32(15); pc = 78; continue; }
case 78: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 79; continue; }
case 79: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->EL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 80; continue; }
case 80: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 81; continue; }
case 81: { r[1] = Value.ref("EN"); pc = 82; continue; }
case 82: { r[2] = Value.i32(16); pc = 83; continue; }
case 83: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 84; continue; }
case 84: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->EN:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 85; continue; }
case 85: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 86; continue; }
case 86: { r[1] = Value.ref("ES"); pc = 87; continue; }
case 87: { r[2] = Value.i32(17); pc = 88; continue; }
case 88: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 89; continue; }
case 89: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->ES:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 90; continue; }
case 90: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 91; continue; }
case 91: { r[1] = Value.ref("ET"); pc = 92; continue; }
case 92: { r[2] = Value.i32(18); pc = 93; continue; }
case 93: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 94; continue; }
case 94: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->ET:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 95; continue; }
case 95: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 96; continue; }
case 96: { r[1] = Value.ref("EU"); pc = 97; continue; }
case 97: { r[2] = Value.i32(19); pc = 98; continue; }
case 98: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 99; continue; }
case 99: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->EU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 100; continue; }
case 100: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 101; continue; }
case 101: { r[1] = Value.ref("FA"); pc = 102; continue; }
case 102: { r[2] = Value.i32(20); pc = 103; continue; }
case 103: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 104; continue; }
case 104: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->FA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 105; continue; }
case 105: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 106; continue; }
case 106: { r[1] = Value.ref("FI"); pc = 107; continue; }
case 107: { r[2] = Value.i32(21); pc = 108; continue; }
case 108: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 109; continue; }
case 109: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->FI:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 110; continue; }
case 110: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 111; continue; }
case 111: { r[1] = Value.ref("FR"); pc = 112; continue; }
case 112: { r[2] = Value.i32(22); pc = 113; continue; }
case 113: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 114; continue; }
case 114: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->FR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 115; continue; }
case 115: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 116; continue; }
case 116: { r[1] = Value.ref("GL"); pc = 117; continue; }
case 117: { r[2] = Value.i32(23); pc = 118; continue; }
case 118: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 119; continue; }
case 119: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->GL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 120; continue; }
case 120: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 121; continue; }
case 121: { r[1] = Value.ref("GU"); pc = 122; continue; }
case 122: { r[2] = Value.i32(24); pc = 123; continue; }
case 123: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 124; continue; }
case 124: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->GU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 125; continue; }
case 125: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 126; continue; }
case 126: { r[1] = Value.ref("HE"); pc = 127; continue; }
case 127: { r[2] = Value.i32(25); pc = 128; continue; }
case 128: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 129; continue; }
case 129: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->HE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 130; continue; }
case 130: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 131; continue; }
case 131: { r[1] = Value.ref("HI"); pc = 132; continue; }
case 132: { r[2] = Value.i32(26); pc = 133; continue; }
case 133: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 134; continue; }
case 134: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->HI:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 135; continue; }
case 135: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 136; continue; }
case 136: { r[1] = Value.ref("HR"); pc = 137; continue; }
case 137: { r[2] = Value.i32(27); pc = 138; continue; }
case 138: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 139; continue; }
case 139: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->HR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 140; continue; }
case 140: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 141; continue; }
case 141: { r[1] = Value.ref("HU"); pc = 142; continue; }
case 142: { r[2] = Value.i32(28); pc = 143; continue; }
case 143: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 144; continue; }
case 144: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->HU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 145; continue; }
case 145: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 146; continue; }
case 146: { r[1] = Value.ref("HY"); pc = 147; continue; }
case 147: { r[2] = Value.i32(29); pc = 148; continue; }
case 148: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 149; continue; }
case 149: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->HY:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 150; continue; }
case 150: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 151; continue; }
case 151: { r[1] = Value.ref("ID"); pc = 152; continue; }
case 152: { r[2] = Value.i32(30); pc = 153; continue; }
case 153: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 154; continue; }
case 154: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->ID:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 155; continue; }
case 155: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 156; continue; }
case 156: { r[1] = Value.ref("IS"); pc = 157; continue; }
case 157: { r[2] = Value.i32(31); pc = 158; continue; }
case 158: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 159; continue; }
case 159: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->IS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 160; continue; }
case 160: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 161; continue; }
case 161: { r[1] = Value.ref("IT"); pc = 162; continue; }
case 162: { r[2] = Value.i32(32); pc = 163; continue; }
case 163: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 164; continue; }
case 164: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->IT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 165; continue; }
case 165: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 166; continue; }
case 166: { r[1] = Value.ref("JA"); pc = 167; continue; }
case 167: { r[2] = Value.i32(33); pc = 168; continue; }
case 168: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 169; continue; }
case 169: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->JA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 170; continue; }
case 170: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 171; continue; }
case 171: { r[1] = Value.ref("KA"); pc = 172; continue; }
case 172: { r[2] = Value.i32(34); pc = 173; continue; }
case 173: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 174; continue; }
case 174: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->KA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 175; continue; }
case 175: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 176; continue; }
case 176: { r[1] = Value.ref("KK"); pc = 177; continue; }
case 177: { r[2] = Value.i32(35); pc = 178; continue; }
case 178: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 179; continue; }
case 179: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->KK:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 180; continue; }
case 180: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 181; continue; }
case 181: { r[1] = Value.ref("KM"); pc = 182; continue; }
case 182: { r[2] = Value.i32(36); pc = 183; continue; }
case 183: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 184; continue; }
case 184: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->KM:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 185; continue; }
case 185: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 186; continue; }
case 186: { r[1] = Value.ref("KN"); pc = 187; continue; }
case 187: { r[2] = Value.i32(37); pc = 188; continue; }
case 188: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 189; continue; }
case 189: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->KN:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 190; continue; }
case 190: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 191; continue; }
case 191: { r[1] = Value.ref("KO"); pc = 192; continue; }
case 192: { r[2] = Value.i32(38); pc = 193; continue; }
case 193: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 194; continue; }
case 194: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->KO:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 195; continue; }
case 195: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 196; continue; }
case 196: { r[1] = Value.ref("KY"); pc = 197; continue; }
case 197: { r[2] = Value.i32(39); pc = 198; continue; }
case 198: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 199; continue; }
case 199: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->KY:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 200; continue; }
case 200: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 201; continue; }
case 201: { r[1] = Value.ref("LO"); pc = 202; continue; }
case 202: { r[2] = Value.i32(40); pc = 203; continue; }
case 203: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 204; continue; }
case 204: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->LO:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 205; continue; }
case 205: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 206; continue; }
case 206: { r[1] = Value.ref("LT"); pc = 207; continue; }
case 207: { r[2] = Value.i32(41); pc = 208; continue; }
case 208: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 209; continue; }
case 209: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->LT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 210; continue; }
case 210: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 211; continue; }
case 211: { r[1] = Value.ref("LV"); pc = 212; continue; }
case 212: { r[2] = Value.i32(42); pc = 213; continue; }
case 213: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 214; continue; }
case 214: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->LV:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 215; continue; }
case 215: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 216; continue; }
case 216: { r[1] = Value.ref("MK"); pc = 217; continue; }
case 217: { r[2] = Value.i32(43); pc = 218; continue; }
case 218: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 219; continue; }
case 219: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->MK:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 220; continue; }
case 220: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 221; continue; }
case 221: { r[1] = Value.ref("ML"); pc = 222; continue; }
case 222: { r[2] = Value.i32(44); pc = 223; continue; }
case 223: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 224; continue; }
case 224: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->ML:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 225; continue; }
case 225: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 226; continue; }
case 226: { r[1] = Value.ref("MN"); pc = 227; continue; }
case 227: { r[2] = Value.i32(45); pc = 228; continue; }
case 228: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 229; continue; }
case 229: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->MN:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 230; continue; }
case 230: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 231; continue; }
case 231: { r[1] = Value.ref("MR"); pc = 232; continue; }
case 232: { r[2] = Value.i32(46); pc = 233; continue; }
case 233: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 234; continue; }
case 234: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->MR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 235; continue; }
case 235: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 236; continue; }
case 236: { r[1] = Value.ref("MS"); pc = 237; continue; }
case 237: { r[2] = Value.i32(47); pc = 238; continue; }
case 238: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 239; continue; }
case 239: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->MS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 240; continue; }
case 240: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 241; continue; }
case 241: { r[1] = Value.ref("MY"); pc = 242; continue; }
case 242: { r[2] = Value.i32(48); pc = 243; continue; }
case 243: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 244; continue; }
case 244: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->MY:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 245; continue; }
case 245: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 246; continue; }
case 246: { r[1] = Value.ref("NB"); pc = 247; continue; }
case 247: { r[2] = Value.i32(49); pc = 248; continue; }
case 248: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 249; continue; }
case 249: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->NB:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 250; continue; }
case 250: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 251; continue; }
case 251: { r[1] = Value.ref("NE"); pc = 252; continue; }
case 252: { r[2] = Value.i32(50); pc = 253; continue; }
case 253: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 254; continue; }
case 254: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->NE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 255; continue; }
case 255: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 256; continue; }
case 256: { r[1] = Value.ref("NL"); pc = 257; continue; }
case 257: { r[2] = Value.i32(51); pc = 258; continue; }
case 258: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 259; continue; }
case 259: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->NL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 260; continue; }
case 260: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 261; continue; }
case 261: { r[1] = Value.ref("OR"); pc = 262; continue; }
case 262: { r[2] = Value.i32(52); pc = 263; continue; }
case 263: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 264; continue; }
case 264: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->OR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 265; continue; }
case 265: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 266; continue; }
case 266: { r[1] = Value.ref("PA"); pc = 267; continue; }
case 267: { r[2] = Value.i32(53); pc = 268; continue; }
case 268: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 269; continue; }
case 269: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->PA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 270; continue; }
case 270: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 271; continue; }
case 271: { r[1] = Value.ref("PL"); pc = 272; continue; }
case 272: { r[2] = Value.i32(54); pc = 273; continue; }
case 273: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 274; continue; }
case 274: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->PL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 275; continue; }
case 275: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 276; continue; }
case 276: { r[1] = Value.ref("PT"); pc = 277; continue; }
case 277: { r[2] = Value.i32(55); pc = 278; continue; }
case 278: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 279; continue; }
case 279: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->PT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 280; continue; }
case 280: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 281; continue; }
case 281: { r[1] = Value.ref("RO"); pc = 282; continue; }
case 282: { r[2] = Value.i32(56); pc = 283; continue; }
case 283: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 284; continue; }
case 284: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->RO:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 285; continue; }
case 285: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 286; continue; }
case 286: { r[1] = Value.ref("RU"); pc = 287; continue; }
case 287: { r[2] = Value.i32(57); pc = 288; continue; }
case 288: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 289; continue; }
case 289: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->RU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 290; continue; }
case 290: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 291; continue; }
case 291: { r[1] = Value.ref("SI"); pc = 292; continue; }
case 292: { r[2] = Value.i32(58); pc = 293; continue; }
case 293: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 294; continue; }
case 294: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->SI:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 295; continue; }
case 295: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 296; continue; }
case 296: { r[1] = Value.ref("SK"); pc = 297; continue; }
case 297: { r[2] = Value.i32(59); pc = 298; continue; }
case 298: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 299; continue; }
case 299: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->SK:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 300; continue; }
case 300: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 301; continue; }
case 301: { r[1] = Value.ref("SL"); pc = 302; continue; }
case 302: { r[2] = Value.i32(60); pc = 303; continue; }
case 303: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 304; continue; }
case 304: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->SL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 305; continue; }
case 305: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 306; continue; }
case 306: { r[1] = Value.ref("SQ"); pc = 307; continue; }
case 307: { r[2] = Value.i32(61); pc = 308; continue; }
case 308: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 309; continue; }
case 309: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->SQ:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 310; continue; }
case 310: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 311; continue; }
case 311: { r[1] = Value.ref("SR"); pc = 312; continue; }
case 312: { r[2] = Value.i32(62); pc = 313; continue; }
case 313: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 314; continue; }
case 314: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->SR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 315; continue; }
case 315: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 316; continue; }
case 316: { r[1] = Value.ref("SV"); pc = 317; continue; }
case 317: { r[2] = Value.i32(63); pc = 318; continue; }
case 318: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 319; continue; }
case 319: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->SV:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 320; continue; }
case 320: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 321; continue; }
case 321: { r[1] = Value.ref("SW"); pc = 322; continue; }
case 322: { r[2] = Value.i32(64); pc = 323; continue; }
case 323: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 324; continue; }
case 324: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->SW:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 325; continue; }
case 325: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 326; continue; }
case 326: { r[1] = Value.ref("TA"); pc = 327; continue; }
case 327: { r[2] = Value.i32(65); pc = 328; continue; }
case 328: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 329; continue; }
case 329: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->TA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 330; continue; }
case 330: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 331; continue; }
case 331: { r[1] = Value.ref("TE"); pc = 332; continue; }
case 332: { r[2] = Value.i32(66); pc = 333; continue; }
case 333: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 334; continue; }
case 334: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->TE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 335; continue; }
case 335: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 336; continue; }
case 336: { r[1] = Value.ref("TH"); pc = 337; continue; }
case 337: { r[2] = Value.i32(67); pc = 338; continue; }
case 338: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 339; continue; }
case 339: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->TH:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 340; continue; }
case 340: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 341; continue; }
case 341: { r[1] = Value.ref("TL"); pc = 342; continue; }
case 342: { r[2] = Value.i32(68); pc = 343; continue; }
case 343: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 344; continue; }
case 344: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->TL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 345; continue; }
case 345: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 346; continue; }
case 346: { r[1] = Value.ref("TR"); pc = 347; continue; }
case 347: { r[2] = Value.i32(69); pc = 348; continue; }
case 348: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 349; continue; }
case 349: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->TR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 350; continue; }
case 350: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 351; continue; }
case 351: { r[1] = Value.ref("UK"); pc = 352; continue; }
case 352: { r[2] = Value.i32(70); pc = 353; continue; }
case 353: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 354; continue; }
case 354: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->UK:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 355; continue; }
case 355: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 356; continue; }
case 356: { r[1] = Value.ref("UR"); pc = 357; continue; }
case 357: { r[2] = Value.i32(71); pc = 358; continue; }
case 358: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 359; continue; }
case 359: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->UR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 360; continue; }
case 360: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 361; continue; }
case 361: { r[1] = Value.ref("UZ"); pc = 362; continue; }
case 362: { r[2] = Value.i32(72); pc = 363; continue; }
case 363: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 364; continue; }
case 364: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->UZ:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 365; continue; }
case 365: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 366; continue; }
case 366: { r[1] = Value.ref("VI"); pc = 367; continue; }
case 367: { r[2] = Value.i32(73); pc = 368; continue; }
case 368: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 369; continue; }
case 369: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->VI:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 370; continue; }
case 370: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 371; continue; }
case 371: { r[1] = Value.ref("ZH"); pc = 372; continue; }
case 372: { r[2] = Value.i32(74); pc = 373; continue; }
case 373: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 374; continue; }
case 374: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->ZH:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 375; continue; }
case 375: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 376; continue; }
case 376: { r[1] = Value.ref("ZU"); pc = 377; continue; }
case 377: { r[2] = Value.i32(75); pc = 378; continue; }
case 378: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 379; continue; }
case 379: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->ZU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 380; continue; }
case 380: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Lapp/revanced/extension/shared/settings/AppLanguage;->$values()[Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, new Value[]{}); pc = 381; continue; }
case 381: { r[0] = result; pc = 382; continue; }
case 382: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->$VALUES:[Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true, r[0]); pc = 383; continue; }
case 383: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_503b8debd8e14342369397ed(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/AppLanguage;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Ljava/lang/Enum;->name()Ljava/lang/String;", r[0], new Value[]{}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { r[2] = rt.readField("Ljava/util/Locale;->US:Ljava/util/Locale;", Value.NULL, true); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;", r[1], new Value[]{r[2]}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->language:Ljava/lang/String;", r[0], false, r[1]); pc = 7; continue; }
case 7: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/AppLanguage;", "Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;", Value.NULL, new Value[]{r[1]}); pc = 8; continue; }
case 8: { r[1] = result; pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/settings/AppLanguage;->locale:Ljava/util/Locale;", r[0], false, r[1]); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_767bfea05ac4fa4ce7776ab0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(76); pc = 1; continue; }
case 1: { r[0] = rt.newArray("[Lapp/revanced/extension/shared/settings/AppLanguage;", r[0].i()); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->DEFAULT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->GA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 6; continue; }
case 6: { r[2] = Value.i32(1); pc = 7; continue; }
case 7: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->AF:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 9; continue; }
case 9: { r[2] = Value.i32(2); pc = 10; continue; }
case 10: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 11; continue; }
case 11: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->AM:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 12; continue; }
case 12: { r[2] = Value.i32(3); pc = 13; continue; }
case 13: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 14; continue; }
case 14: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->AR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 15; continue; }
case 15: { r[2] = Value.i32(4); pc = 16; continue; }
case 16: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 17; continue; }
case 17: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->AS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 18; continue; }
case 18: { r[2] = Value.i32(5); pc = 19; continue; }
case 19: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 20; continue; }
case 20: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->AZ:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 21; continue; }
case 21: { r[2] = Value.i32(6); pc = 22; continue; }
case 22: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 23; continue; }
case 23: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->BE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 24; continue; }
case 24: { r[2] = Value.i32(7); pc = 25; continue; }
case 25: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 26; continue; }
case 26: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->BG:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 27; continue; }
case 27: { r[2] = Value.i32(8); pc = 28; continue; }
case 28: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 29; continue; }
case 29: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->BN:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 30; continue; }
case 30: { r[2] = Value.i32(9); pc = 31; continue; }
case 31: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 32; continue; }
case 32: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->BS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 33; continue; }
case 33: { r[2] = Value.i32(10); pc = 34; continue; }
case 34: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 35; continue; }
case 35: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->CA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 36; continue; }
case 36: { r[2] = Value.i32(11); pc = 37; continue; }
case 37: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 38; continue; }
case 38: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->CS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 39; continue; }
case 39: { r[2] = Value.i32(12); pc = 40; continue; }
case 40: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 41; continue; }
case 41: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->DA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 42; continue; }
case 42: { r[2] = Value.i32(13); pc = 43; continue; }
case 43: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 44; continue; }
case 44: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->DE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 45; continue; }
case 45: { r[2] = Value.i32(14); pc = 46; continue; }
case 46: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 47; continue; }
case 47: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->EL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 48; continue; }
case 48: { r[2] = Value.i32(15); pc = 49; continue; }
case 49: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 50; continue; }
case 50: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->EN:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 51; continue; }
case 51: { r[2] = Value.i32(16); pc = 52; continue; }
case 52: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 53; continue; }
case 53: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->ES:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 54; continue; }
case 54: { r[2] = Value.i32(17); pc = 55; continue; }
case 55: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 56; continue; }
case 56: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->ET:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 57; continue; }
case 57: { r[2] = Value.i32(18); pc = 58; continue; }
case 58: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 59; continue; }
case 59: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->EU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 60; continue; }
case 60: { r[2] = Value.i32(19); pc = 61; continue; }
case 61: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 62; continue; }
case 62: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->FA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 63; continue; }
case 63: { r[2] = Value.i32(20); pc = 64; continue; }
case 64: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 65; continue; }
case 65: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->FI:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 66; continue; }
case 66: { r[2] = Value.i32(21); pc = 67; continue; }
case 67: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 68; continue; }
case 68: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->FR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 69; continue; }
case 69: { r[2] = Value.i32(22); pc = 70; continue; }
case 70: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 71; continue; }
case 71: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->GL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 72; continue; }
case 72: { r[2] = Value.i32(23); pc = 73; continue; }
case 73: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 74; continue; }
case 74: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->GU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 75; continue; }
case 75: { r[2] = Value.i32(24); pc = 76; continue; }
case 76: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 77; continue; }
case 77: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->HE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 78; continue; }
case 78: { r[2] = Value.i32(25); pc = 79; continue; }
case 79: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 80; continue; }
case 80: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->HI:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 81; continue; }
case 81: { r[2] = Value.i32(26); pc = 82; continue; }
case 82: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 83; continue; }
case 83: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->HR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 84; continue; }
case 84: { r[2] = Value.i32(27); pc = 85; continue; }
case 85: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 86; continue; }
case 86: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->HU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 87; continue; }
case 87: { r[2] = Value.i32(28); pc = 88; continue; }
case 88: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 89; continue; }
case 89: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->HY:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 90; continue; }
case 90: { r[2] = Value.i32(29); pc = 91; continue; }
case 91: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 92; continue; }
case 92: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->ID:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 93; continue; }
case 93: { r[2] = Value.i32(30); pc = 94; continue; }
case 94: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 95; continue; }
case 95: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->IS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 96; continue; }
case 96: { r[2] = Value.i32(31); pc = 97; continue; }
case 97: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 98; continue; }
case 98: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->IT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 99; continue; }
case 99: { r[2] = Value.i32(32); pc = 100; continue; }
case 100: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 101; continue; }
case 101: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->JA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 102; continue; }
case 102: { r[2] = Value.i32(33); pc = 103; continue; }
case 103: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 104; continue; }
case 104: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->KA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 105; continue; }
case 105: { r[2] = Value.i32(34); pc = 106; continue; }
case 106: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 107; continue; }
case 107: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->KK:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 108; continue; }
case 108: { r[2] = Value.i32(35); pc = 109; continue; }
case 109: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 110; continue; }
case 110: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->KM:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 111; continue; }
case 111: { r[2] = Value.i32(36); pc = 112; continue; }
case 112: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 113; continue; }
case 113: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->KN:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 114; continue; }
case 114: { r[2] = Value.i32(37); pc = 115; continue; }
case 115: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 116; continue; }
case 116: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->KO:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 117; continue; }
case 117: { r[2] = Value.i32(38); pc = 118; continue; }
case 118: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 119; continue; }
case 119: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->KY:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 120; continue; }
case 120: { r[2] = Value.i32(39); pc = 121; continue; }
case 121: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 122; continue; }
case 122: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->LO:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 123; continue; }
case 123: { r[2] = Value.i32(40); pc = 124; continue; }
case 124: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 125; continue; }
case 125: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->LT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 126; continue; }
case 126: { r[2] = Value.i32(41); pc = 127; continue; }
case 127: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 128; continue; }
case 128: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->LV:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 129; continue; }
case 129: { r[2] = Value.i32(42); pc = 130; continue; }
case 130: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 131; continue; }
case 131: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->MK:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 132; continue; }
case 132: { r[2] = Value.i32(43); pc = 133; continue; }
case 133: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 134; continue; }
case 134: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->ML:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 135; continue; }
case 135: { r[2] = Value.i32(44); pc = 136; continue; }
case 136: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 137; continue; }
case 137: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->MN:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 138; continue; }
case 138: { r[2] = Value.i32(45); pc = 139; continue; }
case 139: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 140; continue; }
case 140: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->MR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 141; continue; }
case 141: { r[2] = Value.i32(46); pc = 142; continue; }
case 142: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 143; continue; }
case 143: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->MS:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 144; continue; }
case 144: { r[2] = Value.i32(47); pc = 145; continue; }
case 145: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 146; continue; }
case 146: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->MY:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 147; continue; }
case 147: { r[2] = Value.i32(48); pc = 148; continue; }
case 148: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 149; continue; }
case 149: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->NB:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 150; continue; }
case 150: { r[2] = Value.i32(49); pc = 151; continue; }
case 151: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 152; continue; }
case 152: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->NE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 153; continue; }
case 153: { r[2] = Value.i32(50); pc = 154; continue; }
case 154: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 155; continue; }
case 155: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->NL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 156; continue; }
case 156: { r[2] = Value.i32(51); pc = 157; continue; }
case 157: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 158; continue; }
case 158: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->OR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 159; continue; }
case 159: { r[2] = Value.i32(52); pc = 160; continue; }
case 160: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 161; continue; }
case 161: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->PA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 162; continue; }
case 162: { r[2] = Value.i32(53); pc = 163; continue; }
case 163: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 164; continue; }
case 164: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->PL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 165; continue; }
case 165: { r[2] = Value.i32(54); pc = 166; continue; }
case 166: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 167; continue; }
case 167: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->PT:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 168; continue; }
case 168: { r[2] = Value.i32(55); pc = 169; continue; }
case 169: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 170; continue; }
case 170: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->RO:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 171; continue; }
case 171: { r[2] = Value.i32(56); pc = 172; continue; }
case 172: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 173; continue; }
case 173: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->RU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 174; continue; }
case 174: { r[2] = Value.i32(57); pc = 175; continue; }
case 175: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 176; continue; }
case 176: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->SI:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 177; continue; }
case 177: { r[2] = Value.i32(58); pc = 178; continue; }
case 178: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 179; continue; }
case 179: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->SK:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 180; continue; }
case 180: { r[2] = Value.i32(59); pc = 181; continue; }
case 181: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 182; continue; }
case 182: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->SL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 183; continue; }
case 183: { r[2] = Value.i32(60); pc = 184; continue; }
case 184: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 185; continue; }
case 185: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->SQ:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 186; continue; }
case 186: { r[2] = Value.i32(61); pc = 187; continue; }
case 187: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 188; continue; }
case 188: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->SR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 189; continue; }
case 189: { r[2] = Value.i32(62); pc = 190; continue; }
case 190: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 191; continue; }
case 191: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->SV:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 192; continue; }
case 192: { r[2] = Value.i32(63); pc = 193; continue; }
case 193: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 194; continue; }
case 194: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->SW:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 195; continue; }
case 195: { r[2] = Value.i32(64); pc = 196; continue; }
case 196: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 197; continue; }
case 197: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->TA:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 198; continue; }
case 198: { r[2] = Value.i32(65); pc = 199; continue; }
case 199: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 200; continue; }
case 200: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->TE:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 201; continue; }
case 201: { r[2] = Value.i32(66); pc = 202; continue; }
case 202: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 203; continue; }
case 203: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->TH:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 204; continue; }
case 204: { r[2] = Value.i32(67); pc = 205; continue; }
case 205: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 206; continue; }
case 206: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->TL:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 207; continue; }
case 207: { r[2] = Value.i32(68); pc = 208; continue; }
case 208: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 209; continue; }
case 209: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->TR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 210; continue; }
case 210: { r[2] = Value.i32(69); pc = 211; continue; }
case 211: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 212; continue; }
case 212: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->UK:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 213; continue; }
case 213: { r[2] = Value.i32(70); pc = 214; continue; }
case 214: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 215; continue; }
case 215: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->UR:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 216; continue; }
case 216: { r[2] = Value.i32(71); pc = 217; continue; }
case 217: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 218; continue; }
case 218: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->UZ:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 219; continue; }
case 219: { r[2] = Value.i32(72); pc = 220; continue; }
case 220: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 221; continue; }
case 221: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->VI:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 222; continue; }
case 222: { r[2] = Value.i32(73); pc = 223; continue; }
case 223: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 224; continue; }
case 224: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->ZH:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 225; continue; }
case 225: { r[2] = Value.i32(74); pc = 226; continue; }
case 226: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 227; continue; }
case 227: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->ZU:Lapp/revanced/extension/shared/settings/AppLanguage;", Value.NULL, true); pc = 228; continue; }
case 228: { r[2] = Value.i32(75); pc = 229; continue; }
case 229: { rt.arrayPut(r[0], r[2].i(), r[1]); pc = 230; continue; }
case 230: { return rt.check(r[0], "[Lapp/revanced/extension/shared/settings/AppLanguage;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
