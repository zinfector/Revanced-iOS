package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_a2b90f18ded32793 extends RuntimeForeign.SourceProxy implements java.util.concurrent.Executor {
Proxy_a2b90f18ded32793(RuntimeForeign owner,Instance source){super(owner,source);}
public void execute(java.lang.Runnable a0) {Value result=owner.callback(source,"Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V",new Value[]{owner.importValue(a0)}); return;}
}
