package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_b1b54795e7b5f923 extends RuntimeForeign.SourceProxy implements java.util.ListIterator {
Source_b1b54795e7b5f923(RuntimeForeign owner,Instance source){super(owner,source);}
public boolean hasNext() {Value result=owner.callback(source,"Ljava/util/ListIterator;->hasNext()Z",new Value[]{}); return result.z();}
public java.lang.Object next() {Value result=owner.callback(source,"Ljava/util/ListIterator;->next()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public boolean hasPrevious() {Value result=owner.callback(source,"Ljava/util/ListIterator;->hasPrevious()Z",new Value[]{}); return result.z();}
public java.lang.Object previous() {Value result=owner.callback(source,"Ljava/util/ListIterator;->previous()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public int nextIndex() {Value result=owner.callback(source,"Ljava/util/ListIterator;->nextIndex()I",new Value[]{}); return result.i();}
public int previousIndex() {Value result=owner.callback(source,"Ljava/util/ListIterator;->previousIndex()I",new Value[]{}); return result.i();}
public void remove() {Value result=owner.callback(source,"Ljava/util/ListIterator;->remove()V",new Value[]{}); return;}
public void set(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/ListIterator;->set(Ljava/lang/Object;)V",new Value[]{owner.importValue(a0)}); return;}
public void add(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/ListIterator;->add(Ljava/lang/Object;)V",new Value[]{owner.importValue(a0)}); return;}
}
