package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_2e46b552f787bd33a0d3 {
static ClassInfo info_2e46b552f787bd33a0d3() {return new ClassInfo("Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;->f$0:Lapp/revanced/extension/youtube/shared/VideoState;", "Lapp/revanced/extension/youtube/shared/VideoState;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/shared/VideoState;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/shared/VideoState;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "VideoState$Companion$$ExternalSyntheticLambda1");}
}
