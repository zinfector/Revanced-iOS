package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_2df84d76ede30468bcef {
static Value m_3cfe31b00e53c191ff918037(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[3] = rt.check(receiver, "Lkotlin/collections/AbstractList$SubList;");
r[4] = rt.check(arguments[0], "I");
r[5] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lkotlin/collections/AbstractList$SubList;->_size:I",r[3],false); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$SubList;","Lkotlin/collections/AbstractList$Companion;->checkRangeIndexes$kotlin_stdlib(III)V",r[0],new Value[]{r[4], r[5], r[1]}); pc = 3; continue; }
case 3: { r[0] = rt.allocate("Lkotlin/collections/AbstractList$SubList;"); pc = 4; continue; }
case 4: { r[1] = rt.readField("Lkotlin/collections/AbstractList$SubList;->list:Lkotlin/collections/AbstractList;",r[3],false); pc = 5; continue; }
case 5: { r[2] = rt.readField("Lkotlin/collections/AbstractList$SubList;->fromIndex:I",r[3],false); pc = 6; continue; }
case 6: { r[4] = Value.i32((r[4].i()) + (r[2].i())); pc = 7; continue; }
case 7: { r[2] = Value.i32((r[2].i()) + (r[5].i())); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lkotlin/collections/AbstractList$SubList;","Lkotlin/collections/AbstractList$SubList;-><init>(Lkotlin/collections/AbstractList;II)V",r[0],new Value[]{r[1], r[4], r[2]}); pc = 9; continue; }
case 9: { return rt.check(r[0],"Ljava/util/List;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b631d900c7ab343deafbbad4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList$SubList;");
r[2] = rt.check(arguments[0], "Lkotlin/collections/AbstractList;");
r[3] = rt.check(arguments[1], "I");
r[4] = rt.check(arguments[2], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$SubList;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[2],new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lkotlin/collections/AbstractList$SubList;","Lkotlin/collections/AbstractList;-><init>()V",r[1],new Value[]{}); pc = 2; continue; }
case 2: { rt.writeField("Lkotlin/collections/AbstractList$SubList;->list:Lkotlin/collections/AbstractList;",r[1],false,r[2]); pc = 3; continue; }
case 3: { rt.writeField("Lkotlin/collections/AbstractList$SubList;->fromIndex:I",r[1],false,r[3]); pc = 4; continue; }
case 4: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;",Value.NULL,true); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$SubList;","Lkotlin/collections/AbstractCollection;->size()I",r[2],new Value[]{}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$SubList;","Lkotlin/collections/AbstractList$Companion;->checkRangeIndexes$kotlin_stdlib(III)V",r[0],new Value[]{r[3], r[4], r[2]}); pc = 8; continue; }
case 8: { r[4] = Value.i32((r[4].i()) - (r[3].i())); pc = 9; continue; }
case 9: { rt.writeField("Lkotlin/collections/AbstractList$SubList;->_size:I",r[1],false,r[4]); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e0422afa513fb0611eae8e23(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(receiver, "Lkotlin/collections/AbstractList$SubList;");
r[3] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/collections/AbstractList;->Companion:Lkotlin/collections/AbstractList$Companion;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lkotlin/collections/AbstractList$SubList;->_size:I",r[2],false); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$SubList;","Lkotlin/collections/AbstractList$Companion;->checkElementIndex$kotlin_stdlib(II)V",r[0],new Value[]{r[3], r[1]}); pc = 3; continue; }
case 3: { r[0] = rt.readField("Lkotlin/collections/AbstractList$SubList;->list:Lkotlin/collections/AbstractList;",r[2],false); pc = 4; continue; }
case 4: { r[1] = rt.readField("Lkotlin/collections/AbstractList$SubList;->fromIndex:I",r[2],false); pc = 5; continue; }
case 5: { r[1] = Value.i32((r[1].i()) + (r[3].i())); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lkotlin/collections/AbstractList$SubList;","Lkotlin/collections/AbstractList;->get(I)Ljava/lang/Object;",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { r[3] = result; pc = 8; continue; }
case 8: { return rt.check(r[3],"Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_db666d9892bb075be7b3a56d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lkotlin/collections/AbstractList$SubList;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lkotlin/collections/AbstractList$SubList;->_size:I",r[1],false); pc = 1; continue; }
case 1: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
