package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_fa2c878866aa7a37a341 {
static Value m_2ea16eeb1c537fe910150889(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Landroid/widget/Toolbar;");
r[1] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticApiModelOutline0;","Landroid/widget/Toolbar;->setTitleMarginStart(I)V",r[0],new Value[]{r[1]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
