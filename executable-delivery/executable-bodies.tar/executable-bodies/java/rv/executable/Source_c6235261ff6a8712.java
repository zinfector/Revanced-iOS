package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_c6235261ff6a8712 extends RuntimeForeign.SourceProxy {
Source_c6235261ff6a8712(RuntimeForeign owner,Instance source){super(owner,source);}

}
