package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_76dc52fd4ac507ed097f {
static ClassInfo info_76dc52fd4ac507ed097f() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/ui/CreateSegmentButton$$ExternalSyntheticLambda1;", "Ljava/lang/Object;", new String[]{"Landroid/view/View$OnClickListener;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("onClick(Landroid/view/View;)V", 17)}, "CreateSegmentButton$$ExternalSyntheticLambda1");}
}
