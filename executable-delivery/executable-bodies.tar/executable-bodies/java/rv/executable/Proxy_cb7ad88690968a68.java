package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_cb7ad88690968a68 extends RuntimeForeign.SourceProxy implements java.util.concurrent.BlockingQueue {
Proxy_cb7ad88690968a68(RuntimeForeign owner,Instance source){super(owner,source);}
public boolean add(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->add(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean offer(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->offer(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public void put(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->put(Ljava/lang/Object;)V",new Value[]{owner.importValue(a0)}); return;}
public boolean offer(java.lang.Object a0,long a1,java.util.concurrent.TimeUnit a2) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->offer(Ljava/lang/Object;JLjava/util/concurrent/TimeUnit;)Z",new Value[]{owner.importValue(a0),Value.i64(a1),owner.importValue(a2)}); return result.z();}
public java.lang.Object take() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->take()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object poll(long a0,java.util.concurrent.TimeUnit a1) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;",new Value[]{Value.i64(a0),owner.importValue(a1)}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public int remainingCapacity() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->remainingCapacity()I",new Value[]{}); return result.i();}
public boolean remove(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->remove(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean contains(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->contains(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int drainTo(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->drainTo(Ljava/util/Collection;)I",new Value[]{owner.importValue(a0)}); return result.i();}
public int drainTo(java.util.Collection a0,int a1) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->drainTo(Ljava/util/Collection;I)I",new Value[]{owner.importValue(a0),Value.i32(a1)}); return result.i();}
public java.lang.Object remove() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->remove()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object poll() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->poll()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object element() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->element()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object peek() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->peek()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public int size() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->size()I",new Value[]{}); return result.i();}
public boolean isEmpty() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->isEmpty()Z",new Value[]{}); return result.z();}
public java.util.Iterator iterator() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->iterator()Ljava/util/Iterator;",new Value[]{}); return (java.util.Iterator)owner.exportObject(result.o(),"Ljava/util/Iterator;");}
public java.lang.Object[] toArray() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->toArray()[Ljava/lang/Object;",new Value[]{}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public java.lang.Object[] toArray(java.lang.Object[] a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;",new Value[]{owner.importValue(a0)}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public boolean containsAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->containsAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean addAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->addAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean removeAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->removeAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean retainAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->retainAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public void clear() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->clear()V",new Value[]{}); return;}
public boolean equals(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->equals(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int hashCode() {Value result=owner.callback(source,"Ljava/util/concurrent/BlockingQueue;->hashCode()I",new Value[]{}); return result.i();}
}
