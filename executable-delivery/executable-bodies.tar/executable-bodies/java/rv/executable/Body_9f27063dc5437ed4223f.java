package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_9f27063dc5437ed4223f {
static Value m_be41555163ac09a55c844f47(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("19.17.00"); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_19_17_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 4; continue; }
case 4: { r[0] = Value.ref("19.20.00"); pc = 5; continue; }
case 5: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_19_20_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 8; continue; }
case 8: { r[0] = Value.ref("19.21.00"); pc = 9; continue; }
case 9: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 10; continue; }
case 10: { r[0] = result; pc = 11; continue; }
case 11: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_19_21_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 12; continue; }
case 12: { r[0] = Value.ref("19.26.00"); pc = 13; continue; }
case 13: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 14; continue; }
case 14: { r[0] = result; pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_19_26_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 16; continue; }
case 16: { r[0] = Value.ref("19.29.00"); pc = 17; continue; }
case 17: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 18; continue; }
case 18: { r[0] = result; pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_19_29_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 20; continue; }
case 20: { r[0] = Value.ref("19.34.00"); pc = 21; continue; }
case 21: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 22; continue; }
case 22: { r[0] = result; pc = 23; continue; }
case 23: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_19_34_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 24; continue; }
case 24: { r[0] = Value.ref("20.21.00"); pc = 25; continue; }
case 25: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 26; continue; }
case 26: { r[0] = result; pc = 27; continue; }
case 27: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_20_21_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 28; continue; }
case 28: { r[0] = Value.ref("20.22.00"); pc = 29; continue; }
case 29: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 30; continue; }
case 30: { r[0] = result; pc = 31; continue; }
case 31: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_20_22_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 32; continue; }
case 32: { r[0] = Value.ref("20.31.00"); pc = 33; continue; }
case 33: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 34; continue; }
case 34: { r[0] = result; pc = 35; continue; }
case 35: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_20_31_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 36; continue; }
case 36: { r[0] = Value.ref("20.37.00"); pc = 37; continue; }
case 37: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->isVersionOrGreater(Ljava/lang/String;)Z", Value.NULL, new Value[]{r[0]}); pc = 38; continue; }
case 38: { r[0] = result; pc = 39; continue; }
case 39: { rt.writeField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_20_37_OR_GREATER:Z", Value.NULL, true, r[0]); pc = 40; continue; }
case 40: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e506f31eb9576dc8cf2ebc25(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new VerifyError("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Lapp/revanced/extension/shared/Utils;->getAppVersionName()Ljava/lang/String;", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/patches/VersionCheckPatch;", "Ljava/lang/String;->compareTo(Ljava/lang/String;)I", r[0], new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { pc = (r[1].i() < 0) ? 7 : 5; continue; }
case 5: { r[1] = Value.i32(1); pc = 6; continue; }
case 6: { return rt.check(r[1], "Z"); }
case 7: { r[1] = Value.i32(0); pc = 8; continue; }
case 8: { return rt.check(r[1], "Z"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
