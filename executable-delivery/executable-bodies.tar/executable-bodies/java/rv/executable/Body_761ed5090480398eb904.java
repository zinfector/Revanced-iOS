package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_761ed5090480398eb904 {
static Value m_ac26336a7424a2856779a876(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->newSponsorSegmentDialogShownMillis:J",Value.NULL,true,r[0]); pc = 2; continue; }
case 2: { r[0] = Value.i64(-1L); r[1] = r[0]; pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->newSponsorSegmentStartMillis:J",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->newSponsorSegmentEndMillis:J",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = Value.i32(0); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->newSponsorSegmentPreviewed:Z",Value.NULL,true,r[0]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_af207b212fc22450270aa43d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("#FFC83D"); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->LOCKED_COLOR:I",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { r[0] = Value.ref("((\\d{1,2}):)?(\\d{1,2}):(\\d{2})(\\.(\\d{1,3}))?"); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->manualEditTimePattern:Ljava/util/regex/Pattern;",Value.NULL,true,r[0]); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Ljava/text/NumberFormat;->getNumberInstance()Ljava/text/NumberFormat;",Value.NULL,new Value[]{}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->statsNumberFormatter:Ljava/text/NumberFormat;",Value.NULL,true,r[0]); pc = 11; continue; }
case 11: { r[0] = Value.i64(-1L); r[1] = r[0]; pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->newSponsorSegmentStartMillis:J",Value.NULL,true,r[0]); pc = 13; continue; }
case 13: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->newSponsorSegmentEndMillis:J",Value.NULL,true,r[0]); pc = 14; continue; }
case 14: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$1;"); pc = 15; continue; }
case 15: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$1;-><init>()V",r[0],new Value[]{}); pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->newSponsorSegmentDialogListener:Landroid/content/DialogInterface$OnClickListener;",Value.NULL,true,r[0]); pc = 17; continue; }
case 17: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$2;"); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$2;-><init>()V",r[0],new Value[]{}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->segmentTypeListener:Landroid/content/DialogInterface$OnClickListener;",Value.NULL,true,r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$3;"); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$3;-><init>()V",r[0],new Value[]{}); pc = 22; continue; }
case 22: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->segmentReadyDialogButtonListener:Landroid/content/DialogInterface$OnClickListener;",Value.NULL,true,r[0]); pc = 23; continue; }
case 23: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda7;"); pc = 24; continue; }
case 24: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda7;-><init>()V",r[0],new Value[]{}); pc = 25; continue; }
case 25: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->segmentCategorySelectedDialogListener:Landroid/content/DialogInterface$OnClickListener;",Value.NULL,true,r[0]); pc = 26; continue; }
case 26: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;"); pc = 27; continue; }
case 27: { r[1] = Value.i32(0); pc = 28; continue; }
case 28: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;-><init>(Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils-IA;)V",r[0],new Value[]{r[1]}); pc = 29; continue; }
case 29: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->editByHandSaveDialogListener:Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$EditByHandSaveDialogListener;",Value.NULL,true,r[0]); pc = 30; continue; }
case 30: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda8;"); pc = 31; continue; }
case 31: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda8;-><init>()V",r[0],new Value[]{}); pc = 32; continue; }
case 32: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->editByHandDialogListener:Landroid/content/DialogInterface$OnClickListener;",Value.NULL,true,r[0]); pc = 33; continue; }
case 33: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda9;"); pc = 34; continue; }
case 34: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda9;-><init>()V",r[0],new Value[]{}); pc = 35; continue; }
case 35: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->segmentVoteClickListener:Landroid/content/DialogInterface$OnClickListener;",Value.NULL,true,r[0]); pc = 36; continue; }
case 36: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c661885c373d41f127da3411(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(1); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;->newSponsorSegmentPreviewed:Z",Value.NULL,true,r[0]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d6799b0e7fcc680f88d2802e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[6] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->recordedAsSkipped:Z",r[6],false); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?37:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->category:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",r[6],false); pc = 3; continue; }
case 3: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->UNSUBMITTED:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 4; continue; }
case 4: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?6:5; continue; }
case 5: { pc=37; continue; }
case 6: { r[0] = Value.i32(1); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->recordedAsSkipped:Z",r[6],false,r[0]); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_LOCAL_TIME_SAVED_MILLISECONDS:Lapp/revanced/extension/shared/settings/LongSetting;",Value.NULL,true); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/shared/settings/LongSetting;->get()Ljava/lang/Long;",r[1],new Value[]{}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Ljava/lang/Long;->longValue()J",r[2],new Value[]{}); pc = 12; continue; }
case 12: { r[2] = result; r[3] = r[2]; pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->length()J",r[6],new Value[]{}); pc = 14; continue; }
case 14: { r[4] = result; r[5] = r[4]; pc = 15; continue; }
case 15: { r[2] = Value.i64((r[2].j()) + (r[4].j())); r[3] = r[2]; pc = 16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[2]}); pc = 17; continue; }
case 17: { r[2] = result; pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/shared/settings/LongSetting;->save(Ljava/lang/Object;)V",r[1],new Value[]{r[2]}); pc = 19; continue; }
case 19: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_LOCAL_TIME_SAVED_NUMBER_SEGMENTS:Lapp/revanced/extension/shared/settings/IntegerSetting;",Value.NULL,true); pc = 20; continue; }
case 20: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/shared/settings/IntegerSetting;->get()Ljava/lang/Integer;",r[1],new Value[]{}); pc = 21; continue; }
case 21: { r[2] = result; pc = 22; continue; }
case 22: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Ljava/lang/Integer;->intValue()I",r[2],new Value[]{}); pc = 23; continue; }
case 23: { r[2] = result; pc = 24; continue; }
case 24: { r[2] = Value.i32((r[2].i()) + (r[0].i())); pc = 25; continue; }
case 25: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[2]}); pc = 26; continue; }
case 26: { r[0] = result; pc = 27; continue; }
case 27: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/shared/settings/IntegerSetting;->save(Ljava/lang/Object;)V",r[1],new Value[]{r[0]}); pc = 28; continue; }
case 28: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_TRACK_SKIP_COUNT:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 29; continue; }
case 29: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 30; continue; }
case 30: { r[0] = result; pc = 31; continue; }
case 31: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 32; continue; }
case 32: { r[0] = result; pc = 33; continue; }
case 33: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?37:34; continue; }
case 34: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda5;"); pc = 35; continue; }
case 35: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils$$ExternalSyntheticLambda5;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[0],new Value[]{r[6]}); pc = 36; continue; }
case 36: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/shared/Utils;->runOnBackgroundThread(Ljava/lang/Runnable;)V",Value.NULL,new Value[]{r[0]}); pc = 37; continue; }
case 37: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a1da30793305a5b5565c950d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockUtils;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->sendSegmentSkippedViewedRequest(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",Value.NULL,new Value[]{r[0]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
