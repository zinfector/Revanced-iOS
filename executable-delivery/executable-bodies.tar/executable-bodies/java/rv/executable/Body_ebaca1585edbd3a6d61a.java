package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_ebaca1585edbd3a6d61a {
static Value m_5ca1790252fe47bcff31b79d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "[Ljava/lang/Object;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lkotlin/collections/ArraysKt___ArraysKt;", "Ljava/lang/Object;->getClass()Ljava/lang/Class;", r[1], new Value[]{}); pc = 1; continue; }
case 1: { pc = (r[2].i() < 0) ? 6 : 2; continue; }
case 2: { r[0] = Value.i32(rt.length(r[1])); pc = 3; continue; }
case 3: { pc = (r[2].i() >= r[0].i()) ? 6 : 4; continue; }
case 4: { r[1] = rt.arrayGet(r[1], r[2].i()); pc = 5; continue; }
case 5: { return rt.check(r[1], "Ljava/lang/Object;"); }
case 6: { r[1] = Value.i32(0); pc = 7; continue; }
case 7: { return rt.check(r[1], "Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
