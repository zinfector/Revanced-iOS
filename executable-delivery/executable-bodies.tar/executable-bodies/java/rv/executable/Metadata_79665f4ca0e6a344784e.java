package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_79665f4ca0e6a344784e {
static ClassInfo info_79665f4ca0e6a344784e() {return new ClassInfo("Lapp/revanced/extension/shared/settings/Setting$3;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 0, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/settings/Setting$3;->val$parents:[Lapp/revanced/extension/shared/settings/BooleanSetting;", "[Lapp/revanced/extension/shared/settings/BooleanSetting;", 4112, ExecutableRuntime.zero("[Lapp/revanced/extension/shared/settings/BooleanSetting;"))}, new MethodInfo[]{new MethodInfo("<init>([Lapp/revanced/extension/shared/settings/BooleanSetting;)V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
