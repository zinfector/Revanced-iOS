package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_bfe4a174fe5094aa6dd2 {
static Value m_c75292e3a6450e7230118985(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;");
r[1] = rt.check(arguments[0], "Z");
r[2] = rt.check(arguments[1], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;->f$0:Z",r[0],false,r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;->f$1:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",r[0],false,r[2]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;->f$2:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",r[0],false,r[3]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_62b34f5e9efe5b5e5e6bca7e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;->f$0:Z",r[3],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;->f$1:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",r[3],false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;->f$2:Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;",r[3],false); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda7;","Lapp/revanced/extension/youtube/patches/VideoInformation;->$r8$lambda$dvA6Vap0vcjwSb0ETSAGswFjycY(ZLapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;Lapp/revanced/extension/youtube/patches/VideoInformation$VideoQualityInterface;)Ljava/lang/String;",Value.NULL,new Value[]{r[0], r[1], r[2]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
