package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_a132ee80c908c91cca84 {
static Value m_02acdad03c13cbf93546f629(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->$VALUES:[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true); pc = 1; continue; }
case 1: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", "[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->clone()Ljava/lang/Object;", r[0], new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0], "[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;"); pc = 4; continue; }
case 4: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_96feeb4babc063bc6881844e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("DISABLED"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->DISABLED:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true, r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("PORTRAIT"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->PORTRAIT:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true, r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("LANDSCAPE"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->LANDSCAPE:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true, r[0]); pc = 15; continue; }
case 15: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;"); pc = 16; continue; }
case 16: { r[1] = Value.ref("PORTRAIT_LANDSCAPE"); pc = 17; continue; }
case 17: { r[2] = Value.i32(3); pc = 18; continue; }
case 18: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->PORTRAIT_LANDSCAPE:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true, r[0]); pc = 20; continue; }
case 20: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->$values()[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, new Value[]{}); pc = 21; continue; }
case 21: { r[0] = result; pc = 22; continue; }
case 22: { rt.writeField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->$VALUES:[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true, r[0]); pc = 23; continue; }
case 23: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4126c4b252615ed3ed8d7bbf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4ebeaf95b33d2fab4cb3ffdd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->DISABLED:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->PORTRAIT:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->LANDSCAPE:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->PORTRAIT_LANDSCAPE:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true); pc = 4; continue; }
case 4: { result = rt.filledArray("[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", new Value[]{r[0], r[1], r[2], r[3]}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
