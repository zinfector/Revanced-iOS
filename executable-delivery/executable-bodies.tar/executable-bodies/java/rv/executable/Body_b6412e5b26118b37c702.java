package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_b6412e5b26118b37c702 {
static Value m_526cb7f0d24052237d4a8fba(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[15];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1; continue; }
case 1: { r[1] = rt.readField("Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = Value.ref("revanced_advanced_video_quality_menu"); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[1]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ADVANCED_VIDEO_QUALITY_MENU:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 6; continue; }
case 6: { r[2] = rt.readField("Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;", Value.NULL, true); pc = 7; continue; }
case 7: { r[3] = Value.ref("revanced_disable_hdr_video"); pc = 8; continue; }
case 8: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_HDR_VIDEO:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 11; continue; }
case 11: { r[3] = Value.ref("revanced_force_avc_codec_user_dialog_message"); pc = 12; continue; }
case 12: { r[4] = Value.ref("revanced_force_avc_codec"); pc = 13; continue; }
case 13: { r[5] = Value.i32(1); pc = 14; continue; }
case 14: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLjava/lang/String;)V", r[0], new Value[]{r[4], r[2], r[5], r[3]}); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->FORCE_AVC_CODEC:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 16; continue; }
case 16: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 17; continue; }
case 17: { r[3] = Value.ref("revanced_force_original_audio"); pc = 18; continue; }
case 18: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->FORCE_ORIGINAL_AUDIO:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 21; continue; }
case 21: { r[3] = Value.ref("revanced_hide_premium_video_quality"); pc = 22; continue; }
case 22: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 23; continue; }
case 23: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PREMIUM_VIDEO_QUALITY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 24; continue; }
case 24: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 25; continue; }
case 25: { r[3] = Value.i32(-2); pc = 26; continue; }
case 26: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[3]}); pc = 27; continue; }
case 27: { r[3] = result; pc = 28; continue; }
case 28: { r[4] = Value.ref("revanced_video_quality_default_wifi"); pc = 29; continue; }
case 29: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V", r[0], new Value[]{r[4], r[3]}); pc = 30; continue; }
case 30: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->VIDEO_QUALITY_DEFAULT_WIFI:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[0]); pc = 31; continue; }
case 31: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 32; continue; }
case 32: { r[4] = Value.ref("revanced_video_quality_default_mobile"); pc = 33; continue; }
case 33: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V", r[0], new Value[]{r[4], r[3]}); pc = 34; continue; }
case 34: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->VIDEO_QUALITY_DEFAULT_MOBILE:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[0]); pc = 35; continue; }
case 35: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 36; continue; }
case 36: { r[4] = Value.ref("revanced_remember_video_quality_last_selected"); pc = 37; continue; }
case 37: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[4], r[2]}); pc = 38; continue; }
case 38: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->REMEMBER_VIDEO_QUALITY_LAST_SELECTED:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 39; continue; }
case 39: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 40; continue; }
case 40: { r[6] = Value.ref("revanced_shorts_quality_default_wifi"); pc = 41; continue; }
case 41: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;Z)V", r[4], new Value[]{r[6], r[3], r[5]}); pc = 42; continue; }
case 42: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SHORTS_QUALITY_DEFAULT_WIFI:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[4]); pc = 43; continue; }
case 43: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 44; continue; }
case 44: { r[6] = Value.ref("revanced_shorts_quality_default_mobile"); pc = 45; continue; }
case 45: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;Z)V", r[4], new Value[]{r[6], r[3], r[5]}); pc = 46; continue; }
case 46: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SHORTS_QUALITY_DEFAULT_MOBILE:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[4]); pc = 47; continue; }
case 47: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 48; continue; }
case 48: { r[4] = Value.ref("revanced_remember_shorts_quality_last_selected"); pc = 49; continue; }
case 49: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[3], new Value[]{r[4], r[2]}); pc = 50; continue; }
case 50: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->REMEMBER_SHORTS_QUALITY_LAST_SELECTED:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 51; continue; }
case 51: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 52; continue; }
case 52: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[3]}); pc = 53; continue; }
case 53: { r[0] = result; pc = 54; continue; }
case 54: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 55; continue; }
case 55: { r[0] = result; pc = 56; continue; }
case 56: { r[3] = Value.ref("revanced_remember_video_quality_last_selected_toast"); pc = 57; continue; }
case 57: { r[6] = Value.i32(0); pc = 58; continue; }
case 58: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[3], r[1], r[6], r[0]}); pc = 59; continue; }
case 59: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->REMEMBER_VIDEO_QUALITY_LAST_SELECTED_TOAST:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 60; continue; }
case 60: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 61; continue; }
case 61: { r[3] = Value.i32(1073741824); pc = 62; continue; }
case 62: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;", Value.NULL, new Value[]{r[3]}); pc = 63; continue; }
case 63: { r[3] = result; pc = 64; continue; }
case 64: { r[4] = Value.ref("revanced_speed_tap_and_hold"); pc = 65; continue; }
case 65: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;Z)V", r[0], new Value[]{r[4], r[3], r[5]}); pc = 66; continue; }
case 66: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SPEED_TAP_AND_HOLD:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[0]); pc = 67; continue; }
case 67: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 68; continue; }
case 68: { r[3] = Value.ref("revanced_remember_playback_speed_last_selected"); pc = 69; continue; }
case 69: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 70; continue; }
case 70: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->REMEMBER_PLAYBACK_SPEED_LAST_SELECTED:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 71; continue; }
case 71: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 72; continue; }
case 72: { r[4] = Value.ref("revanced_remember_playback_speed_last_selected_toast"); pc = 73; continue; }
case 73: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 74; continue; }
case 74: { r[0] = result; pc = 75; continue; }
case 75: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[1], r[6], r[0]}); pc = 76; continue; }
case 76: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->REMEMBER_PLAYBACK_SPEED_LAST_SELECTED_TOAST:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 77; continue; }
case 77: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 78; continue; }
case 78: { r[3] = Value.i32(-1073741824); pc = 79; continue; }
case 79: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;", Value.NULL, new Value[]{r[3]}); pc = 80; continue; }
case 80: { r[3] = result; pc = 81; continue; }
case 81: { r[4] = Value.ref("revanced_playback_speed_default"); pc = 82; continue; }
case 82: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;)V", r[0], new Value[]{r[4], r[3]}); pc = 83; continue; }
case 83: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->PLAYBACK_SPEED_DEFAULT:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[0]); pc = 84; continue; }
case 84: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 85; continue; }
case 85: { r[3] = Value.ref("revanced_custom_speed_menu"); pc = 86; continue; }
case 86: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 87; continue; }
case 87: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->CUSTOM_SPEED_MENU:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 88; continue; }
case 88: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 89; continue; }
case 89: { r[4] = Value.ref("revanced_restore_old_speed_menu"); pc = 90; continue; }
case 90: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 91; continue; }
case 91: { r[0] = result; pc = 92; continue; }
case 92: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[2], r[0]}); pc = 93; continue; }
case 93: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RESTORE_OLD_SPEED_MENU:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 94; continue; }
case 94: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 95; continue; }
case 95: { r[3] = Value.ref("revanced_custom_playback_speeds"); pc = 96; continue; }
case 96: { r[4] = Value.ref("0.25\n0.5\n0.75\n1.0\n1.25\n1.5\n1.75\n2.0\n2.5\n3.0\n4.0\n5.0\n6.0\n7.0\n8.0"); pc = 97; continue; }
case 97: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Z)V", r[0], new Value[]{r[3], r[4], r[5]}); pc = 98; continue; }
case 98: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->CUSTOM_PLAYBACK_SPEEDS:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[0]); pc = 99; continue; }
case 99: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 100; continue; }
case 100: { r[3] = Value.ref("revanced_hide_creator_store_shelf"); pc = 101; continue; }
case 101: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 102; continue; }
case 102: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CREATOR_STORE_SHELF:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 103; continue; }
case 103: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 104; continue; }
case 104: { r[3] = Value.ref("revanced_hide_end_screen_store_banner"); pc = 105; continue; }
case 105: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 106; continue; }
case 106: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_END_SCREEN_STORE_BANNER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 107; continue; }
case 107: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 108; continue; }
case 108: { r[3] = Value.ref("revanced_hide_fullscreen_ads"); pc = 109; continue; }
case 109: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 110; continue; }
case 110: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FULLSCREEN_ADS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 111; continue; }
case 111: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 112; continue; }
case 112: { r[3] = Value.ref("revanced_hide_player_popup_ads"); pc = 113; continue; }
case 113: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 114; continue; }
case 114: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_POPUP_ADS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 115; continue; }
case 115: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 116; continue; }
case 116: { r[3] = Value.ref("revanced_hide_general_ads"); pc = 117; continue; }
case 117: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 118; continue; }
case 118: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_GENERAL_ADS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 119; continue; }
case 119: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 120; continue; }
case 120: { r[3] = Value.ref("revanced_hide_merchandise_banners"); pc = 121; continue; }
case 121: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 122; continue; }
case 122: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_MERCHANDISE_BANNERS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 123; continue; }
case 123: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 124; continue; }
case 124: { r[3] = Value.ref("revanced_hide_paid_promotion_label"); pc = 125; continue; }
case 125: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 126; continue; }
case 126: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PAID_PROMOTION_LABEL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 127; continue; }
case 127: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 128; continue; }
case 128: { r[3] = Value.ref("revanced_hide_self_sponsor_ads"); pc = 129; continue; }
case 129: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 130; continue; }
case 130: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SELF_SPONSOR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 131; continue; }
case 131: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 132; continue; }
case 132: { r[3] = Value.ref("revanced_hide_shopping_links"); pc = 133; continue; }
case 133: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 134; continue; }
case 134: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHOPPING_LINKS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 135; continue; }
case 135: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 136; continue; }
case 136: { r[3] = Value.ref("revanced_hide_video_ads"); pc = 137; continue; }
case 137: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 138; continue; }
case 138: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_VIDEO_ADS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 139; continue; }
case 139: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 140; continue; }
case 140: { r[3] = Value.ref("revanced_hide_view_products_banner"); pc = 141; continue; }
case 141: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 142; continue; }
case 142: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_VIEW_PRODUCTS_BANNER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 143; continue; }
case 143: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 144; continue; }
case 144: { r[3] = Value.ref("revanced_hide_youtube_premium_promotions"); pc = 145; continue; }
case 145: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 146; continue; }
case 146: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_YOUTUBE_PREMIUM_PROMOTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 147; continue; }
case 147: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 148; continue; }
case 148: { r[3] = Value.ref("revanced_hide_album_cards"); pc = 149; continue; }
case 149: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 150; continue; }
case 150: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_ALBUM_CARDS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 151; continue; }
case 151: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 152; continue; }
case 152: { r[3] = Value.ref("revanced_hide_artist_cards"); pc = 153; continue; }
case 153: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 154; continue; }
case 154: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_ARTIST_CARDS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 155; continue; }
case 155: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 156; continue; }
case 156: { r[3] = Value.ref("revanced_hide_chips_shelf"); pc = 157; continue; }
case 157: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 158; continue; }
case 158: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CHIPS_SHELF:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 159; continue; }
case 159: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 160; continue; }
case 160: { r[3] = Value.ref("revanced_hide_community_posts"); pc = 161; continue; }
case 161: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 162; continue; }
case 162: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMUNITY_POSTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 163; continue; }
case 163: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 164; continue; }
case 164: { r[3] = Value.ref("revanced_hide_compact_banner"); pc = 165; continue; }
case 165: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 166; continue; }
case 166: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMPACT_BANNER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 167; continue; }
case 167: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 168; continue; }
case 168: { r[3] = Value.ref("revanced_hide_doodles"); pc = 169; continue; }
case 169: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 170; continue; }
case 170: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_DOODLES:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 171; continue; }
case 171: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 172; continue; }
case 172: { r[3] = Value.ref("revanced_hide_expandable_card"); pc = 173; continue; }
case 173: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 174; continue; }
case 174: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_EXPANDABLE_CARD:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 175; continue; }
case 175: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 176; continue; }
case 176: { r[3] = Value.ref("revanced_hide_feed_flyout_menu"); pc = 177; continue; }
case 177: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 178; continue; }
case 178: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FEED_FLYOUT_MENU:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 179; continue; }
case 179: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 180; continue; }
case 180: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 181; continue; }
case 181: { r[0] = result; pc = 182; continue; }
case 182: { r[4] = Value.ref("revanced_hide_feed_flyout_menu_filter_strings"); pc = 183; continue; }
case 183: { r[7] = Value.ref(""); pc = 184; continue; }
case 184: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[7], r[5], r[0]}); pc = 185; continue; }
case 185: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FEED_FLYOUT_MENU_FILTER_STRINGS:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[3]); pc = 186; continue; }
case 186: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 187; continue; }
case 187: { r[3] = Value.ref("revanced_hide_filter_bar_feed_in_feed"); pc = 188; continue; }
case 188: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 189; continue; }
case 189: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FILTER_BAR_FEED_IN_FEED:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 190; continue; }
case 190: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 191; continue; }
case 191: { r[3] = Value.ref("revanced_hide_filter_bar_feed_in_history"); pc = 192; continue; }
case 192: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 193; continue; }
case 193: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FILTER_BAR_FEED_IN_HISTORY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 194; continue; }
case 194: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 195; continue; }
case 195: { r[3] = Value.ref("revanced_hide_filter_bar_feed_in_related_videos"); pc = 196; continue; }
case 196: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 197; continue; }
case 197: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FILTER_BAR_FEED_IN_RELATED_VIDEOS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 198; continue; }
case 198: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 199; continue; }
case 199: { r[3] = Value.ref("revanced_hide_filter_bar_feed_in_search"); pc = 200; continue; }
case 200: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 201; continue; }
case 201: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FILTER_BAR_FEED_IN_SEARCH:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 202; continue; }
case 202: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 203; continue; }
case 203: { r[3] = Value.ref("revanced_hide_floating_microphone_button"); pc = 204; continue; }
case 204: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 205; continue; }
case 205: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FLOATING_MICROPHONE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 206; continue; }
case 206: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 207; continue; }
case 207: { r[3] = Value.ref("revanced_hide_horizontal_shelves"); pc = 208; continue; }
case 208: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 209; continue; }
case 209: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_HORIZONTAL_SHELVES:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 210; continue; }
case 210: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 211; continue; }
case 211: { r[3] = Value.ref("revanced_hide_image_shelf"); pc = 212; continue; }
case 212: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 213; continue; }
case 213: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_IMAGE_SHELF:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 214; continue; }
case 214: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 215; continue; }
case 215: { r[3] = Value.ref("revanced_hide_latest_posts"); pc = 216; continue; }
case 216: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 217; continue; }
case 217: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_LATEST_POSTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 218; continue; }
case 218: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 219; continue; }
case 219: { r[3] = Value.ref("revanced_hide_latest_videos_button"); pc = 220; continue; }
case 220: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 221; continue; }
case 221: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_LATEST_VIDEOS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 222; continue; }
case 222: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 223; continue; }
case 223: { r[3] = Value.ref("revanced_hide_mix_playlists"); pc = 224; continue; }
case 224: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 225; continue; }
case 225: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_MIX_PLAYLISTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 226; continue; }
case 226: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 227; continue; }
case 227: { r[3] = Value.ref("revanced_hide_movies_section"); pc = 228; continue; }
case 228: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 229; continue; }
case 229: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_MOVIES_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 230; continue; }
case 230: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 231; continue; }
case 231: { r[3] = Value.ref("revanced_hide_notify_me_button"); pc = 232; continue; }
case 232: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 233; continue; }
case 233: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_NOTIFY_ME_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 234; continue; }
case 234: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 235; continue; }
case 235: { r[3] = Value.ref("revanced_hide_playables"); pc = 236; continue; }
case 236: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 237; continue; }
case 237: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYABLES:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 238; continue; }
case 238: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 239; continue; }
case 239: { r[3] = Value.ref("revanced_hide_show_more_button"); pc = 240; continue; }
case 240: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 241; continue; }
case 241: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHOW_MORE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 242; continue; }
case 242: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 243; continue; }
case 243: { r[3] = Value.ref("revanced_hide_subscribed_channels_bar"); pc = 244; continue; }
case 244: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 245; continue; }
case 245: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SUBSCRIBED_CHANNELS_BAR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 246; continue; }
case 246: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 247; continue; }
case 247: { r[3] = Value.ref("revanced_hide_surveys"); pc = 248; continue; }
case 248: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 249; continue; }
case 249: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SURVEYS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 250; continue; }
case 250: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 251; continue; }
case 251: { r[3] = Value.ref("revanced_hide_ticket_shelf"); pc = 252; continue; }
case 252: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 253; continue; }
case 253: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_TICKET_SHELF:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 254; continue; }
case 254: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 255; continue; }
case 255: { r[3] = Value.ref("revanced_hide_upload_time"); pc = 256; continue; }
case 256: { r[4] = Value.ref("revanced_hide_upload_time_user_dialog_message"); pc = 257; continue; }
case 257: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V", r[0], new Value[]{r[3], r[2], r[4]}); pc = 258; continue; }
case 258: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_UPLOAD_TIME:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 259; continue; }
case 259: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 260; continue; }
case 260: { r[3] = Value.ref("revanced_hide_video_recommendation_labels"); pc = 261; continue; }
case 261: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 262; continue; }
case 262: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_VIDEO_RECOMMENDATION_LABELS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 263; continue; }
case 263: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 264; continue; }
case 264: { r[3] = Value.ref("revanced_hide_view_count"); pc = 265; continue; }
case 265: { r[4] = Value.ref("revanced_hide_view_count_user_dialog_message"); pc = 266; continue; }
case 266: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V", r[0], new Value[]{r[3], r[2], r[4]}); pc = 267; continue; }
case 267: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_VIEW_COUNT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 268; continue; }
case 268: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 269; continue; }
case 269: { r[3] = Value.ref("revanced_hide_web_search_results"); pc = 270; continue; }
case 270: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 271; continue; }
case 271: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_WEB_SEARCH_RESULTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 272; continue; }
case 272: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 273; continue; }
case 273: { r[3] = Value.ref("revanced_hide_you_may_like_section"); pc = 274; continue; }
case 274: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 275; continue; }
case 275: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_YOU_MAY_LIKE_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 276; continue; }
case 276: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 277; continue; }
case 277: { r[3] = Value.ref("revanced_hide_visual_spacer"); pc = 278; continue; }
case 278: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 279; continue; }
case 279: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_VISUAL_SPACER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 280; continue; }
case 280: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 281; continue; }
case 281: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;->ORIGINAL:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailOption;", Value.NULL, true); pc = 282; continue; }
case 282: { r[4] = Value.ref("revanced_alt_thumbnail_home"); pc = 283; continue; }
case 283: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;)V", r[0], new Value[]{r[4], r[3]}); pc = 284; continue; }
case 284: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_HOME:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 285; continue; }
case 285: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 286; continue; }
case 286: { r[4] = Value.ref("revanced_alt_thumbnail_subscription"); pc = 287; continue; }
case 287: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;)V", r[0], new Value[]{r[4], r[3]}); pc = 288; continue; }
case 288: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_SUBSCRIPTIONS:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 289; continue; }
case 289: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 290; continue; }
case 290: { r[4] = Value.ref("revanced_alt_thumbnail_library"); pc = 291; continue; }
case 291: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;)V", r[0], new Value[]{r[4], r[3]}); pc = 292; continue; }
case 292: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_LIBRARY:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 293; continue; }
case 293: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 294; continue; }
case 294: { r[4] = Value.ref("revanced_alt_thumbnail_player"); pc = 295; continue; }
case 295: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;)V", r[0], new Value[]{r[4], r[3]}); pc = 296; continue; }
case 296: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_PLAYER:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 297; continue; }
case 297: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 298; continue; }
case 298: { r[4] = Value.ref("revanced_alt_thumbnail_search"); pc = 299; continue; }
case 299: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;)V", r[0], new Value[]{r[4], r[3]}); pc = 300; continue; }
case 300: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_SEARCH:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 301; continue; }
case 301: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 302; continue; }
case 302: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$DeArrowAvailability;"); pc = 303; continue; }
case 303: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$DeArrowAvailability;-><init>()V", r[3], new Value[]{}); pc = 304; continue; }
case 304: { r[4] = Value.ref("revanced_alt_thumbnail_dearrow_api_url"); pc = 305; continue; }
case 305: { r[8] = Value.ref("https://dearrow-thumb.ajay.app/api/v1/getThumbnail"); pc = 306; continue; }
case 306: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[4], r[8], r[5], r[3]}); pc = 307; continue; }
case 307: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_DEARROW_API_URL:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[0]); pc = 308; continue; }
case 308: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 309; continue; }
case 309: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$DeArrowAvailability;"); pc = 310; continue; }
case 310: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$DeArrowAvailability;-><init>()V", r[3], new Value[]{}); pc = 311; continue; }
case 311: { r[4] = Value.ref("revanced_alt_thumbnail_dearrow_connection_toast"); pc = 312; continue; }
case 312: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[4], r[1], r[3]}); pc = 313; continue; }
case 313: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_DEARROW_CONNECTION_TOAST:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 314; continue; }
case 314: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 315; continue; }
case 315: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;->MIDDLE:Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$ThumbnailStillTime;", Value.NULL, true); pc = 316; continue; }
case 316: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$StillImagesAvailability;"); pc = 317; continue; }
case 317: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$StillImagesAvailability;-><init>()V", r[4], new Value[]{}); pc = 318; continue; }
case 318: { r[8] = Value.ref("revanced_alt_thumbnail_stills_time"); pc = 319; continue; }
case 319: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[8], r[3], r[4]}); pc = 320; continue; }
case 320: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_STILLS_TIME:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 321; continue; }
case 321: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 322; continue; }
case 322: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$StillImagesAvailability;"); pc = 323; continue; }
case 323: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/AlternativeThumbnailsPatch$StillImagesAvailability;-><init>()V", r[3], new Value[]{}); pc = 324; continue; }
case 324: { r[4] = Value.ref("revanced_alt_thumbnail_stills_fast"); pc = 325; continue; }
case 325: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[4], r[2], r[3]}); pc = 326; continue; }
case 326: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ALT_THUMBNAIL_STILLS_FAST:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 327; continue; }
case 327: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 328; continue; }
case 328: { r[3] = Value.ref("revanced_hide_keyword_content_home"); pc = 329; continue; }
case 329: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 330; continue; }
case 330: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_KEYWORD_CONTENT_HOME:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 331; continue; }
case 331: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 332; continue; }
case 332: { r[4] = Value.ref("revanced_hide_keyword_content_subscriptions"); pc = 333; continue; }
case 333: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[3], new Value[]{r[4], r[2]}); pc = 334; continue; }
case 334: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_KEYWORD_CONTENT_SUBSCRIPTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 335; continue; }
case 335: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 336; continue; }
case 336: { r[8] = Value.ref("revanced_hide_keyword_content_search"); pc = 337; continue; }
case 337: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[4], new Value[]{r[8], r[2]}); pc = 338; continue; }
case 338: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_KEYWORD_CONTENT_SEARCH:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 339; continue; }
case 339: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 340; continue; }
case 340: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[3], r[4]}); pc = 341; continue; }
case 341: { r[0] = result; pc = 342; continue; }
case 342: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 343; continue; }
case 343: { r[0] = result; pc = 344; continue; }
case 344: { r[3] = Value.ref("revanced_hide_keyword_content_phrases"); pc = 345; continue; }
case 345: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[3], r[7], r[0]}); pc = 346; continue; }
case 346: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_KEYWORD_CONTENT_PHRASES:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[8]); pc = 347; continue; }
case 347: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 348; continue; }
case 348: { r[3] = Value.ref("revanced_hide_channel_tab"); pc = 349; continue; }
case 349: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 350; continue; }
case 350: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CHANNEL_TAB:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 351; continue; }
case 351: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 352; continue; }
case 352: { r[4] = Value.ref("revanced_hide_channel_tab_filter_strings"); pc = 353; continue; }
case 353: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 354; continue; }
case 354: { r[0] = result; pc = 355; continue; }
case 355: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[7], r[5], r[0]}); pc = 356; continue; }
case 356: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CHANNEL_TAB_FILTER_STRINGS:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[3]); pc = 357; continue; }
case 357: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 358; continue; }
case 358: { r[3] = Value.ref("revanced_hide_community_button"); pc = 359; continue; }
case 359: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 360; continue; }
case 360: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMUNITY_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 361; continue; }
case 361: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 362; continue; }
case 362: { r[3] = Value.ref("revanced_hide_for_you_shelf"); pc = 363; continue; }
case 363: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 364; continue; }
case 364: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FOR_YOU_SHELF:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 365; continue; }
case 365: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 366; continue; }
case 366: { r[3] = Value.ref("revanced_hide_join_button"); pc = 367; continue; }
case 367: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 368; continue; }
case 368: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_JOIN_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 369; continue; }
case 369: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 370; continue; }
case 370: { r[3] = Value.ref("revanced_hide_links_preview"); pc = 371; continue; }
case 371: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 372; continue; }
case 372: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_LINKS_PREVIEW:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 373; continue; }
case 373: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 374; continue; }
case 374: { r[3] = Value.ref("revanced_hide_members_shelf"); pc = 375; continue; }
case 375: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 376; continue; }
case 376: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_MEMBERS_SHELF:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 377; continue; }
case 377: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 378; continue; }
case 378: { r[3] = Value.ref("revanced_hide_store_button"); pc = 379; continue; }
case 379: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 380; continue; }
case 380: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_STORE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 381; continue; }
case 381: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 382; continue; }
case 382: { r[3] = Value.ref("revanced_hide_subscribe_button_in_channel_page"); pc = 383; continue; }
case 383: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 384; continue; }
case 384: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SUBSCRIBE_BUTTON_IN_CHANNEL_PAGE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 385; continue; }
case 385: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 386; continue; }
case 386: { r[3] = Value.ref("revanced_copy_video_url"); pc = 387; continue; }
case 387: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 388; continue; }
case 388: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->COPY_VIDEO_URL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 389; continue; }
case 389: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 390; continue; }
case 390: { r[3] = Value.ref("revanced_copy_video_url_timestamp"); pc = 391; continue; }
case 391: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 392; continue; }
case 392: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->COPY_VIDEO_URL_TIMESTAMP:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 393; continue; }
case 393: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 394; continue; }
case 394: { r[3] = Value.ref("revanced_disable_auto_captions"); pc = 395; continue; }
case 395: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 396; continue; }
case 396: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_AUTO_CAPTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 397; continue; }
case 397: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 398; continue; }
case 398: { r[3] = Value.ref("revanced_disable_chapter_skip_double_tap"); pc = 399; continue; }
case 399: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 400; continue; }
case 400: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_CHAPTER_SKIP_DOUBLE_TAP:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 401; continue; }
case 401: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 402; continue; }
case 402: { r[3] = Value.ref("revanced_disable_haptic_feedback_chapters"); pc = 403; continue; }
case 403: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 404; continue; }
case 404: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_HAPTIC_FEEDBACK_CHAPTERS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 405; continue; }
case 405: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 406; continue; }
case 406: { r[3] = Value.ref("revanced_disable_haptic_feedback_precise_seeking"); pc = 407; continue; }
case 407: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 408; continue; }
case 408: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_HAPTIC_FEEDBACK_PRECISE_SEEKING:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 409; continue; }
case 409: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 410; continue; }
case 410: { r[3] = Value.ref("revanced_disable_haptic_feedback_seek_undo"); pc = 411; continue; }
case 411: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 412; continue; }
case 412: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_HAPTIC_FEEDBACK_SEEK_UNDO:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 413; continue; }
case 413: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 414; continue; }
case 414: { r[3] = Value.ref("revanced_disable_haptic_feedback_tap_and_hold"); pc = 415; continue; }
case 415: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 416; continue; }
case 416: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_HAPTIC_FEEDBACK_TAP_AND_HOLD:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 417; continue; }
case 417: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 418; continue; }
case 418: { r[3] = Value.ref("revanced_disable_haptic_feedback_zoom"); pc = 419; continue; }
case 419: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 420; continue; }
case 420: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_HAPTIC_FEEDBACK_ZOOM:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 421; continue; }
case 421: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 422; continue; }
case 422: { r[3] = Value.ref("revanced_disable_player_popup_panels"); pc = 423; continue; }
case 423: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 424; continue; }
case 424: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_PLAYER_POPUP_PANELS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 425; continue; }
case 425: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 426; continue; }
case 426: { r[3] = Value.ref("revanced_disable_fullscreen_ambient_mode"); pc = 427; continue; }
case 427: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 428; continue; }
case 428: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_FULLSCREEN_AMBIENT_MODE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 429; continue; }
case 429: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 430; continue; }
case 430: { r[3] = Value.ref("revanced_disable_rolling_number_animations"); pc = 431; continue; }
case 431: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 432; continue; }
case 432: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_ROLLING_NUMBER_ANIMATIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 433; continue; }
case 433: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 434; continue; }
case 434: { r[3] = Value.ref("revanced_exit_fullscreen"); pc = 435; continue; }
case 435: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;->DISABLED:Lapp/revanced/extension/youtube/patches/ExitFullscreenPatch$FullscreenMode;", Value.NULL, true); pc = 436; continue; }
case 436: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;)V", r[0], new Value[]{r[3], r[4]}); pc = 437; continue; }
case 437: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->EXIT_FULLSCREEN:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 438; continue; }
case 438: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 439; continue; }
case 439: { r[3] = Value.ref("revanced_hide_autoplay_button"); pc = 440; continue; }
case 440: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 441; continue; }
case 441: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_AUTOPLAY_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 442; continue; }
case 442: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 443; continue; }
case 443: { r[3] = Value.ref("revanced_hide_autoplay_preview"); pc = 444; continue; }
case 444: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 445; continue; }
case 445: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_AUTOPLAY_PREVIEW:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 446; continue; }
case 446: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 447; continue; }
case 447: { r[3] = Value.ref("revanced_hide_captions_button"); pc = 448; continue; }
case 448: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 449; continue; }
case 449: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CAPTIONS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 450; continue; }
case 450: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 451; continue; }
case 451: { r[3] = Value.ref("revanced_hide_cast_button"); pc = 452; continue; }
case 452: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 453; continue; }
case 453: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CAST_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 454; continue; }
case 454: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 455; continue; }
case 455: { r[3] = Value.ref("revanced_hide_collapse_button"); pc = 456; continue; }
case 456: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 457; continue; }
case 457: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COLLAPSE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 458; continue; }
case 458: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 459; continue; }
case 459: { r[3] = Value.ref("revanced_hide_channel_bar"); pc = 460; continue; }
case 460: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 461; continue; }
case 461: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CHANNEL_BAR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 462; continue; }
case 462: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 463; continue; }
case 463: { r[4] = Value.ref("revanced_hide_channel_watermark"); pc = 464; continue; }
case 464: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[3], new Value[]{r[4], r[1]}); pc = 465; continue; }
case 465: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CHANNEL_WATERMARK:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 466; continue; }
case 466: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 467; continue; }
case 467: { r[4] = Value.ref("revanced_hide_crowdfunding_box"); pc = 468; continue; }
case 468: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[3], new Value[]{r[4], r[2], r[5]}); pc = 469; continue; }
case 469: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CROWDFUNDING_BOX:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 470; continue; }
case 470: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 471; continue; }
case 471: { r[4] = Value.ref("revanced_hide_emergency_box"); pc = 472; continue; }
case 472: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[3], new Value[]{r[4], r[1]}); pc = 473; continue; }
case 473: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_EMERGENCY_BOX:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 474; continue; }
case 474: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 475; continue; }
case 475: { r[4] = Value.ref("revanced_hide_end_screen_cards"); pc = 476; continue; }
case 476: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[3], new Value[]{r[4], r[2]}); pc = 477; continue; }
case 477: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_END_SCREEN_CARDS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 478; continue; }
case 478: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 479; continue; }
case 479: { r[4] = Value.ref("revanced_end_screen_suggested_video"); pc = 480; continue; }
case 480: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[3], new Value[]{r[4], r[2], r[5]}); pc = 481; continue; }
case 481: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_END_SCREEN_SUGGESTED_VIDEO:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 482; continue; }
case 482: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 483; continue; }
case 483: { r[4] = Value.ref("revanced_hide_fullscreen_button"); pc = 484; continue; }
case 484: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[3], new Value[]{r[4], r[2], r[5]}); pc = 485; continue; }
case 485: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FULLSCREEN_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 486; continue; }
case 486: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 487; continue; }
case 487: { r[4] = Value.ref("revanced_hide_info_cards"); pc = 488; continue; }
case 488: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[3], new Value[]{r[4], r[2]}); pc = 489; continue; }
case 489: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_INFO_CARDS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 490; continue; }
case 490: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 491; continue; }
case 491: { r[4] = Value.ref("revanced_hide_info_panels"); pc = 492; continue; }
case 492: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[3], new Value[]{r[4], r[1]}); pc = 493; continue; }
case 493: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_INFO_PANELS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 494; continue; }
case 494: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 495; continue; }
case 495: { r[4] = Value.ref("revanced_hide_join_membership_button"); pc = 496; continue; }
case 496: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentNot(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 497; continue; }
case 497: { r[0] = result; pc = 498; continue; }
case 498: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[1], r[0]}); pc = 499; continue; }
case 499: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_JOIN_MEMBERSHIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 500; continue; }
case 500: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 501; continue; }
case 501: { r[3] = Value.ref("revanced_hide_live_chat_replay_button"); pc = 502; continue; }
case 502: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 503; continue; }
case 503: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_LIVE_CHAT_REPLAY_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 504; continue; }
case 504: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 505; continue; }
case 505: { r[3] = Value.ref("revanced_hide_medical_panels"); pc = 506; continue; }
case 506: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 507; continue; }
case 507: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_MEDICAL_PANELS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 508; continue; }
case 508: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 509; continue; }
case 509: { r[3] = Value.ref("revanced_hide_player_control_buttons_background"); pc = 510; continue; }
case 510: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 511; continue; }
case 511: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_CONTROL_BUTTONS_BACKGROUND:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 512; continue; }
case 512: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 513; continue; }
case 513: { r[3] = Value.ref("revanced_hide_player_previous_next_buttons"); pc = 514; continue; }
case 514: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 515; continue; }
case 515: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_PREVIOUS_NEXT_BUTTONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 516; continue; }
case 516: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 517; continue; }
case 517: { r[3] = Value.ref("revanced_hide_quick_actions"); pc = 518; continue; }
case 518: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 519; continue; }
case 519: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_QUICK_ACTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 520; continue; }
case 520: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 521; continue; }
case 521: { r[3] = Value.ref("revanced_hide_related_videos_overlay"); pc = 522; continue; }
case 522: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 523; continue; }
case 523: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_RELATED_VIDEOS_OVERLAY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 524; continue; }
case 524: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 525; continue; }
case 525: { r[3] = Value.ref("revanced_hide_related_videos"); pc = 526; continue; }
case 526: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 527; continue; }
case 527: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_RELATED_VIDEOS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 528; continue; }
case 528: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 529; continue; }
case 529: { r[3] = Value.ref("revanced_hide_subscribers_community_guidelines"); pc = 530; continue; }
case 530: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 531; continue; }
case 531: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SUBSCRIBERS_COMMUNITY_GUIDELINES:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 532; continue; }
case 532: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 533; continue; }
case 533: { r[3] = Value.ref("revanced_hide_timed_reactions"); pc = 534; continue; }
case 534: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 535; continue; }
case 535: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_TIMED_REACTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 536; continue; }
case 536: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 537; continue; }
case 537: { r[3] = Value.ref("revanced_hide_video_title"); pc = 538; continue; }
case 538: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 539; continue; }
case 539: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_VIDEO_TITLE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 540; continue; }
case 540: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 541; continue; }
case 541: { r[3] = Value.ref("revanced_open_videos_fullscreen_portrait"); pc = 542; continue; }
case 542: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 543; continue; }
case 543: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->OPEN_VIDEOS_FULLSCREEN_PORTRAIT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 544; continue; }
case 544: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 545; continue; }
case 545: { r[3] = Value.ref("revanced_playback_speed_dialog_button"); pc = 546; continue; }
case 546: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 547; continue; }
case 547: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->PLAYBACK_SPEED_DIALOG_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 548; continue; }
case 548: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 549; continue; }
case 549: { r[3] = Value.ref("revanced_video_quality_dialog_button"); pc = 550; continue; }
case 550: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 551; continue; }
case 551: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->VIDEO_QUALITY_DIALOG_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 552; continue; }
case 552: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 553; continue; }
case 553: { r[3] = Value.i32(100); pc = 554; continue; }
case 554: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[3]}); pc = 555; continue; }
case 555: { r[3] = result; pc = 556; continue; }
case 556: { r[4] = Value.ref("revanced_player_overlay_opacity"); pc = 557; continue; }
case 557: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;Z)V", r[0], new Value[]{r[4], r[3], r[5]}); pc = 558; continue; }
case 558: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->PLAYER_OVERLAY_OPACITY:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[0]); pc = 559; continue; }
case 559: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 560; continue; }
case 560: { r[4] = Value.ref("revanced_miniplayer_type"); pc = 561; continue; }
case 561: { r[8] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->DEFAULT:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;", Value.NULL, true); pc = 562; continue; }
case 562: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;Z)V", r[0], new Value[]{r[4], r[8], r[5]}); pc = 563; continue; }
case 563: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_TYPE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 564; continue; }
case 564: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 565; continue; }
case 565: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;"); pc = 566; continue; }
case 566: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;-><init>()V", r[4], new Value[]{}); pc = 567; continue; }
case 567: { r[8] = Value.ref("revanced_miniplayer_disable_drag_and_drop"); pc = 568; continue; }
case 568: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[8], r[2], r[5], r[4]}); pc = 569; continue; }
case 569: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_DISABLE_DRAG_AND_DROP:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 570; continue; }
case 570: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 571; continue; }
case 571: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHorizontalDragAvailability;"); pc = 572; continue; }
case 572: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHorizontalDragAvailability;-><init>()V", r[4], new Value[]{}); pc = 573; continue; }
case 573: { r[8] = Value.ref("revanced_miniplayer_disable_horizontal_drag"); pc = 574; continue; }
case 574: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[8], r[2], r[5], r[4]}); pc = 575; continue; }
case 575: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_DISABLE_HORIZONTAL_DRAG:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 576; continue; }
case 576: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 577; continue; }
case 577: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;"); pc = 578; continue; }
case 578: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;-><init>()V", r[4], new Value[]{}); pc = 579; continue; }
case 579: { r[8] = Value.ref("revanced_miniplayer_disable_rounded_corners"); pc = 580; continue; }
case 580: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[8], r[2], r[5], r[4]}); pc = 581; continue; }
case 581: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_DISABLE_ROUNDED_CORNERS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 582; continue; }
case 582: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 583; continue; }
case 583: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;"); pc = 584; continue; }
case 584: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;-><init>()V", r[4], new Value[]{}); pc = 585; continue; }
case 585: { r[8] = Value.ref("revanced_miniplayer_double_tap_action"); pc = 586; continue; }
case 586: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[8], r[1], r[5], r[4]}); pc = 587; continue; }
case 587: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_DOUBLE_TAP_ACTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 588; continue; }
case 588: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 589; continue; }
case 589: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideOverlayButtonsAvailability;"); pc = 590; continue; }
case 590: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideOverlayButtonsAvailability;-><init>()V", r[1], new Value[]{}); pc = 591; continue; }
case 591: { r[4] = Value.ref("revanced_miniplayer_hide_overlay_buttons"); pc = 592; continue; }
case 592: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[4], r[2], r[5], r[1]}); pc = 593; continue; }
case 593: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_HIDE_OVERLAY_BUTTONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 594; continue; }
case 594: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 595; continue; }
case 595: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideSubtextsAvailability;"); pc = 596; continue; }
case 596: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideSubtextsAvailability;-><init>()V", r[1], new Value[]{}); pc = 597; continue; }
case 597: { r[4] = Value.ref("revanced_miniplayer_hide_subtext"); pc = 598; continue; }
case 598: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[4], r[2], r[5], r[1]}); pc = 599; continue; }
case 599: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_HIDE_SUBTEXT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 600; continue; }
case 600: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 601; continue; }
case 601: { r[1] = rt.readField("Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;", Value.NULL, true); pc = 602; continue; }
case 602: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideRewindOrOverlayOpacityAvailability;"); pc = 603; continue; }
case 603: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideRewindOrOverlayOpacityAvailability;-><init>()V", r[2], new Value[]{}); pc = 604; continue; }
case 604: { r[4] = Value.ref("revanced_miniplayer_hide_rewind_forward"); pc = 605; continue; }
case 605: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[4], r[1], r[5], r[2]}); pc = 606; continue; }
case 606: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_HIDE_REWIND_FORWARD:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 607; continue; }
case 607: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 608; continue; }
case 608: { r[2] = Value.i32(192); pc = 609; continue; }
case 609: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[2]}); pc = 610; continue; }
case 610: { r[2] = result; pc = 611; continue; }
case 611: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;"); pc = 612; continue; }
case 612: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerAnyModernAvailability;-><init>()V", r[4], new Value[]{}); pc = 613; continue; }
case 613: { r[8] = Value.ref("revanced_miniplayer_width_dip"); pc = 614; continue; }
case 614: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[8], r[2], r[5], r[4]}); pc = 615; continue; }
case 615: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_WIDTH_DIP:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[0]); pc = 616; continue; }
case 616: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 617; continue; }
case 617: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideRewindOrOverlayOpacityAvailability;"); pc = 618; continue; }
case 618: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerHideRewindOrOverlayOpacityAvailability;-><init>()V", r[2], new Value[]{}); pc = 619; continue; }
case 619: { r[4] = Value.ref("revanced_miniplayer_opacity"); pc = 620; continue; }
case 620: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[4], r[3], r[5], r[2]}); pc = 621; continue; }
case 621: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_OPACITY:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[0]); pc = 622; continue; }
case 622: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 623; continue; }
case 623: { r[2] = rt.readField("Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;", Value.NULL, true); pc = 624; continue; }
case 624: { r[3] = Value.ref("revanced_external_downloader"); pc = 625; continue; }
case 625: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 626; continue; }
case 626: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->EXTERNAL_DOWNLOADER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 627; continue; }
case 627: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 628; continue; }
case 628: { r[4] = Value.ref("revanced_external_downloader_action_button"); pc = 629; continue; }
case 629: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[3], new Value[]{r[4], r[2]}); pc = 630; continue; }
case 630: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->EXTERNAL_DOWNLOADER_ACTION_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 631; continue; }
case 631: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 632; continue; }
case 632: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[3]}); pc = 633; continue; }
case 633: { r[0] = result; pc = 634; continue; }
case 634: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 635; continue; }
case 635: { r[0] = result; pc = 636; continue; }
case 636: { r[3] = Value.ref("revanced_external_downloader_name"); pc = 637; continue; }
case 637: { r[8] = Value.ref("com.deniscerri.ytdl"); pc = 638; continue; }
case 638: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[3], r[8], r[0]}); pc = 639; continue; }
case 639: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->EXTERNAL_DOWNLOADER_PACKAGE_NAME:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[4]); pc = 640; continue; }
case 640: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 641; continue; }
case 641: { r[3] = Value.ref("revanced_hide_comments_ai_chat_summary"); pc = 642; continue; }
case 642: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 643; continue; }
case 643: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_AI_CHAT_SUMMARY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 644; continue; }
case 644: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 645; continue; }
case 645: { r[3] = Value.ref("revanced_hide_comments_ai_summary"); pc = 646; continue; }
case 646: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 647; continue; }
case 647: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_AI_SUMMARY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 648; continue; }
case 648: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 649; continue; }
case 649: { r[3] = Value.ref("revanced_hide_comments_by_members_header"); pc = 650; continue; }
case 650: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 651; continue; }
case 651: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_BY_MEMBERS_HEADER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 652; continue; }
case 652: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 653; continue; }
case 653: { r[3] = Value.ref("revanced_hide_comments_channel_guidelines"); pc = 654; continue; }
case 654: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 655; continue; }
case 655: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_CHANNEL_GUIDELINES:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 656; continue; }
case 656: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 657; continue; }
case 657: { r[3] = Value.ref("revanced_hide_comments_community_guidelines"); pc = 658; continue; }
case 658: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 659; continue; }
case 659: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_COMMUNITY_GUIDELINES:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 660; continue; }
case 660: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 661; continue; }
case 661: { r[3] = Value.ref("revanced_hide_comments_create_a_short_button"); pc = 662; continue; }
case 662: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 663; continue; }
case 663: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_CREATE_A_SHORT_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 664; continue; }
case 664: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 665; continue; }
case 665: { r[3] = Value.ref("revanced_hide_comments_preview_comment"); pc = 666; continue; }
case 666: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 667; continue; }
case 667: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_PREVIEW_COMMENT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 668; continue; }
case 668: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 669; continue; }
case 669: { r[3] = Value.ref("revanced_hide_comments_emoji_and_timestamp_buttons"); pc = 670; continue; }
case 670: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 671; continue; }
case 671: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_EMOJI_AND_TIMESTAMP_BUTTONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 672; continue; }
case 672: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 673; continue; }
case 673: { r[3] = Value.ref("revanced_hide_comments_section"); pc = 674; continue; }
case 674: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 675; continue; }
case 675: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 676; continue; }
case 676: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 677; continue; }
case 677: { r[4] = Value.ref("revanced_hide_comments_section_in_home_feed"); pc = 678; continue; }
case 678: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentNot(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 679; continue; }
case 679: { r[0] = result; pc = 680; continue; }
case 680: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[2], r[0]}); pc = 681; continue; }
case 681: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_SECTION_IN_HOME_FEED:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 682; continue; }
case 682: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 683; continue; }
case 683: { r[3] = Value.ref("revanced_hide_comments_thanks_button"); pc = 684; continue; }
case 684: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 685; continue; }
case 685: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_THANKS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 686; continue; }
case 686: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 687; continue; }
case 687: { r[3] = Value.ref("revanced_hide_ai_generated_video_summary_section"); pc = 688; continue; }
case 688: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 689; continue; }
case 689: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_AI_GENERATED_VIDEO_SUMMARY_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 690; continue; }
case 690: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 691; continue; }
case 691: { r[3] = Value.ref("revanced_hide_ask_section"); pc = 692; continue; }
case 692: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 693; continue; }
case 693: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_ASK_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 694; continue; }
case 694: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 695; continue; }
case 695: { r[3] = Value.ref("revanced_hide_attributes_section"); pc = 696; continue; }
case 696: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 697; continue; }
case 697: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_ATTRIBUTES_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 698; continue; }
case 698: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 699; continue; }
case 699: { r[3] = Value.ref("revanced_hide_chapters_section"); pc = 700; continue; }
case 700: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 701; continue; }
case 701: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CHAPTERS_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 702; continue; }
case 702: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 703; continue; }
case 703: { r[3] = Value.ref("revanced_hide_course_progress_section"); pc = 704; continue; }
case 704: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 705; continue; }
case 705: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COURSE_PROGRESS_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 706; continue; }
case 706: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 707; continue; }
case 707: { r[3] = Value.ref("revanced_hide_explore_section"); pc = 708; continue; }
case 708: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 709; continue; }
case 709: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_EXPLORE_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 710; continue; }
case 710: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 711; continue; }
case 711: { r[4] = Value.ref("revanced_hide_explore_course_section"); pc = 712; continue; }
case 712: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentNot(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 713; continue; }
case 713: { r[8] = result; pc = 714; continue; }
case 714: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[2], r[8]}); pc = 715; continue; }
case 715: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_EXPLORE_COURSE_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 716; continue; }
case 716: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 717; continue; }
case 717: { r[4] = Value.ref("revanced_hide_explore_podcast_section"); pc = 718; continue; }
case 718: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentNot(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 719; continue; }
case 719: { r[0] = result; pc = 720; continue; }
case 720: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[2], r[0]}); pc = 721; continue; }
case 721: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_EXPLORE_PODCAST_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 722; continue; }
case 722: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 723; continue; }
case 723: { r[3] = Value.ref("revanced_hide_featured_places_section"); pc = 724; continue; }
case 724: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 725; continue; }
case 725: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FEATURED_PLACES_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 726; continue; }
case 726: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 727; continue; }
case 727: { r[3] = Value.ref("revanced_hide_gaming_section"); pc = 728; continue; }
case 728: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 729; continue; }
case 729: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_GAMING_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 730; continue; }
case 730: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 731; continue; }
case 731: { r[3] = Value.ref("revanced_hide_how_this_was_made_section"); pc = 732; continue; }
case 732: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 733; continue; }
case 733: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_HOW_THIS_WAS_MADE_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 734; continue; }
case 734: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 735; continue; }
case 735: { r[3] = Value.ref("revanced_hide_hype_points"); pc = 736; continue; }
case 736: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 737; continue; }
case 737: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_HYPE_POINTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 738; continue; }
case 738: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 739; continue; }
case 739: { r[3] = Value.ref("revanced_hide_info_cards_section"); pc = 740; continue; }
case 740: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 741; continue; }
case 741: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_INFO_CARDS_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 742; continue; }
case 742: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 743; continue; }
case 743: { r[4] = Value.ref("revanced_hide_featured_links_section"); pc = 744; continue; }
case 744: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentNot(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 745; continue; }
case 745: { r[8] = result; pc = 746; continue; }
case 746: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[2], r[8]}); pc = 747; continue; }
case 747: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FEATURED_LINKS_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 748; continue; }
case 748: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 749; continue; }
case 749: { r[4] = Value.ref("revanced_hide_featured_videos_section"); pc = 750; continue; }
case 750: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentNot(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 751; continue; }
case 751: { r[8] = result; pc = 752; continue; }
case 752: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[2], r[8]}); pc = 753; continue; }
case 753: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_FEATURED_VIDEOS_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 754; continue; }
case 754: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 755; continue; }
case 755: { r[4] = Value.ref("revanced_hide_subscribe_button"); pc = 756; continue; }
case 756: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentNot(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 757; continue; }
case 757: { r[0] = result; pc = 758; continue; }
case 758: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[4], r[2], r[0]}); pc = 759; continue; }
case 759: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SUBSCRIBE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 760; continue; }
case 760: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 761; continue; }
case 761: { r[3] = Value.ref("revanced_hide_key_concepts_section"); pc = 762; continue; }
case 762: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 763; continue; }
case 763: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_KEY_CONCEPTS_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 764; continue; }
case 764: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 765; continue; }
case 765: { r[3] = Value.ref("revanced_hide_music_section"); pc = 766; continue; }
case 766: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 767; continue; }
case 767: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_MUSIC_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 768; continue; }
case 768: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 769; continue; }
case 769: { r[3] = Value.ref("revanced_hide_transcript_section"); pc = 770; continue; }
case 770: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 771; continue; }
case 771: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_TRANSCRIPT_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 772; continue; }
case 772: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 773; continue; }
case 773: { r[3] = Value.ref("revanced_hide_quizzes_section"); pc = 774; continue; }
case 774: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 775; continue; }
case 775: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_QUIZZES_SECTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 776; continue; }
case 776: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 777; continue; }
case 777: { r[3] = Value.ref("revanced_disable_like_subscribe_glow"); pc = 778; continue; }
case 778: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 779; continue; }
case 779: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_LIKE_SUBSCRIBE_GLOW:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 780; continue; }
case 780: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 781; continue; }
case 781: { r[3] = Value.ref("revanced_hide_ask_button"); pc = 782; continue; }
case 782: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 783; continue; }
case 783: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_ASK_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 784; continue; }
case 784: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 785; continue; }
case 785: { r[3] = Value.ref("revanced_hide_clip_button"); pc = 786; continue; }
case 786: { r[4] = Value.ref("revanced_hide_clip_button_user_dialog_message"); pc = 787; continue; }
case 787: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V", r[0], new Value[]{r[3], r[2], r[4]}); pc = 788; continue; }
case 788: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CLIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 789; continue; }
case 789: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 790; continue; }
case 790: { r[3] = Value.ref("revanced_hide_comments_button"); pc = 791; continue; }
case 791: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 792; continue; }
case 792: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_COMMENTS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 793; continue; }
case 793: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 794; continue; }
case 794: { r[3] = Value.ref("revanced_hide_download_button"); pc = 795; continue; }
case 795: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 796; continue; }
case 796: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_DOWNLOAD_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 797; continue; }
case 797: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 798; continue; }
case 798: { r[3] = Value.ref("revanced_hide_hype_button"); pc = 799; continue; }
case 799: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 800; continue; }
case 800: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_HYPE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 801; continue; }
case 801: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 802; continue; }
case 802: { r[3] = Value.ref("revanced_hide_like_dislike_button"); pc = 803; continue; }
case 803: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 804; continue; }
case 804: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_LIKE_DISLIKE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 805; continue; }
case 805: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 806; continue; }
case 806: { r[3] = Value.ref("revanced_hide_promote_button"); pc = 807; continue; }
case 807: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 808; continue; }
case 808: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PROMOTE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 809; continue; }
case 809: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 810; continue; }
case 810: { r[3] = Value.ref("revanced_hide_remix_button"); pc = 811; continue; }
case 811: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 812; continue; }
case 812: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_REMIX_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 813; continue; }
case 813: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 814; continue; }
case 814: { r[3] = Value.ref("revanced_hide_report_button"); pc = 815; continue; }
case 815: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 816; continue; }
case 816: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_REPORT_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 817; continue; }
case 817: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 818; continue; }
case 818: { r[3] = Value.ref("revanced_hide_save_button"); pc = 819; continue; }
case 819: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 820; continue; }
case 820: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SAVE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 821; continue; }
case 821: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 822; continue; }
case 822: { r[3] = Value.ref("revanced_hide_share_button"); pc = 823; continue; }
case 823: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 824; continue; }
case 824: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHARE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 825; continue; }
case 825: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 826; continue; }
case 826: { r[3] = Value.ref("revanced_hide_shop_button"); pc = 827; continue; }
case 827: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 828; continue; }
case 828: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHOP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 829; continue; }
case 829: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 830; continue; }
case 830: { r[3] = Value.ref("revanced_hide_stop_ads_button"); pc = 831; continue; }
case 831: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 832; continue; }
case 832: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_STOP_ADS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 833; continue; }
case 833: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 834; continue; }
case 834: { r[3] = Value.ref("revanced_hide_thanks_button"); pc = 835; continue; }
case 835: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 836; continue; }
case 836: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_THANKS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 837; continue; }
case 837: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 838; continue; }
case 838: { r[3] = Value.ref("revanced_hide_player_flyout_additional_settings"); pc = 839; continue; }
case 839: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 840; continue; }
case 840: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_ADDITIONAL_SETTINGS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 841; continue; }
case 841: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 842; continue; }
case 842: { r[3] = Value.ref("revanced_hide_player_flyout_ambient_mode"); pc = 843; continue; }
case 843: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 844; continue; }
case 844: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_AMBIENT_MODE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 845; continue; }
case 845: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 846; continue; }
case 846: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/patches/litho/PlayerFlyoutMenuItemsFilter$HideAudioFlyoutMenuAvailability;"); pc = 847; continue; }
case 847: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/litho/PlayerFlyoutMenuItemsFilter$HideAudioFlyoutMenuAvailability;-><init>()V", r[3], new Value[]{}); pc = 848; continue; }
case 848: { r[4] = Value.ref("revanced_hide_player_flyout_audio_track"); pc = 849; continue; }
case 849: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[4], r[2], r[3]}); pc = 850; continue; }
case 850: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_AUDIO_TRACK:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 851; continue; }
case 851: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 852; continue; }
case 852: { r[3] = Value.ref("revanced_hide_player_flyout_captions"); pc = 853; continue; }
case 853: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 854; continue; }
case 854: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_CAPTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 855; continue; }
case 855: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 856; continue; }
case 856: { r[3] = Value.ref("revanced_hide_player_flyout_help"); pc = 857; continue; }
case 857: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 858; continue; }
case 858: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_HELP:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 859; continue; }
case 859: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 860; continue; }
case 860: { r[3] = Value.ref("revanced_hide_player_flyout_listen_with_youtube_music"); pc = 861; continue; }
case 861: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 862; continue; }
case 862: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_LISTEN_WITH_YOUTUBE_MUSIC:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 863; continue; }
case 863: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 864; continue; }
case 864: { r[3] = Value.ref("revanced_hide_player_flyout_lock_screen"); pc = 865; continue; }
case 865: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 866; continue; }
case 866: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_LOCK_SCREEN:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 867; continue; }
case 867: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 868; continue; }
case 868: { r[3] = Value.ref("revanced_hide_player_flyout_loop_video"); pc = 869; continue; }
case 869: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 870; continue; }
case 870: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_LOOP_VIDEO:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 871; continue; }
case 871: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 872; continue; }
case 872: { r[3] = Value.ref("revanced_hide_player_flyout_sleep_timer"); pc = 873; continue; }
case 873: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 874; continue; }
case 874: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_SLEEP_TIMER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 875; continue; }
case 875: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 876; continue; }
case 876: { r[3] = Value.ref("revanced_hide_player_flyout_speed"); pc = 877; continue; }
case 877: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 878; continue; }
case 878: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_SPEED:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 879; continue; }
case 879: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 880; continue; }
case 880: { r[3] = Value.ref("revanced_hide_player_flyout_stable_volume"); pc = 881; continue; }
case 881: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 882; continue; }
case 882: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_STABLE_VOLUME:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 883; continue; }
case 883: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 884; continue; }
case 884: { r[3] = Value.ref("revanced_hide_player_flyout_video_quality_footer"); pc = 885; continue; }
case 885: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 886; continue; }
case 886: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_VIDEO_QUALITY_FOOTER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 887; continue; }
case 887: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 888; continue; }
case 888: { r[3] = Value.ref("revanced_hide_player_flyout_video_quality"); pc = 889; continue; }
case 889: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 890; continue; }
case 890: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_VIDEO_QUALITY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 891; continue; }
case 891: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 892; continue; }
case 892: { r[3] = Value.ref("revanced_hide_player_flyout_watch_in_vr"); pc = 893; continue; }
case 893: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 894; continue; }
case 894: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_PLAYER_FLYOUT_WATCH_IN_VR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 895; continue; }
case 895: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 896; continue; }
case 896: { r[3] = Value.ref("revanced_restore_old_settings_menus"); pc = 897; continue; }
case 897: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 898; continue; }
case 898: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RESTORE_OLD_SETTINGS_MENUS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 899; continue; }
case 899: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 900; continue; }
case 900: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true); pc = 901; continue; }
case 901: { r[4] = Value.ref("revanced_change_form_factor_user_dialog_message"); pc = 902; continue; }
case 902: { r[8] = Value.ref("revanced_change_form_factor"); pc = 903; continue; }
case 903: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;ZLjava/lang/String;)V", r[0], new Value[]{r[8], r[3], r[5], r[4]}); pc = 904; continue; }
case 904: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->CHANGE_FORM_FACTOR:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 905; continue; }
case 905: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 906; continue; }
case 906: { r[3] = Value.ref("revanced_bypass_image_region_restrictions"); pc = 907; continue; }
case 907: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 908; continue; }
case 908: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->BYPASS_IMAGE_REGION_RESTRICTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 909; continue; }
case 909: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 910; continue; }
case 910: { r[3] = Value.ref("revanced_gradient_loading_screen"); pc = 911; continue; }
case 911: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 912; continue; }
case 912: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->GRADIENT_LOADING_SCREEN:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 913; continue; }
case 913: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 914; continue; }
case 914: { r[3] = Value.ref("revanced_splash_screen_animation_style"); pc = 915; continue; }
case 915: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;->FPS_60_ONE_SECOND:Lapp/revanced/extension/youtube/patches/theme/ThemePatch$SplashScreenAnimationStyle;", Value.NULL, true); pc = 916; continue; }
case 916: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;Z)V", r[0], new Value[]{r[3], r[4], r[5]}); pc = 917; continue; }
case 917: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SPLASH_SCREEN_ANIMATION_STYLE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 918; continue; }
case 918: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 919; continue; }
case 919: { r[3] = Value.ref("revanced_header_logo"); pc = 920; continue; }
case 920: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;", Value.NULL, true); pc = 921; continue; }
case 921: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;Z)V", r[0], new Value[]{r[3], r[4], r[5]}); pc = 922; continue; }
case 922: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HEADER_LOGO:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 923; continue; }
case 923: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 924; continue; }
case 924: { r[3] = Value.ref("revanced_disable_sign_in_to_tv_popup"); pc = 925; continue; }
case 925: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 926; continue; }
case 926: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_SIGN_IN_TO_TV_POPUP:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 927; continue; }
case 927: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 928; continue; }
case 928: { r[3] = Value.ref("revanced_remove_viewer_discretion_dialog"); pc = 929; continue; }
case 929: { r[4] = Value.ref("revanced_remove_viewer_discretion_dialog_user_dialog_message"); pc = 930; continue; }
case 930: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;)V", r[0], new Value[]{r[3], r[2], r[4]}); pc = 931; continue; }
case 931: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->REMOVE_VIEWER_DISCRETION_DIALOG:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 932; continue; }
case 932: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 933; continue; }
case 933: { r[3] = Value.ref("revanced_spoof_app_version"); pc = 934; continue; }
case 934: { r[4] = Value.ref("revanced_spoof_app_version_user_dialog_message"); pc = 935; continue; }
case 935: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLjava/lang/String;)V", r[0], new Value[]{r[3], r[2], r[5], r[4]}); pc = 936; continue; }
case 936: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_APP_VERSION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 937; continue; }
case 937: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 938; continue; }
case 938: { r[4] = Value.ref("revanced_change_start_page"); pc = 939; continue; }
case 939: { r[8] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$StartPage;", Value.NULL, true); pc = 940; continue; }
case 940: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;Z)V", r[3], new Value[]{r[4], r[8], r[5]}); pc = 941; continue; }
case 941: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->CHANGE_START_PAGE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[3]); pc = 942; continue; }
case 942: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 943; continue; }
case 943: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$ChangeStartPageTypeAvailability;"); pc = 944; continue; }
case 944: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/ChangeStartPagePatch$ChangeStartPageTypeAvailability;-><init>()V", r[4], new Value[]{}); pc = 945; continue; }
case 945: { r[8] = Value.ref("revanced_change_start_page_always"); pc = 946; continue; }
case 946: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[8], r[2], r[5], r[4]}); pc = 947; continue; }
case 947: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->CHANGE_START_PAGE_ALWAYS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[3]); pc = 948; continue; }
case 948: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 949; continue; }
case 949: { r[4] = Value.ref("20.05.46"); pc = 950; continue; }
case 950: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 951; continue; }
case 951: { r[0] = result; pc = 952; continue; }
case 952: { r[8] = Value.ref("revanced_spoof_app_version_target"); pc = 953; continue; }
case 953: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[8], r[4], r[5], r[0]}); pc = 954; continue; }
case 954: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_APP_VERSION_TARGET:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[3]); pc = 955; continue; }
case 955: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 956; continue; }
case 956: { r[3] = Value.ref("revanced_hide_home_button"); pc = 957; continue; }
case 957: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 958; continue; }
case 958: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_HOME_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 959; continue; }
case 959: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 960; continue; }
case 960: { r[3] = Value.ref("revanced_hide_create_button"); pc = 961; continue; }
case 961: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 962; continue; }
case 962: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_CREATE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 963; continue; }
case 963: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 964; continue; }
case 964: { r[3] = Value.ref("revanced_hide_shorts_button"); pc = 965; continue; }
case 965: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 966; continue; }
case 966: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 967; continue; }
case 967: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 968; continue; }
case 968: { r[3] = Value.ref("revanced_hide_subscriptions_button"); pc = 969; continue; }
case 969: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 970; continue; }
case 970: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SUBSCRIPTIONS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 971; continue; }
case 971: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 972; continue; }
case 972: { r[3] = Value.ref("revanced_hide_navigation_button_labels"); pc = 973; continue; }
case 973: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 974; continue; }
case 974: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_NAVIGATION_BUTTON_LABELS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 975; continue; }
case 975: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 976; continue; }
case 976: { r[3] = Value.ref("revanced_narrow_navigation_buttons"); pc = 977; continue; }
case 977: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 978; continue; }
case 978: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->NARROW_NAVIGATION_BUTTONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 979; continue; }
case 979: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 980; continue; }
case 980: { r[3] = Value.ref("revanced_hide_notifications_button"); pc = 981; continue; }
case 981: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 982; continue; }
case 982: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_NOTIFICATIONS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 983; continue; }
case 983: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 984; continue; }
case 984: { r[3] = Value.ref("revanced_switch_create_with_notifications_button"); pc = 985; continue; }
case 985: { r[4] = Value.ref("revanced_switch_create_with_notifications_button_user_dialog_message"); pc = 986; continue; }
case 986: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLjava/lang/String;)V", r[0], new Value[]{r[3], r[1], r[5], r[4]}); pc = 987; continue; }
case 987: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWITCH_CREATE_WITH_NOTIFICATIONS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 988; continue; }
case 988: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 989; continue; }
case 989: { r[3] = Value.ref("revanced_navigation_bar_animations"); pc = 990; continue; }
case 990: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 991; continue; }
case 991: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->NAVIGATION_BAR_ANIMATIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 992; continue; }
case 992: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 993; continue; }
case 993: { r[3] = Value.ref("revanced_disable_translucent_status_bar"); pc = 994; continue; }
case 994: { r[4] = Value.ref("revanced_disable_translucent_status_bar_user_dialog_message"); pc = 995; continue; }
case 995: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLjava/lang/String;)V", r[0], new Value[]{r[3], r[2], r[5], r[4]}); pc = 996; continue; }
case 996: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_TRANSLUCENT_STATUS_BAR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 997; continue; }
case 997: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 998; continue; }
case 998: { r[3] = Value.ref("revanced_disable_translucent_navigation_bar_light"); pc = 999; continue; }
case 999: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 1000; continue; }
case 1000: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_TRANSLUCENT_NAVIGATION_BAR_LIGHT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1001; continue; }
case 1001: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1002; continue; }
case 1002: { r[3] = Value.ref("revanced_disable_translucent_navigation_bar_dark"); pc = 1003; continue; }
case 1003: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 1004; continue; }
case 1004: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_TRANSLUCENT_NAVIGATION_BAR_DARK:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1005; continue; }
case 1005: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1006; continue; }
case 1006: { r[3] = Value.ref("revanced_hide_toolbar_create_button"); pc = 1007; continue; }
case 1007: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[1], r[5]}); pc = 1008; continue; }
case 1008: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_TOOLBAR_CREATE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1009; continue; }
case 1009: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1010; continue; }
case 1010: { r[3] = Value.ref("revanced_hide_toolbar_notification_button"); pc = 1011; continue; }
case 1011: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 1012; continue; }
case 1012: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_TOOLBAR_NOTIFICATION_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1013; continue; }
case 1013: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1014; continue; }
case 1014: { r[3] = Value.ref("revanced_hide_toolbar_search_button"); pc = 1015; continue; }
case 1015: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 1016; continue; }
case 1016: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_TOOLBAR_SEARCH_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1017; continue; }
case 1017: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1018; continue; }
case 1018: { r[3] = Value.ref("revanced_wide_searchbar"); pc = 1019; continue; }
case 1019: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 1020; continue; }
case 1020: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->WIDE_SEARCHBAR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1021; continue; }
case 1021: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1022; continue; }
case 1022: { r[3] = Value.ref("revanced_disable_resuming_shorts_player"); pc = 1023; continue; }
case 1023: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1024; continue; }
case 1024: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_RESUMING_SHORTS_PLAYER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1025; continue; }
case 1025: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1026; continue; }
case 1026: { r[3] = Value.ref("revanced_shorts_disable_background_playback"); pc = 1027; continue; }
case 1027: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1028; continue; }
case 1028: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_SHORTS_BACKGROUND_PLAYBACK:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1029; continue; }
case 1029: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 1030; continue; }
case 1030: { r[3] = Value.ref("revanced_shorts_player_type"); pc = 1031; continue; }
case 1031: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->SHORTS_PLAYER:Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true); pc = 1032; continue; }
case 1032: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;)V", r[0], new Value[]{r[3], r[4]}); pc = 1033; continue; }
case 1033: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SHORTS_PLAYER_TYPE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 1034; continue; }
case 1034: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1035; continue; }
case 1035: { r[3] = Value.ref("revanced_hide_shorts_ai_button"); pc = 1036; continue; }
case 1036: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1037; continue; }
case 1037: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_AI_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1038; continue; }
case 1038: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1039; continue; }
case 1039: { r[3] = Value.ref("revanced_hide_shorts_auto_dubbed_label"); pc = 1040; continue; }
case 1040: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1041; continue; }
case 1041: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_AUTO_DUBBED_LABEL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1042; continue; }
case 1042: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1043; continue; }
case 1043: { r[3] = Value.ref("revanced_hide_shorts_channel"); pc = 1044; continue; }
case 1044: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1045; continue; }
case 1045: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_CHANNEL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1046; continue; }
case 1046: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1047; continue; }
case 1047: { r[3] = Value.ref("revanced_hide_shorts_channel_bar"); pc = 1048; continue; }
case 1048: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1049; continue; }
case 1049: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_CHANNEL_BAR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1050; continue; }
case 1050: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1051; continue; }
case 1051: { r[3] = Value.ref("revanced_hide_shorts_comments_button"); pc = 1052; continue; }
case 1052: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1053; continue; }
case 1053: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_COMMENTS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1054; continue; }
case 1054: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1055; continue; }
case 1055: { r[3] = Value.ref("revanced_hide_shorts_dislike_button"); pc = 1056; continue; }
case 1056: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1057; continue; }
case 1057: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_DISLIKE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1058; continue; }
case 1058: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1059; continue; }
case 1059: { r[3] = Value.ref("revanced_hide_shorts_full_video_link_label"); pc = 1060; continue; }
case 1060: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1061; continue; }
case 1061: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_FULL_VIDEO_LINK_LABEL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1062; continue; }
case 1062: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1063; continue; }
case 1063: { r[3] = Value.ref("revanced_hide_shorts_effect_button"); pc = 1064; continue; }
case 1064: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1065; continue; }
case 1065: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_EFFECT_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1066; continue; }
case 1066: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1067; continue; }
case 1067: { r[3] = Value.ref("revanced_hide_shorts_green_screen_button"); pc = 1068; continue; }
case 1068: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1069; continue; }
case 1069: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_GREEN_SCREEN_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1070; continue; }
case 1070: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1071; continue; }
case 1071: { r[3] = Value.ref("revanced_hide_shorts_new_posts_button"); pc = 1072; continue; }
case 1072: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1073; continue; }
case 1073: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_NEW_POSTS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1074; continue; }
case 1074: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1075; continue; }
case 1075: { r[3] = Value.ref("revanced_hide_shorts_hashtag_button"); pc = 1076; continue; }
case 1076: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1077; continue; }
case 1077: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_HASHTAG_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1078; continue; }
case 1078: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1079; continue; }
case 1079: { r[3] = Value.ref("revanced_hide_shorts_history"); pc = 1080; continue; }
case 1080: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1081; continue; }
case 1081: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_HISTORY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1082; continue; }
case 1082: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1083; continue; }
case 1083: { r[3] = Value.ref("revanced_hide_shorts_home"); pc = 1084; continue; }
case 1084: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1085; continue; }
case 1085: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_HOME:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1086; continue; }
case 1086: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1087; continue; }
case 1087: { r[3] = Value.ref("revanced_hide_shorts_info_panel"); pc = 1088; continue; }
case 1088: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1089; continue; }
case 1089: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_INFO_PANEL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1090; continue; }
case 1090: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1091; continue; }
case 1091: { r[3] = Value.ref("revanced_hide_shorts_join_button"); pc = 1092; continue; }
case 1092: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1093; continue; }
case 1093: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_JOIN_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1094; continue; }
case 1094: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1095; continue; }
case 1095: { r[3] = Value.ref("revanced_hide_shorts_like_button"); pc = 1096; continue; }
case 1096: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1097; continue; }
case 1097: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_LIKE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1098; continue; }
case 1098: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1099; continue; }
case 1099: { r[3] = Value.ref("revanced_hide_shorts_like_fountain"); pc = 1100; continue; }
case 1100: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1101; continue; }
case 1101: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_LIKE_FOUNTAIN:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1102; continue; }
case 1102: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1103; continue; }
case 1103: { r[3] = Value.ref("revanced_hide_shorts_live_preview"); pc = 1104; continue; }
case 1104: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1105; continue; }
case 1105: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_LIVE_PREVIEW:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1106; continue; }
case 1106: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1107; continue; }
case 1107: { r[3] = Value.ref("revanced_hide_shorts_location_label"); pc = 1108; continue; }
case 1108: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1109; continue; }
case 1109: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_LOCATION_LABEL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1110; continue; }
case 1110: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1111; continue; }
case 1111: { r[3] = Value.ref("revanced_hide_shorts_navigation_bar"); pc = 1112; continue; }
case 1112: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[3], r[2], r[5]}); pc = 1113; continue; }
case 1113: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_NAVIGATION_BAR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1114; continue; }
case 1114: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1115; continue; }
case 1115: { r[3] = Value.ref("revanced_hide_shorts_paused_overlay_buttons"); pc = 1116; continue; }
case 1116: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1117; continue; }
case 1117: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_PAUSED_OVERLAY_BUTTONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1118; continue; }
case 1118: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1119; continue; }
case 1119: { r[3] = Value.ref("revanced_hide_shorts_preview_comment"); pc = 1120; continue; }
case 1120: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1121; continue; }
case 1121: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_PREVIEW_COMMENT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1122; continue; }
case 1122: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1123; continue; }
case 1123: { r[3] = Value.ref("revanced_hide_shorts_remix_button"); pc = 1124; continue; }
case 1124: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1125; continue; }
case 1125: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_REMIX_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1126; continue; }
case 1126: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1127; continue; }
case 1127: { r[3] = Value.ref("revanced_hide_shorts_save_sound_button"); pc = 1128; continue; }
case 1128: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1129; continue; }
case 1129: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SAVE_SOUND_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1130; continue; }
case 1130: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1131; continue; }
case 1131: { r[3] = Value.ref("revanced_hide_shorts_search"); pc = 1132; continue; }
case 1132: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1133; continue; }
case 1133: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SEARCH:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1134; continue; }
case 1134: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1135; continue; }
case 1135: { r[3] = Value.ref("revanced_hide_shorts_search_suggestions"); pc = 1136; continue; }
case 1136: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1137; continue; }
case 1137: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SEARCH_SUGGESTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1138; continue; }
case 1138: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1139; continue; }
case 1139: { r[3] = Value.ref("revanced_hide_shorts_share_button"); pc = 1140; continue; }
case 1140: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1141; continue; }
case 1141: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SHARE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1142; continue; }
case 1142: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1143; continue; }
case 1143: { r[3] = Value.ref("revanced_hide_shorts_shop_button"); pc = 1144; continue; }
case 1144: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1145; continue; }
case 1145: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SHOP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1146; continue; }
case 1146: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1147; continue; }
case 1147: { r[3] = Value.ref("revanced_hide_shorts_sound_button"); pc = 1148; continue; }
case 1148: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1149; continue; }
case 1149: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SOUND_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1150; continue; }
case 1150: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1151; continue; }
case 1151: { r[3] = Value.ref("revanced_hide_shorts_sound_metadata_label"); pc = 1152; continue; }
case 1152: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1153; continue; }
case 1153: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SOUND_METADATA_LABEL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1154; continue; }
case 1154: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1155; continue; }
case 1155: { r[3] = Value.ref("revanced_hide_shorts_stickers"); pc = 1156; continue; }
case 1156: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1157; continue; }
case 1157: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_STICKERS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1158; continue; }
case 1158: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1159; continue; }
case 1159: { r[3] = Value.ref("revanced_hide_shorts_subscribe_button"); pc = 1160; continue; }
case 1160: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1161; continue; }
case 1161: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SUBSCRIBE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1162; continue; }
case 1162: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1163; continue; }
case 1163: { r[3] = Value.ref("revanced_hide_shorts_subscriptions"); pc = 1164; continue; }
case 1164: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1165; continue; }
case 1165: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SUBSCRIPTIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1166; continue; }
case 1166: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1167; continue; }
case 1167: { r[3] = Value.ref("revanced_hide_shorts_super_thanks_button"); pc = 1168; continue; }
case 1168: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1169; continue; }
case 1169: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_SUPER_THANKS_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1170; continue; }
case 1170: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1171; continue; }
case 1171: { r[3] = Value.ref("revanced_hide_shorts_tagged_products"); pc = 1172; continue; }
case 1172: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1173; continue; }
case 1173: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_TAGGED_PRODUCTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1174; continue; }
case 1174: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1175; continue; }
case 1175: { r[3] = Value.ref("revanced_hide_shorts_upcoming_button"); pc = 1176; continue; }
case 1176: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1177; continue; }
case 1177: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_UPCOMING_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1178; continue; }
case 1178: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1179; continue; }
case 1179: { r[1] = rt.readField("Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;", Value.NULL, true); pc = 1180; continue; }
case 1180: { r[3] = Value.ref("revanced_hide_shorts_use_sound_button"); pc = 1181; continue; }
case 1181: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1182; continue; }
case 1182: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_USE_SOUND_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1183; continue; }
case 1183: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1184; continue; }
case 1184: { r[3] = Value.ref("revanced_hide_shorts_use_template_button"); pc = 1185; continue; }
case 1185: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[1]}); pc = 1186; continue; }
case 1186: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_USE_TEMPLATE_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1187; continue; }
case 1187: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1188; continue; }
case 1188: { r[3] = Value.ref("revanced_hide_shorts_video_description"); pc = 1189; continue; }
case 1189: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[3], r[2]}); pc = 1190; continue; }
case 1190: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_VIDEO_DESCRIPTION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1191; continue; }
case 1191: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1192; continue; }
case 1192: { r[10] = rt.readField("Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;", Value.NULL, true); pc = 1193; continue; }
case 1193: { r[2] = Value.ref("revanced_hide_shorts_video_title"); pc = 1194; continue; }
case 1194: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[10]}); pc = 1195; continue; }
case 1195: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SHORTS_VIDEO_TITLE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1196; continue; }
case 1196: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1197; continue; }
case 1197: { r[2] = Value.ref("revanced_shorts_autoplay"); pc = 1198; continue; }
case 1198: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[10]}); pc = 1199; continue; }
case 1199: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SHORTS_AUTOPLAY:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1200; continue; }
case 1200: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1201; continue; }
case 1201: { r[2] = Value.ref("revanced_shorts_autoplay_background"); pc = 1202; continue; }
case 1202: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[1]}); pc = 1203; continue; }
case 1203: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SHORTS_AUTOPLAY_BACKGROUND:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1204; continue; }
case 1204: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1205; continue; }
case 1205: { r[2] = Value.ref("revanced_disable_precise_seeking_gesture"); pc = 1206; continue; }
case 1206: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[10]}); pc = 1207; continue; }
case 1207: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DISABLE_PRECISE_SEEKING_GESTURE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1208; continue; }
case 1208: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1209; continue; }
case 1209: { r[2] = Value.ref("revanced_hide_seekbar"); pc = 1210; continue; }
case 1210: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[2], r[10], r[5]}); pc = 1211; continue; }
case 1211: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SEEKBAR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1212; continue; }
case 1212: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1213; continue; }
case 1213: { r[2] = Value.ref("revanced_hide_seekbar_thumbnail"); pc = 1214; continue; }
case 1214: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[2], r[10], r[5]}); pc = 1215; continue; }
case 1215: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_SEEKBAR_THUMBNAIL:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1216; continue; }
case 1216: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1217; continue; }
case 1217: { r[2] = Value.ref("revanced_fullscreen_large_seekbar"); pc = 1218; continue; }
case 1218: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[10]}); pc = 1219; continue; }
case 1219: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->FULLSCREEN_LARGE_SEEKBAR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1220; continue; }
case 1220: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1221; continue; }
case 1221: { r[2] = Value.ref("revanced_hide_timestamp"); pc = 1222; continue; }
case 1222: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[10]}); pc = 1223; continue; }
case 1223: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->HIDE_TIMESTAMP:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1224; continue; }
case 1224: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1225; continue; }
case 1225: { r[2] = Value.ref("revanced_slide_to_seek"); pc = 1226; continue; }
case 1226: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[2], r[10], r[5]}); pc = 1227; continue; }
case 1227: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SLIDE_TO_SEEK:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1228; continue; }
case 1228: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1229; continue; }
case 1229: { r[2] = Value.ref("revanced_tap_to_seek"); pc = 1230; continue; }
case 1230: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[2], r[10]}); pc = 1231; continue; }
case 1231: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->TAP_TO_SEEK:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1232; continue; }
case 1232: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1233; continue; }
case 1233: { r[2] = Value.ref("revanced_seekbar_custom_color"); pc = 1234; continue; }
case 1234: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[2], r[10], r[5]}); pc = 1235; continue; }
case 1235: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SEEKBAR_CUSTOM_COLOR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1236; continue; }
case 1236: { r[2] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1237; continue; }
case 1237: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1238; continue; }
case 1238: { r[3] = result; pc = 1239; continue; }
case 1239: { r[4] = Value.ref("revanced_seekbar_custom_color_primary"); pc = 1240; continue; }
case 1240: { r[14] = Value.ref("#FF0033"); pc = 1241; continue; }
case 1241: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[2], new Value[]{r[4], r[14], r[5], r[3]}); pc = 1242; continue; }
case 1242: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SEEKBAR_CUSTOM_COLOR_PRIMARY:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[2]); pc = 1243; continue; }
case 1243: { r[3] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1244; continue; }
case 1244: { r[4] = Value.ref("#FF2791"); pc = 1245; continue; }
case 1245: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1246; continue; }
case 1246: { r[0] = result; pc = 1247; continue; }
case 1247: { r[8] = Value.ref("revanced_seekbar_custom_color_accent"); pc = 1248; continue; }
case 1248: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[3], new Value[]{r[8], r[4], r[5], r[0]}); pc = 1249; continue; }
case 1249: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SEEKBAR_CUSTOM_COLOR_ACCENT:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[3]); pc = 1250; continue; }
case 1250: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1251; continue; }
case 1251: { r[4] = Value.ref("revanced_announcements"); pc = 1252; continue; }
case 1252: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[4], r[1]}); pc = 1253; continue; }
case 1253: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ANNOUNCEMENTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1254; continue; }
case 1254: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 1255; continue; }
case 1255: { r[4] = Value.i32(-1); pc = 1256; continue; }
case 1256: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[4]}); pc = 1257; continue; }
case 1257: { r[4] = result; pc = 1258; continue; }
case 1258: { r[8] = Value.ref("revanced_announcement_last_id"); pc = 1259; continue; }
case 1259: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;ZZ)V", r[0], new Value[]{r[8], r[4], r[6], r[6]}); pc = 1260; continue; }
case 1260: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->ANNOUNCEMENT_LAST_ID:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[0]); pc = 1261; continue; }
case 1261: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1262; continue; }
case 1262: { r[4] = Value.ref("revanced_loop_video"); pc = 1263; continue; }
case 1263: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[4], r[10]}); pc = 1264; continue; }
case 1264: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->LOOP_VIDEO:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1265; continue; }
case 1265: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1266; continue; }
case 1266: { r[4] = Value.ref("revanced_loop_video_button"); pc = 1267; continue; }
case 1267: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[4], r[10]}); pc = 1268; continue; }
case 1268: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->LOOP_VIDEO_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1269; continue; }
case 1269: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1270; continue; }
case 1270: { r[4] = Value.ref("revanced_pause_on_audio_interrupt"); pc = 1271; continue; }
case 1271: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[4], r[10], r[5]}); pc = 1272; continue; }
case 1272: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->PAUSE_ON_AUDIO_INTERRUPT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1273; continue; }
case 1273: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1274; continue; }
case 1274: { r[4] = Value.ref("revanced_bypass_url_redirects"); pc = 1275; continue; }
case 1275: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[4], r[1]}); pc = 1276; continue; }
case 1276: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->BYPASS_URL_REDIRECTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1277; continue; }
case 1277: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1278; continue; }
case 1278: { r[4] = Value.ref("revanced_external_browser"); pc = 1279; continue; }
case 1279: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[4], r[1], r[5]}); pc = 1280; continue; }
case 1280: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->EXTERNAL_BROWSER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1281; continue; }
case 1281: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1282; continue; }
case 1282: { r[4] = Value.ref("revanced_spoof_device_dimensions"); pc = 1283; continue; }
case 1283: { r[8] = Value.ref("revanced_spoof_device_dimensions_user_dialog_message"); pc = 1284; continue; }
case 1284: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLjava/lang/String;)V", r[0], new Value[]{r[4], r[10], r[5], r[8]}); pc = 1285; continue; }
case 1285: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_DEVICE_DIMENSIONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1286; continue; }
case 1286: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 1287; continue; }
case 1287: { r[4] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_VR_1_43_32:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true); pc = 1288; continue; }
case 1288: { r[8] = rt.readField("Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;->SPOOF_VIDEO_STREAMS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true); pc = 1289; continue; }
case 1289: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[8]}); pc = 1290; continue; }
case 1290: { r[8] = result; pc = 1291; continue; }
case 1291: { r[9] = Value.ref("revanced_spoof_video_streams_client_type"); pc = 1292; continue; }
case 1292: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[0], new Value[]{r[9], r[4], r[5], r[8]}); pc = 1293; continue; }
case 1293: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_VIDEO_STREAMS_CLIENT_TYPE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[0]); pc = 1294; continue; }
case 1294: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1295; continue; }
case 1295: { r[13] = rt.allocate("Lapp/revanced/extension/youtube/patches/spoof/SpoofVideoStreamsPatch$SpoofClientAv1Availability;"); pc = 1296; continue; }
case 1296: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/patches/spoof/SpoofVideoStreamsPatch$SpoofClientAv1Availability;-><init>()V", r[13], new Value[]{}); pc = 1297; continue; }
case 1297: { r[9] = Value.ref("revanced_spoof_video_streams_av1"); pc = 1298; continue; }
case 1298: { r[11] = Value.i32(1); pc = 1299; continue; }
case 1299: { r[12] = Value.ref("revanced_spoof_video_streams_av1_user_dialog_message"); pc = 1300; continue; }
case 1300: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[9], r[10], r[11], r[12], r[13]}); pc = 1301; continue; }
case 1301: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_VIDEO_STREAMS_AV1:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[8]); pc = 1302; continue; }
case 1302: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1303; continue; }
case 1303: { r[4] = Value.ref("revanced_swipe_change_video"); pc = 1304; continue; }
case 1304: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[4], r[10], r[5]}); pc = 1305; continue; }
case 1305: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_CHANGE_VIDEO:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1306; continue; }
case 1306: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1307; continue; }
case 1307: { r[4] = Value.ref("revanced_swipe_brightness"); pc = 1308; continue; }
case 1308: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[0], new Value[]{r[4], r[10], r[5]}); pc = 1309; continue; }
case 1309: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_BRIGHTNESS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1310; continue; }
case 1310: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1311; continue; }
case 1311: { r[8] = Value.ref("revanced_swipe_volume"); pc = 1312; continue; }
case 1312: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Z)V", r[4], new Value[]{r[8], r[10], r[5]}); pc = 1313; continue; }
case 1313: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_VOLUME:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1314; continue; }
case 1314: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1315; continue; }
case 1315: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[4]}); pc = 1316; continue; }
case 1316: { r[9] = result; pc = 1317; continue; }
case 1317: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[9]}); pc = 1318; continue; }
case 1318: { r[9] = result; pc = 1319; continue; }
case 1319: { r[11] = Value.ref("revanced_swipe_press_to_engage"); pc = 1320; continue; }
case 1320: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[11], r[10], r[5], r[9]}); pc = 1321; continue; }
case 1321: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_PRESS_TO_ENGAGE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[8]); pc = 1322; continue; }
case 1322: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1323; continue; }
case 1323: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[4]}); pc = 1324; continue; }
case 1324: { r[9] = result; pc = 1325; continue; }
case 1325: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[9]}); pc = 1326; continue; }
case 1326: { r[9] = result; pc = 1327; continue; }
case 1327: { r[11] = Value.ref("revanced_swipe_haptic_feedback"); pc = 1328; continue; }
case 1328: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[11], r[1], r[5], r[9]}); pc = 1329; continue; }
case 1329: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_HAPTIC_FEEDBACK:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[8]); pc = 1330; continue; }
case 1330: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 1331; continue; }
case 1331: { r[9] = Value.i32(30); pc = 1332; continue; }
case 1332: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[9]}); pc = 1333; continue; }
case 1333: { r[9] = result; pc = 1334; continue; }
case 1334: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[4]}); pc = 1335; continue; }
case 1335: { r[11] = result; pc = 1336; continue; }
case 1336: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[11]}); pc = 1337; continue; }
case 1337: { r[11] = result; pc = 1338; continue; }
case 1338: { r[12] = Value.ref("revanced_swipe_threshold"); pc = 1339; continue; }
case 1339: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[12], r[9], r[5], r[11]}); pc = 1340; continue; }
case 1340: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_MAGNITUDE_THRESHOLD:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[8]); pc = 1341; continue; }
case 1341: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 1342; continue; }
case 1342: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[5]}); pc = 1343; continue; }
case 1343: { r[9] = result; pc = 1344; continue; }
case 1344: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[4]}); pc = 1345; continue; }
case 1345: { r[11] = result; pc = 1346; continue; }
case 1346: { r[12] = Value.ref("revanced_swipe_volume_sensitivity"); pc = 1347; continue; }
case 1347: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[12], r[9], r[5], r[11]}); pc = 1348; continue; }
case 1348: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_VOLUME_SENSITIVITY:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[8]); pc = 1349; continue; }
case 1349: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 1350; continue; }
case 1350: { r[9] = rt.readField("Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;->HORIZONTAL:Lapp/revanced/extension/youtube/swipecontrols/SwipeControlsConfigurationProvider$SwipeOverlayStyle;", Value.NULL, true); pc = 1351; continue; }
case 1351: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[4]}); pc = 1352; continue; }
case 1352: { r[11] = result; pc = 1353; continue; }
case 1353: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[11]}); pc = 1354; continue; }
case 1354: { r[11] = result; pc = 1355; continue; }
case 1355: { r[12] = Value.ref("revanced_swipe_overlay_style"); pc = 1356; continue; }
case 1356: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[12], r[9], r[5], r[11]}); pc = 1357; continue; }
case 1357: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_OVERLAY_STYLE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[8]); pc = 1358; continue; }
case 1358: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 1359; continue; }
case 1359: { r[9] = Value.i32(14); pc = 1360; continue; }
case 1360: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[9]}); pc = 1361; continue; }
case 1361: { r[9] = result; pc = 1362; continue; }
case 1362: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[4]}); pc = 1363; continue; }
case 1363: { r[11] = result; pc = 1364; continue; }
case 1364: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[11]}); pc = 1365; continue; }
case 1365: { r[11] = result; pc = 1366; continue; }
case 1366: { r[12] = Value.ref("revanced_swipe_text_overlay_size"); pc = 1367; continue; }
case 1367: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[12], r[9], r[5], r[11]}); pc = 1368; continue; }
case 1368: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_OVERLAY_TEXT_SIZE:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[8]); pc = 1369; continue; }
case 1369: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 1370; continue; }
case 1370: { r[9] = Value.i32(60); pc = 1371; continue; }
case 1371: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[9]}); pc = 1372; continue; }
case 1372: { r[9] = result; pc = 1373; continue; }
case 1373: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[4]}); pc = 1374; continue; }
case 1374: { r[11] = result; pc = 1375; continue; }
case 1375: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[11]}); pc = 1376; continue; }
case 1376: { r[11] = result; pc = 1377; continue; }
case 1377: { r[12] = Value.ref("revanced_swipe_overlay_background_opacity"); pc = 1378; continue; }
case 1378: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[12], r[9], r[5], r[11]}); pc = 1379; continue; }
case 1379: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_OVERLAY_OPACITY:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[8]); pc = 1380; continue; }
case 1380: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1381; continue; }
case 1381: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1382; continue; }
case 1382: { r[9] = result; pc = 1383; continue; }
case 1383: { r[11] = Value.ref("revanced_swipe_overlay_progress_brightness_color"); pc = 1384; continue; }
case 1384: { r[12] = Value.ref("#BFFFFFFF"); pc = 1385; continue; }
case 1385: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[11], r[12], r[5], r[9]}); pc = 1386; continue; }
case 1386: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_OVERLAY_BRIGHTNESS_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[8]); pc = 1387; continue; }
case 1387: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1388; continue; }
case 1388: { r[9] = Value.ref("revanced_swipe_overlay_progress_volume_color"); pc = 1389; continue; }
case 1389: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[4]}); pc = 1390; continue; }
case 1390: { r[11] = result; pc = 1391; continue; }
case 1391: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[9], r[12], r[5], r[11]}); pc = 1392; continue; }
case 1392: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_OVERLAY_VOLUME_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[8]); pc = 1393; continue; }
case 1393: { r[8] = rt.allocate("Lapp/revanced/extension/shared/settings/LongSetting;"); pc = 1394; continue; }
case 1394: { r[11] = Value.i64(500L); r[12] = r[11]; pc = 1395; continue; }
case 1395: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;", Value.NULL, new Value[]{r[11]}); pc = 1396; continue; }
case 1396: { r[9] = result; pc = 1397; continue; }
case 1397: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[4]}); pc = 1398; continue; }
case 1398: { r[4] = result; pc = 1399; continue; }
case 1399: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAny([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[4]}); pc = 1400; continue; }
case 1400: { r[4] = result; pc = 1401; continue; }
case 1401: { r[11] = Value.ref("revanced_swipe_overlay_timeout"); pc = 1402; continue; }
case 1402: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/LongSetting;-><init>(Ljava/lang/String;Ljava/lang/Long;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[8], new Value[]{r[11], r[9], r[5], r[4]}); pc = 1403; continue; }
case 1403: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_OVERLAY_TIMEOUT:Lapp/revanced/extension/shared/settings/LongSetting;", Value.NULL, true, r[8]); pc = 1404; continue; }
case 1404: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1405; continue; }
case 1405: { r[8] = Value.ref("revanced_swipe_save_and_restore_brightness"); pc = 1406; continue; }
case 1406: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1407; continue; }
case 1407: { r[9] = result; pc = 1408; continue; }
case 1408: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[8], r[1], r[5], r[9]}); pc = 1409; continue; }
case 1409: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_SAVE_AND_RESTORE_BRIGHTNESS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1410; continue; }
case 1410: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1411; continue; }
case 1411: { r[8] = Value.i32(-1082130432); pc = 1412; continue; }
case 1412: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;", Value.NULL, new Value[]{r[8]}); pc = 1413; continue; }
case 1413: { r[8] = result; pc = 1414; continue; }
case 1414: { r[9] = Value.ref("revanced_swipe_brightness_value"); pc = 1415; continue; }
case 1415: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;)V", r[4], new Value[]{r[9], r[8]}); pc = 1416; continue; }
case 1416: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_BRIGHTNESS_VALUE:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[4]); pc = 1417; continue; }
case 1417: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1418; continue; }
case 1418: { r[8] = Value.ref("revanced_swipe_lowest_value_enable_auto_brightness"); pc = 1419; continue; }
case 1419: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1420; continue; }
case 1420: { r[0] = result; pc = 1421; continue; }
case 1421: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[8], r[10], r[5], r[0]}); pc = 1422; continue; }
case 1422: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SWIPE_LOWEST_VALUE_ENABLE_AUTO_BRIGHTNESS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1423; continue; }
case 1423: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1424; continue; }
case 1424: { r[4] = Value.ref("revanced_ryd_enabled"); pc = 1425; continue; }
case 1425: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[4], r[1]}); pc = 1426; continue; }
case 1426: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RYD_ENABLED:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1427; continue; }
case 1427: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1428; continue; }
case 1428: { r[8] = Value.ref("revanced_ryd_user_id"); pc = 1429; continue; }
case 1429: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZZ)V", r[4], new Value[]{r[8], r[7], r[6], r[6]}); pc = 1430; continue; }
case 1430: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RYD_USER_ID:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[4]); pc = 1431; continue; }
case 1431: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1432; continue; }
case 1432: { r[8] = Value.ref("revanced_ryd_shorts"); pc = 1433; continue; }
case 1433: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1434; continue; }
case 1434: { r[9] = result; pc = 1435; continue; }
case 1435: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[8], r[1], r[9]}); pc = 1436; continue; }
case 1436: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RYD_SHORTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1437; continue; }
case 1437: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1438; continue; }
case 1438: { r[8] = Value.ref("revanced_ryd_dislike_percentage"); pc = 1439; continue; }
case 1439: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1440; continue; }
case 1440: { r[9] = result; pc = 1441; continue; }
case 1441: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[8], r[10], r[5], r[9]}); pc = 1442; continue; }
case 1442: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RYD_DISLIKE_PERCENTAGE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1443; continue; }
case 1443: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1444; continue; }
case 1444: { r[8] = Value.ref("revanced_ryd_compact_layout"); pc = 1445; continue; }
case 1445: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1446; continue; }
case 1446: { r[9] = result; pc = 1447; continue; }
case 1447: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[8], r[10], r[5], r[9]}); pc = 1448; continue; }
case 1448: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RYD_COMPACT_LAYOUT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1449; continue; }
case 1449: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1450; continue; }
case 1450: { r[8] = Value.ref("revanced_ryd_estimated_like"); pc = 1451; continue; }
case 1451: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1452; continue; }
case 1452: { r[9] = result; pc = 1453; continue; }
case 1453: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[8], r[1], r[5], r[9]}); pc = 1454; continue; }
case 1454: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RYD_ESTIMATED_LIKE:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1455; continue; }
case 1455: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1456; continue; }
case 1456: { r[5] = Value.ref("revanced_ryd_toast_on_connection_error"); pc = 1457; continue; }
case 1457: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1458; continue; }
case 1458: { r[0] = result; pc = 1459; continue; }
case 1459: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[1], r[0]}); pc = 1460; continue; }
case 1460: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->RYD_TOAST_ON_CONNECTION_ERROR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1461; continue; }
case 1461: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1462; continue; }
case 1462: { r[4] = Value.ref("sb_enabled"); pc = 1463; continue; }
case 1463: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[4], r[1]}); pc = 1464; continue; }
case 1464: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_ENABLED:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 1465; continue; }
case 1465: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1466; continue; }
case 1466: { r[5] = Value.ref("sb_private_user_id_Do_Not_Share"); pc = 1467; continue; }
case 1467: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1468; continue; }
case 1468: { r[8] = result; pc = 1469; continue; }
case 1469: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[7], r[8]}); pc = 1470; continue; }
case 1470: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_PRIVATE_USER_ID:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[4]); pc = 1471; continue; }
case 1471: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 1472; continue; }
case 1472: { r[5] = Value.i32(150); pc = 1473; continue; }
case 1473: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[5]}); pc = 1474; continue; }
case 1474: { r[5] = result; pc = 1475; continue; }
case 1475: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1476; continue; }
case 1476: { r[7] = result; pc = 1477; continue; }
case 1477: { r[8] = Value.ref("sb_create_new_segment_step"); pc = 1478; continue; }
case 1478: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[8], r[5], r[7]}); pc = 1479; continue; }
case 1479: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CREATE_NEW_SEGMENT_STEP:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[4]); pc = 1480; continue; }
case 1480: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1481; continue; }
case 1481: { r[5] = Value.ref("sb_voting_button"); pc = 1482; continue; }
case 1482: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1483; continue; }
case 1483: { r[7] = result; pc = 1484; continue; }
case 1484: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[10], r[7]}); pc = 1485; continue; }
case 1485: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_VOTING_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1486; continue; }
case 1486: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1487; continue; }
case 1487: { r[5] = Value.ref("sb_create_new_segment"); pc = 1488; continue; }
case 1488: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1489; continue; }
case 1489: { r[7] = result; pc = 1490; continue; }
case 1490: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[10], r[7]}); pc = 1491; continue; }
case 1491: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CREATE_NEW_SEGMENT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1492; continue; }
case 1492: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1493; continue; }
case 1493: { r[5] = Value.ref("sb_square_layout"); pc = 1494; continue; }
case 1494: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1495; continue; }
case 1495: { r[7] = result; pc = 1496; continue; }
case 1496: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[10], r[7]}); pc = 1497; continue; }
case 1497: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_SQUARE_LAYOUT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1498; continue; }
case 1498: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1499; continue; }
case 1499: { r[5] = Value.ref("sb_compact_skip_button"); pc = 1500; continue; }
case 1500: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1501; continue; }
case 1501: { r[7] = result; pc = 1502; continue; }
case 1502: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[10], r[7]}); pc = 1503; continue; }
case 1503: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_COMPACT_SKIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1504; continue; }
case 1504: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1505; continue; }
case 1505: { r[5] = Value.ref("sb_auto_hide_skip_button"); pc = 1506; continue; }
case 1506: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1507; continue; }
case 1507: { r[7] = result; pc = 1508; continue; }
case 1508: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[1], r[7]}); pc = 1509; continue; }
case 1509: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_AUTO_HIDE_SKIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1510; continue; }
case 1510: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 1511; continue; }
case 1511: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->FOUR_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 1512; continue; }
case 1512: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1513; continue; }
case 1513: { r[7] = result; pc = 1514; continue; }
case 1514: { r[8] = Value.ref("sb_auto_hide_skip_button_duration"); pc = 1515; continue; }
case 1515: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[8], r[5], r[7]}); pc = 1516; continue; }
case 1516: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_AUTO_HIDE_SKIP_BUTTON_DURATION:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[4]); pc = 1517; continue; }
case 1517: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1518; continue; }
case 1518: { r[7] = Value.ref("sb_toast_on_skip"); pc = 1519; continue; }
case 1519: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1520; continue; }
case 1520: { r[8] = result; pc = 1521; continue; }
case 1521: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[7], r[1], r[8]}); pc = 1522; continue; }
case 1522: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_TOAST_ON_SKIP:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1523; continue; }
case 1523: { r[7] = rt.allocate("Lapp/revanced/extension/shared/settings/EnumSetting;"); pc = 1524; continue; }
case 1524: { result = rt.filledArray("[Lapp/revanced/extension/shared/settings/BooleanSetting;", new Value[]{r[0], r[4]}); pc = 1525; continue; }
case 1525: { r[4] = result; pc = 1526; continue; }
case 1526: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parentsAll([Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[4]}); pc = 1527; continue; }
case 1527: { r[4] = result; pc = 1528; continue; }
case 1528: { r[8] = Value.ref("sb_toast_on_skip_duration"); pc = 1529; continue; }
case 1529: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;-><init>(Ljava/lang/String;Ljava/lang/Enum;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[7], new Value[]{r[8], r[5], r[4]}); pc = 1530; continue; }
case 1530: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_TOAST_ON_SKIP_DURATION:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true, r[7]); pc = 1531; continue; }
case 1531: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1532; continue; }
case 1532: { r[5] = Value.ref("sb_toast_on_connection_error"); pc = 1533; continue; }
case 1533: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1534; continue; }
case 1534: { r[7] = result; pc = 1535; continue; }
case 1535: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[1], r[7]}); pc = 1536; continue; }
case 1536: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_TOAST_ON_CONNECTION_ERROR:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1537; continue; }
case 1537: { r[4] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1538; continue; }
case 1538: { r[5] = Value.ref("sb_track_skip_count"); pc = 1539; continue; }
case 1539: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1540; continue; }
case 1540: { r[7] = result; pc = 1541; continue; }
case 1541: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[4], new Value[]{r[5], r[1], r[7]}); pc = 1542; continue; }
case 1542: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_TRACK_SKIP_COUNT:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[4]); pc = 1543; continue; }
case 1543: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1544; continue; }
case 1544: { r[4] = Value.i32(0); pc = 1545; continue; }
case 1545: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;", Value.NULL, new Value[]{r[4]}); pc = 1546; continue; }
case 1546: { r[4] = result; pc = 1547; continue; }
case 1547: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1548; continue; }
case 1548: { r[5] = result; pc = 1549; continue; }
case 1549: { r[7] = Value.ref("sb_min_segment_duration"); pc = 1550; continue; }
case 1550: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[7], r[4], r[5]}); pc = 1551; continue; }
case 1551: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_SEGMENT_MIN_DURATION:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1552; continue; }
case 1552: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1553; continue; }
case 1553: { r[4] = Value.ref("sb_video_length_without_segments"); pc = 1554; continue; }
case 1554: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1555; continue; }
case 1555: { r[5] = result; pc = 1556; continue; }
case 1556: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[4], r[10], r[5]}); pc = 1557; continue; }
case 1557: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_VIDEO_LENGTH_WITHOUT_SEGMENTS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[1]); pc = 1558; continue; }
case 1558: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1559; continue; }
case 1559: { r[4] = Value.ref("https://sponsor.ajay.app"); pc = 1560; continue; }
case 1560: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1561; continue; }
case 1561: { r[5] = result; pc = 1562; continue; }
case 1562: { r[7] = Value.ref("sb_api_url"); pc = 1563; continue; }
case 1563: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[7], r[4], r[5]}); pc = 1564; continue; }
case 1564: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_API_URL:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1565; continue; }
case 1565: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1566; continue; }
case 1566: { r[4] = Value.ref("sb_user_is_vip"); pc = 1567; continue; }
case 1567: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[1], new Value[]{r[4], r[10]}); pc = 1568; continue; }
case 1568: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_USER_IS_VIP:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[1]); pc = 1569; continue; }
case 1569: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/IntegerSetting;"); pc = 1570; continue; }
case 1570: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[6]}); pc = 1571; continue; }
case 1571: { r[4] = result; pc = 1572; continue; }
case 1572: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1573; continue; }
case 1573: { r[5] = result; pc = 1574; continue; }
case 1574: { r[7] = Value.ref("sb_local_time_saved_number_segments"); pc = 1575; continue; }
case 1575: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/IntegerSetting;-><init>(Ljava/lang/String;Ljava/lang/Integer;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[7], r[4], r[5]}); pc = 1576; continue; }
case 1576: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_LOCAL_TIME_SAVED_NUMBER_SEGMENTS:Lapp/revanced/extension/shared/settings/IntegerSetting;", Value.NULL, true, r[1]); pc = 1577; continue; }
case 1577: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/LongSetting;"); pc = 1578; continue; }
case 1578: { r[4] = Value.i64(0L); r[5] = r[4]; pc = 1579; continue; }
case 1579: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;", Value.NULL, new Value[]{r[4]}); pc = 1580; continue; }
case 1580: { r[4] = result; pc = 1581; continue; }
case 1581: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1582; continue; }
case 1582: { r[5] = result; pc = 1583; continue; }
case 1583: { r[7] = Value.ref("sb_local_time_saved_milliseconds"); pc = 1584; continue; }
case 1584: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/LongSetting;-><init>(Ljava/lang/String;Ljava/lang/Long;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[7], r[4], r[5]}); pc = 1585; continue; }
case 1585: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_LOCAL_TIME_SAVED_MILLISECONDS:Lapp/revanced/extension/shared/settings/LongSetting;", Value.NULL, true, r[1]); pc = 1586; continue; }
case 1586: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/LongSetting;"); pc = 1587; continue; }
case 1587: { r[5] = Value.ref("sb_last_vip_check"); pc = 1588; continue; }
case 1588: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/LongSetting;-><init>(Ljava/lang/String;Ljava/lang/Long;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1589; continue; }
case 1589: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_LAST_VIP_CHECK:Lapp/revanced/extension/shared/settings/LongSetting;", Value.NULL, true, r[1]); pc = 1590; continue; }
case 1590: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1591; continue; }
case 1591: { r[4] = Value.ref("sb_hide_export_warning"); pc = 1592; continue; }
case 1592: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZZ)V", r[1], new Value[]{r[4], r[10], r[6], r[6]}); pc = 1593; continue; }
case 1593: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_HIDE_EXPORT_WARNING:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[1]); pc = 1594; continue; }
case 1594: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1595; continue; }
case 1595: { r[4] = Value.ref("sb_seen_guidelines"); pc = 1596; continue; }
case 1596: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZZ)V", r[1], new Value[]{r[4], r[10], r[6], r[6]}); pc = 1597; continue; }
case 1597: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_SEEN_GUIDELINES:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[1]); pc = 1598; continue; }
case 1598: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1599; continue; }
case 1599: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SKIP_AUTOMATICALLY_ONCE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 1600; continue; }
case 1600: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[4], false); pc = 1601; continue; }
case 1601: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1602; continue; }
case 1602: { r[5] = result; pc = 1603; continue; }
case 1603: { r[7] = Value.ref("sb_sponsor"); pc = 1604; continue; }
case 1604: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[7], r[4], r[5]}); pc = 1605; continue; }
case 1605: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SPONSOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1606; continue; }
case 1606: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1607; continue; }
case 1607: { r[4] = Value.ref("sb_sponsor_color"); pc = 1608; continue; }
case 1608: { r[5] = Value.ref("#CC00D400"); pc = 1609; continue; }
case 1609: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[4], r[5]}); pc = 1610; continue; }
case 1610: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SPONSOR_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1611; continue; }
case 1611: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1612; continue; }
case 1612: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->MANUAL_SKIP:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 1613; continue; }
case 1613: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[4], false); pc = 1614; continue; }
case 1614: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1615; continue; }
case 1615: { r[7] = result; pc = 1616; continue; }
case 1616: { r[8] = Value.ref("sb_selfpromo"); pc = 1617; continue; }
case 1617: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[8], r[5], r[7]}); pc = 1618; continue; }
case 1618: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SELF_PROMO:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1619; continue; }
case 1619: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1620; continue; }
case 1620: { r[5] = Value.ref("sb_selfpromo_color"); pc = 1621; continue; }
case 1621: { r[7] = Value.ref("#CCFFFF00"); pc = 1622; continue; }
case 1622: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[5], r[7]}); pc = 1623; continue; }
case 1623: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SELF_PROMO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1624; continue; }
case 1624: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1625; continue; }
case 1625: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[4], false); pc = 1626; continue; }
case 1626: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1627; continue; }
case 1627: { r[7] = result; pc = 1628; continue; }
case 1628: { r[8] = Value.ref("sb_interaction"); pc = 1629; continue; }
case 1629: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[8], r[5], r[7]}); pc = 1630; continue; }
case 1630: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTERACTION:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1631; continue; }
case 1631: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1632; continue; }
case 1632: { r[5] = Value.ref("sb_interaction_color"); pc = 1633; continue; }
case 1633: { r[7] = Value.ref("#CCCC00FF"); pc = 1634; continue; }
case 1634: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[5], r[7]}); pc = 1635; continue; }
case 1635: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTERACTION_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1636; continue; }
case 1636: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1637; continue; }
case 1637: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[4], false); pc = 1638; continue; }
case 1638: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1639; continue; }
case 1639: { r[7] = result; pc = 1640; continue; }
case 1640: { r[8] = Value.ref("sb_highlight"); pc = 1641; continue; }
case 1641: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[8], r[5], r[7]}); pc = 1642; continue; }
case 1642: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HIGHLIGHT:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1643; continue; }
case 1643: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1644; continue; }
case 1644: { r[5] = Value.ref("sb_highlight_color"); pc = 1645; continue; }
case 1645: { r[7] = Value.ref("#CCFF1684"); pc = 1646; continue; }
case 1646: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[5], r[7]}); pc = 1647; continue; }
case 1647: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HIGHLIGHT_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1648; continue; }
case 1648: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1649; continue; }
case 1649: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->IGNORE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 1650; continue; }
case 1650: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[5], false); pc = 1651; continue; }
case 1651: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1652; continue; }
case 1652: { r[8] = result; pc = 1653; continue; }
case 1653: { r[9] = Value.ref("sb_hook"); pc = 1654; continue; }
case 1654: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[9], r[7], r[8]}); pc = 1655; continue; }
case 1655: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HOOK:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1656; continue; }
case 1656: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1657; continue; }
case 1657: { r[7] = Value.ref("sb_hook_color"); pc = 1658; continue; }
case 1658: { r[8] = Value.ref("#CC395699"); pc = 1659; continue; }
case 1659: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[7], r[8]}); pc = 1660; continue; }
case 1660: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HOOK_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1661; continue; }
case 1661: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1662; continue; }
case 1662: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[4], false); pc = 1663; continue; }
case 1663: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1664; continue; }
case 1664: { r[8] = result; pc = 1665; continue; }
case 1665: { r[9] = Value.ref("sb_intro"); pc = 1666; continue; }
case 1666: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[9], r[7], r[8]}); pc = 1667; continue; }
case 1667: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTRO:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1668; continue; }
case 1668: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1669; continue; }
case 1669: { r[7] = Value.ref("sb_intro_color"); pc = 1670; continue; }
case 1670: { r[8] = Value.ref("#CC00FFFF"); pc = 1671; continue; }
case 1671: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[7], r[8]}); pc = 1672; continue; }
case 1672: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTRO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1673; continue; }
case 1673: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1674; continue; }
case 1674: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[4], false); pc = 1675; continue; }
case 1675: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1676; continue; }
case 1676: { r[8] = result; pc = 1677; continue; }
case 1677: { r[9] = Value.ref("sb_outro"); pc = 1678; continue; }
case 1678: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[9], r[7], r[8]}); pc = 1679; continue; }
case 1679: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_OUTRO:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1680; continue; }
case 1680: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1681; continue; }
case 1681: { r[7] = Value.ref("sb_outro_color"); pc = 1682; continue; }
case 1682: { r[8] = Value.ref("#CC0202ED"); pc = 1683; continue; }
case 1683: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[7], r[8]}); pc = 1684; continue; }
case 1684: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_OUTRO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1685; continue; }
case 1685: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1686; continue; }
case 1686: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[5], false); pc = 1687; continue; }
case 1687: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1688; continue; }
case 1688: { r[8] = result; pc = 1689; continue; }
case 1689: { r[9] = Value.ref("sb_preview"); pc = 1690; continue; }
case 1690: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[9], r[7], r[8]}); pc = 1691; continue; }
case 1691: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_PREVIEW:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1692; continue; }
case 1692: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1693; continue; }
case 1693: { r[7] = Value.ref("sb_preview_color"); pc = 1694; continue; }
case 1694: { r[8] = Value.ref("#CC008FD6"); pc = 1695; continue; }
case 1695: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[7], r[8]}); pc = 1696; continue; }
case 1696: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_PREVIEW_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1697; continue; }
case 1697: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1698; continue; }
case 1698: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[5], false); pc = 1699; continue; }
case 1699: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1700; continue; }
case 1700: { r[7] = result; pc = 1701; continue; }
case 1701: { r[8] = Value.ref("sb_filler"); pc = 1702; continue; }
case 1702: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[8], r[5], r[7]}); pc = 1703; continue; }
case 1703: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_FILLER:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1704; continue; }
case 1704: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1705; continue; }
case 1705: { r[5] = Value.ref("sb_filler_color"); pc = 1706; continue; }
case 1706: { r[7] = Value.ref("#CC7300FF"); pc = 1707; continue; }
case 1707: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[1], new Value[]{r[5], r[7]}); pc = 1708; continue; }
case 1708: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_FILLER_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1709; continue; }
case 1709: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1710; continue; }
case 1710: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[4], false); pc = 1711; continue; }
case 1711: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 1712; continue; }
case 1712: { r[0] = result; pc = 1713; continue; }
case 1713: { r[5] = Value.ref("sb_music_offtopic"); pc = 1714; continue; }
case 1714: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[5], r[4], r[0]}); pc = 1715; continue; }
case 1715: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_MUSIC_OFFTOPIC:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 1716; continue; }
case 1716: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1717; continue; }
case 1717: { r[1] = Value.ref("sb_music_offtopic_color"); pc = 1718; continue; }
case 1718: { r[4] = Value.ref("#CCFF9900"); pc = 1719; continue; }
case 1719: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[0], new Value[]{r[1], r[4]}); pc = 1720; continue; }
case 1720: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_MUSIC_OFFTOPIC_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[0]); pc = 1721; continue; }
case 1721: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1722; continue; }
case 1722: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SKIP_AUTOMATICALLY:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 1723; continue; }
case 1723: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[1], false); pc = 1724; continue; }
case 1724: { r[4] = Value.ref("sb_unsubmitted"); pc = 1725; continue; }
case 1725: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZZ)V", r[0], new Value[]{r[4], r[1], r[6], r[6]}); pc = 1726; continue; }
case 1726: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_UNSUBMITTED:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[0]); pc = 1727; continue; }
case 1727: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1728; continue; }
case 1728: { r[1] = Value.ref("sb_unsubmitted_color"); pc = 1729; continue; }
case 1729: { r[4] = Value.ref("#FFFFFFFF"); pc = 1730; continue; }
case 1730: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZZ)V", r[0], new Value[]{r[1], r[4], r[6], r[6]}); pc = 1731; continue; }
case 1731: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_UNSUBMITTED_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[0]); pc = 1732; continue; }
case 1732: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 1733; continue; }
case 1733: { r[1] = Value.ref("revanced_seekbar_custom_color_value"); pc = 1734; continue; }
case 1734: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;)V", r[0], new Value[]{r[1], r[14]}); pc = 1735; continue; }
case 1735: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SEEKBAR_CUSTOM_COLOR_PRIMARY:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[0]); pc = 1736; continue; }
case 1736: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1737; continue; }
case 1737: { r[4] = Value.i32(1061997773); pc = 1738; continue; }
case 1738: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;", Value.NULL, new Value[]{r[4]}); pc = 1739; continue; }
case 1739: { r[4] = result; pc = 1740; continue; }
case 1740: { r[5] = Value.ref("sb_sponsor_opacity"); pc = 1741; continue; }
case 1741: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1742; continue; }
case 1742: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_SPONSOR_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1743; continue; }
case 1743: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1744; continue; }
case 1744: { r[5] = Value.ref("sb_selfpromo_opacity"); pc = 1745; continue; }
case 1745: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1746; continue; }
case 1746: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_SELF_PROMO_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1747; continue; }
case 1747: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1748; continue; }
case 1748: { r[5] = Value.ref("sb_interaction_opacity"); pc = 1749; continue; }
case 1749: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1750; continue; }
case 1750: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_INTERACTION_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1751; continue; }
case 1751: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1752; continue; }
case 1752: { r[5] = Value.ref("sb_highlight_opacity"); pc = 1753; continue; }
case 1753: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1754; continue; }
case 1754: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_HIGHLIGHT_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1755; continue; }
case 1755: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1756; continue; }
case 1756: { r[5] = Value.ref("sb_hook_opacity"); pc = 1757; continue; }
case 1757: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1758; continue; }
case 1758: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_HOOK_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1759; continue; }
case 1759: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1760; continue; }
case 1760: { r[5] = Value.ref("sb_intro_opacity"); pc = 1761; continue; }
case 1761: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1762; continue; }
case 1762: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_INTRO_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1763; continue; }
case 1763: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1764; continue; }
case 1764: { r[5] = Value.ref("sb_outro_opacity"); pc = 1765; continue; }
case 1765: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1766; continue; }
case 1766: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_OUTRO_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1767; continue; }
case 1767: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1768; continue; }
case 1768: { r[5] = Value.ref("sb_preview_opacity"); pc = 1769; continue; }
case 1769: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1770; continue; }
case 1770: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_PREVIEW_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1771; continue; }
case 1771: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1772; continue; }
case 1772: { r[5] = Value.ref("sb_filler_opacity"); pc = 1773; continue; }
case 1773: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1774; continue; }
case 1774: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_FILLER_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1775; continue; }
case 1775: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/FloatSetting;"); pc = 1776; continue; }
case 1776: { r[5] = Value.ref("sb_music_offtopic_opacity"); pc = 1777; continue; }
case 1777: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;-><init>(Ljava/lang/String;Ljava/lang/Float;ZZ)V", r[1], new Value[]{r[5], r[4], r[6], r[6]}); pc = 1778; continue; }
case 1778: { rt.writeField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_MUSIC_OFFTOPIC_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true, r[1]); pc = 1779; continue; }
case 1779: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/VersionCheckPatch;->IS_20_37_OR_GREATER:Z", Value.NULL, true); pc = 1780; continue; }
case 1780: { pc = (ExecutableRuntime.equal(r[1], Value.i32(0))) ? 1790 : 1781; continue; }
case 1781: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->MINIPLAYER_TYPE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true); pc = 1782; continue; }
case 1782: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;", r[1], new Value[]{}); pc = 1783; continue; }
case 1783: { r[4] = result; pc = 1784; continue; }
case 1784: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;->TABLET:Lapp/revanced/extension/youtube/patches/MiniplayerPatch$MiniplayerType;", Value.NULL, true); pc = 1785; continue; }
case 1785: { pc = (!ExecutableRuntime.equal(r[4], r[5])) ? 1790 : 1786; continue; }
case 1786: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda0;"); pc = 1787; continue; }
case 1787: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda0;-><init>()V", r[4], new Value[]{}); pc = 1788; continue; }
case 1788: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;)V", Value.NULL, new Value[]{r[4]}); pc = 1789; continue; }
case 1789: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;->resetToDefault()Ljava/lang/Object;", r[1], new Value[]{}); pc = 1790; continue; }
case 1790: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->HEADER_LOGO:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true); pc = 1791; continue; }
case 1791: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;", r[1], new Value[]{}); pc = 1792; continue; }
case 1792: { r[4] = result; pc = 1793; continue; }
case 1793: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->REVANCED:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;", Value.NULL, true); pc = 1794; continue; }
case 1794: { pc = (!ExecutableRuntime.equal(r[4], r[5])) ? 1797 : 1795; continue; }
case 1795: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->ROUNDED:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;", Value.NULL, true); pc = 1796; continue; }
case 1796: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;->save(Ljava/lang/Object;)V", r[1], new Value[]{r[4]}); pc = 1797; continue; }
case 1797: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;", r[1], new Value[]{}); pc = 1798; continue; }
case 1798: { r[4] = result; pc = 1799; continue; }
case 1799: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->REVANCED_MINIMAL:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;", Value.NULL, true); pc = 1800; continue; }
case 1800: { pc = (!ExecutableRuntime.equal(r[4], r[5])) ? 1803 : 1801; continue; }
case 1801: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;->MINIMAL:Lapp/revanced/extension/youtube/patches/ChangeHeaderPatch$HeaderLogo;", Value.NULL, true); pc = 1802; continue; }
case 1802: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;->save(Ljava/lang/Object;)V", r[1], new Value[]{r[4]}); pc = 1803; continue; }
case 1803: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->isSetToDefault()Z", r[0], new Value[]{}); pc = 1804; continue; }
case 1804: { r[1] = result; pc = 1805; continue; }
case 1805: { pc = (!ExecutableRuntime.equal(r[1], Value.i32(0))) ? 1851 : 1806; continue; }
case 1806: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;", r[0], new Value[]{}); pc = 1807; continue; }
case 1807: { r[0] = result; pc = 1808; continue; }
case 1808: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I", Value.NULL, new Value[]{r[0]}); pc = 1809; continue; }
case 1809: { r[1] = result; pc = 1810; continue; }
case 1810: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->save(Ljava/lang/Object;)V", r[2], new Value[]{r[0]}); pc = 1811; continue; }
case 1811: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Landroid/graphics/Color;->red(I)I", Value.NULL, new Value[]{r[1]}); pc = 1812; continue; }
case 1812: { r[0] = result; pc = 1813; continue; }
case 1813: { r[0] = Value.f32((float)(r[0].i())); pc = 1814; continue; }
case 1814: { r[2] = Value.i32(1067869798); pc = 1815; continue; }
case 1815: { r[0] = Value.f32((r[0].f()) * (r[2].f())); pc = 1816; continue; }
case 1816: { r[0] = Value.i32((int)(r[0].f())); pc = 1817; continue; }
case 1817: { r[4] = Value.i32(255); pc = 1818; continue; }
case 1818: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Math;->min(II)I", Value.NULL, new Value[]{r[4], r[0]}); pc = 1819; continue; }
case 1819: { r[0] = result; pc = 1820; continue; }
case 1820: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Landroid/graphics/Color;->green(I)I", Value.NULL, new Value[]{r[1]}); pc = 1821; continue; }
case 1821: { r[5] = result; pc = 1822; continue; }
case 1822: { r[5] = Value.f32((float)(r[5].i())); pc = 1823; continue; }
case 1823: { r[5] = Value.f32((r[5].f()) * (r[2].f())); pc = 1824; continue; }
case 1824: { r[5] = Value.i32((int)(r[5].f())); pc = 1825; continue; }
case 1825: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Math;->min(II)I", Value.NULL, new Value[]{r[4], r[5]}); pc = 1826; continue; }
case 1826: { r[5] = result; pc = 1827; continue; }
case 1827: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Landroid/graphics/Color;->blue(I)I", Value.NULL, new Value[]{r[1]}); pc = 1828; continue; }
case 1828: { r[1] = result; pc = 1829; continue; }
case 1829: { r[1] = Value.f32((float)(r[1].i())); pc = 1830; continue; }
case 1830: { r[1] = Value.f32((r[1].f()) * (r[2].f())); pc = 1831; continue; }
case 1831: { r[1] = Value.i32((int)(r[1].f())); pc = 1832; continue; }
case 1832: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Math;->min(II)I", Value.NULL, new Value[]{r[4], r[1]}); pc = 1833; continue; }
case 1833: { r[1] = result; pc = 1834; continue; }
case 1834: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Landroid/graphics/Color;->argb(IIII)I", Value.NULL, new Value[]{r[6], r[0], r[5], r[1]}); pc = 1835; continue; }
case 1835: { r[0] = result; pc = 1836; continue; }
case 1836: { r[1] = Value.ref("#%06X"); pc = 1837; continue; }
case 1837: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[0]}); pc = 1838; continue; }
case 1838: { r[0] = result; pc = 1839; continue; }
case 1839: { result = rt.filledArray("[Ljava/lang/Object;", new Value[]{r[0]}); pc = 1840; continue; }
case 1840: { r[0] = result; pc = 1841; continue; }
case 1841: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;", Value.NULL, new Value[]{r[1], r[0]}); pc = 1842; continue; }
case 1842: { r[0] = result; pc = 1843; continue; }
case 1843: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->save(Ljava/lang/Object;)V", r[3], new Value[]{r[0]}); pc = 1844; continue; }
case 1844: { pc = 1849; continue; }
case 1845: { r[0] = Value.ref(exception); exception = null; pc = 1846; continue; }
case 1846: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda1;"); pc = 1847; continue; }
case 1847: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda1;-><init>()V", r[1], new Value[]{}); pc = 1848; continue; }
case 1848: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V", Value.NULL, new Value[]{r[1], r[0]}); pc = 1849; continue; }
case 1849: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SEEKBAR_CUSTOM_COLOR_PRIMARY:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1850; continue; }
case 1850: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->resetToDefault()Ljava/lang/Object;", r[0], new Value[]{}); pc = 1851; continue; }
case 1851: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_APP_VERSION_TARGET:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1852; continue; }
case 1852: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->isSetToDefault()Z", r[0], new Value[]{}); pc = 1853; continue; }
case 1853: { r[1] = result; pc = 1854; continue; }
case 1854: { pc = (!ExecutableRuntime.equal(r[1], Value.i32(0))) ? 1875 : 1855; continue; }
case 1855: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;", r[0], new Value[]{}); pc = 1856; continue; }
case 1856: { r[1] = result; pc = 1857; continue; }
case 1857: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/StringSetting;->defaultValue:Ljava/lang/Object;", r[0], false); pc = 1858; continue; }
case 1858: { r[2] = rt.cast(r[2], "Ljava/lang/String;"); pc = 1859; continue; }
case 1859: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/String;->compareTo(Ljava/lang/String;)I", r[1], new Value[]{r[2]}); pc = 1860; continue; }
case 1860: { r[1] = result; pc = 1861; continue; }
case 1861: { pc = (r[1].i() < 0) ? 1869 : 1862; continue; }
case 1862: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/Utils;->getAppVersionName()Ljava/lang/String;", Value.NULL, new Value[]{}); pc = 1863; continue; }
case 1863: { r[1] = result; pc = 1864; continue; }
case 1864: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;", r[0], new Value[]{}); pc = 1865; continue; }
case 1865: { r[2] = result; pc = 1866; continue; }
case 1866: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/String;->compareTo(Ljava/lang/String;)I", r[1], new Value[]{r[2]}); pc = 1867; continue; }
case 1867: { r[1] = result; pc = 1868; continue; }
case 1868: { pc = (r[1].i() > 0) ? 1875 : 1869; continue; }
case 1869: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda2;"); pc = 1870; continue; }
case 1870: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda2;-><init>()V", r[1], new Value[]{}); pc = 1871; continue; }
case 1871: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;)V", Value.NULL, new Value[]{r[1]}); pc = 1872; continue; }
case 1872: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->resetToDefault()Ljava/lang/Object;", r[0], new Value[]{}); pc = 1873; continue; }
case 1873: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_APP_VERSION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true); pc = 1874; continue; }
case 1874: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;->resetToDefault()Ljava/lang/Object;", r[1], new Value[]{}); pc = 1875; continue; }
case 1875: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->SETTINGS_DISABLE_BOLD_ICONS:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true); pc = 1876; continue; }
case 1876: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;", r[1], new Value[]{}); pc = 1877; continue; }
case 1877: { r[2] = result; pc = 1878; continue; }
case 1878: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Boolean;->booleanValue()Z", r[2], new Value[]{}); pc = 1879; continue; }
case 1879: { r[2] = result; pc = 1880; continue; }
case 1880: { pc = (!ExecutableRuntime.equal(r[2], Value.i32(0))) ? 1898 : 1881; continue; }
case 1881: { r[2] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_APP_VERSION:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true); pc = 1882; continue; }
case 1882: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;", r[2], new Value[]{}); pc = 1883; continue; }
case 1883: { r[2] = result; pc = 1884; continue; }
case 1884: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Boolean;->booleanValue()Z", r[2], new Value[]{}); pc = 1885; continue; }
case 1885: { r[2] = result; pc = 1886; continue; }
case 1886: { pc = (ExecutableRuntime.equal(r[2], Value.i32(0))) ? 1898 : 1887; continue; }
case 1887: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;", r[0], new Value[]{}); pc = 1888; continue; }
case 1888: { r[0] = result; pc = 1889; continue; }
case 1889: { r[2] = Value.ref("19.35.00"); pc = 1890; continue; }
case 1890: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/String;->compareTo(Ljava/lang/String;)I", r[0], new Value[]{r[2]}); pc = 1891; continue; }
case 1891: { r[0] = result; pc = 1892; continue; }
case 1892: { pc = (r[0].i() > 0) ? 1898 : 1893; continue; }
case 1893: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda3;"); pc = 1894; continue; }
case 1894: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda3;-><init>()V", r[0], new Value[]{}); pc = 1895; continue; }
case 1895: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;)V", Value.NULL, new Value[]{r[0]}); pc = 1896; continue; }
case 1896: { r[0] = rt.readField("Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;", Value.NULL, true); pc = 1897; continue; }
case 1897: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;->privateSetValue(Lapp/revanced/extension/shared/settings/BooleanSetting;Ljava/lang/Boolean;)V", Value.NULL, new Value[]{r[1], r[0]}); pc = 1898; continue; }
case 1898: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_VIDEO_STREAMS_CLIENT_TYPE:Lapp/revanced/extension/shared/settings/EnumSetting;", Value.NULL, true); pc = 1899; continue; }
case 1899: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;", r[0], new Value[]{}); pc = 1900; continue; }
case 1900: { r[1] = result; pc = 1901; continue; }
case 1901: { r[2] = rt.readField("Lapp/revanced/extension/shared/spoof/ClientType;->ANDROID_VR_1_61_48:Lapp/revanced/extension/shared/spoof/ClientType;", Value.NULL, true); pc = 1902; continue; }
case 1902: { pc = (!ExecutableRuntime.equal(r[1], r[2])) ? 1904 : 1903; continue; }
case 1903: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/EnumSetting;->resetToDefault()Ljava/lang/Object;", r[0], new Value[]{}); pc = 1904; continue; }
case 1904: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SPONSOR_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1905; continue; }
case 1905: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_SPONSOR_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1906; continue; }
case 1906: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1907; continue; }
case 1907: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_SELF_PROMO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1908; continue; }
case 1908: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_SELF_PROMO_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1909; continue; }
case 1909: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1910; continue; }
case 1910: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTERACTION_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1911; continue; }
case 1911: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_INTERACTION_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1912; continue; }
case 1912: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1913; continue; }
case 1913: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HIGHLIGHT_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1914; continue; }
case 1914: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_HIGHLIGHT_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1915; continue; }
case 1915: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1916; continue; }
case 1916: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_HOOK_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1917; continue; }
case 1917: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_HOOK_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1918; continue; }
case 1918: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1919; continue; }
case 1919: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_INTRO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1920; continue; }
case 1920: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_INTRO_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1921; continue; }
case 1921: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1922; continue; }
case 1922: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_OUTRO_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1923; continue; }
case 1923: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_OUTRO_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1924; continue; }
case 1924: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1925; continue; }
case 1925: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_PREVIEW_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1926; continue; }
case 1926: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_PREVIEW_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1927; continue; }
case 1927: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1928; continue; }
case 1928: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_FILLER_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1929; continue; }
case 1929: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_FILLER_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1930; continue; }
case 1930: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1931; continue; }
case 1931: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_CATEGORY_MUSIC_OFFTOPIC_COLOR:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true); pc = 1932; continue; }
case 1932: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->DEPRECATED_SB_CATEGORY_MUSIC_OFFTOPIC_OPACITY:Lapp/revanced/extension/shared/settings/FloatSetting;", Value.NULL, true); pc = 1933; continue; }
case 1933: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/settings/Settings;->applyOldSbOpacityToColor(Lapp/revanced/extension/shared/settings/StringSetting;Lapp/revanced/extension/shared/settings/FloatSetting;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 1934; continue; }
case 1934: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;->SB_IMPORT_EXPORT_CALLBACK:Lapp/revanced/extension/shared/settings/Setting$ImportExportCallback;", Value.NULL, true); pc = 1935; continue; }
case 1935: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/Setting;->addImportExportCallback(Lapp/revanced/extension/shared/settings/Setting$ImportExportCallback;)V", Value.NULL, new Value[]{r[0]}); pc = 1936; continue; }
case 1936: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 1806 && pc < 1844) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=1845; continue; } }
throw error;
}
}

}

static Value m_93996883aa8bc58583dececb(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[3] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/StringSetting;");
r[4] = rt.check(arguments[1], "Lapp/revanced/extension/shared/settings/FloatSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;", r[3], new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/String;->length()I", r[0], new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { r[2] = Value.i32(8); pc = 5; continue; }
case 5: { pc = (r[1].i() < r[2].i()) ? 7 : 6; continue; }
case 6: { return Value.VOID; }
case 7: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/FloatSetting;->get()Ljava/lang/Float;", r[4], new Value[]{}); pc = 8; continue; }
case 8: { r[4] = result; pc = 9; continue; }
case 9: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Ljava/lang/Float;->floatValue()F", r[4], new Value[]{}); pc = 10; continue; }
case 10: { r[4] = result; pc = 11; continue; }
case 11: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;->migrateOldColorString(Ljava/lang/String;F)Ljava/lang/String;", Value.NULL, new Value[]{r[0], r[4]}); pc = 12; continue; }
case 12: { r[4] = result; pc = 13; continue; }
case 13: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/settings/Settings;", "Lapp/revanced/extension/shared/settings/StringSetting;->save(Ljava/lang/Object;)V", r[3], new Value[]{r[4]}); pc = 14; continue; }
case 14: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_28ae463aa59ad0846cac72a1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Temporarily disabling bold icons that don't work with old spoof targets"); pc = 1; continue; }
case 1: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0e16881d95c439de66619435(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Resetting miniplayer tablet type"); pc = 1; continue; }
case 1: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_54da4f3daebd86e929fdb4e2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Could not parse old seekbar color"); pc = 1; continue; }
case 1: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e34bc5576a6dff431abf0a09(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Resetting spoof app version"); pc = 1; continue; }
case 1: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
