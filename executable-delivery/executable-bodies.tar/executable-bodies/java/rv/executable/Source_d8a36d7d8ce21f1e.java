package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_d8a36d7d8ce21f1e extends RuntimeForeign.SourceProxy {
Source_d8a36d7d8ce21f1e(RuntimeForeign owner,Instance source){super(owner,source);}

}
