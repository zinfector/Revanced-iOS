package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_55d067a69690dae1d1dc {
static ClassInfo info_55d067a69690dae1d1dc() {return new ClassInfo("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory$$ExternalSyntheticLambda1;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SharedPrefCategory$$ExternalSyntheticLambda1");}
}
