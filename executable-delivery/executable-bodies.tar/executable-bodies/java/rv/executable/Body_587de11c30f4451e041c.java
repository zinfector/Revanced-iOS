package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_587de11c30f4451e041c {
static Value m_f50b419eb5a5a76a3a4ef891(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$1;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$1;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;->SB_IMPORT_EXPORT_CALLBACK:Lapp/revanced/extension/shared/settings/Setting$ImportExportCallback;",Value.NULL,true,r[0]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9150dd17725188260ead2549(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[3] = rt.check(arguments[0], "Ljava/lang/String;");
r[4] = rt.check(arguments[1], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/String;->length()I",r[3],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = Value.i32(8); pc = 3; continue; }
case 3: { pc=(r[0].i() < r[1].i())?5:4; continue; }
case 4: { return rt.check(r[3],"Ljava/lang/String;"); }
case 5: { r[0] = Value.ref("#"); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/String;->startsWith(Ljava/lang/String;)Z",r[3],new Value[]{r[0]}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?12:9; continue; }
case 9: { r[1] = Value.i32(1); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/String;->substring(I)Ljava/lang/String;",r[3],new Value[]{r[1]}); pc = 11; continue; }
case 11: { r[3] = result; pc = 12; continue; }
case 12: { r[1] = rt.readField("Ljava/util/Locale;->US:Ljava/util/Locale;",Value.NULL,true); pc = 13; continue; }
case 13: { r[2] = Value.i32(1132396544); pc = 14; continue; }
case 14: { r[4] = Value.f32((r[4].f()) * (r[2].f())); pc = 15; continue; }
case 15: { r[4] = Value.i32((int)(r[4].f())); pc = 16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[4]}); pc = 17; continue; }
case 17: { r[4] = result; pc = 18; continue; }
case 18: { result=rt.filledArray("[Ljava/lang/Object;",new Value[]{r[4]}); pc = 19; continue; }
case 19: { r[4] = result; pc = 20; continue; }
case 20: { r[2] = Value.ref("%02X"); pc = 21; continue; }
case 21: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[1], r[2], r[4]}); pc = 22; continue; }
case 22: { r[4] = result; pc = 23; continue; }
case 23: { r[1] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 24; continue; }
case 24: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[0]}); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[4]}); pc = 26; continue; }
case 26: { r[4] = Value.i32(0); pc = 27; continue; }
case 27: { r[0] = Value.i32(6); pc = 28; continue; }
case 28: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/String;->substring(II)Ljava/lang/String;",r[3],new Value[]{r[4], r[0]}); pc = 29; continue; }
case 29: { r[3] = result; pc = 30; continue; }
case 30: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[3]}); pc = 31; continue; }
case 31: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[1],new Value[]{}); pc = 32; continue; }
case 32: { r[3] = result; pc = 33; continue; }
case 33: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$$ExternalSyntheticLambda5;"); pc = 34; continue; }
case 34: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$$ExternalSyntheticLambda5;-><init>(Ljava/lang/String;)V",r[4],new Value[]{r[3]}); pc = 35; continue; }
case 35: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[4]}); pc = 36; continue; }
case 36: { return rt.check(r[3],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8eba57d807c6a09c6720622d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Migrating old color string with default opacity: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
