package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_367790c6d20210ec68d2 {
static Value m_bc0e1d9ba0309dcfa0f3d565(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("ONE_SECOND"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { r[3] = Value.i32(1); pc = 4; continue; }
case 4: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->ONE_SECOND:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 6; continue; }
case 6: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 7; continue; }
case 7: { r[1] = Value.ref("TWO_SECONDS"); pc = 8; continue; }
case 8: { r[2] = Value.i32(2); pc = 9; continue; }
case 9: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[3], r[2]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->TWO_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 11; continue; }
case 11: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 12; continue; }
case 12: { r[1] = Value.ref("THREE_SECONDS"); pc = 13; continue; }
case 13: { r[3] = Value.i32(3); pc = 14; continue; }
case 14: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->THREE_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 16; continue; }
case 16: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 17; continue; }
case 17: { r[1] = Value.ref("FOUR_SECONDS"); pc = 18; continue; }
case 18: { r[2] = Value.i32(4); pc = 19; continue; }
case 19: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[3], r[2]}); pc = 20; continue; }
case 20: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->FOUR_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 21; continue; }
case 21: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 22; continue; }
case 22: { r[1] = Value.ref("FIVE_SECONDS"); pc = 23; continue; }
case 23: { r[3] = Value.i32(5); pc = 24; continue; }
case 24: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 25; continue; }
case 25: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->FIVE_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 26; continue; }
case 26: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 27; continue; }
case 27: { r[1] = Value.ref("SIX_SECONDS"); pc = 28; continue; }
case 28: { r[2] = Value.i32(6); pc = 29; continue; }
case 29: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[3], r[2]}); pc = 30; continue; }
case 30: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->SIX_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 31; continue; }
case 31: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 32; continue; }
case 32: { r[1] = Value.ref("SEVEN_SECONDS"); pc = 33; continue; }
case 33: { r[3] = Value.i32(7); pc = 34; continue; }
case 34: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 35; continue; }
case 35: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->SEVEN_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 36; continue; }
case 36: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 37; continue; }
case 37: { r[1] = Value.ref("EIGHT_SECONDS"); pc = 38; continue; }
case 38: { r[2] = Value.i32(8); pc = 39; continue; }
case 39: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[3], r[2]}); pc = 40; continue; }
case 40: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->EIGHT_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 41; continue; }
case 41: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 42; continue; }
case 42: { r[1] = Value.ref("NINE_SECONDS"); pc = 43; continue; }
case 43: { r[3] = Value.i32(9); pc = 44; continue; }
case 44: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[2], r[3]}); pc = 45; continue; }
case 45: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->NINE_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 46; continue; }
case 46: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); pc = 47; continue; }
case 47: { r[1] = Value.ref("TEN_SECONDS"); pc = 48; continue; }
case 48: { r[2] = Value.i32(10); pc = 49; continue; }
case 49: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;-><init>(Ljava/lang/String;II)V", r[0], new Value[]{r[1], r[3], r[2]}); pc = 50; continue; }
case 50: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->TEN_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 51; continue; }
case 51: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->$values()[Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, new Value[]{}); pc = 52; continue; }
case 52: { r[0] = result; pc = 53; continue; }
case 53: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->$VALUES:[Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true, r[0]); pc = 54; continue; }
case 54: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_086cee3c1f386c191427c112(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[2] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;");
r[3] = rt.check(arguments[0], "Ljava/lang/String;");
r[4] = rt.check(arguments[1], "I");
r[5] = rt.check(arguments[2], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[2], new Value[]{r[3], r[4]}); pc = 1; continue; }
case 1: { r[3] = Value.i64((long)(r[5].i())); r[4] = r[3]; pc = 2; continue; }
case 2: { r[0] = Value.i64(1000L); r[1] = r[0]; pc = 3; continue; }
case 3: { r[3] = Value.i64((r[3].j()) * (r[0].j())); r[4] = r[3]; pc = 4; continue; }
case 4: { r[0] = Value.i64(200L); r[1] = r[0]; pc = 5; continue; }
case 5: { r[3] = Value.i64((r[3].j()) - (r[0].j())); r[4] = r[3]; pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->adjustedDuration:J", r[2], false, r[3]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_85cf202df640c31c813f9d2f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[10];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->ONE_SECOND:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->TWO_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->THREE_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->FOUR_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->FIVE_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->SIX_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 6; continue; }
case 6: { r[6] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->SEVEN_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 7; continue; }
case 7: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->EIGHT_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 8; continue; }
case 8: { r[8] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->NINE_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 9; continue; }
case 9: { r[9] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;->TEN_SECONDS:Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", Value.NULL, true); pc = 10; continue; }
case 10: { result = rt.filledArray("[Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;", new Value[]{r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$SponsorBlockDuration;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
