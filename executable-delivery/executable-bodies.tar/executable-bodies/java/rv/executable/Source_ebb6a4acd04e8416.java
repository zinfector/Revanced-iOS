package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_ebb6a4acd04e8416 extends RuntimeForeign.SourceProxy {
Source_ebb6a4acd04e8416(RuntimeForeign owner,Instance source){super(owner,source);}

}
