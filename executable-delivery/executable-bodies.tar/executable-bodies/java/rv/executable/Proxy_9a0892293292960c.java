package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_9a0892293292960c extends RuntimeForeign.SourceProxy implements java.lang.AutoCloseable {
Proxy_9a0892293292960c(RuntimeForeign owner,Instance source){super(owner,source);}
public void close() {Value result=owner.callback(source,"Ljava/lang/AutoCloseable;->close()V",new Value[]{}); return;}
}
