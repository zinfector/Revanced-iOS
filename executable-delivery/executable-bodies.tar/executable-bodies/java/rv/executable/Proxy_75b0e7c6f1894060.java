package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_75b0e7c6f1894060 extends RuntimeForeign.SourceProxy implements java.lang.CharSequence {
Proxy_75b0e7c6f1894060(RuntimeForeign owner,Instance source){super(owner,source);}
public int length() {Value result=owner.callback(source,"Ljava/lang/CharSequence;->length()I",new Value[]{}); return result.i();}
public char charAt(int a0) {Value result=owner.callback(source,"Ljava/lang/CharSequence;->charAt(I)C",new Value[]{Value.i32(a0)}); return (char)result.i();}
public java.lang.CharSequence subSequence(int a0,int a1) {Value result=owner.callback(source,"Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;",new Value[]{Value.i32(a0),Value.i32(a1)}); return (java.lang.CharSequence)owner.exportObject(result.o(),"Ljava/lang/CharSequence;");}
public java.lang.String toString() {Value result=owner.callback(source,"Ljava/lang/CharSequence;->toString()Ljava/lang/String;",new Value[]{}); return (java.lang.String)owner.exportObject(result.o(),"Ljava/lang/String;");}
}
