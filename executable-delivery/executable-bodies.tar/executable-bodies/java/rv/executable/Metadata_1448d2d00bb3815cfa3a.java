package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_1448d2d00bb3815cfa3a {
static ClassInfo info_1448d2d00bb3815cfa3a() {return new ClassInfo("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;", "Ljava/lang/Object;", new String[]{"Lkotlin/jvm/functions/Function1;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda2;->f$0:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;", "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;)V", 69633), new MethodInfo("invoke(Ljava/lang/Object;)Ljava/lang/Object;", 17)}, "PlayerControlButton$$ExternalSyntheticLambda2");}
}
