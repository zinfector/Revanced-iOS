package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_3990c6295d5270876521 {
static Value m_34acd566c7b1a59b612c07f1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticLambda12;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticLambda12;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ec9e49800ca9b822204f355b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticLambda12;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticLambda12;","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment;->$r8$lambda$w8HVenrWPuEECpwrlnzWRZ9XHIA()Ljava/lang/String;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
