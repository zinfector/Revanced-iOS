package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_97da4066bd739fb2 extends RuntimeForeign.SourceProxy {
Source_97da4066bd739fb2(RuntimeForeign owner,Instance source){super(owner,source);}

}
