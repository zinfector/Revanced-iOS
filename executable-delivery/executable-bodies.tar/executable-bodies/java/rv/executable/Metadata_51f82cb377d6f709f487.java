package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_51f82cb377d6f709f487 {
static ClassInfo info_51f82cb377d6f709f487() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda21;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda21;->f$0:I", "I", 4113, ExecutableRuntime.zero("I"))}, new MethodInfo[]{new MethodInfo("<init>(I)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "Utils$$ExternalSyntheticLambda21");}
}
