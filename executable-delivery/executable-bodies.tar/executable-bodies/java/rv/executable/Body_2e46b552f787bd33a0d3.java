package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_2e46b552f787bd33a0d3 {
static Value m_210baf20dad5755a0779ddb1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/VideoState;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;->f$0:Lapp/revanced/extension/youtube/shared/VideoState;",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f4f3c94d9a05de18912c5c5d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;->f$0:Lapp/revanced/extension/youtube/shared/VideoState;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/shared/VideoState$Companion$$ExternalSyntheticLambda1;","Lapp/revanced/extension/youtube/shared/VideoState$Companion;->$r8$lambda$5XkDzp09vtuF9JiLqs2gTyr19ns(Lapp/revanced/extension/youtube/shared/VideoState;)Ljava/lang/String;",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
