package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8358a9acddafe172df7b {
static ClassInfo info_8358a9acddafe172df7b() {return new ClassInfo("Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda3;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/settings/BaseActivityHook$$ExternalSyntheticLambda3;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "BaseActivityHook$$ExternalSyntheticLambda3");}
}
