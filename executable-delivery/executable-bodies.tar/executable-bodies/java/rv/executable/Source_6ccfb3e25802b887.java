package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_6ccfb3e25802b887 extends RuntimeForeign.SourceProxy {
Source_6ccfb3e25802b887(RuntimeForeign owner,Instance source){super(owner,source);}

}
