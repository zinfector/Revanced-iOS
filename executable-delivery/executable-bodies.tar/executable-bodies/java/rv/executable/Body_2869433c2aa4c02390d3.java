package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_2869433c2aa4c02390d3 {
static Value m_4a1e49682d10d4d84835c0b9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 5) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;");
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;");
r[2] = rt.check(arguments[1], "Landroid/content/Context;");
r[3] = rt.check(arguments[2], "Landroid/widget/LinearLayout;");
r[4] = rt.check(arguments[3], "Ljava/util/Collection;");
r[5] = rt.check(arguments[4], "Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$OnSelectHistoryItemListener;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;->this$0:Lapp/revanced/extension/shared/settings/search/SearchHistoryManager;",r[0],false,r[1]); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;->history:Ljava/util/Collection;",r[0],false,r[4]); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;","Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;",Value.NULL,new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;->inflater:Landroid/view/LayoutInflater;",r[0],false,r[1]); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;->container:Landroid/widget/LinearLayout;",r[0],false,r[3]); pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$SearchHistoryAdapter;->onSelectHistoryItemListener:Lapp/revanced/extension/shared/settings/search/SearchHistoryManager$OnSelectHistoryItemListener;",r[0],false,r[5]); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
