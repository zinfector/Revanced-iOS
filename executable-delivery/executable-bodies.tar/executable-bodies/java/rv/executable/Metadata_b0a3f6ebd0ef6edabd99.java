package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_b0a3f6ebd0ef6edabd99 {
static ClassInfo info_b0a3f6ebd0ef6edabd99() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;", "Ljava/lang/Object;", new String[]{"Ljava/lang/Runnable;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;")), new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;->f$1:I", "I", 4113, ExecutableRuntime.zero("I"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;I)V", 69633), new MethodInfo("run()V", 17)});}
}
