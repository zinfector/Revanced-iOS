package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_88da2bc72225ddefc97e {
static ClassInfo info_88da2bc72225ddefc97e() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda42;", "Ljava/lang/Object;", new String[]{"Ljava/util/function/Predicate;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda42;->f$0:J", "J", 4113, ExecutableRuntime.zero("J"))}, new MethodInfo[]{new MethodInfo("<init>(J)V", 69633), new MethodInfo("test(Ljava/lang/Object;)Z", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda42");}
}
