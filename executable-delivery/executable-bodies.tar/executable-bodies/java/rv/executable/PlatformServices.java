package rv.executable;

import java.util.Map;

/** Reviewed services, independent of any patch. No service enables a feature. */
public interface PlatformServices {
    String preference(String namespace,String key);
    boolean commitPreferences(String namespace,Map<String,String> changes);
    int log(int level,String tag,String message,Throwable error);
    boolean isMainThread();
    boolean postMain(Runnable task,long delayMillis);
    String metadata(String key);
    int resourceIdentifier(String name,String type,String packageName);
    String resourceString(int identifier);
    void toast(String message,int duration);
}
