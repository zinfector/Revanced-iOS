package rv.executable;

import java.util.Map;
import java.util.Objects;

/** Reviewed services, independent of any patch. No service enables a feature. */
public interface PlatformServices {
    String preference(String namespace,String key);
    boolean commitPreferences(String namespace,Map<String,String> changes);
    int log(int level,String tag,String message,Throwable error);
    boolean isMainThread();
    boolean postMain(Runnable task,long delayMillis);
    String metadata(String key);
    int resourceIdentifier(String name,String type,String packageName);
    String resourceString(int identifier);
    default String resourceString(int identifier,String locale) {
        if(Objects.equals(metadata("source.locale"),locale))return resourceString(identifier);
        throw new ExecutableRuntime.MissingOperation("localized-resource:"+locale+":"+identifier);
    }
    default int resourceColor(int identifier) { throw new ExecutableRuntime.MissingOperation("resource-color:"+identifier); }
    void toast(String message,int duration);
}
