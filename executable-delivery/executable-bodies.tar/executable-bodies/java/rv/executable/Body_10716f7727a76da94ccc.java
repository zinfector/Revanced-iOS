package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_10716f7727a76da94ccc {
static Value m_4f36f33f81e3e91c3a3cdcd9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
r[8] = rt.check(arguments[0], "Landroid/view/ViewGroup;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda3;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda3;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideAll()V",Value.NULL,new Value[]{}); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { r[2] = rt.allocate("Landroid/widget/RelativeLayout;"); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V",r[2],new Value[]{r[0]}); pc = 8; continue; }
case 8: { r[1] = rt.allocate("Landroid/widget/RelativeLayout$LayoutParams;"); pc = 9; continue; }
case 9: { r[3] = Value.i32(-1); pc = 10; continue; }
case 10: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V",r[1],new Value[]{r[3], r[3]}); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V",r[2],new Value[]{r[1]}); pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;",Value.NULL,new Value[]{r[0]}); pc = 13; continue; }
case 13: { r[0] = result; pc = 14; continue; }
case 14: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->LAYOUT:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 15; continue; }
case 15: { r[3] = Value.ref("revanced_sb_inline_sponsor_overlay"); pc = 16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[1], r[3]}); pc = 17; continue; }
case 17: { r[1] = result; pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;",r[0],new Value[]{r[1], r[2]}); pc = 19; continue; }
case 19: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 20; continue; }
case 20: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[2]}); pc = 21; continue; }
case 21: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->inlineSponsorOverlayRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 22; continue; }
case 22: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/ViewGroup;->addView(Landroid/view/View;)V",r[8],new Value[]{r[2]}); pc = 23; continue; }
case 23: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$1;"); pc = 24; continue; }
case 24: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$1;-><init>()V",r[0],new Value[]{}); pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/ViewGroup;->setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V",r[8],new Value[]{r[0]}); pc = 26; continue; }
case 26: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 27; continue; }
case 27: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[8]}); pc = 28; continue; }
case 28: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->youtubeOverlaysLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 29; continue; }
case 29: { r[8] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 30; continue; }
case 30: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ID:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 31; continue; }
case 31: { r[1] = Value.ref("revanced_sb_skip_highlight_button"); pc = 32; continue; }
case 32: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifier(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 33; continue; }
case 33: { r[1] = result; pc = 34; continue; }
case 34: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->findViewById(I)Landroid/view/View;",r[2],new Value[]{r[1]}); pc = 35; continue; }
case 35: { r[1] = result; pc = 36; continue; }
case 36: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 37; continue; }
case 37: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[1]}); pc = 38; continue; }
case 38: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[8],new Value[]{r[1]}); pc = 39; continue; }
case 39: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlightButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[8]); pc = 40; continue; }
case 40: { r[8] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 41; continue; }
case 41: { r[1] = Value.ref("revanced_sb_skip_sponsor_button"); pc = 42; continue; }
case 42: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifier(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 43; continue; }
case 43: { r[1] = result; pc = 44; continue; }
case 44: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->findViewById(I)Landroid/view/View;",r[2],new Value[]{r[1]}); pc = 45; continue; }
case 45: { r[1] = result; pc = 46; continue; }
case 46: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 47; continue; }
case 47: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[1]}); pc = 48; continue; }
case 48: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[8],new Value[]{r[1]}); pc = 49; continue; }
case 49: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSponsorButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[8]); pc = 50; continue; }
case 50: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;"); pc = 51; continue; }
case 51: { r[3] = Value.ref("revanced_sb_skip_sponsor_button"); pc = 52; continue; }
case 52: { r[5] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda4;"); pc = 53; continue; }
case 53: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda4;-><init>()V",r[5],new Value[]{}); pc = 54; continue; }
case 54: { r[6] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda5;"); pc = 55; continue; }
case 55: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda5;-><init>()V",r[6],new Value[]{}); pc = 56; continue; }
case 56: { r[7] = Value.i32(0); pc = 57; continue; }
case 57: { r[4] = Value.i32(0); pc = 58; continue; }
case 58: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;-><init>(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$PlayerControlButtonStatus;Landroid/view/View$OnClickListener;Landroid/view/View$OnLongClickListener;)V",r[1],new Value[]{r[2], r[3], r[4], r[5], r[6], r[7]}); pc = 59; continue; }
case 59: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSponsorPlayerButton:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true,r[1]); pc = 60; continue; }
case 60: { r[8] = Value.ref("revanced_sb_new_segment_view"); pc = 61; continue; }
case 61: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifier(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[8]}); pc = 62; continue; }
case 62: { r[8] = result; pc = 63; continue; }
case 63: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->findViewById(I)Landroid/view/View;",r[2],new Value[]{r[8]}); pc = 64; continue; }
case 64: { r[8] = result; pc = 65; continue; }
case 65: { r[8] = rt.cast(r[8],"Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;"); pc = 66; continue; }
case 66: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[8]}); pc = 67; continue; }
case 67: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 68; continue; }
case 68: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[8]}); pc = 69; continue; }
case 69: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 70; continue; }
case 70: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;->updateLayout()V",r[8],new Value[]{}); pc = 71; continue; }
case 71: { r[8] = Value.i32(0); pc = 72; continue; }
case 72: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutVisible:Z",Value.NULL,true,r[8]); pc = 73; continue; }
case 73: { r[8] = Value.i32(0); pc = 74; continue; }
case 74: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlight:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[8]); pc = 75; continue; }
case 75: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[8]); pc = 76; continue; }
case 76: { return Value.VOID; }
case 77: { r[0] = Value.ref(exception); exception=null; pc = 78; continue; }
case 78: { r[8] = r[0]; pc = 79; continue; }
case 79: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda6;"); pc = 80; continue; }
case 80: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda6;-><init>()V",r[0],new Value[]{}); pc = 81; continue; }
case 81: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[8]}); pc = 82; continue; }
case 82: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 76) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=77; continue; } }
throw error;
}
}

}

static Value m_97c67d73230b7d5c80858032(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[0];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideSkipHighlightButton()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideSkipSegmentButton()V",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->hideNewSegmentLayout()V",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_36c153cdc60fbac3d1880739(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlight:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[0]); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlightButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[1],new Value[]{}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 6; continue; }
case 6: { r[2] = Value.i32(0); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->updateSkipButton(Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;ZLapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;Z)V",Value.NULL,new Value[]{r[1], r[2], r[0], r[2]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a90eb2e3ce02583ea722e731(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[3]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlight:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[3]); pc = 2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;"); pc = 6; continue; }
case 6: { r[1] = Value.i32(0); pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?14:8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->getVisibility()I",r[0],new Value[]{}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?12:11; continue; }
case 11: { pc=14; continue; }
case 12: { r[0] = r[1]; pc = 13; continue; }
case 13: { pc=15; continue; }
case 14: { r[0] = Value.i32(1); pc = 15; continue; }
case 15: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlightButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 16; continue; }
case 16: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[2],new Value[]{}); pc = 17; continue; }
case 17: { r[2] = result; pc = 18; continue; }
case 18: { r[2] = rt.cast(r[2],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->updateSkipButton(Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;ZLapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;Z)V",Value.NULL,new Value[]{r[2], r[1], r[3], r[0]}); pc = 20; continue; }
case 20: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_16d3d5328754fc82567d4916(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_AUTO_HIDE_SKIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[1] = Value.i32(0); pc = 6; continue; }
case 6: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?8:7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[1]); pc = 8; continue; }
case 8: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSponsorButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[0],new Value[]{}); pc = 10; continue; }
case 10: { r[0] = result; pc = 11; continue; }
case 11: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 12; continue; }
case 12: { r[2] = Value.i32(1); pc = 13; continue; }
case 13: { r[3] = Value.i32(0); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->updateSkipButton(Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;ZLapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;Z)V",Value.NULL,new Value[]{r[0], r[2], r[1], r[3]}); pc = 15; continue; }
case 15: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d0e36e136cd30dc98b05f1c3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->inlineSponsorOverlayRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->youtubeOverlaysLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 7; continue; }
case 7: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlightButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 11; continue; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 13; continue; }
case 13: { r[0] = rt.allocate("Ljava/lang/ref/WeakReference;"); pc = 14; continue; }
case 14: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V",r[0],new Value[]{r[1]}); pc = 15; continue; }
case 15: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSponsorButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true,r[0]); pc = 16; continue; }
case 16: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/shared/PlayerType;->getOnChange()Lapp/revanced/extension/youtube/shared/Event;",Value.NULL,new Value[]{}); pc = 17; continue; }
case 17: { r[0] = result; pc = 18; continue; }
case 18: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda0;"); pc = 19; continue; }
case 19: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda0;-><init>()V",r[1],new Value[]{}); pc = 20; continue; }
case 20: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/shared/Event;->addObserver(Lkotlin/jvm/functions/Function1;)V",r[0],new Value[]{r[1]}); pc = 21; continue; }
case 21: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e269453f8f74f1598fb90d82(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutVisible:Z",Value.NULL,true,r[0]); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[1],new Value[]{}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { r[1] = rt.cast(r[1],"Landroid/view/View;"); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setGenericViewVisibility(Landroid/view/View;Z)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_68f7a40e5c1c5491bede56c3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;");
r[1] = rt.check(arguments[1], "Z");
r[2] = rt.check(arguments[2], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[3], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?2:1; continue; }
case 1: { return Value.VOID; }
case 2: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?4:3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;->updateSkipButtonText(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?13:5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_AUTO_HIDE_SKIP_BUTTON:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[1],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/Boolean;->booleanValue()Z",r[1],new Value[]{}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?13:11; continue; }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setVisibilityImmediate(Z)V",Value.NULL,new Value[]{r[3]}); pc = 12; continue; }
case 12: { return Value.VOID; }
case 13: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setGenericViewVisibility(Landroid/view/View;Z)V",Value.NULL,new Value[]{r[0], r[3]}); pc = 14; continue; }
case 14: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a78bef6687a17a4e1f6ec4bc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[1]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[1]); pc = 2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSponsorButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 6; continue; }
case 6: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?8:7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;->updateSkipButtonText(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[0],new Value[]{r[1]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_531356f4c5ac6516202a9ae3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true,r[2]); pc = 2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSponsorButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 6; continue; }
case 6: { r[1] = Value.i32(1); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->updateSkipButton(Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;ZLapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;Z)V",Value.NULL,new Value[]{r[0], r[1], r[2], r[1]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2518227ce83484572f1132bd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Landroid/view/View;");
r[2] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?2:1; continue; }
case 1: { pc=12; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->canShowViewElements:Z",Value.NULL,true); pc = 3; continue; }
case 3: { r[2] = Value.i32((r[2].i()) & (r[0].i())); pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?7:5; continue; }
case 5: { r[2] = Value.i32(0); pc = 6; continue; }
case 6: { pc=8; continue; }
case 7: { r[2] = Value.i32(8); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->getVisibility()I",r[1],new Value[]{}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { pc=(ExecutableRuntime.equal(r[0],r[2]))?12:11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->setVisibility(I)V",r[1],new Value[]{r[2]}); pc = 12; continue; }
case 12: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ad70fdea63daf1f606493540(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?5:1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->shouldNotFadeOutPlayerOverlaySkipButton()Z",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:4; continue; }
case 4: { pc=8; continue; }
case 5: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSponsorPlayerButton:Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;",Value.NULL,true); pc = 6; continue; }
case 6: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?8:7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->setVisibilityImmediate(Z)V",r[0],new Value[]{r[1]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_95e0daf79c8db9dcb0b4b5ea(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->canShowViewElements:Z",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?7:2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController;->currentlyInsideSkippableSegment()Z",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?7:5; continue; }
case 5: { r[0] = Value.i32(1); pc = 6; continue; }
case 6: { return rt.check(r[0],"Z"); }
case 7: { r[0] = Value.i32(0); pc = 8; continue; }
case 8: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_86d28ef9b362124cfa085e26(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("initialize failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_05c01e75a3f0409ba3c50f11(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("initializing"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6214ab58e23768c2d30414ed(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->playerTypeChanged(Lapp/revanced/extension/youtube/shared/PlayerType;)V",Value.NULL,new Value[]{r[0]}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;",Value.NULL,true); pc = 2; continue; }
case 2: { return rt.check(r[0],"Lkotlin/Unit;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2d3b1cc3b6c0899874f0bbef(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[4] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/shared/PlayerType;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_FULLSCREEN:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { r[2] = Value.i32(1); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[4],r[0]))?6:4; continue; }
case 4: { r[0] = r[2]; pc = 5; continue; }
case 5: { pc=7; continue; }
case 6: { r[0] = r[1]; pc = 7; continue; }
case 7: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?13:8; continue; }
case 8: { r[3] = rt.readField("Lapp/revanced/extension/youtube/shared/PlayerType;->WATCH_WHILE_MAXIMIZED:Lapp/revanced/extension/youtube/shared/PlayerType;",Value.NULL,true); pc = 9; continue; }
case 9: { pc=(!ExecutableRuntime.equal(r[4],r[3]))?11:10; continue; }
case 10: { pc=13; continue; }
case 11: { r[4] = r[1]; pc = 12; continue; }
case 12: { pc=14; continue; }
case 13: { r[4] = r[2]; pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->canShowViewElements:Z",Value.NULL,true,r[4]); pc = 15; continue; }
case 15: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 16; continue; }
case 16: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[4],new Value[]{}); pc = 17; continue; }
case 17: { r[4] = result; pc = 18; continue; }
case 18: { r[4] = rt.cast(r[4],"Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;"); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setNewSegmentLayoutMargins(Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;Z)V",Value.NULL,new Value[]{r[4], r[0]}); pc = 20; continue; }
case 20: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[4],new Value[]{}); pc = 22; continue; }
case 22: { r[4] = result; pc = 23; continue; }
case 23: { r[4] = rt.cast(r[4],"Landroid/view/View;"); pc = 24; continue; }
case 24: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->newSegmentLayoutVisible:Z",Value.NULL,true); pc = 25; continue; }
case 25: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setGenericViewVisibility(Landroid/view/View;Z)V",Value.NULL,new Value[]{r[4], r[3]}); pc = 26; continue; }
case 26: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlightButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 27; continue; }
case 27: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[4],new Value[]{}); pc = 28; continue; }
case 28: { r[4] = result; pc = 29; continue; }
case 29: { r[4] = rt.cast(r[4],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setSkipButtonMargins(Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;Z)V",Value.NULL,new Value[]{r[4], r[0]}); pc = 31; continue; }
case 31: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipHighlight:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 32; continue; }
case 32: { pc=(ExecutableRuntime.equal(r[3],Value.i32(0)))?35:33; continue; }
case 33: { r[3] = r[2]; pc = 34; continue; }
case 34: { pc=36; continue; }
case 35: { r[3] = r[1]; pc = 36; continue; }
case 36: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setGenericViewVisibility(Landroid/view/View;Z)V",Value.NULL,new Value[]{r[4], r[3]}); pc = 37; continue; }
case 37: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSponsorButtonRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 38; continue; }
case 38: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[4],new Value[]{}); pc = 39; continue; }
case 39: { r[4] = result; pc = 40; continue; }
case 40: { r[4] = rt.cast(r[4],"Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;"); pc = 41; continue; }
case 41: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setSkipButtonMargins(Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;Z)V",Value.NULL,new Value[]{r[4], r[0]}); pc = 42; continue; }
case 42: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->skipSegment:Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",Value.NULL,true); pc = 43; continue; }
case 43: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?45:44; continue; }
case 44: { r[1] = r[2]; pc = 45; continue; }
case 45: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setGenericViewVisibility(Landroid/view/View;Z)V",Value.NULL,new Value[]{r[4], r[1]}); pc = 46; continue; }
case 46: { return Value.VOID; }
case 47: { r[4] = Value.ref(exception); exception=null; pc = 48; continue; }
case 48: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda7;"); pc = 49; continue; }
case 49: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda7;-><init>()V",r[0],new Value[]{}); pc = 50; continue; }
case 50: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[4]}); pc = 51; continue; }
case 51: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 46) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=47; continue; } }
throw error;
}
}

}

static Value m_4d80f153211b98a338fd1a09(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;");
r[3] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?4:1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;->defaultBottomMargin:I",r[2],false); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/NewSegmentLayout;->ctaBottomMargin:I",r[2],false); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setLayoutMargins(Landroid/view/View;ZII)V",Value.NULL,new Value[]{r[2], r[3], r[0], r[1]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1a458dbfffd8ce10f8340e33(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;");
r[3] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?4:1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;->defaultBottomMargin:I",r[2],false); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SkipSponsorButton;->ctaBottomMargin:I",r[2],false); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->setLayoutMargins(Landroid/view/View;ZII)V",Value.NULL,new Value[]{r[2], r[3], r[0], r[1]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_eae2adb4923564603d84a8c2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[1] = rt.check(arguments[0], "Landroid/view/View;");
r[2] = rt.check(arguments[1], "Z");
r[3] = rt.check(arguments[2], "I");
r[4] = rt.check(arguments[3], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[0] = rt.cast(r[0],"Landroid/widget/RelativeLayout$LayoutParams;"); pc = 3; continue; }
case 3: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?8:4; continue; }
case 4: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda2;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda2;-><init>()V",r[1],new Value[]{}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 7; continue; }
case 7: { return Value.VOID; }
case 8: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?10:9; continue; }
case 9: { r[3] = r[4]; pc = 10; continue; }
case 10: { rt.writeField("Landroid/widget/RelativeLayout$LayoutParams;->bottomMargin:I",r[0],false,r[3]); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V",r[1],new Value[]{r[0]}); pc = 12; continue; }
case 12: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2534581a949b07cbe7cb60f8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("playerTypeChanged failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5887f43ab042e044689f1960(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;->youtubeOverlaysLayoutRef:Ljava/lang/ref/WeakReference;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Ljava/lang/ref/Reference;->get()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"Landroid/view/ViewGroup;"); pc = 4; continue; }
case 4: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?7:5; continue; }
case 5: { r[0] = Value.i32(0); pc = 6; continue; }
case 6: { return rt.check(r[0],"Landroid/content/Context;"); }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController;","Landroid/view/View;->getContext()Landroid/content/Context;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { return rt.check(r[0],"Landroid/content/Context;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1e3d36c8325eaf18d186c9ba(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Unable to setNewSegmentLayoutMargins (params are null)"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
