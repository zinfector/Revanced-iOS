package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_d8882623ab7ee8fe extends RuntimeForeign.SourceProxy implements java.util.Queue {
Proxy_d8882623ab7ee8fe(RuntimeForeign owner,Instance source){super(owner,source);}
public boolean add(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Queue;->add(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean offer(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Queue;->offer(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public java.lang.Object remove() {Value result=owner.callback(source,"Ljava/util/Queue;->remove()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object poll() {Value result=owner.callback(source,"Ljava/util/Queue;->poll()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object element() {Value result=owner.callback(source,"Ljava/util/Queue;->element()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object peek() {Value result=owner.callback(source,"Ljava/util/Queue;->peek()Ljava/lang/Object;",new Value[]{}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public int size() {Value result=owner.callback(source,"Ljava/util/Queue;->size()I",new Value[]{}); return result.i();}
public boolean isEmpty() {Value result=owner.callback(source,"Ljava/util/Queue;->isEmpty()Z",new Value[]{}); return result.z();}
public boolean contains(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Queue;->contains(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public java.util.Iterator iterator() {Value result=owner.callback(source,"Ljava/util/Queue;->iterator()Ljava/util/Iterator;",new Value[]{}); return (java.util.Iterator)owner.exportObject(result.o(),"Ljava/util/Iterator;");}
public java.lang.Object[] toArray() {Value result=owner.callback(source,"Ljava/util/Queue;->toArray()[Ljava/lang/Object;",new Value[]{}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public java.lang.Object[] toArray(java.lang.Object[] a0) {Value result=owner.callback(source,"Ljava/util/Queue;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;",new Value[]{owner.importValue(a0)}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public boolean remove(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Queue;->remove(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean containsAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Queue;->containsAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean addAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Queue;->addAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean removeAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Queue;->removeAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean retainAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Queue;->retainAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public void clear() {Value result=owner.callback(source,"Ljava/util/Queue;->clear()V",new Value[]{}); return;}
public boolean equals(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Queue;->equals(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int hashCode() {Value result=owner.callback(source,"Ljava/util/Queue;->hashCode()I",new Value[]{}); return result.i();}
}
