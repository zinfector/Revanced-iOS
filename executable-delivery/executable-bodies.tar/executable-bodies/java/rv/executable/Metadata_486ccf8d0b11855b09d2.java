package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_486ccf8d0b11855b09d2 {
static ClassInfo info_486ccf8d0b11855b09d2() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda18;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda18;->f$0:Ljava/util/List;", "Ljava/util/List;", 4113, ExecutableRuntime.zero("Ljava/util/List;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/util/List;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SBRequester$$ExternalSyntheticLambda18");}
}
