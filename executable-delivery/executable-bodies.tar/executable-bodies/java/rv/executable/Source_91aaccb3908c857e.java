package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_91aaccb3908c857e extends RuntimeForeign.SourceProxy {
Source_91aaccb3908c857e(RuntimeForeign owner,Instance source){super(owner,source);}

}
