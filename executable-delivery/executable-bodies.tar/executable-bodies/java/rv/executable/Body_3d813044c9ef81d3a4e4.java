package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_3d813044c9ef81d3a4e4 {
static Value m_9e684abe548f54a3fa2e07d8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 1; continue; }
case 1: { r[3] = rt.readField("Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;", Value.NULL, true); pc = 2; continue; }
case 2: { r[1] = Value.ref("revanced_custom_filter"); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V", r[0], new Value[]{r[1], r[3]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;->CUSTOM_FILTER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[0]); pc = 5; continue; }
case 5: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/StringSetting;"); pc = 6; continue; }
case 6: { r[2] = Value.i32(1); pc = 7; continue; }
case 7: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { r[4] = Value.ref("revanced_custom_filter_strings"); pc = 10; continue; }
case 10: { r[5] = Value.ref(""); pc = 11; continue; }
case 11: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;", "Lapp/revanced/extension/shared/settings/StringSetting;-><init>(Ljava/lang/String;Ljava/lang/String;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[4], r[5], r[2], r[0]}); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;->CUSTOM_FILTER_STRINGS:Lapp/revanced/extension/shared/settings/StringSetting;", Value.NULL, true, r[1]); pc = 13; continue; }
case 13: { r[1] = rt.allocate("Lapp/revanced/extension/shared/settings/BooleanSetting;"); pc = 14; continue; }
case 14: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->DEBUG:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true); pc = 15; continue; }
case 15: { result = rt.invoke("static", "Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;", "Lapp/revanced/extension/shared/settings/Setting;->parent(Lapp/revanced/extension/shared/settings/BooleanSetting;)Lapp/revanced/extension/shared/settings/Setting$Availability;", Value.NULL, new Value[]{r[0]}); pc = 16; continue; }
case 16: { r[6] = result; pc = 17; continue; }
case 17: { r[2] = Value.ref("revanced_debug_protocolbuffer"); pc = 18; continue; }
case 18: { r[4] = Value.i32(0); pc = 19; continue; }
case 19: { r[5] = Value.ref("revanced_debug_protocolbuffer_user_dialog_message"); pc = 20; continue; }
case 20: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;", "Lapp/revanced/extension/shared/settings/BooleanSetting;-><init>(Ljava/lang/String;Ljava/lang/Boolean;ZLjava/lang/String;Lapp/revanced/extension/shared/settings/Setting$Availability;)V", r[1], new Value[]{r[2], r[3], r[4], r[5], r[6]}); pc = 21; continue; }
case 21: { rt.writeField("Lapp/revanced/extension/shared/settings/YouTubeAndMusicSettings;->DEBUG_PROTOCOLBUFFER:Lapp/revanced/extension/shared/settings/BooleanSetting;", Value.NULL, true, r[1]); pc = 22; continue; }
case 22: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
