package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_7523b3dfcf6e9cceb96b {
static Value m_50e2efb2f3a30d9fb3b799be(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Logger$LogLevel;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("DEBUG"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger$LogLevel;","Lapp/revanced/extension/shared/Logger$LogLevel;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/Logger$LogLevel;->DEBUG:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true,r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Logger$LogLevel;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("INFO"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger$LogLevel;","Lapp/revanced/extension/shared/Logger$LogLevel;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/shared/Logger$LogLevel;->INFO:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Logger$LogLevel;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("ERROR"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger$LogLevel;","Lapp/revanced/extension/shared/Logger$LogLevel;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/shared/Logger$LogLevel;->ERROR:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true,r[0]); pc = 15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger$LogLevel;","Lapp/revanced/extension/shared/Logger$LogLevel;->$values()[Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,new Value[]{}); pc = 16; continue; }
case 16: { r[0] = result; pc = 17; continue; }
case 17: { rt.writeField("Lapp/revanced/extension/shared/Logger$LogLevel;->$VALUES:[Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true,r[0]); pc = 18; continue; }
case 18: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4c338a91ae899cf875040347(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Logger$LogLevel;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger$LogLevel;","Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_542febbf36213b2044399ba6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(3); pc = 1; continue; }
case 1: { r[0] = rt.newArray("[Lapp/revanced/extension/shared/Logger$LogLevel;",r[0].i()); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->DEBUG:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->INFO:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 6; continue; }
case 6: { r[2] = Value.i32(1); pc = 7; continue; }
case 7: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->ERROR:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 9; continue; }
case 9: { r[2] = Value.i32(2); pc = 10; continue; }
case 10: { rt.arrayPut(r[0],r[2].i(),r[1]); pc = 11; continue; }
case 11: { return rt.check(r[0],"[Lapp/revanced/extension/shared/Logger$LogLevel;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1d76c858f76d051cddb5ca65(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->$VALUES:[Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger$LogLevel;","[Lapp/revanced/extension/shared/Logger$LogLevel;->clone()Ljava/lang/Object;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/shared/Logger$LogLevel;"); pc = 4; continue; }
case 4: { return rt.check(r[0],"[Lapp/revanced/extension/shared/Logger$LogLevel;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
