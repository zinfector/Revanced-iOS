package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_27a213441bc2609e extends RuntimeForeign.SourceProxy {
Source_27a213441bc2609e(RuntimeForeign owner,Instance source){super(owner,source);}

}
