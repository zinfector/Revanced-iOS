package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8c48567b9b1ef39dfc0f {
static ClassInfo info_8c48567b9b1ef39dfc0f() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/ui/SponsorBlockViewController$$ExternalSyntheticLambda2;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SponsorBlockViewController$$ExternalSyntheticLambda2");}
}
