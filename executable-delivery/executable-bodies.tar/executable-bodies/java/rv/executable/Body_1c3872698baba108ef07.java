package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_1c3872698baba108ef07 {
static Value m_e869d17344781b07fe80badc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "I");
r[1] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { pc=(r[0].i() >= r[1].i())?2:1; continue; }
case 1: { return rt.check(r[1],"I"); }
case 2: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
