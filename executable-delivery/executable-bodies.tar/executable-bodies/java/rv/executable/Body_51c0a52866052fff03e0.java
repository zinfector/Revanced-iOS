package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_51c0a52866052fff03e0 {
static Value m_67100aadf101a6da3093bd5d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/Logger$LogMessage;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Exception;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c3d333aa66273ee8c882570c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/Logger$LogMessage;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Exception;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9995ab0cfde7fa7fb73248c9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[0];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_41df0dc6149540e7061de8e8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[3] = rt.check(arguments[0], "Lapp/revanced/extension/shared/Logger$LogMessage;");
r[4] = rt.check(arguments[1], "Ljava/lang/Exception;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->INFO:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->includeStackTrace()Z",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->logInternal(Lapp/revanced/extension/shared/Logger$LogLevel;Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;ZZ)V",Value.NULL,new Value[]{r[0], r[3], r[4], r[1], r[2]}); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_24c082155b864f193195b7b8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[3] = rt.check(arguments[0], "Lapp/revanced/extension/shared/Logger$LogMessage;");
r[4] = rt.check(arguments[1], "Ljava/lang/Exception;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->shouldLogDebug()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?8:3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->DEBUG:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->includeStackTrace()Z",Value.NULL,new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { r[2] = Value.i32(0); pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->logInternal(Lapp/revanced/extension/shared/Logger$LogLevel;Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;ZZ)V",Value.NULL,new Value[]{r[0], r[3], r[4], r[1], r[2]}); pc = 8; continue; }
case 8: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a21e4e686949ff20e22622da(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[3] = rt.check(arguments[0], "Lapp/revanced/extension/shared/Logger$LogMessage;");
r[4] = rt.check(arguments[1], "Ljava/lang/Throwable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Logger$LogLevel;->ERROR:Lapp/revanced/extension/shared/Logger$LogLevel;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->includeStackTrace()Z",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->shouldShowErrorToast()Z",Value.NULL,new Value[]{}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->logInternal(Lapp/revanced/extension/shared/Logger$LogLevel;Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;ZZ)V",Value.NULL,new Value[]{r[0], r[3], r[4], r[1], r[2]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5f094642131321dd2372960f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?10:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->DEBUG_STACKTRACE:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?10:8; continue; }
case 8: { r[0] = Value.i32(1); pc = 9; continue; }
case 9: { return rt.check(r[0],"Z"); }
case 10: { r[0] = Value.i32(0); pc = 11; continue; }
case 11: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e3649e1d14b2cb093bbe3935(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 5) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
r[3] = rt.check(arguments[0], "Lapp/revanced/extension/shared/Logger$LogLevel;");
r[4] = rt.check(arguments[1], "Lapp/revanced/extension/shared/Logger$LogMessage;");
r[5] = rt.check(arguments[2], "Ljava/lang/Throwable;");
r[6] = rt.check(arguments[3], "Z");
r[7] = rt.check(arguments[4], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("interface","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger$LogMessage;->buildMessageString()Ljava/lang/String;",r[4],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->getOuterClassSimpleName(Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[4]}); pc = 3; continue; }
case 3: { r[4] = result; pc = 4; continue; }
case 4: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?16:5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Throwable;->getMessage()Ljava/lang/String;",r[5],new Value[]{}); pc = 6; continue; }
case 6: { r[1] = result; pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?16:8; continue; }
case 8: { r[2] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;-><init>()V",r[2],new Value[]{}); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 11; continue; }
case 11: { r[0] = Value.ref("\nException: "); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[1]}); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[2],new Value[]{}); pc = 15; continue; }
case 15: { r[0] = result; pc = 16; continue; }
case 16: { pc=(ExecutableRuntime.equal(r[6],Value.i32(0)))?40:17; continue; }
case 17: { r[6] = rt.allocate("Ljava/io/StringWriter;"); pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger;","Ljava/io/StringWriter;-><init>()V",r[6],new Value[]{}); pc = 19; continue; }
case 19: { r[1] = rt.allocate("Ljava/lang/Throwable;"); pc = 20; continue; }
case 20: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Throwable;-><init>()V",r[1],new Value[]{}); pc = 21; continue; }
case 21: { r[2] = rt.allocate("Ljava/io/PrintWriter;"); pc = 22; continue; }
case 22: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger;","Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V",r[2],new Value[]{r[6]}); pc = 23; continue; }
case 23: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V",r[1],new Value[]{r[2]}); pc = 24; continue; }
case 24: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/io/StringWriter;->toString()Ljava/lang/String;",r[6],new Value[]{}); pc = 25; continue; }
case 25: { r[6] = result; pc = 26; continue; }
case 26: { r[1] = rt.readField("Lapp/revanced/extension/shared/Logger;->LOGGER_CLASS_NAME:Ljava/lang/String;",Value.NULL,true); pc = 27; continue; }
case 27: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I",r[6],new Value[]{r[1]}); pc = 28; continue; }
case 28: { r[1] = result; pc = 29; continue; }
case 29: { r[2] = Value.i32(10); pc = 30; continue; }
case 30: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/String;->indexOf(II)I",r[6],new Value[]{r[2], r[1]}); pc = 31; continue; }
case 31: { r[1] = result; pc = 32; continue; }
case 32: { r[2] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 33; continue; }
case 33: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;-><init>()V",r[2],new Value[]{}); pc = 34; continue; }
case 34: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 35; continue; }
case 35: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/String;->substring(I)Ljava/lang/String;",r[6],new Value[]{r[1]}); pc = 36; continue; }
case 36: { r[6] = result; pc = 37; continue; }
case 37: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[6]}); pc = 38; continue; }
case 38: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[2],new Value[]{}); pc = 39; continue; }
case 39: { r[0] = result; pc = 40; continue; }
case 40: { r[6] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 41; continue; }
case 41: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;-><init>()V",r[6],new Value[]{}); pc = 42; continue; }
case 42: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[6],new Value[]{r[4]}); pc = 43; continue; }
case 43: { r[1] = Value.ref(": "); pc = 44; continue; }
case 44: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[6],new Value[]{r[1]}); pc = 45; continue; }
case 45: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[6],new Value[]{r[0]}); pc = 46; continue; }
case 46: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[6],new Value[]{}); pc = 47; continue; }
case 47: { r[6] = result; pc = 48; continue; }
case 48: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/settings/preference/LogBufferManager;->appendToLogBuffer(Ljava/lang/String;)V",Value.NULL,new Value[]{r[6]}); pc = 49; continue; }
case 49: { r[1] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 50; continue; }
case 50: { r[2] = Value.ref("revanced: "); pc = 51; continue; }
case 51: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 52; continue; }
case 52: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[1],new Value[]{r[4]}); pc = 53; continue; }
case 53: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[1],new Value[]{}); pc = 54; continue; }
case 54: { r[4] = result; pc = 55; continue; }
case 55: { r[1] = rt.readField("Lapp/revanced/extension/shared/Logger$1;->$SwitchMap$app$revanced$extension$shared$Logger$LogLevel:[I",Value.NULL,true); pc = 56; continue; }
case 56: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Enum;->ordinal()I",r[3],new Value[]{}); pc = 57; continue; }
case 57: { r[3] = result; pc = 58; continue; }
case 58: { r[3] = rt.arrayGet(r[1],r[3].i()); pc = 59; continue; }
case 59: { r[1] = Value.i32(1); pc = 60; continue; }
case 60: { pc=(ExecutableRuntime.equal(r[3],r[1]))?76:61; continue; }
case 61: { r[1] = Value.i32(2); pc = 62; continue; }
case 62: { pc=(ExecutableRuntime.equal(r[3],r[1]))?71:63; continue; }
case 63: { r[1] = Value.i32(3); pc = 64; continue; }
case 64: { pc=(ExecutableRuntime.equal(r[3],r[1]))?66:65; continue; }
case 65: { pc=80; continue; }
case 66: { pc=(!ExecutableRuntime.equal(r[5],Value.i32(0)))?69:67; continue; }
case 67: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I",Value.NULL,new Value[]{r[4], r[0]}); pc = 68; continue; }
case 68: { pc=80; continue; }
case 69: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I",Value.NULL,new Value[]{r[4], r[0], r[5]}); pc = 70; continue; }
case 70: { pc=80; continue; }
case 71: { pc=(!ExecutableRuntime.equal(r[5],Value.i32(0)))?74:72; continue; }
case 72: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I",Value.NULL,new Value[]{r[4], r[0]}); pc = 73; continue; }
case 73: { pc=80; continue; }
case 74: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I",Value.NULL,new Value[]{r[4], r[0], r[5]}); pc = 75; continue; }
case 75: { pc=80; continue; }
case 76: { pc=(!ExecutableRuntime.equal(r[5],Value.i32(0)))?79:77; continue; }
case 77: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I",Value.NULL,new Value[]{r[4], r[0]}); pc = 78; continue; }
case 78: { pc=80; continue; }
case 79: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I",Value.NULL,new Value[]{r[4], r[0], r[5]}); pc = 80; continue; }
case 80: { pc=(ExecutableRuntime.equal(r[7],Value.i32(0)))?82:81; continue; }
case 81: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Utils;->showToastLong(Ljava/lang/String;)V",Value.NULL,new Value[]{r[6]}); pc = 82; continue; }
case 82: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_eac4679e4265017e80c3c8f0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?11:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->DEBUG:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?9:8; continue; }
case 8: { pc=11; continue; }
case 9: { r[0] = Value.i32(0); pc = 10; continue; }
case 10: { return rt.check(r[0],"Z"); }
case 11: { r[0] = Value.i32(1); pc = 12; continue; }
case 12: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c8049d8ad9a5be151be74d5f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?10:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->DEBUG_TOAST_ON_ERROR:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?10:8; continue; }
case 8: { r[0] = Value.i32(1); pc = 9; continue; }
case 9: { return rt.check(r[0],"Z"); }
case 10: { r[0] = Value.i32(0); pc = 11; continue; }
case 11: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5dd539aeb2887bd543a7e969(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/Object;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[2],new Value[]{}); pc = 1; continue; }
case 1: { r[2] = result; pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Class;->getName()Ljava/lang/String;",r[2],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[1] = Value.i32(36); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/String;->indexOf(I)I",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { r[1] = result; pc = 7; continue; }
case 7: { pc=(r[1].i() >= 0)?11:8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/Class;->getSimpleName()Ljava/lang/String;",r[2],new Value[]{}); pc = 9; continue; }
case 9: { r[2] = result; pc = 10; continue; }
case 10: { return rt.check(r[2],"Ljava/lang/String;"); }
case 11: { r[2] = Value.i32(46); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/String;->lastIndexOf(I)I",r[0],new Value[]{r[2]}); pc = 13; continue; }
case 13: { r[2] = result; pc = 14; continue; }
case 14: { r[2] = Value.i32((r[2].i()) + (1)); pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Logger;","Ljava/lang/String;->substring(II)Ljava/lang/String;",r[0],new Value[]{r[2], r[1]}); pc = 16; continue; }
case 16: { r[2] = result; pc = 17; continue; }
case 17: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3525b5806a94dc19ac332f29(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/Logger$LogMessage;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Logger;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
