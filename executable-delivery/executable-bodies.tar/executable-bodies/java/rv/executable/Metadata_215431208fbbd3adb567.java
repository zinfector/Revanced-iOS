package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_215431208fbbd3adb567 {
static ClassInfo info_215431208fbbd3adb567() {return new ClassInfo("Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;", "Ljava/lang/Object;", new String[]{}, 1537, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("getActivity()Landroid/app/Activity;", 1025), new MethodInfo("getPreferenceScreenForSearch()Landroid/preference/PreferenceScreen;", 1025), new MethodInfo("getView()Landroid/view/View;", 1025)}, "BasePreferenceFragment");}
}
