package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_a4860df4772dd5effc7d {
static Value m_cc96441e11d64a0cdc14848d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Landroid/widget/EditText;");
r[1] = rt.check(arguments[1], "Landroid/graphics/drawable/Drawable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$$ExternalSyntheticApiModelOutline0;","Landroid/widget/EditText;->setTextCursorDrawable(Landroid/graphics/drawable/Drawable;)V",r[0],new Value[]{r[1]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
