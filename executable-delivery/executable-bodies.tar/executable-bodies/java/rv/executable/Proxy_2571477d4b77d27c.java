package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_2571477d4b77d27c extends RuntimeForeign.SourceProxy implements java.util.List {
Proxy_2571477d4b77d27c(RuntimeForeign owner,Instance source){super(owner,source);}
public int size() {Value result=owner.callback(source,"Ljava/util/List;->size()I",new Value[]{}); return result.i();}
public boolean isEmpty() {Value result=owner.callback(source,"Ljava/util/List;->isEmpty()Z",new Value[]{}); return result.z();}
public boolean contains(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/List;->contains(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public java.util.Iterator iterator() {Value result=owner.callback(source,"Ljava/util/List;->iterator()Ljava/util/Iterator;",new Value[]{}); return (java.util.Iterator)owner.exportObject(result.o(),"Ljava/util/Iterator;");}
public java.lang.Object[] toArray() {Value result=owner.callback(source,"Ljava/util/List;->toArray()[Ljava/lang/Object;",new Value[]{}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public java.lang.Object[] toArray(java.lang.Object[] a0) {Value result=owner.callback(source,"Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;",new Value[]{owner.importValue(a0)}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public boolean add(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/List;->add(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean remove(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/List;->remove(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean containsAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/List;->containsAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean addAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/List;->addAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean addAll(int a0,java.util.Collection a1) {Value result=owner.callback(source,"Ljava/util/List;->addAll(ILjava/util/Collection;)Z",new Value[]{Value.i32(a0),owner.importValue(a1)}); return result.z();}
public boolean removeAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/List;->removeAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean retainAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/List;->retainAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public void clear() {Value result=owner.callback(source,"Ljava/util/List;->clear()V",new Value[]{}); return;}
public boolean equals(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/List;->equals(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int hashCode() {Value result=owner.callback(source,"Ljava/util/List;->hashCode()I",new Value[]{}); return result.i();}
public java.lang.Object get(int a0) {Value result=owner.callback(source,"Ljava/util/List;->get(I)Ljava/lang/Object;",new Value[]{Value.i32(a0)}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public java.lang.Object set(int a0,java.lang.Object a1) {Value result=owner.callback(source,"Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;",new Value[]{Value.i32(a0),owner.importValue(a1)}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public void add(int a0,java.lang.Object a1) {Value result=owner.callback(source,"Ljava/util/List;->add(ILjava/lang/Object;)V",new Value[]{Value.i32(a0),owner.importValue(a1)}); return;}
public java.lang.Object remove(int a0) {Value result=owner.callback(source,"Ljava/util/List;->remove(I)Ljava/lang/Object;",new Value[]{Value.i32(a0)}); return (java.lang.Object)owner.exportObject(result.o(),"Ljava/lang/Object;");}
public int indexOf(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/List;->indexOf(Ljava/lang/Object;)I",new Value[]{owner.importValue(a0)}); return result.i();}
public int lastIndexOf(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/List;->lastIndexOf(Ljava/lang/Object;)I",new Value[]{owner.importValue(a0)}); return result.i();}
public java.util.ListIterator listIterator() {Value result=owner.callback(source,"Ljava/util/List;->listIterator()Ljava/util/ListIterator;",new Value[]{}); return (java.util.ListIterator)owner.exportObject(result.o(),"Ljava/util/ListIterator;");}
public java.util.ListIterator listIterator(int a0) {Value result=owner.callback(source,"Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;",new Value[]{Value.i32(a0)}); return (java.util.ListIterator)owner.exportObject(result.o(),"Ljava/util/ListIterator;");}
public java.util.List subList(int a0,int a1) {Value result=owner.callback(source,"Ljava/util/List;->subList(II)Ljava/util/List;",new Value[]{Value.i32(a0),Value.i32(a1)}); return (java.util.List)owner.exportObject(result.o(),"Ljava/util/List;");}
}
