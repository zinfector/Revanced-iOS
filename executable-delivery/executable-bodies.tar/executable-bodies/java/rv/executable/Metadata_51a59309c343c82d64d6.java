package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_51a59309c343c82d64d6 {
static ClassInfo info_51a59309c343c82d64d6() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda3;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/patches/VideoInformation$$ExternalSyntheticLambda3;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "VideoInformation$$ExternalSyntheticLambda3");}
}
