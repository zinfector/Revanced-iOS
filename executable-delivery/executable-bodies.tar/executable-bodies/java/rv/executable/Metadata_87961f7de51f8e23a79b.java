package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_87961f7de51f8e23a79b {
static ClassInfo info_87961f7de51f8e23a79b() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda10;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SBRequester$$ExternalSyntheticLambda10");}
}
