package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_97da4066bd739fb2600c {
static ClassInfo info_97da4066bd739fb2600c() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda12;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda12;->f$0:Landroid/content/Context;", "Landroid/content/Context;", 4113, ExecutableRuntime.zero("Landroid/content/Context;"))}, new MethodInfo[]{new MethodInfo("<init>(Landroid/content/Context;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "Utils$$ExternalSyntheticLambda12");}
}
