package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_b97ff44eb35b8f21dc0c {
static ClassInfo info_b97ff44eb35b8f21dc0c() {return new ClassInfo("Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda3;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/settings/Setting$$ExternalSyntheticLambda3;->f$0:Lapp/revanced/extension/shared/settings/Setting;", "Lapp/revanced/extension/shared/settings/Setting;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/shared/settings/Setting;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/shared/settings/Setting;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "Setting$$ExternalSyntheticLambda3");}
}
