package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_f3c0d2c87ca5378bf47c {
static Value m_84999d2913d0b09292959d57(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Utils;->verifyOffMainThread()V",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->VIEWED_SEGMENT:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true); pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->UUID:Ljava/lang/String;",r[2],false); pc = 3; continue; }
case 3: { result=rt.filledArray("[Ljava/lang/String;",new Value[]{r[1]}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->getConnectionFromRoute(Lapp/revanced/extension/shared/requests/Route;[Ljava/lang/String;)Ljava/net/HttpURLConnection;",Value.NULL,new Value[]{r[0], r[1]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/net/HttpURLConnection;->getResponseCode()I",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { r[1] = Value.i32(200); pc = 10; continue; }
case 10: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?15:11; continue; }
case 11: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda8;"); pc = 12; continue; }
case 12: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda8;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;)V",r[0],new Value[]{r[2]}); pc = 13; continue; }
case 13: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 14; continue; }
case 14: { return Value.VOID; }
case 15: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda9;"); pc = 16; continue; }
case 16: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda9;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;I)V",r[1],new Value[]{r[2], r[0]}); pc = 17; continue; }
case 17: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 18; continue; }
case 18: { return Value.VOID; }
case 19: { r[2] = Value.ref(exception); exception=null; pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda11;"); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda11;-><init>()V",r[0],new Value[]{}); pc = 22; continue; }
case 22: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[2]}); pc = 23; continue; }
case 23: { pc=28; continue; }
case 24: { r[2] = Value.ref(exception); exception=null; pc = 25; continue; }
case 25: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda10;"); pc = 26; continue; }
case 26: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda10;-><init>()V",r[0],new Value[]{}); pc = 27; continue; }
case 27: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Exception;)V",Value.NULL,new Value[]{r[0], r[2]}); pc = 28; continue; }
case 28: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 1 && pc < 18) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/io/IOException;")) { exception=ExecutableRuntime.caught(error); pc=24; continue; } if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=19; continue; } }
throw error;
}
}

}

static Value m_ec531b82a04a30584e5486b9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[22];
r[21] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = r[21]; pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Utils;->verifyOffMainThread()V",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[1] = rt.allocate("Ljava/util/ArrayList;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/util/ArrayList;-><init>()V",r[1],new Value[]{}); pc = 4; continue; }
case 4: { r[2] = Value.i32(0); pc = 5; continue; }
case 5: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->GET_SEGMENTS:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true); pc = 6; continue; }
case 6: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->sponsorBlockAPIFetchCategories:Ljava/lang/String;",Value.NULL,true); pc = 7; continue; }
case 7: { result=rt.filledArray("[Ljava/lang/String;",new Value[]{r[0], r[4]}); pc = 8; continue; }
case 8: { r[4] = result; pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->getConnectionFromRoute(Lapp/revanced/extension/shared/requests/Route;[Ljava/lang/String;)Ljava/net/HttpURLConnection;",Value.NULL,new Value[]{r[3], r[4]}); pc = 10; continue; }
case 10: { r[3] = result; pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/net/HttpURLConnection;->getResponseCode()I",r[3],new Value[]{}); pc = 12; continue; }
case 12: { r[4] = result; pc = 13; continue; }
case 13: { r[5] = Value.i32(200); pc = 14; continue; }
case 14: { pc=(!ExecutableRuntime.equal(r[4],r[5]))?88:15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/requests/Requester;->parseJSONArray(Ljava/net/HttpURLConnection;)Lorg/json/JSONArray;",Value.NULL,new Value[]{r[3]}); pc = 16; continue; }
case 16: { r[0] = result; pc = 17; continue; }
case 17: { r[3] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_SEGMENT_MIN_DURATION:Lapp/revanced/extension/shared/settings/FloatSetting;",Value.NULL,true); pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/settings/FloatSetting;->get()Ljava/lang/Float;",r[3],new Value[]{}); pc = 19; continue; }
case 19: { r[3] = result; pc = 20; continue; }
case 20: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/Float;->floatValue()F",r[3],new Value[]{}); pc = 21; continue; }
case 21: { r[3] = result; pc = 22; continue; }
case 22: { r[4] = Value.i32(1148846080); pc = 23; continue; }
case 23: { r[3] = Value.f32((r[3].f()) * (r[4].f())); pc = 24; continue; }
case 24: { r[3] = Value.i64((long)(r[3].f())); r[4] = r[3]; pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONArray;->length()I",r[0],new Value[]{}); pc = 26; continue; }
case 26: { r[5] = result; pc = 27; continue; }
case 27: { r[6] = r[2]; pc = 28; continue; }
case 28: { pc=(r[6].i() >= r[5].i())?83:29; continue; }
case 29: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONArray;->get(I)Ljava/lang/Object;",r[0],new Value[]{r[6]}); pc = 30; continue; }
case 30: { r[7] = result; pc = 31; continue; }
case 31: { r[7] = rt.cast(r[7],"Lorg/json/JSONObject;"); pc = 32; continue; }
case 32: { r[8] = Value.ref("segment"); pc = 33; continue; }
case 33: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;",r[7],new Value[]{r[8]}); pc = 34; continue; }
case 34: { r[8] = result; pc = 35; continue; }
case 35: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONArray;->getDouble(I)D",r[8],new Value[]{r[2]}); pc = 36; continue; }
case 36: { r[9] = result; r[10] = r[9]; pc = 37; continue; }
case 37: { r[11] = Value.i64(4652007308841189376L); r[12] = r[11]; pc = 38; continue; }
case 38: { r[9] = Value.f64((r[9].d()) * (r[11].d())); r[10] = r[9]; pc = 39; continue; }
case 39: { r[9] = Value.i64((long)(r[9].d())); r[10] = r[9]; pc = 40; continue; }
case 40: { r[13] = Value.i32(1); pc = 41; continue; }
case 41: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONArray;->getDouble(I)D",r[8],new Value[]{r[13]}); pc = 42; continue; }
case 42: { r[14] = result; r[15] = r[14]; pc = 43; continue; }
case 43: { r[14] = Value.f64((r[14].d()) * (r[11].d())); r[15] = r[14]; pc = 44; continue; }
case 44: { r[11] = Value.i64((long)(r[14].d())); r[12] = r[11]; pc = 45; continue; }
case 45: { r[8] = Value.ref("UUID"); pc = 46; continue; }
case 46: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;",r[7],new Value[]{r[8]}); pc = 47; continue; }
case 47: { r[15] = result; pc = 48; continue; }
case 48: { r[8] = Value.ref("locked"); pc = 49; continue; }
case 49: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I",r[7],new Value[]{r[8]}); pc = 50; continue; }
case 50: { r[8] = result; pc = 51; continue; }
case 51: { pc=(!ExecutableRuntime.equal(r[8],r[13]))?54:52; continue; }
case 52: { r[20] = r[13]; pc = 53; continue; }
case 53: { pc=55; continue; }
case 54: { r[20] = r[2]; pc = 55; continue; }
case 55: { r[8] = Value.ref("category"); pc = 56; continue; }
case 56: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;",r[7],new Value[]{r[8]}); pc = 57; continue; }
case 57: { r[7] = result; pc = 58; continue; }
case 58: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->byCategoryKey(Ljava/lang/String;)Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,new Value[]{r[7]}); pc = 59; continue; }
case 59: { r[14] = result; pc = 60; continue; }
case 60: { pc=(!ExecutableRuntime.equal(r[14],Value.i32(0)))?71:61; continue; }
case 61: { r[8] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda17;"); pc = 62; continue; }
case 62: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda17;-><init>(Ljava/lang/String;)V",r[8],new Value[]{r[7]}); pc = 63; continue; }
case 63: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[8]}); pc = 64; continue; }
case 64: { pc=81; continue; }
case 65: { r[0] = Value.ref(exception); exception=null; pc = 66; continue; }
case 66: { pc=105; continue; }
case 67: { r[0] = Value.ref(exception); exception=null; pc = 68; continue; }
case 68: { pc=109; continue; }
case 69: { r[0] = Value.ref(exception); exception=null; pc = 70; continue; }
case 70: { pc=114; continue; }
case 71: { r[7] = Value.i64((r[11].j()) - (r[9].j())); r[8] = r[7]; pc = 72; continue; }
case 72: { r[7] = Value.i32(ExecutableRuntime.compareLong(r[7].j(), r[3].j())); pc = 73; continue; }
case 73: { pc=(r[7].i() >= 0)?76:74; continue; }
case 74: { r[7] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;->HIGHLIGHT:Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;",Value.NULL,true); pc = 75; continue; }
case 75: { pc=(!ExecutableRuntime.equal(r[14],r[7]))?81:76; continue; }
case 76: { r[13] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"); pc = 77; continue; }
case 77: { r[16] = r[9]; r[17] = r[16]; pc = 78; continue; }
case 78: { r[18] = r[11]; r[19] = r[18]; pc = 79; continue; }
case 79: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;-><init>(Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory;Ljava/lang/String;JJZ)V",r[13],new Value[]{r[14], r[15], r[16], r[18], r[20]}); pc = 80; continue; }
case 80: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/util/List;->add(Ljava/lang/Object;)Z",r[1],new Value[]{r[13]}); pc = 81; continue; }
case 81: { r[6] = Value.i32((r[6].i()) + (1)); pc = 82; continue; }
case 82: { pc=28; continue; }
case 83: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda18;"); pc = 84; continue; }
case 84: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda18;-><init>(Ljava/util/List;)V",r[0],new Value[]{r[1]}); pc = 85; continue; }
case 85: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 86; continue; }
case 86: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->runVipCheckInBackgroundIfNeeded()V",Value.NULL,new Value[]{}); pc = 87; continue; }
case 87: { pc=118; continue; }
case 88: { r[5] = Value.i32(404); pc = 89; continue; }
case 89: { pc=(!ExecutableRuntime.equal(r[4],r[5]))?94:90; continue; }
case 90: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda19;"); pc = 91; continue; }
case 91: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda19;-><init>(Ljava/lang/String;)V",r[3],new Value[]{r[0]}); pc = 92; continue; }
case 92: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[3]}); pc = 93; continue; }
case 93: { pc=118; continue; }
case 94: { r[0] = Value.ref("revanced_sb_sponsorblock_connection_failure_status"); pc = 95; continue; }
case 95: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[4]}); pc = 96; continue; }
case 96: { r[4] = result; pc = 97; continue; }
case 97: { result=rt.filledArray("[Ljava/lang/Object;",new Value[]{r[4]}); pc = 98; continue; }
case 98: { r[4] = result; pc = 99; continue; }
case 99: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/StringRef;->str(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[0], r[4]}); pc = 100; continue; }
case 100: { r[0] = result; pc = 101; continue; }
case 101: { r[4] = Value.i32(0); pc = 102; continue; }
case 102: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->handleConnectionError(Ljava/lang/String;Ljava/lang/Exception;)V",Value.NULL,new Value[]{r[0], r[4]}); pc = 103; continue; }
case 103: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/net/HttpURLConnection;->disconnect()V",r[3],new Value[]{}); pc = 104; continue; }
case 104: { pc=118; continue; }
case 105: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda20;"); pc = 106; continue; }
case 106: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda20;-><init>()V",r[3],new Value[]{}); pc = 107; continue; }
case 107: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[3], r[0]}); pc = 108; continue; }
case 108: { pc=118; continue; }
case 109: { r[3] = Value.ref("revanced_sb_sponsorblock_connection_failure_generic"); pc = 110; continue; }
case 110: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/StringRef;->str(Ljava/lang/String;)Ljava/lang/String;",Value.NULL,new Value[]{r[3]}); pc = 111; continue; }
case 111: { r[3] = result; pc = 112; continue; }
case 112: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->handleConnectionError(Ljava/lang/String;Ljava/lang/Exception;)V",Value.NULL,new Value[]{r[3], r[0]}); pc = 113; continue; }
case 113: { pc=118; continue; }
case 114: { r[3] = Value.ref("revanced_sb_sponsorblock_connection_failure_timeout"); pc = 115; continue; }
case 115: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/StringRef;->str(Ljava/lang/String;)Ljava/lang/String;",Value.NULL,new Value[]{r[3]}); pc = 116; continue; }
case 116: { r[3] = result; pc = 117; continue; }
case 117: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->handleConnectionError(Ljava/lang/String;Ljava/lang/Exception;)V",Value.NULL,new Value[]{r[3], r[0]}); pc = 118; continue; }
case 118: { r[0] = rt.newArray("[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;",r[2].i()); pc = 119; continue; }
case 119: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;",r[1],new Value[]{r[0]}); pc = 120; continue; }
case 120: { r[0] = result; pc = 121; continue; }
case 121: { r[0] = rt.cast(r[0],"[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"); pc = 122; continue; }
case 122: { return rt.check(r[0],"[Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 5 && pc < 104) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/net/SocketTimeoutException;")) { exception=ExecutableRuntime.caught(error); pc=69; continue; } if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/io/IOException;")) { exception=ExecutableRuntime.caught(error); pc=67; continue; } if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=65; continue; } }
throw error;
}
}

}

static Value m_f425aeb078d5d6058fb145e2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/requests/Route;");
r[2] = rt.check(arguments[1], "[Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_API_URL:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/requests/Requester;->getConnectionFromRoute(Ljava/lang/String;Lapp/revanced/extension/shared/requests/Route;[Ljava/lang/String;)Ljava/net/HttpURLConnection;",Value.NULL,new Value[]{r[0], r[1], r[2]}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { r[2] = Value.i32(7000); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/net/URLConnection;->setConnectTimeout(I)V",r[1],new Value[]{r[2]}); pc = 7; continue; }
case 7: { r[2] = Value.i32(10000); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/net/URLConnection;->setReadTimeout(I)V",r[1],new Value[]{r[2]}); pc = 9; continue; }
case 9: { return rt.check(r[1],"Ljava/net/HttpURLConnection;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ac10589f0ac872c46afe1545(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;->userHasSBPrivateID()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?4:3; continue; }
case 3: { pc=15; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/System;->currentTimeMillis()J",Value.NULL,new Value[]{}); pc = 5; continue; }
case 5: { r[0] = result; r[1] = r[0]; pc = 6; continue; }
case 6: { r[2] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_LAST_VIP_CHECK:Lapp/revanced/extension/shared/settings/LongSetting;",Value.NULL,true); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/settings/LongSetting;->get()Ljava/lang/Long;",r[2],new Value[]{}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/Long;->longValue()J",r[2],new Value[]{}); pc = 10; continue; }
case 10: { r[2] = result; r[3] = r[2]; pc = 11; continue; }
case 11: { r[4] = Value.i64(259200000L); r[5] = r[4]; pc = 12; continue; }
case 12: { r[2] = Value.i64((r[2].j()) + (r[4].j())); r[3] = r[2]; pc = 13; continue; }
case 13: { r[2] = Value.i32(ExecutableRuntime.compareLong(r[0].j(), r[2].j())); pc = 14; continue; }
case 14: { pc=(r[2].i() >= 0)?16:15; continue; }
case 15: { return Value.VOID; }
case 16: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda12;"); pc = 17; continue; }
case 17: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda12;-><init>(J)V",r[2],new Value[]{r[0]}); pc = 18; continue; }
case 18: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Utils;->runOnBackgroundThread(Ljava/lang/Runnable;)V",Value.NULL,new Value[]{r[2]}); pc = 19; continue; }
case 19: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_35e229e7602318c935b211a5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Exception;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_TOAST_ON_CONNECTION_ERROR:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?7:6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Utils;->showToastShort(Ljava/lang/String;)V",Value.NULL,new Value[]{r[1]}); pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?11:8; continue; }
case 8: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda16;"); pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda16;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Exception;)V",Value.NULL,new Value[]{r[0], r[2]}); pc = 11; continue; }
case 11: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8b82d25422046775e3046b3f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Failed to send view count request"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4b040cc2ec2c3cf7a33d4f4c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Successfully sent view count for segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_24febea4f66c9ed7547b7437(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Failed to send view count"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_168363bb16718dd93882a2bf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;");
r[3] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Failed to sent view count for segment: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;->UUID:Ljava/lang/String;",r[2],false); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 5; continue; }
case 5: { r[2] = Value.ref(" responseCode: "); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 9; continue; }
case 9: { r[2] = result; pc = 10; continue; }
case 10: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_27d3802f51cc8eaa96bb193f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(arguments[0], "Ljava/util/List;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Downloaded segments:"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/util/List;->iterator()Ljava/util/Iterator;",r[3],new Value[]{}); pc = 4; continue; }
case 4: { r[3] = result; pc = 5; continue; }
case 5: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/util/Iterator;->hasNext()Z",r[3],new Value[]{}); pc = 6; continue; }
case 6: { r[1] = result; pc = 7; continue; }
case 7: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?15:8; continue; }
case 8: { result=rt.invoke("interface","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/util/Iterator;->next()Ljava/lang/Object;",r[3],new Value[]{}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { r[1] = rt.cast(r[1],"Lapp/revanced/extension/youtube/sponsorblock/objects/SponsorSegment;"); pc = 11; continue; }
case 11: { r[2] = Value.i32(10); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 14; continue; }
case 14: { pc=5; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 16; continue; }
case 16: { r[3] = result; pc = 17; continue; }
case 17: { return rt.check(r[3],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4df260fffbf79182660bce5e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Received unknown category: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fd72713364ec030e4d56281b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("getSegments failure"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_77a45a8b1b98636c52b3c5bb(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("No segments found for video: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d7996adddea5004d77625b44(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "J"); r[3] = r[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRoutes;->IS_USER_VIP:Lapp/revanced/extension/shared/requests/Route;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings;->getSBPrivateUserID()Ljava/lang/String;",Value.NULL,new Value[]{}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { result=rt.filledArray("[Ljava/lang/String;",new Value[]{r[1]}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->getJSONObject(Lapp/revanced/extension/shared/requests/Route;[Ljava/lang/String;)Lorg/json/JSONObject;",Value.NULL,new Value[]{r[0], r[1]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { r[1] = Value.ref("vip"); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lorg/json/JSONObject;->getBoolean(Ljava/lang/String;)Z",r[0],new Value[]{r[1]}); pc = 9; continue; }
case 9: { r[0] = result; pc = 10; continue; }
case 10: { r[1] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_USER_IS_VIP:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 11; continue; }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;",Value.NULL,new Value[]{r[0]}); pc = 12; continue; }
case 12: { r[0] = result; pc = 13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/settings/BooleanSetting;->save(Ljava/lang/Object;)V",r[1],new Value[]{r[0]}); pc = 14; continue; }
case 14: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SB_LAST_VIP_CHECK:Lapp/revanced/extension/shared/settings/LongSetting;",Value.NULL,true); pc = 15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;",Value.NULL,new Value[]{r[2]}); pc = 16; continue; }
case 16: { r[2] = result; pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/settings/LongSetting;->save(Ljava/lang/Object;)V",r[0],new Value[]{r[2]}); pc = 18; continue; }
case 18: { return Value.VOID; }
case 19: { r[2] = Value.ref(exception); exception=null; pc = 20; continue; }
case 20: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda7;"); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda7;-><init>()V",r[3],new Value[]{}); pc = 22; continue; }
case 22: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[3], r[2]}); pc = 23; continue; }
case 23: { pc=28; continue; }
case 24: { r[2] = Value.ref(exception); exception=null; pc = 25; continue; }
case 25: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda6;"); pc = 26; continue; }
case 26: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester$$ExternalSyntheticLambda6;-><init>()V",r[3],new Value[]{}); pc = 27; continue; }
case 27: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Exception;)V",Value.NULL,new Value[]{r[3], r[2]}); pc = 28; continue; }
case 28: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 18) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/io/IOException;")) { exception=ExecutableRuntime.caught(error); pc=24; continue; } if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=19; continue; } }
throw error;
}
}

}

static Value m_a8cb0f36ec614ab3977da088(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e74fa35ac0f87c49dada682b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Lapp/revanced/extension/shared/requests/Route;");
r[1] = rt.check(arguments[1], "[Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;->getConnectionFromRoute(Lapp/revanced/extension/shared/requests/Route;[Ljava/lang/String;)Ljava/net/HttpURLConnection;",Value.NULL,new Value[]{r[0], r[1]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/youtube/sponsorblock/requests/SBRequester;","Lapp/revanced/extension/shared/requests/Requester;->parseJSONObject(Ljava/net/HttpURLConnection;)Lorg/json/JSONObject;",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"Lorg/json/JSONObject;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_bdd0290a4cb8d347ef6e5703(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Failed to check VIP"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cf00139a922dbadd713314b2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Failed to check VIP (network error)"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
