package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_4685a8b19c14e6474063 {
static Value m_073728754db17e8f208ecfa2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->$VALUES:[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true); pc = 1; continue; }
case 1: { result = rt.invoke("virtual", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", "[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->clone()Ljava/lang/Object;", r[0], new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { r[0] = rt.cast(r[0], "[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;"); pc = 4; continue; }
case 4: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ec21a57c88254414a5ca0e3b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("SHORTS_PLAYER"); pc = 2; continue; }
case 2: { r[2] = Value.i32(0); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->SHORTS_PLAYER:Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true, r[0]); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("REGULAR_PLAYER"); pc = 7; continue; }
case 7: { r[2] = Value.i32(1); pc = 8; continue; }
case 8: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->REGULAR_PLAYER:Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true, r[0]); pc = 10; continue; }
case 10: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;"); pc = 11; continue; }
case 11: { r[1] = Value.ref("REGULAR_PLAYER_FULLSCREEN"); pc = 12; continue; }
case 12: { r[2] = Value.i32(2); pc = 13; continue; }
case 13: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 14; continue; }
case 14: { rt.writeField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->REGULAR_PLAYER_FULLSCREEN:Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true, r[0]); pc = 15; continue; }
case 15: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->$values()[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, new Value[]{}); pc = 16; continue; }
case 16: { r[0] = result; pc = 17; continue; }
case 17: { rt.writeField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->$VALUES:[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true, r[0]); pc = 18; continue; }
case 18: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_821caea7458074e3846db924(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9f4e42a8c140ff860a69c922(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->SHORTS_PLAYER:Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->REGULAR_PLAYER:Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;->REGULAR_PLAYER_FULLSCREEN:Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", Value.NULL, true); pc = 3; continue; }
case 3: { result = rt.filledArray("[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;", new Value[]{r[0], r[1], r[2]}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/patches/OpenShortsInRegularPlayerPatch$ShortsPlayerType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
