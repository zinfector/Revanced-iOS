package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_b23c12097b678f42a78a {
static ClassInfo info_b23c12097b678f42a78a() {return new ClassInfo("Lkotlin/enums/EnumEntriesKt;", "Ljava/lang/Object;", new String[]{}, 1025, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;", 25)});}
}
