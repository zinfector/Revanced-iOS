package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_58db4869e469d82ebf4a {
static Value m_1586941f042fbfd1f7ad176f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/net/HttpURLConnection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lorg/json/JSONArray;"); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/requests/Requester;->parseString(Ljava/net/HttpURLConnection;)Ljava/lang/String;",Value.NULL,new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Requester;","Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { return rt.check(r[0],"Lorg/json/JSONArray;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fdeceec092e2dd9092fe3ca3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(arguments[0], "Ljava/lang/String;");
r[1] = rt.check(arguments[1], "Lapp/revanced/extension/shared/requests/Route;");
r[2] = rt.check(arguments[2], "[Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/requests/Route;->compile([Ljava/lang/String;)Lapp/revanced/extension/shared/requests/Route$CompiledRoute;",r[1],new Value[]{r[2]}); pc = 1; continue; }
case 1: { r[1] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/requests/Requester;->getConnectionFromCompiledRoute(Ljava/lang/String;Lapp/revanced/extension/shared/requests/Route$CompiledRoute;)Ljava/net/HttpURLConnection;",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"Ljava/net/HttpURLConnection;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f71f59946cb06f36c263e7a9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Ljava/net/HttpURLConnection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;",r[0],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/requests/Requester;->parseInputStreamAndClose(Ljava/io/InputStream;)Ljava/lang/String;",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_22317948a790466524e792b9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Lapp/revanced/extension/shared/requests/Route$CompiledRoute;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/requests/Route$CompiledRoute;->getCompiledRoute()Ljava/lang/String;",r[2],new Value[]{}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { r[0] = rt.allocate("Ljava/net/URL;"); pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Requester;","Ljava/net/URL;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/net/URL;->openConnection()Ljava/net/URLConnection;",r[0],new Value[]{}); pc = 11; continue; }
case 11: { r[1] = result; pc = 12; continue; }
case 12: { r[1] = rt.cast(r[1],"Ljava/net/HttpURLConnection;"); pc = 13; continue; }
case 13: { r[0] = Value.i32(0); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V",r[1],new Value[]{r[0]}); pc = 15; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/requests/Route$CompiledRoute;->getMethod()Lapp/revanced/extension/shared/requests/Route$Method;",r[2],new Value[]{}); pc = 16; continue; }
case 16: { r[2] = result; pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/Enum;->name()Ljava/lang/String;",r[2],new Value[]{}); pc = 18; continue; }
case 18: { r[2] = result; pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 20; continue; }
case 20: { r[2] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 21; continue; }
case 21: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;-><init>()V",r[2],new Value[]{}); pc = 22; continue; }
case 22: { r[0] = Value.ref("http.agent"); pc = 23; continue; }
case 23: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;",Value.NULL,new Value[]{r[0]}); pc = 24; continue; }
case 24: { r[0] = result; pc = 25; continue; }
case 25: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 26; continue; }
case 26: { r[0] = Value.ref("; ReVanced/"); pc = 27; continue; }
case 27: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/Utils;->getAppVersionName()Ljava/lang/String;",Value.NULL,new Value[]{}); pc = 29; continue; }
case 29: { r[0] = result; pc = 30; continue; }
case 30: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 31; continue; }
case 31: { r[0] = Value.ref(" ("); pc = 32; continue; }
case 32: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 33; continue; }
case 33: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/Utils;->getPatchesReleaseVersion()Ljava/lang/String;",Value.NULL,new Value[]{}); pc = 34; continue; }
case 34: { r[0] = result; pc = 35; continue; }
case 35: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 36; continue; }
case 36: { r[0] = Value.ref(")"); pc = 37; continue; }
case 37: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[0]}); pc = 38; continue; }
case 38: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[2],new Value[]{}); pc = 39; continue; }
case 39: { r[2] = result; pc = 40; continue; }
case 40: { r[0] = Value.ref("User-Agent"); pc = 41; continue; }
case 41: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V",r[1],new Value[]{r[0], r[2]}); pc = 42; continue; }
case 42: { return rt.check(r[1],"Ljava/net/HttpURLConnection;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f5627de7cba061215ef806de(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/io/InputStream;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/io/BufferedReader;"); pc = 1; continue; }
case 1: { r[1] = rt.allocate("Ljava/io/InputStreamReader;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Requester;","Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V",r[1],new Value[]{r[2]}); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Requester;","Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { r[2] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;-><init>()V",r[2],new Value[]{}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/io/BufferedReader;->readLine()Ljava/lang/String;",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { pc=(ExecutableRuntime.equal(r[1],Value.i32(0)))?15:9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[2],new Value[]{r[1]}); pc = 10; continue; }
case 10: { r[1] = Value.i32(10); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;",r[2],new Value[]{r[1]}); pc = 12; continue; }
case 12: { pc=6; continue; }
case 13: { r[2] = Value.ref(exception); exception=null; pc = 14; continue; }
case 14: { pc=19; continue; }
case 15: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[2],new Value[]{}); pc = 16; continue; }
case 16: { r[2] = result; pc = 17; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/io/BufferedReader;->close()V",r[0],new Value[]{}); pc = 18; continue; }
case 18: { return rt.check(r[2],"Ljava/lang/String;"); }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/io/BufferedReader;->close()V",r[0],new Value[]{}); pc = 20; continue; }
case 20: { pc=23; continue; }
case 21: { r[0] = Value.ref(exception); exception=null; pc = 22; continue; }
case 22: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/requests/Requester;","Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V",r[2],new Value[]{r[0]}); pc = 23; continue; }
case 23: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 4 && pc < 17) { if(true) { exception=ExecutableRuntime.caught(error); pc=13; continue; } }
if(pc >= 19 && pc < 20) { if(true) { exception=ExecutableRuntime.caught(error); pc=21; continue; } }
throw error;
}
}

}

static Value m_29a589d186a38a0ad6748067(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/net/HttpURLConnection;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lorg/json/JSONObject;"); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/requests/Requester;","Lapp/revanced/extension/shared/requests/Requester;->parseString(Ljava/net/HttpURLConnection;)Ljava/lang/String;",Value.NULL,new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = result; pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/shared/requests/Requester;","Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { return rt.check(r[0],"Lorg/json/JSONObject;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
