package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_f26362e2b94463a39911 {
static Value m_31c60362fc94b02881499f6b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda7;");
r[1] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda7;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda7;->f$0:Landroid/view/View;",r[0],false,r[1]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_837da97e795f523ff0844633(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda7;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda7;->f$0:Landroid/view/View;",r[1],false); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton$$ExternalSyntheticLambda7;","Lapp/revanced/extension/youtube/videoplayer/PlayerControlButton;->$r8$lambda$4-JQLH9W2drH0xf1BvgxdrG6Amo(Landroid/view/View;)V",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
