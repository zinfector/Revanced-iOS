package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_ebb6a4acd04e8416a976 {
static Value m_54c6a7a799965fbb50287584(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;",r[1],false); pc = 1; continue; }
case 1: { r[0] = rt.cast(r[0],"Ljava/lang/Enum;"); pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/lang/Enum;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e116dc794582e1db50627a02(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Enum;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/EnumSetting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZLjava/lang/String;)V",r[0],new Value[]{r[1], r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c8a87bfe394621a7e5c26cd5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Enum;");
r[3] = rt.check(arguments[2], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/EnumSetting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;Z)V",r[0],new Value[]{r[1], r[2], r[3]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3dcc6099db523b13de4b49b5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/EnumSetting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;)V",r[0],new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_60d4369636bd382fa649ba05(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Enum;");
r[3] = rt.check(arguments[2], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/EnumSetting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;Lapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4200b28819c15559bb119367(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "Ljava/lang/Enum;");
r[3] = rt.check(arguments[2], "Z");
r[4] = rt.check(arguments[3], "Lapp/revanced/extension/shared/settings/Setting$Availability;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/EnumSetting;","Lapp/revanced/extension/shared/settings/Setting;-><init>(Ljava/lang/String;Ljava/lang/Object;ZLapp/revanced/extension/shared/settings/Setting$Availability;)V",r[0],new Value[]{r[1], r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_11d98f9b42ba2d990d86e80f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->preferences:Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;",r[3],false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;",r[3],false); pc = 3; continue; }
case 3: { r[2] = rt.cast(r[2],"Ljava/lang/Enum;"); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/EnumSetting;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->saveEnumAsString(Ljava/lang/String;Ljava/lang/Enum;)V",r[0],new Value[]{r[1], r[2]}); pc = 5; continue; }
case 5: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8ff87bb9505239d818eb2cd0(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->preferences:Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->key:Ljava/lang/String;",r[3],false); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/shared/settings/Setting;->defaultValue:Ljava/lang/Object;",r[3],false); pc = 3; continue; }
case 3: { r[2] = rt.cast(r[2],"Ljava/lang/Enum;"); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/EnumSetting;","Lapp/revanced/extension/shared/settings/preference/SharedPrefCategory;->getEnum(Ljava/lang/String;Ljava/lang/Enum;)Ljava/lang/Enum;",r[0],new Value[]{r[1], r[2]}); pc = 5; continue; }
case 5: { r[0] = result; pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/Setting;->value:Ljava/lang/Object;",r[3],false,r[0]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_fe799ee8b98b5688dd3aa863(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/EnumSetting;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/EnumSetting;","Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { return rt.check(r[0],"Ljava/lang/Object;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
