package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_3f3d5393350478ab extends RuntimeForeign.SourceProxy {
Source_3f3d5393350478ab(RuntimeForeign owner,Instance source){super(owner,source);}

}
