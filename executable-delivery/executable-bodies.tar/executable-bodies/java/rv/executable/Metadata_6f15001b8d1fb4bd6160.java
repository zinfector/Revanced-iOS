package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_6f15001b8d1fb4bd6160 {
static ClassInfo info_6f15001b8d1fb4bd6160() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;", "Ljava/lang/Object;", new String[]{"Ljava/lang/Runnable;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda4;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("run()V", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda4");}
}
