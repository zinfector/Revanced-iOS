package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_c4205e6cc603810a5bed {
static Value m_fcc48d3bc7a548ed9c7132dc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$1;");
r[1] = rt.check(arguments[0], "Landroid/view/View;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$1;->val$button:Landroid/view/View;",r[0],false,r[1]); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$1;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/patches/PlayerControlsPatch$1;->lastVisibility:I",r[0],false,r[1]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
