package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_ae511f57e59392af43fd {
static Value m_9321d6f4d44f278ad8898d2c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;->SPOOF_APP_VERSION_ENABLED:Z",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?8:2; continue; }
case 2: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;->SPOOF_APP_VERSION_TARGET:Ljava/lang/String;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;","Ljava/lang/String;->compareTo(Ljava/lang/String;)I",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { pc=(r[1].i() >= 0)?8:6; continue; }
case 6: { r[1] = Value.i32(1); pc = 7; continue; }
case 7: { return rt.check(r[1],"Z"); }
case 8: { r[1] = Value.i32(0); pc = 9; continue; }
case 9: { return rt.check(r[1],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_e5d537a04ec9d62b8aeb5718(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_APP_VERSION:Lapp/revanced/extension/shared/settings/BooleanSetting;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;","Lapp/revanced/extension/shared/settings/BooleanSetting;->get()Ljava/lang/Boolean;",r[0],new Value[]{}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;->SPOOF_APP_VERSION_ENABLED:Z",Value.NULL,true,r[0]); pc = 6; continue; }
case 6: { r[0] = rt.readField("Lapp/revanced/extension/youtube/settings/Settings;->SPOOF_APP_VERSION_TARGET:Lapp/revanced/extension/shared/settings/StringSetting;",Value.NULL,true); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;","Lapp/revanced/extension/shared/settings/StringSetting;->get()Ljava/lang/String;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { rt.writeField("Lapp/revanced/extension/youtube/patches/spoof/SpoofAppVersionPatch;->SPOOF_APP_VERSION_TARGET:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 10; continue; }
case 10: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
