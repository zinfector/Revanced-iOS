package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_d0d0e268ce2f783fa118 {
static Value m_4a8582a7d3da4146258fdd52(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[0] = rt.check(arguments[0], "Landroid/view/Window;");
r[1] = rt.check(arguments[1], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/settings/preference/ToolbarPreferenceFragment$$ExternalSyntheticApiModelOutline0;","Landroid/view/Window;->setNavigationBarContrastEnforced(Z)V",r[0],new Value[]{r[1]}); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
