package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_b0a3f6ebd0ef6edabd99 {
static Value m_3416ae98374043a07ae873bd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;","Ljava/lang/Object;-><init>()V",r[0],new Value[]{}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;->f$0:Ljava/lang/String;",r[0],false,r[1]); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;->f$1:I",r[0],false,r[2]); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6b052e22d013d1be344f5c0e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(receiver, "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;->f$0:Ljava/lang/String;",r[2],false); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;->f$1:I",r[2],false); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;","Lapp/revanced/extension/shared/Utils;->$r8$lambda$OwrbCJNttEfMUBPI9-VXyiYlI3g(Ljava/lang/String;I)V",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
