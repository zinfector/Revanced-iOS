package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Source_fca4c8a4dba2495d extends RuntimeForeign.SourceProxy {
Source_fca4c8a4dba2495d(RuntimeForeign owner,Instance source){super(owner,source);}

}
