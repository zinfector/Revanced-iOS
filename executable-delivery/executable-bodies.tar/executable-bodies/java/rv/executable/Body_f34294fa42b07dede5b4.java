package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_f34294fa42b07dede5b4 {
static Value m_d35a8ea639cbb2db253c6714(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;"); pc = 1; continue; }
case 1: { r[1] = Value.i32(0); pc = 2; continue; }
case 2: { r[2] = Value.ref("DEFAULT"); pc = 3; continue; }
case 3: { r[3] = Value.i32(0); pc = 4; continue; }
case 4: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V", r[0], new Value[]{r[2], r[3], r[1]}); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true, r[0]); pc = 6; continue; }
case 6: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;"); pc = 7; continue; }
case 7: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[3]}); pc = 8; continue; }
case 8: { r[1] = result; pc = 9; continue; }
case 9: { r[2] = Value.ref("UNKNOWN"); pc = 10; continue; }
case 10: { r[3] = Value.i32(1); pc = 11; continue; }
case 11: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V", r[0], new Value[]{r[2], r[3], r[1]}); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->UNKNOWN:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true, r[0]); pc = 13; continue; }
case 13: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;"); pc = 14; continue; }
case 14: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[3]}); pc = 15; continue; }
case 15: { r[1] = result; pc = 16; continue; }
case 16: { r[2] = Value.ref("SMALL"); pc = 17; continue; }
case 17: { r[3] = Value.i32(2); pc = 18; continue; }
case 18: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V", r[0], new Value[]{r[2], r[3], r[1]}); pc = 19; continue; }
case 19: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->SMALL:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true, r[0]); pc = 20; continue; }
case 20: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;"); pc = 21; continue; }
case 21: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[3]}); pc = 22; continue; }
case 22: { r[1] = result; pc = 23; continue; }
case 23: { r[2] = Value.ref("LARGE"); pc = 24; continue; }
case 24: { r[3] = Value.i32(3); pc = 25; continue; }
case 25: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V", r[0], new Value[]{r[2], r[3], r[1]}); pc = 26; continue; }
case 26: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->LARGE:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true, r[0]); pc = 27; continue; }
case 27: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;"); pc = 28; continue; }
case 28: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[3]}); pc = 29; continue; }
case 29: { r[1] = result; pc = 30; continue; }
case 30: { r[2] = Value.ref("AUTOMOTIVE"); pc = 31; continue; }
case 31: { r[3] = Value.i32(4); pc = 32; continue; }
case 32: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V", r[0], new Value[]{r[2], r[3], r[1]}); pc = 33; continue; }
case 33: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->AUTOMOTIVE:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true, r[0]); pc = 34; continue; }
case 34: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;"); pc = 35; continue; }
case 35: { r[1] = Value.i32(5); pc = 36; continue; }
case 36: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;", Value.NULL, new Value[]{r[3]}); pc = 37; continue; }
case 37: { r[2] = result; pc = 38; continue; }
case 38: { r[3] = Value.ref("WEARABLE"); pc = 39; continue; }
case 39: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;-><init>(Ljava/lang/String;ILjava/lang/Integer;)V", r[0], new Value[]{r[3], r[1], r[2]}); pc = 40; continue; }
case 40: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->WEARABLE:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true, r[0]); pc = 41; continue; }
case 41: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->$values()[Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, new Value[]{}); pc = 42; continue; }
case 42: { r[0] = result; pc = 43; continue; }
case 43: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->$VALUES:[Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true, r[0]); pc = 44; continue; }
case 44: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ff18300d8a908e43fab2bddf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new VerifyError("Parameter arity");
Value[] r = new Value[4];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Ljava/lang/Integer;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { rt.writeField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->formFactorType:Ljava/lang/Integer;", r[0], false, r[3]); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_32198fe0af60516d93eb9d75(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[6];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->DEFAULT:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->UNKNOWN:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->SMALL:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->LARGE:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->AUTOMOTIVE:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true); pc = 5; continue; }
case 5: { r[5] = rt.readField("Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;->WEARABLE:Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", Value.NULL, true); pc = 6; continue; }
case 6: { result = rt.filledArray("[Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;", new Value[]{r[0], r[1], r[2], r[3], r[4], r[5]}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/patches/ChangeFormFactorPatch$FormFactor;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
