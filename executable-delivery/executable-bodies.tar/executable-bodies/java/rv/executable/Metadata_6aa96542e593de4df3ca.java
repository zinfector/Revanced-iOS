package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_6aa96542e593de4df3ca {
static ClassInfo info_6aa96542e593de4df3ca() {return new ClassInfo("Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda2;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "Settings$$ExternalSyntheticLambda2");}
}
