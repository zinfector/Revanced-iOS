package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_a1ff284cb003da86060e {
static ClassInfo info_a1ff284cb003da86060e() {return new ClassInfo("Lapp/revanced/extension/youtube/settings/Settings$$ExternalSyntheticLambda3;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
