package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_3e3a2db20ee8f949a364 {
static Value m_d1d1b07b3ffcd734040ddbfd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[5] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/patches/EnableDebuggingPatch$$ExternalSyntheticBackport0;","Ljava/lang/String;->length()I",r[5],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { r[2] = r[1]; pc = 4; continue; }
case 4: { pc=(r[2].i() >= r[0].i())?15:5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/patches/EnableDebuggingPatch$$ExternalSyntheticBackport0;","Ljava/lang/String;->codePointAt(I)I",r[5],new Value[]{r[2]}); pc = 6; continue; }
case 6: { r[3] = result; pc = 7; continue; }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/shared/patches/EnableDebuggingPatch$$ExternalSyntheticBackport0;","Ljava/lang/Character;->isWhitespace(I)Z",Value.NULL,new Value[]{r[3]}); pc = 8; continue; }
case 8: { r[4] = result; pc = 9; continue; }
case 9: { pc=(!ExecutableRuntime.equal(r[4],Value.i32(0)))?11:10; continue; }
case 10: { return rt.check(r[1],"Z"); }
case 11: { result=rt.invoke("static","Lapp/revanced/extension/shared/patches/EnableDebuggingPatch$$ExternalSyntheticBackport0;","Ljava/lang/Character;->charCount(I)I",Value.NULL,new Value[]{r[3]}); pc = 12; continue; }
case 12: { r[3] = result; pc = 13; continue; }
case 13: { r[2] = Value.i32((r[2].i()) + (r[3].i())); pc = 14; continue; }
case 14: { pc=4; continue; }
case 15: { r[5] = Value.i32(1); pc = 16; continue; }
case 16: { return rt.check(r[5],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
