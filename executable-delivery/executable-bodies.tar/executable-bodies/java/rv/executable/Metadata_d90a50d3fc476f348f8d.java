package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_d90a50d3fc476f348f8d {
static ClassInfo info_d90a50d3fc476f348f8d() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/VideoAdsPatch;", "Ljava/lang/Object;", new String[]{}, 1, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/patches/VideoAdsPatch;->SHOW_VIDEO_ADS:Z", "Z", 26, ExecutableRuntime.zero("Z"))}, new MethodInfo[]{new MethodInfo("<clinit>()V", 65544), new MethodInfo("<init>()V", 65537), new MethodInfo("hideShortsAds(Ljava/lang/String;)Ljava/lang/String;", 9), new MethodInfo("shouldShowAds()Z", 9)}, "VideoAdsPatch");}
}
