package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_fb2cff6286d661a16a24 {
static ClassInfo info_fb2cff6286d661a16a24() {return new ClassInfo("Lapp/revanced/extension/youtube/shared/ShortsPlayerState$Companion;", "Ljava/lang/Object;", new String[]{}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("$r8$lambda$K_RfrUU8KI1JzPvXNBaHqZnpsks()Ljava/lang/String;", 9), new MethodInfo("<init>()V", 65538), new MethodInfo("<init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V", 69633), new MethodInfo("getOnChange$annotations()V", 4105), new MethodInfo("getOnChange()Lapp/revanced/extension/youtube/shared/Event;", 17), new MethodInfo("isOpen()Z", 17), new MethodInfo("setOpen(Z)V", 17)});}
}
