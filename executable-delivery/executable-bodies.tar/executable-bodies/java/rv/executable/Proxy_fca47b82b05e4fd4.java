package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_fca47b82b05e4fd4 extends RuntimeForeign.SourceProxy implements java.lang.Iterable {
Proxy_fca47b82b05e4fd4(RuntimeForeign owner,Instance source){super(owner,source);}
public java.util.Iterator iterator() {Value result=owner.callback(source,"Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;",new Value[]{}); return (java.util.Iterator)owner.exportObject(result.o(),"Ljava/util/Iterator;");}
}
