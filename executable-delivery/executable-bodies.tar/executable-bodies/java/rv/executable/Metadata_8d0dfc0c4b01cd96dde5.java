package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_8d0dfc0c4b01cd96dde5 {
static ClassInfo info_8d0dfc0c4b01cd96dde5() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/BackgroundPlaybackPatch;", "Ljava/lang/Object;", new String[]{}, 1, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("isBackgroundPlaybackAllowed(Z)Z", 9), new MethodInfo("isBackgroundShortsPlaybackAllowed(Z)Z", 9)}, "BackgroundPlaybackPatch");}
}
