package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_d0bc2b636d5ee94be9b3 {
static ClassInfo info_d0bc2b636d5ee94be9b3() {return new ClassInfo("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
