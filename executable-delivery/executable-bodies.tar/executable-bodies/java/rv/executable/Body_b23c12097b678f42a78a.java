package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_b23c12097b678f42a78a {
static Value m_c9272a9d2f6abaad8833f66d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "[Ljava/lang/Enum;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lkotlin/enums/EnumEntriesKt;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = rt.allocate("Lkotlin/enums/EnumEntriesList;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lkotlin/enums/EnumEntriesKt;","Lkotlin/enums/EnumEntriesList;-><init>([Ljava/lang/Enum;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { return rt.check(r[0],"Lkotlin/enums/EnumEntries;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
