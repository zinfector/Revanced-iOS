package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_b60d81a481563b520ac5 {
static Value m_6a3720111d2ddbeace1202cc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ID:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 1; continue; }
case 1: { r[1] = Value.ref("preference_title"); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;->ID_PREFERENCE_TITLE:I",Value.NULL,true,r[1]); pc = 5; continue; }
case 5: { r[1] = Value.ref("preference_summary"); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;->ID_PREFERENCE_SUMMARY:I",Value.NULL,true,r[1]); pc = 9; continue; }
case 9: { r[1] = Value.ref("preference_path"); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 11; continue; }
case 11: { r[1] = result; pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;->ID_PREFERENCE_PATH:I",Value.NULL,true,r[1]); pc = 13; continue; }
case 13: { r[1] = Value.ref("preference_switch"); pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 15; continue; }
case 15: { r[1] = result; pc = 16; continue; }
case 16: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;->ID_PREFERENCE_SWITCH:I",Value.NULL,true,r[1]); pc = 17; continue; }
case 17: { r[1] = Value.ref("preference_color_dot"); pc = 18; continue; }
case 18: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1]}); pc = 19; continue; }
case 19: { r[0] = result; pc = 20; continue; }
case 20: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;->ID_PREFERENCE_COLOR_DOT:I",Value.NULL,true,r[0]); pc = 21; continue; }
case 21: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_df09a8e880ae772793caa72b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[1] = rt.check(receiver, "Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;");
r[2] = rt.check(arguments[0], "Landroid/content/Context;");
r[3] = rt.check(arguments[1], "Ljava/util/List;");
r[4] = rt.check(arguments[2], "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;");
r[5] = rt.check(arguments[3], "Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;","Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V",r[1],new Value[]{r[2], r[0], r[3]}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;","Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;",Value.NULL,new Value[]{r[2]}); pc = 3; continue; }
case 3: { r[2] = result; pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;->inflater:Landroid/view/LayoutInflater;",r[1],false,r[2]); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;->fragment:Lapp/revanced/extension/shared/settings/search/BaseSearchViewController$BasePreferenceFragment;",r[1],false,r[4]); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/shared/settings/search/BaseSearchResultsAdapter;->searchViewController:Lapp/revanced/extension/shared/settings/search/BaseSearchViewController;",r[1],false,r[5]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
