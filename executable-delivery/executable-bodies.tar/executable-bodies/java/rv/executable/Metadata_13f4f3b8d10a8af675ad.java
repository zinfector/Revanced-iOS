package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_13f4f3b8d10a8af675ad {
static ClassInfo info_13f4f3b8d10a8af675ad() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda33;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/SegmentPlaybackController$$ExternalSyntheticLambda33;->f$0:Landroid/util/Range;", "Landroid/util/Range;", 4113, ExecutableRuntime.zero("Landroid/util/Range;"))}, new MethodInfo[]{new MethodInfo("<init>(Landroid/util/Range;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentPlaybackController$$ExternalSyntheticLambda33");}
}
