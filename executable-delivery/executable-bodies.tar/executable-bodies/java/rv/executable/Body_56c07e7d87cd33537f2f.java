package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_56c07e7d87cd33537f2f {
static Value m_34afc2c82d34085fb6f0c2ab(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[11];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("revanced_sb_skip_automatically"); pc = 2; continue; }
case 2: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;", Value.NULL, new Value[]{r[1]}); pc = 3; continue; }
case 3: { r[6] = result; pc = 4; continue; }
case 4: { r[1] = Value.ref("SKIP_AUTOMATICALLY"); pc = 5; continue; }
case 5: { r[2] = Value.i32(0); pc = 6; continue; }
case 6: { r[3] = Value.ref("skip"); pc = 7; continue; }
case 7: { r[4] = Value.i32(2); pc = 8; continue; }
case 8: { r[5] = Value.i32(1); pc = 9; continue; }
case 9: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;-><init>(Ljava/lang/String;ILjava/lang/String;IZLapp/revanced/extension/shared/StringRef;)V", r[0], new Value[]{r[1], r[2], r[3], r[4], r[5], r[6]}); pc = 10; continue; }
case 10: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SKIP_AUTOMATICALLY:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true, r[0]); pc = 11; continue; }
case 11: { r[1] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;"); pc = 12; continue; }
case 12: { r[0] = Value.ref("revanced_sb_skip_automatically_once"); pc = 13; continue; }
case 13: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;", Value.NULL, new Value[]{r[0]}); pc = 14; continue; }
case 14: { r[7] = result; pc = 15; continue; }
case 15: { r[2] = Value.ref("SKIP_AUTOMATICALLY_ONCE"); pc = 16; continue; }
case 16: { r[3] = Value.i32(1); pc = 17; continue; }
case 17: { r[4] = Value.ref("skip-once"); pc = 18; continue; }
case 18: { r[5] = Value.i32(3); pc = 19; continue; }
case 19: { r[6] = Value.i32(1); pc = 20; continue; }
case 20: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;-><init>(Ljava/lang/String;ILjava/lang/String;IZLapp/revanced/extension/shared/StringRef;)V", r[1], new Value[]{r[2], r[3], r[4], r[5], r[6], r[7]}); pc = 21; continue; }
case 21: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SKIP_AUTOMATICALLY_ONCE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true, r[1]); pc = 22; continue; }
case 22: { r[2] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;"); pc = 23; continue; }
case 23: { r[0] = Value.ref("revanced_sb_skip_showbutton"); pc = 24; continue; }
case 24: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;", Value.NULL, new Value[]{r[0]}); pc = 25; continue; }
case 25: { r[8] = result; pc = 26; continue; }
case 26: { r[3] = Value.ref("MANUAL_SKIP"); pc = 27; continue; }
case 27: { r[4] = Value.i32(2); pc = 28; continue; }
case 28: { r[5] = Value.ref("manual-skip"); pc = 29; continue; }
case 29: { r[7] = Value.i32(0); pc = 30; continue; }
case 30: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;-><init>(Ljava/lang/String;ILjava/lang/String;IZLapp/revanced/extension/shared/StringRef;)V", r[2], new Value[]{r[3], r[4], r[5], r[6], r[7], r[8]}); pc = 31; continue; }
case 31: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->MANUAL_SKIP:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true, r[2]); pc = 32; continue; }
case 32: { r[3] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;"); pc = 33; continue; }
case 33: { r[0] = Value.ref("revanced_sb_skip_seekbaronly"); pc = 34; continue; }
case 34: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;", Value.NULL, new Value[]{r[0]}); pc = 35; continue; }
case 35: { r[9] = result; pc = 36; continue; }
case 36: { r[4] = Value.ref("SHOW_IN_SEEKBAR"); pc = 37; continue; }
case 37: { r[5] = Value.i32(3); pc = 38; continue; }
case 38: { r[6] = Value.ref("seekbar-only"); pc = 39; continue; }
case 39: { r[8] = Value.i32(0); pc = 40; continue; }
case 40: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;-><init>(Ljava/lang/String;ILjava/lang/String;IZLapp/revanced/extension/shared/StringRef;)V", r[3], new Value[]{r[4], r[5], r[6], r[7], r[8], r[9]}); pc = 41; continue; }
case 41: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SHOW_IN_SEEKBAR:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true, r[3]); pc = 42; continue; }
case 42: { r[4] = rt.allocate("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;"); pc = 43; continue; }
case 43: { r[0] = Value.ref("revanced_sb_skip_ignore"); pc = 44; continue; }
case 44: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/shared/StringRef;->sf(Ljava/lang/String;)Lapp/revanced/extension/shared/StringRef;", Value.NULL, new Value[]{r[0]}); pc = 45; continue; }
case 45: { r[10] = result; pc = 46; continue; }
case 46: { r[5] = Value.ref("IGNORE"); pc = 47; continue; }
case 47: { r[6] = Value.i32(4); pc = 48; continue; }
case 48: { r[7] = Value.ref("ignore"); pc = 49; continue; }
case 49: { r[8] = Value.i32(-1); pc = 50; continue; }
case 50: { r[9] = Value.i32(0); pc = 51; continue; }
case 51: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;-><init>(Ljava/lang/String;ILjava/lang/String;IZLapp/revanced/extension/shared/StringRef;)V", r[4], new Value[]{r[5], r[6], r[7], r[8], r[9], r[10]}); pc = 52; continue; }
case 52: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->IGNORE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true, r[4]); pc = 53; continue; }
case 53: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->$values()[Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, new Value[]{}); pc = 54; continue; }
case 54: { r[0] = result; pc = 55; continue; }
case 55: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->$VALUES:[Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true, r[0]); pc = 56; continue; }
case 56: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5d6aecf8a202836f8b12c3a8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 6) throw new VerifyError("Parameter arity");
Value[] r = new Value[7];
r[0] = rt.check(receiver, "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;");
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "Ljava/lang/String;");
r[4] = rt.check(arguments[3], "I");
r[5] = rt.check(arguments[4], "Z");
r[6] = rt.check(arguments[5], "Lapp/revanced/extension/shared/StringRef;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("direct", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[3]}); pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->reVancedKeyValue:Ljava/lang/String;", r[0], false, r[3]); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->desktopKeyValue:I", r[0], false, r[4]); pc = 4; continue; }
case 4: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->skipAutomatically:Z", r[0], false, r[5]); pc = 5; continue; }
case 5: { result = rt.invoke("static", "Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[6]}); pc = 6; continue; }
case 6: { rt.writeField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->description:Lapp/revanced/extension/shared/StringRef;", r[0], false, r[6]); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c4e17b8daacd09c656043e79(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new VerifyError("Parameter arity");
Value[] r = new Value[5];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SKIP_AUTOMATICALLY:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 1; continue; }
case 1: { r[1] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SKIP_AUTOMATICALLY_ONCE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 2; continue; }
case 2: { r[2] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->MANUAL_SKIP:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 3; continue; }
case 3: { r[3] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->SHOW_IN_SEEKBAR:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 4; continue; }
case 4: { r[4] = rt.readField("Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;->IGNORE:Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", Value.NULL, true); pc = 5; continue; }
case 5: { result = rt.filledArray("[Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;", new Value[]{r[0], r[1], r[2], r[3], r[4]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { return rt.check(r[0], "[Lapp/revanced/extension/youtube/sponsorblock/objects/CategoryBehaviour;"); }
default: throw new VerifyError("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
