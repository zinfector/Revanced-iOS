package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_df03f95cc38a5c68cfb6 {
static ClassInfo info_df03f95cc38a5c68cfb6() {return new ClassInfo("Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lkotlin/jvm/functions/Function1;"}, 4113, new FieldInfo[]{new FieldInfo("Lkotlin/collections/AbstractCollection$$ExternalSyntheticLambda0;->f$0:Lkotlin/collections/AbstractCollection;", "Lkotlin/collections/AbstractCollection;", 4113, ExecutableRuntime.zero("Lkotlin/collections/AbstractCollection;"))}, new MethodInfo[]{new MethodInfo("<init>(Lkotlin/collections/AbstractCollection;)V", 69633), new MethodInfo("invoke(Ljava/lang/Object;)Ljava/lang/Object;", 17)});}
}
