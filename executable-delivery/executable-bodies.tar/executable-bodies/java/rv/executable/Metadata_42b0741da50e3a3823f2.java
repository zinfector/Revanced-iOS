package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_42b0741da50e3a3823f2 {
static ClassInfo info_42b0741da50e3a3823f2() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/SponsorBlockSettings$1;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$ImportExportCallback;"}, 0, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("settingsExported(Landroid/content/Context;)V", 1), new MethodInfo("settingsImported(Landroid/content/Context;)V", 1)});}
}
