package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Proxy_2f23a69a81efd3b1 extends RuntimeForeign.SourceProxy implements java.util.Set {
Proxy_2f23a69a81efd3b1(RuntimeForeign owner,Instance source){super(owner,source);}
public int size() {Value result=owner.callback(source,"Ljava/util/Set;->size()I",new Value[]{}); return result.i();}
public boolean isEmpty() {Value result=owner.callback(source,"Ljava/util/Set;->isEmpty()Z",new Value[]{}); return result.z();}
public boolean contains(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Set;->contains(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public java.util.Iterator iterator() {Value result=owner.callback(source,"Ljava/util/Set;->iterator()Ljava/util/Iterator;",new Value[]{}); return (java.util.Iterator)owner.exportObject(result.o(),"Ljava/util/Iterator;");}
public java.lang.Object[] toArray() {Value result=owner.callback(source,"Ljava/util/Set;->toArray()[Ljava/lang/Object;",new Value[]{}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public java.lang.Object[] toArray(java.lang.Object[] a0) {Value result=owner.callback(source,"Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;",new Value[]{owner.importValue(a0)}); return (java.lang.Object[])owner.exportObject(result.o(),"[Ljava/lang/Object;");}
public boolean add(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Set;->add(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean remove(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Set;->remove(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean containsAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean addAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Set;->addAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean retainAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Set;->retainAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public boolean removeAll(java.util.Collection a0) {Value result=owner.callback(source,"Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public void clear() {Value result=owner.callback(source,"Ljava/util/Set;->clear()V",new Value[]{}); return;}
public boolean equals(java.lang.Object a0) {Value result=owner.callback(source,"Ljava/util/Set;->equals(Ljava/lang/Object;)Z",new Value[]{owner.importValue(a0)}); return result.z();}
public int hashCode() {Value result=owner.callback(source,"Ljava/util/Set;->hashCode()I",new Value[]{}); return result.i();}
}
