package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_27a213441bc2609ed9b8 {
static ClassInfo info_27a213441bc2609ed9b8() {return new ClassInfo("Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda0;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/shared/StringRef$$ExternalSyntheticLambda0;->f$0:Lapp/revanced/extension/shared/StringRef;", "Lapp/revanced/extension/shared/StringRef;", 4113, ExecutableRuntime.zero("Lapp/revanced/extension/shared/StringRef;"))}, new MethodInfo[]{new MethodInfo("<init>(Lapp/revanced/extension/shared/StringRef;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)});}
}
