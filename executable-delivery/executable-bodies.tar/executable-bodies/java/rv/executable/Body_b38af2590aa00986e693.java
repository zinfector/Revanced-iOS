package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_b38af2590aa00986e693 {
static Value m_d133dd24051091352facc0c8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 4) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "I");
r[4] = rt.check(arguments[2], "Ljava/lang/Object;");
r[5] = rt.check(arguments[3], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/IndexOutOfBoundsException;"); pc = 1; continue; }
case 1: { r[1] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 2; continue; }
case 2: { result = rt.invoke("direct", "Lkotlin/collections/EmptyList$$ExternalSyntheticBUOutline0;", "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V", r[1], new Value[]{r[2]}); pc = 3; continue; }
case 3: { result = rt.invoke("virtual", "Lkotlin/collections/EmptyList$$ExternalSyntheticBUOutline0;", "Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;", r[1], new Value[]{r[3]}); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lkotlin/collections/EmptyList$$ExternalSyntheticBUOutline0;", "Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;", r[1], new Value[]{r[4]}); pc = 5; continue; }
case 5: { result = rt.invoke("virtual", "Lkotlin/collections/EmptyList$$ExternalSyntheticBUOutline0;", "Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;", r[1], new Value[]{r[5]}); pc = 6; continue; }
case 6: { result = rt.invoke("virtual", "Lkotlin/collections/EmptyList$$ExternalSyntheticBUOutline0;", "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;", r[1], new Value[]{}); pc = 7; continue; }
case 7: { r[2] = result; pc = 8; continue; }
case 8: { result = rt.invoke("direct", "Lkotlin/collections/EmptyList$$ExternalSyntheticBUOutline0;", "Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V", r[0], new Value[]{r[2]}); pc = 9; continue; }
case 9: { ExecutableRuntime.raise(r[0].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
