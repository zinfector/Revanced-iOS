package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_88bcb6a0c2cacbf5f46a {
static ClassInfo info_88bcb6a0c2cacbf5f46a() {return new ClassInfo("Lkotlin/collections/CollectionsKt__IterablesKt;", "Lkotlin/collections/CollectionsKt__CollectionsKt;", new String[]{}, 1025, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("collectionSizeOrDefault(Ljava/lang/Iterable;I)I", 9)}, "CollectionsKt__IterablesKt");}
}
