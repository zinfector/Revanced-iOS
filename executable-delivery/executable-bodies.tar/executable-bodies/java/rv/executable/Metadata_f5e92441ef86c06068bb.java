package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_f5e92441ef86c06068bb {
static ClassInfo info_f5e92441ef86c06068bb() {return new ClassInfo("Lapp/revanced/extension/youtube/patches/litho/PlayerFlyoutMenuItemsFilter$HideAudioFlyoutMenuAvailability;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/settings/Setting$Availability;"}, 17, new FieldInfo[]{}, new MethodInfo[]{new MethodInfo("<init>()V", 65537), new MethodInfo("getParentSettings()Ljava/util/List;", 1), new MethodInfo("isAvailable()Z", 1)});}
}
