package rv.executable;
import rv.executable.ExecutableRuntime.*;
final class Metadata_4711b040f959545c4470 {
static ClassInfo info_4711b040f959545c4470() {return new ClassInfo("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda1;", "Ljava/lang/Object;", new String[]{"Lapp/revanced/extension/shared/Logger$LogMessage;"}, 4113, new FieldInfo[]{new FieldInfo("Lapp/revanced/extension/youtube/sponsorblock/objects/SegmentCategory$$ExternalSyntheticLambda1;->f$0:Ljava/lang/String;", "Ljava/lang/String;", 4113, ExecutableRuntime.zero("Ljava/lang/String;"))}, new MethodInfo[]{new MethodInfo("<init>(Ljava/lang/String;)V", 69633), new MethodInfo("buildMessageString()Ljava/lang/String;", 17)}, "SegmentCategory$$ExternalSyntheticLambda1");}
}
