package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_e4c5e7a6950f1f6e0c2f {
static Value m_a7fb137736614ef3973ebdfc(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[3] = rt.check(arguments[0], "Landroid/content/Context;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda12;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda12;-><init>(Landroid/content/Context;)V",r[0],new Value[]{r[3]}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printInfo(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true,r[3]); pc = 4; continue; }
case 4: { r[0] = rt.readField("Lapp/revanced/extension/shared/settings/BaseSettings;->REVANCED_LANGUAGE:Lapp/revanced/extension/shared/settings/EnumSetting;",Value.NULL,true); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/settings/EnumSetting;->get()Ljava/lang/Enum;",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { r[0] = rt.cast(r[0],"Lapp/revanced/extension/shared/settings/AppLanguage;"); pc = 8; continue; }
case 8: { r[1] = rt.readField("Lapp/revanced/extension/shared/settings/AppLanguage;->DEFAULT:Lapp/revanced/extension/shared/settings/AppLanguage;",Value.NULL,true); pc = 9; continue; }
case 9: { pc=(ExecutableRuntime.equal(r[0],r[1]))?25:10; continue; }
case 10: { r[1] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;"); pc = 11; continue; }
case 11: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda13;-><init>(Lapp/revanced/extension/shared/settings/AppLanguage;)V",r[1],new Value[]{r[0]}); pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 13; continue; }
case 13: { r[1] = rt.allocate("Landroid/content/res/Configuration;"); pc = 14; continue; }
case 14: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->getResources()Landroid/content/res/Resources;",r[3],new Value[]{}); pc = 15; continue; }
case 15: { r[2] = result; pc = 16; continue; }
case 16: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;",r[2],new Value[]{}); pc = 17; continue; }
case 17: { r[2] = result; pc = 18; continue; }
case 18: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V",r[1],new Value[]{r[2]}); pc = 19; continue; }
case 19: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/settings/AppLanguage;->getLocale()Ljava/util/Locale;",r[0],new Value[]{}); pc = 20; continue; }
case 20: { r[0] = result; pc = 21; continue; }
case 21: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V",r[1],new Value[]{r[0]}); pc = 22; continue; }
case 22: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;",r[3],new Value[]{r[1]}); pc = 23; continue; }
case 23: { r[3] = result; pc = 24; continue; }
case 24: { rt.writeField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true,r[3]); pc = 25; continue; }
case 25: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeLightColorResourceName()Ljava/lang/String;",Value.NULL,new Value[]{}); pc = 26; continue; }
case 26: { r[3] = result; pc = 27; continue; }
case 27: { r[0] = Value.i32(-1); pc = 28; continue; }
case 28: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeColor(Ljava/lang/String;I)I",Value.NULL,new Value[]{r[3], r[0]}); pc = 29; continue; }
case 29: { r[3] = result; pc = 30; continue; }
case 30: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->setThemeLightColor(I)V",Value.NULL,new Value[]{r[3]}); pc = 31; continue; }
case 31: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeDarkColorResourceName()Ljava/lang/String;",Value.NULL,new Value[]{}); pc = 32; continue; }
case 32: { r[3] = result; pc = 33; continue; }
case 33: { r[0] = Value.i32(-16777216); pc = 34; continue; }
case 34: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeColor(Ljava/lang/String;I)I",Value.NULL,new Value[]{r[3], r[0]}); pc = 35; continue; }
case 35: { r[3] = result; pc = 36; continue; }
case 36: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->setThemeDarkColor(I)V",Value.NULL,new Value[]{r[3]}); pc = 37; continue; }
case 37: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cdd8ab49f971fd2d7842ba50(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?6:2; continue; }
case 2: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;-><init>()V",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[1] = Value.i32(0); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[0], r[1]}); pc = 6; continue; }
case 6: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true); pc = 7; continue; }
case 7: { return rt.check(r[0],"Landroid/content/Context;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_d6af8789b32578f29c5dc654(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->isCurrentlyOnMainThread()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?4:3; continue; }
case 3: { return Value.VOID; }
case 4: { r[0] = rt.allocate("Ljava/lang/IllegalStateException;"); pc = 5; continue; }
case 5: { r[1] = Value.ref("Must call _on_ the main thread"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { ExecutableRuntime.raise(r[0].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0c1492a3a1eb018afc4edde5(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;",Value.NULL,new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { rt.writeField("Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled:Ljava/lang/Boolean;",Value.NULL,true,r[0]); pc = 3; continue; }
case 3: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda24;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda24;-><init>(Z)V",r[0],new Value[]{r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_a429a7bbb898f29959565eac(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getNetworkType()Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->MOBILE:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],r[1]))?9:4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->OTHER:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 5; continue; }
case 5: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?7:6; continue; }
case 6: { pc=9; continue; }
case 7: { r[0] = Value.i32(0); pc = 8; continue; }
case 8: { return rt.check(r[0],"Z"); }
case 9: { r[0] = Value.i32(1); pc = 10; continue; }
case 10: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_195ae7ee2a46b10d5fa49193(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->backgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8fd0d86a7e58b94e81a998f9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(arguments[0], "Ljava/lang/Runnable;");
r[3] = rt.check(arguments[1], "J"); r[4] = r[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda22;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda22;-><init>(Ljava/lang/Runnable;)V",r[0],new Value[]{r[2]}); pc = 2; continue; }
case 2: { r[2] = rt.allocate("Landroid/os/Handler;"); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;",Value.NULL,new Value[]{}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Landroid/os/Handler;-><init>(Landroid/os/Looper;)V",r[2],new Value[]{r[1]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z",r[2],new Value[]{r[0], r[3]}); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ff3db72fd3b6fce1763f4187(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Landroid/view/View;");
r[2] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ID:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[2]}); pc = 2; continue; }
case 2: { r[2] = result; pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/view/View;->findViewById(I)Landroid/view/View;",r[1],new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { return rt.check(r[1],"Landroid/view/View;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0eb608c09ea1f5b17f4dbc47(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/ResourceType;");
r[2] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Landroid/content/Context;Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1], r[2]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { return rt.check(r[1],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_291c4294bb7501ffba04cf9e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Lapp/revanced/extension/shared/ResourceType;");
r[2] = rt.check(arguments[1], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifier(Landroid/content/Context;Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[0], r[1], r[2]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { return rt.check(r[1],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ef6ac09409e47ca0bbee4126(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("\\p{P}+"); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;",Value.NULL,new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/Utils;->PUNCTUATION_PATTERN:Ljava/util/regex/Pattern;",Value.NULL,true,r[0]); pc = 4; continue; }
case 4: { r[0] = Value.ref("\\p{M}"); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;",Value.NULL,new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/shared/Utils;->DIACRITICS_PATTERN:Ljava/util/regex/Pattern;",Value.NULL,true,r[0]); pc = 8; continue; }
case 8: { r[1] = rt.allocate("Ljava/util/concurrent/ThreadPoolExecutor;"); pc = 9; continue; }
case 9: { r[7] = rt.allocate("Ljava/util/concurrent/SynchronousQueue;"); pc = 10; continue; }
case 10: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/util/concurrent/SynchronousQueue;-><init>()V",r[7],new Value[]{}); pc = 11; continue; }
case 11: { r[8] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda20;"); pc = 12; continue; }
case 12: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda20;-><init>()V",r[8],new Value[]{}); pc = 13; continue; }
case 13: { r[2] = Value.i32(3); pc = 14; continue; }
case 14: { r[3] = Value.i32(2147483647); pc = 15; continue; }
case 15: { r[4] = Value.i64(10L); r[5] = r[4]; pc = 16; continue; }
case 16: { r[6] = rt.readField("Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;",Value.NULL,true); pc = 17; continue; }
case 17: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V",r[1],new Value[]{r[2], r[3], r[4], r[6], r[7], r[8]}); pc = 18; continue; }
case 18: { rt.writeField("Lapp/revanced/extension/shared/Utils;->backgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;",Value.NULL,true,r[1]); pc = 19; continue; }
case 19: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_af19a3ab59c22bdc111322e7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("#FFFFFFFF"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9c65452444a28448389f36cf(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getColorFromString(Ljava/lang/String;)I",Value.NULL,new Value[]{r[2]}); pc = 1; continue; }
case 1: { r[2] = result; pc = 2; continue; }
case 2: { return rt.check(r[2],"I"); }
case 3: { r[0] = Value.ref(exception); exception=null; pc = 4; continue; }
case 4: { r[1] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda19;"); pc = 5; continue; }
case 5: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda19;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 7; continue; }
case 7: { return rt.check(r[3],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 2) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=3; continue; } }
throw error;
}
}

}

static Value m_98fdd4e047a9b5c108072345(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda9;-><init>(I)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/Utils;->lightColor:I",Value.NULL,true,r[1]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_895fe575595410e39b2be8aa(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("#FF000000"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_81dc59be4e617daa328ddd00(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda21;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda21;-><init>(I)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/Utils;->darkColor:I",Value.NULL,true,r[1]); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_89cd0119b08db4e3c23ab865(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/Thread;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V",r[0],new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = Value.i32(10); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Thread;->setPriority(I)V",r[0],new Value[]{r[1]}); pc = 4; continue; }
case 4: { return rt.check(r[0],"Ljava/lang/Thread;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_52486034b7d7bcb0f773f677(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/os/Looper;->isCurrentThread()Z",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_43da65d3b7fdb6738ff259ee(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
r[0] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { rt.writeField("Lapp/revanced/extension/shared/Utils;->appIsUsingBoldIcons:Z",Value.NULL,true,r[0]); pc = 1; continue; }
case 1: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_671f08c07344012e5eb3161a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->versionName:Ljava/lang/String;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?13:2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getPackageInfo()Landroid/content/pm/PackageInfo;",Value.NULL,new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[0] = rt.readField("Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;",r[0],false); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/Utils;->versionName:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 6; continue; }
case 6: { pc=13; continue; }
case 7: { r[0] = Value.ref(exception); exception=null; pc = 8; continue; }
case 8: { r[1] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda11;"); pc = 9; continue; }
case 9: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda11;-><init>()V",r[1],new Value[]{}); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 11; continue; }
case 11: { r[0] = Value.ref("Unknown"); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/Utils;->versionName:Ljava/lang/String;",Value.NULL,true,r[0]); pc = 13; continue; }
case 13: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->versionName:Ljava/lang/String;",Value.NULL,true); pc = 14; continue; }
case 14: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 2 && pc < 6) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=7; continue; } }
throw error;
}
}

}

static Value m_35e891243fb5715745b39c08(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?5:3; continue; }
case 3: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->NONE:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 4; continue; }
case 4: { return rt.check(r[0],"Lapp/revanced/extension/shared/Utils$NetworkType;"); }
case 5: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true); pc = 6; continue; }
case 6: { r[1] = Value.ref("connectivity"); pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;",r[0],new Value[]{r[1]}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { r[0] = rt.cast(r[0],"Landroid/net/ConnectivityManager;"); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;",r[0],new Value[]{}); pc = 11; continue; }
case 11: { r[0] = result; pc = 12; continue; }
case 12: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?27:13; continue; }
case 13: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/net/NetworkInfo;->isConnected()Z",r[0],new Value[]{}); pc = 14; continue; }
case 14: { r[1] = result; pc = 15; continue; }
case 15: { pc=(!ExecutableRuntime.equal(r[1],Value.i32(0)))?17:16; continue; }
case 16: { pc=27; continue; }
case 17: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/net/NetworkInfo;->getType()I",r[0],new Value[]{}); pc = 18; continue; }
case 18: { r[0] = result; pc = 19; continue; }
case 19: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?25:20; continue; }
case 20: { r[1] = Value.i32(7); pc = 21; continue; }
case 21: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?23:22; continue; }
case 22: { pc=25; continue; }
case 23: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->OTHER:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 24; continue; }
case 24: { return rt.check(r[0],"Lapp/revanced/extension/shared/Utils$NetworkType;"); }
case 25: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->MOBILE:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 26; continue; }
case 26: { return rt.check(r[0],"Lapp/revanced/extension/shared/Utils$NetworkType;"); }
case 27: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils$NetworkType;->NONE:Lapp/revanced/extension/shared/Utils$NetworkType;",Value.NULL,true); pc = 28; continue; }
case 28: { return rt.check(r[0],"Lapp/revanced/extension/shared/Utils$NetworkType;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_760dc00b5bc93f75b53d2f21(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->appIsUsingBoldIcons:Z",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_54c639816ae3453d5b859c23(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->getResources()Landroid/content/res/Resources;",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->INTEGER:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Resources;->getInteger(I)I",r[0],new Value[]{r[2]}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f893c6bf7073f583755e78ef(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->runOnMainThreadDelayed(Ljava/lang/Runnable;J)V",Value.NULL,new Value[]{r[2], r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_13bbc5dddbb08fcecfda2a11(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(arguments[0], "Landroid/content/Context;");
r[3] = rt.check(arguments[1], "Lapp/revanced/extension/shared/ResourceType;");
r[4] = rt.check(arguments[2], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifier(Landroid/content/Context;Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[2], r[3], r[4]}); pc = 1; continue; }
case 1: { r[2] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?4:3; continue; }
case 3: { return rt.check(r[2],"I"); }
case 4: { r[2] = rt.allocate("Landroid/content/res/Resources$NotFoundException;"); pc = 5; continue; }
case 5: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 6; continue; }
case 6: { r[1] = Value.ref("No resource id exists with name: "); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[4]}); pc = 9; continue; }
case 9: { r[4] = Value.ref(" type: "); pc = 10; continue; }
case 10: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[4]}); pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[3]}); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 13; continue; }
case 13: { r[3] = result; pc = 14; continue; }
case 14: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V",r[2],new Value[]{r[3]}); pc = 15; continue; }
case 15: { ExecutableRuntime.raise(r[2].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2c448e90d633173a2967cdb3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[1] = rt.check(arguments[0], "Landroid/content/Context;");
r[2] = rt.check(arguments[1], "Lapp/revanced/extension/shared/ResourceType;");
r[3] = rt.check(arguments[2], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->getResources()Landroid/content/res/Resources;",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[2],Value.i32(0)))?5:3; continue; }
case 3: { r[2] = Value.i32(0); pc = 4; continue; }
case 4: { pc=6; continue; }
case 5: { r[2] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->value:Ljava/lang/String;",r[2],false); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->getPackageName()Ljava/lang/String;",r[1],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I",r[0],new Value[]{r[3], r[2], r[1]}); pc = 9; continue; }
case 9: { r[1] = result; pc = 10; continue; }
case 10: { return rt.check(r[1],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f11fc400298d717f1de248ff(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->getResources()Landroid/content/res/Resources;",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->COLOR:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Resources;->getColor(I)I",r[0],new Value[]{r[2]}); pc = 8; continue; }
case 8: { r[2] = result; pc = 9; continue; }
case 9: { return rt.check(r[2],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_02d94912c6d3962cef5a25a1(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("#"); pc = 1; continue; }
case 1: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/String;->startsWith(Ljava/lang/String;)Z",r[1],new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?7:4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I",Value.NULL,new Value[]{r[1]}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { return rt.check(r[1],"I"); }
case 7: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getResourceColor(Ljava/lang/String;)I",Value.NULL,new Value[]{r[1]}); pc = 8; continue; }
case 8: { r[1] = result; pc = 9; continue; }
case 9: { return rt.check(r[1],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5a47b2f7416730ca5a80b50f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(1); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->showToast(Ljava/lang/String;I)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1abe1213599e4a5a3a925896(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[7];
r[4] = rt.check(arguments[0], "Landroid/view/ViewGroup;");
r[5] = rt.check(arguments[1], "Z");
r[6] = rt.check(arguments[2], "Lapp/revanced/extension/shared/Utils$MatchFilter;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/view/ViewGroup;->getChildCount()I",r[4],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = Value.i32(0); pc = 3; continue; }
case 3: { pc=(r[1].i() >= r[0].i())?21:4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;",r[4],new Value[]{r[1]}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { result=rt.invoke("interface","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$MatchFilter;->matches(Ljava/lang/Object;)Z",r[6],new Value[]{r[2]}); pc = 7; continue; }
case 7: { r[3] = result; pc = 8; continue; }
case 8: { pc=(ExecutableRuntime.equal(r[3],Value.i32(0)))?10:9; continue; }
case 9: { return rt.check(r[2],"Landroid/view/View;"); }
case 10: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?19:11; continue; }
case 11: { r[3] = Value.i32(rt.isInstance(r[2].o(),"Landroid/view/ViewGroup;")?1:0); pc = 12; continue; }
case 12: { pc=(ExecutableRuntime.equal(r[3],Value.i32(0)))?19:13; continue; }
case 13: { r[2] = rt.cast(r[2],"Landroid/view/ViewGroup;"); pc = 14; continue; }
case 14: { r[3] = Value.i32(1); pc = 15; continue; }
case 15: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getChildView(Landroid/view/ViewGroup;ZLapp/revanced/extension/shared/Utils$MatchFilter;)Landroid/view/View;",Value.NULL,new Value[]{r[2], r[3], r[6]}); pc = 16; continue; }
case 16: { r[2] = result; pc = 17; continue; }
case 17: { pc=(ExecutableRuntime.equal(r[2],Value.i32(0)))?19:18; continue; }
case 18: { return rt.check(r[2],"Landroid/view/View;"); }
case 19: { r[1] = Value.i32((r[1].i()) + (1)); pc = 20; continue; }
case 20: { pc=3; continue; }
case 21: { r[4] = Value.i32(0); pc = 22; continue; }
case 22: { return rt.check(r[4],"Landroid/view/View;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9c6a8e385e90d5a9ffb83e08(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?6:3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeLightColor()I",Value.NULL,new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { return rt.check(r[0],"I"); }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeDarkColor()I",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_81a9367a1390204552044c1c(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled:Ljava/lang/Boolean;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Boolean;->booleanValue()Z",r[0],new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"Z"); }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;",Value.NULL,new Value[]{}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;",r[0],new Value[]{}); pc = 8; continue; }
case 8: { r[0] = result; pc = 9; continue; }
case 9: { r[0] = rt.readField("Landroid/content/res/Configuration;->uiMode:I",r[0],false); pc = 10; continue; }
case 10: { r[0] = Value.i32((r[0].i()) & (48)); pc = 11; continue; }
case 11: { r[1] = Value.i32(32); pc = 12; continue; }
case 12: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?15:13; continue; }
case 13: { r[0] = Value.i32(1); pc = 14; continue; }
case 14: { return rt.check(r[0],"Z"); }
case 15: { r[0] = Value.i32(0); pc = 16; continue; }
case 16: { return rt.check(r[0],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_730f478efadedd28130cc2de(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[0]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->getPackageName()Ljava/lang/String;",r[0],new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;",r[1],new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { r[2] = rt.readField("Landroid/os/Build$VERSION;->SDK_INT:I",Value.NULL,true); pc = 9; continue; }
case 9: { r[3] = Value.i32(33); pc = 10; continue; }
case 10: { pc=(r[2].i() < r[3].i())?17:11; continue; }
case 11: { r[2] = Value.i64(0L); r[3] = r[2]; pc = 12; continue; }
case 12: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticApiModelOutline0;->m(J)Landroid/content/pm/PackageManager$PackageInfoFlags;",Value.NULL,new Value[]{r[2]}); pc = 13; continue; }
case 13: { r[2] = result; pc = 14; continue; }
case 14: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticApiModelOutline1;->m(Landroid/content/pm/PackageManager;Ljava/lang/String;Landroid/content/pm/PackageManager$PackageInfoFlags;)Landroid/content/pm/PackageInfo;",Value.NULL,new Value[]{r[1], r[0], r[2]}); pc = 15; continue; }
case 15: { r[0] = result; pc = 16; continue; }
case 16: { return rt.check(r[0],"Landroid/content/pm/PackageInfo;"); }
case 17: { r[2] = Value.i32(0); pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;",r[1],new Value[]{r[0], r[2]}); pc = 19; continue; }
case 19: { r[0] = result; pc = 20; continue; }
case 20: { return rt.check(r[0],"Landroid/content/pm/PackageInfo;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6cdc61fc1e4e0a2e5163bd6a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;",Value.NULL,new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;"); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[1], r[2]}); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->runOnMainThreadNowOrLater(Ljava/lang/Runnable;)V",Value.NULL,new Value[]{r[0]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_29338bab1f9df1008b10be83(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Setting theme dark color: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getColorHexString(I)Ljava/lang/String;",Value.NULL,new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[2] = result; pc = 8; continue; }
case 8: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_4f49558e1f746e310af2a0b2(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Dark mode status: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2d15de1e0ec4539421f366f8(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Invalid custom theme color: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_3a3541013b494f8a93643c5a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Setting theme light color: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getColorHexString(I)Ljava/lang/String;",Value.NULL,new Value[]{r[2]}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 7; continue; }
case 7: { r[2] = result; pc = 8; continue; }
case 8: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5bb37b01a13b0d4ea722adf4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Context is not set by extension hook, returning null"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_42a00195f8c9101fdb81b239(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Lapp/revanced/extension/shared/settings/AppLanguage;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Using app language: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_0dd4b682f2d7553dba2dddf6(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Landroid/content/Context;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Set context: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6bac424b49f50164fc4cff6d(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?6:3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeDarkColor()I",Value.NULL,new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { return rt.check(r[0],"I"); }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeLightColor()I",Value.NULL,new Value[]{}); pc = 7; continue; }
case 7: { r[0] = result; pc = 8; continue; }
case 8: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_81199229ac886d394c15183e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->lightColor:I",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_9eaa33085ffd954eacec2b49(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->darkColor:I",Value.NULL,true); pc = 1; continue; }
case 1: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7d99b3ea9eec3382f4257bf3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Failed to get package info"); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_25b71942bb809b579086f918(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->isCurrentlyOnMainThread()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?5:3; continue; }
case 3: { result=rt.invoke("interface","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Runnable;->run()V",r[1],new Value[]{}); pc = 4; continue; }
case 4: { return Value.VOID; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->runOnMainThread(Ljava/lang/Runnable;)V",Value.NULL,new Value[]{r[1]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_309080ca769215a9b4f8399a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(16777215); pc = 1; continue; }
case 1: { r[2] = Value.i32((r[2].i()) & (r[0].i())); pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;",Value.NULL,new Value[]{r[2]}); pc = 3; continue; }
case 3: { r[2] = result; pc = 4; continue; }
case 4: { r[0] = Value.i32(1); pc = 5; continue; }
case 5: { r[0] = rt.newArray("[Ljava/lang/Object;",r[0].i()); pc = 6; continue; }
case 6: { r[1] = Value.i32(0); pc = 7; continue; }
case 7: { rt.arrayPut(r[0],r[1].i(),r[2]); pc = 8; continue; }
case 8: { r[2] = Value.ref("#%06X"); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;",Value.NULL,new Value[]{r[2], r[0]}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8a392802ef9f0ac8a1805970(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("interface","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Runnable;->run()V",r[2],new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
case 2: { r[0] = Value.ref(exception); exception=null; pc = 3; continue; }
case 3: { r[1] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;"); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;-><init>(Ljava/lang/Runnable;Ljava/lang/Exception;)V",r[1],new Value[]{r[2], r[0]}); pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 1) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=2; continue; } }
throw error;
}
}

}

static Value m_b837e1738be4e47bbbf26f53(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;",Value.NULL,true); pc = 1; continue; }
case 1: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?6:2; continue; }
case 2: { r[3] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda14;"); pc = 3; continue; }
case 3: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda14;-><init>(Ljava/lang/String;)V",r[3],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[3]}); pc = 5; continue; }
case 5: { return Value.VOID; }
case 6: { r[1] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;"); pc = 7; continue; }
case 7: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;-><init>(Ljava/lang/String;)V",r[1],new Value[]{r[2]}); pc = 8; continue; }
case 8: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V",Value.NULL,new Value[]{r[1]}); pc = 9; continue; }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;",Value.NULL,new Value[]{r[0], r[2], r[3]}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/widget/Toast;->show()V",r[2],new Value[]{}); pc = 12; continue; }
case 12: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_c959987ff9aa0ffac3e1dfab(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/util/Locale;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/util/Locale;->getDisplayLanguage()Ljava/lang/String;",r[2],new Value[]{}); pc = 1; continue; }
case 1: { r[2] = result; pc = 2; continue; }
case 2: { r[0] = rt.allocate("Ljava/text/Bidi;"); pc = 3; continue; }
case 3: { r[1] = Value.i32(-2); pc = 4; continue; }
case 4: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/text/Bidi;-><init>(Ljava/lang/String;I)V",r[0],new Value[]{r[2], r[1]}); pc = 5; continue; }
case 5: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/text/Bidi;->isRightToLeft()Z",r[0],new Value[]{}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { return rt.check(r[2],"Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5f7a6c4c495deff8dd49ed23(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->isCurrentlyOnMainThread()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(!ExecutableRuntime.equal(r[0],Value.i32(0)))?4:3; continue; }
case 3: { return Value.VOID; }
case 4: { r[0] = rt.allocate("Ljava/lang/IllegalStateException;"); pc = 5; continue; }
case 5: { r[1] = Value.ref("Must call _off_ the main thread"); pc = 6; continue; }
case 6: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { ExecutableRuntime.raise(r[0].o()); throw new AssertionError("Unreachable throw"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_68ae91754d630aeec02eb025(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Ljava/lang/Runnable;");
r[2] = rt.check(arguments[1], "Ljava/lang/Exception;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>()V",r[0],new Value[]{}); pc = 2; continue; }
case 2: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Object;->getClass()Ljava/lang/Class;",r[1],new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Class;->getSimpleName()Ljava/lang/String;",r[1],new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 7; continue; }
case 7: { r[1] = Value.ref(": "); pc = 8; continue; }
case 8: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 9; continue; }
case 9: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Throwable;->getMessage()Ljava/lang/String;",r[2],new Value[]{}); pc = 10; continue; }
case 10: { r[1] = result; pc = 11; continue; }
case 11: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[1]}); pc = 12; continue; }
case 12: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 13; continue; }
case 13: { r[1] = result; pc = 14; continue; }
case 14: { return rt.check(r[1],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6199d9bb0a3d4f86b0150055(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->isDarkModeEnabled()Z",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc=(ExecutableRuntime.equal(r[0],Value.i32(0)))?9:3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeDarkColor()I",Value.NULL,new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[1] = Value.i32(-16777216); pc = 6; continue; }
case 6: { pc=(!ExecutableRuntime.equal(r[0],r[1]))?8:7; continue; }
case 7: { r[0] = Value.i32(-16250872); pc = 8; continue; }
case 8: { return rt.check(r[0],"I"); }
case 9: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getThemeLightColor()I",Value.NULL,new Value[]{}); pc = 10; continue; }
case 10: { r[0] = result; pc = 11; continue; }
case 11: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ed53ec525f8a8f118420795e(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;",Value.NULL,new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { r[1] = rt.readField("Lapp/revanced/extension/shared/ResourceType;->ANIM:Lapp/revanced/extension/shared/ResourceType;",Value.NULL,true); pc = 3; continue; }
case 3: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->getResourceIdentifierOrThrow(Lapp/revanced/extension/shared/ResourceType;Ljava/lang/String;)I",Value.NULL,new Value[]{r[1], r[2]}); pc = 4; continue; }
case 4: { r[2] = result; pc = 5; continue; }
case 5: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;",Value.NULL,new Value[]{r[0], r[2]}); pc = 6; continue; }
case 6: { r[2] = result; pc = 7; continue; }
case 7: { return rt.check(r[2],"Landroid/view/animation/Animation;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_58828b1d28aa74baf16dca70(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 5) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[6];
r[1] = rt.check(arguments[0], "Landroid/view/Window;");
r[2] = rt.check(arguments[1], "I");
r[3] = rt.check(arguments[2], "I");
r[4] = rt.check(arguments[3], "I");
r[5] = rt.check(arguments[4], "Z");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;",r[1],new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/ui/Dim;->pctPortraitWidth(I)I",Value.NULL,new Value[]{r[4]}); pc = 3; continue; }
case 3: { r[4] = result; pc = 4; continue; }
case 4: { rt.writeField("Landroid/view/WindowManager$LayoutParams;->width:I",r[0],false,r[4]); pc = 5; continue; }
case 5: { r[4] = Value.i32(-2); pc = 6; continue; }
case 6: { rt.writeField("Landroid/view/WindowManager$LayoutParams;->height:I",r[0],false,r[4]); pc = 7; continue; }
case 7: { rt.writeField("Landroid/view/WindowManager$LayoutParams;->gravity:I",r[0],false,r[2]); pc = 8; continue; }
case 8: { pc=(r[3].i() <= 0)?13:9; continue; }
case 9: { r[2] = Value.f32((float)(r[3].i())); pc = 10; continue; }
case 10: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/ui/Dim;->dp(F)I",Value.NULL,new Value[]{r[2]}); pc = 11; continue; }
case 11: { r[2] = result; pc = 12; continue; }
case 12: { pc=14; continue; }
case 13: { r[2] = Value.i32(0); pc = 14; continue; }
case 14: { rt.writeField("Landroid/view/WindowManager$LayoutParams;->y:I",r[0],false,r[2]); pc = 15; continue; }
case 15: { pc=(ExecutableRuntime.equal(r[5],Value.i32(0)))?18:16; continue; }
case 16: { r[2] = Value.i32(0); pc = 17; continue; }
case 17: { rt.writeField("Landroid/view/WindowManager$LayoutParams;->dimAmount:F",r[0],false,r[2]); pc = 18; continue; }
case 18: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V",r[1],new Value[]{r[0]}); pc = 19; continue; }
case 19: { r[2] = Value.i32(0); pc = 20; continue; }
case 20: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V",r[1],new Value[]{r[2]}); pc = 21; continue; }
case 21: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_76522245bcd200a9664b32cd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Cannot show toast (context is null): "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_404fd9479c428a1ecb569974(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Showing toast: "); pc = 2; continue; }
case 2: { result=rt.invoke("direct","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V",r[0],new Value[]{r[1]}); pc = 3; continue; }
case 3: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;",r[0],new Value[]{r[2]}); pc = 4; continue; }
case 4: { result=rt.invoke("virtual","Lapp/revanced/extension/shared/Utils;","Ljava/lang/StringBuilder;->toString()Ljava/lang/String;",r[0],new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_2745729767680ab56a1eb58b(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[8];
r[6] = rt.check(arguments[0], "I");
r[7] = rt.check(arguments[1], "F");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/graphics/Color;->alpha(I)I",Value.NULL,new Value[]{r[6]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/graphics/Color;->red(I)I",Value.NULL,new Value[]{r[6]}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/graphics/Color;->green(I)I",Value.NULL,new Value[]{r[6]}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/graphics/Color;->blue(I)I",Value.NULL,new Value[]{r[6]}); pc = 7; continue; }
case 7: { r[6] = result; pc = 8; continue; }
case 8: { r[3] = Value.i32(1065353216); pc = 9; continue; }
case 9: { r[4] = Value.i32(ExecutableRuntime.compareFloat(r[7].f(), r[3].f(), -1)); pc = 10; continue; }
case 10: { r[5] = Value.i32(255); pc = 11; continue; }
case 11: { pc=(r[4].i() <= 0)?36:12; continue; }
case 12: { r[7] = Value.f32((r[3].f()) / (r[7].f())); pc = 13; continue; }
case 13: { r[3] = Value.f32((r[3].f()) - (r[7].f())); pc = 14; continue; }
case 14: { r[7] = Value.f32((float)(r[1].i())); pc = 15; continue; }
case 15: { r[1] = Value.i32((255) - (r[1].i())); pc = 16; continue; }
case 16: { r[1] = Value.f32((float)(r[1].i())); pc = 17; continue; }
case 17: { r[1] = Value.f32((r[1].f()) * (r[3].f())); pc = 18; continue; }
case 18: { r[7] = Value.f32((r[7].f()) + (r[1].f())); pc = 19; continue; }
case 19: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Math;->round(F)I",Value.NULL,new Value[]{r[7]}); pc = 20; continue; }
case 20: { r[7] = result; pc = 21; continue; }
case 21: { r[1] = Value.f32((float)(r[2].i())); pc = 22; continue; }
case 22: { r[2] = Value.i32((255) - (r[2].i())); pc = 23; continue; }
case 23: { r[2] = Value.f32((float)(r[2].i())); pc = 24; continue; }
case 24: { r[2] = Value.f32((r[2].f()) * (r[3].f())); pc = 25; continue; }
case 25: { r[1] = Value.f32((r[1].f()) + (r[2].f())); pc = 26; continue; }
case 26: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Math;->round(F)I",Value.NULL,new Value[]{r[1]}); pc = 27; continue; }
case 27: { r[1] = result; pc = 28; continue; }
case 28: { r[2] = Value.f32((float)(r[6].i())); pc = 29; continue; }
case 29: { r[6] = Value.i32((255) - (r[6].i())); pc = 30; continue; }
case 30: { r[6] = Value.f32((float)(r[6].i())); pc = 31; continue; }
case 31: { r[6] = Value.f32((r[6].f()) * (r[3].f())); pc = 32; continue; }
case 32: { r[2] = Value.f32((r[2].f()) + (r[6].f())); pc = 33; continue; }
case 33: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Math;->round(F)I",Value.NULL,new Value[]{r[2]}); pc = 34; continue; }
case 34: { r[6] = result; pc = 35; continue; }
case 35: { pc=50; continue; }
case 36: { r[1] = Value.f32((float)(r[1].i())); pc = 37; continue; }
case 37: { r[1] = Value.f32((r[1].f()) * (r[7].f())); pc = 38; continue; }
case 38: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Math;->round(F)I",Value.NULL,new Value[]{r[1]}); pc = 39; continue; }
case 39: { r[1] = result; pc = 40; continue; }
case 40: { r[2] = Value.f32((float)(r[2].i())); pc = 41; continue; }
case 41: { r[2] = Value.f32((r[2].f()) * (r[7].f())); pc = 42; continue; }
case 42: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Math;->round(F)I",Value.NULL,new Value[]{r[2]}); pc = 43; continue; }
case 43: { r[2] = result; pc = 44; continue; }
case 44: { r[6] = Value.f32((float)(r[6].i())); pc = 45; continue; }
case 45: { r[6] = Value.f32((r[6].f()) * (r[7].f())); pc = 46; continue; }
case 46: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Math;->round(F)I",Value.NULL,new Value[]{r[6]}); pc = 47; continue; }
case 47: { r[6] = result; pc = 48; continue; }
case 48: { r[7] = r[1]; pc = 49; continue; }
case 49: { r[1] = r[2]; pc = 50; continue; }
case 50: { r[2] = Value.i32(0); pc = 51; continue; }
case 51: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->clamp(III)I",Value.NULL,new Value[]{r[7], r[2], r[5]}); pc = 52; continue; }
case 52: { r[7] = result; pc = 53; continue; }
case 53: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->clamp(III)I",Value.NULL,new Value[]{r[1], r[2], r[5]}); pc = 54; continue; }
case 54: { r[1] = result; pc = 55; continue; }
case 55: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->clamp(III)I",Value.NULL,new Value[]{r[6], r[2], r[5]}); pc = 56; continue; }
case 56: { r[6] = result; pc = 57; continue; }
case 57: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Landroid/graphics/Color;->argb(IIII)I",Value.NULL,new Value[]{r[0], r[7], r[1], r[6]}); pc = 58; continue; }
case 58: { r[6] = result; pc = 59; continue; }
case 59: { return rt.check(r[6],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_1b61a2565f53a07ab8291b87(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(0); pc = 1; continue; }
case 1: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Lapp/revanced/extension/shared/Utils;->showToast(Ljava/lang/String;I)V",Value.NULL,new Value[]{r[1], r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_394eb18dcfe6db6cad07c262(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 3) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[0] = rt.check(arguments[0], "I");
r[1] = rt.check(arguments[1], "I");
r[2] = rt.check(arguments[2], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Math;->min(II)I",Value.NULL,new Value[]{r[0], r[2]}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result=rt.invoke("static","Lapp/revanced/extension/shared/Utils;","Ljava/lang/Math;->max(II)I",Value.NULL,new Value[]{r[1], r[0]}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0],"I"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_489dad5e243818a44712eee7(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref(""); pc = 1; continue; }
case 1: { return rt.check(r[0],"Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
