package rv.executable;
import rv.executable.ExecutableRuntime.Value;
final class Body_e4c5e7a6950f1f6e0c2f {
static Value m_89cd0119b08db4e3c23ab865(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/Thread;"); pc = 1; continue; }
case 1: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V", r[0], new Value[]{r[1]}); pc = 2; continue; }
case 2: { r[1] = Value.i32(10); pc = 3; continue; }
case 3: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/Thread;->setPriority(I)V", r[0], new Value[]{r[1]}); pc = 4; continue; }
case 4: { return rt.check(r[0], "Ljava/lang/Thread;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_ef6ac09409e47ca0bbee4126(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[9];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("\\p{P}+"); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;", Value.NULL, new Value[]{r[0]}); pc = 2; continue; }
case 2: { r[0] = result; pc = 3; continue; }
case 3: { rt.writeField("Lapp/revanced/extension/shared/Utils;->PUNCTUATION_PATTERN:Ljava/util/regex/Pattern;", Value.NULL, true, r[0]); pc = 4; continue; }
case 4: { r[0] = Value.ref("\\p{M}"); pc = 5; continue; }
case 5: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;", Value.NULL, new Value[]{r[0]}); pc = 6; continue; }
case 6: { r[0] = result; pc = 7; continue; }
case 7: { rt.writeField("Lapp/revanced/extension/shared/Utils;->DIACRITICS_PATTERN:Ljava/util/regex/Pattern;", Value.NULL, true, r[0]); pc = 8; continue; }
case 8: { r[1] = rt.allocate("Ljava/util/concurrent/ThreadPoolExecutor;"); pc = 9; continue; }
case 9: { r[7] = rt.allocate("Ljava/util/concurrent/SynchronousQueue;"); pc = 10; continue; }
case 10: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Ljava/util/concurrent/SynchronousQueue;-><init>()V", r[7], new Value[]{}); pc = 11; continue; }
case 11: { r[8] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda20;"); pc = 12; continue; }
case 12: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda20;-><init>()V", r[8], new Value[]{}); pc = 13; continue; }
case 13: { r[2] = Value.i32(3); pc = 14; continue; }
case 14: { r[3] = Value.i32(2147483647); pc = 15; continue; }
case 15: { r[4] = Value.i64(10L); r[5] = r[4]; pc = 16; continue; }
case 16: { r[6] = rt.readField("Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;", Value.NULL, true); pc = 17; continue; }
case 17: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V", r[1], new Value[]{r[2], r[3], r[4], r[6], r[7], r[8]}); pc = 18; continue; }
case 18: { rt.writeField("Lapp/revanced/extension/shared/Utils;->backgroundThreadPool:Ljava/util/concurrent/ThreadPoolExecutor;", Value.NULL, true, r[1]); pc = 19; continue; }
case 19: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_671f08c07344012e5eb3161a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->versionName:Ljava/lang/String;", Value.NULL, true); pc = 1; continue; }
case 1: { pc = (!ExecutableRuntime.equal(r[0], Value.i32(0))) ? 13 : 2; continue; }
case 2: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils;->getPackageInfo()Landroid/content/pm/PackageInfo;", Value.NULL, new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { r[0] = rt.readField("Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;", r[0], false); pc = 5; continue; }
case 5: { rt.writeField("Lapp/revanced/extension/shared/Utils;->versionName:Ljava/lang/String;", Value.NULL, true, r[0]); pc = 6; continue; }
case 6: { pc = 13; continue; }
case 7: { r[0] = Value.ref(exception); exception = null; pc = 8; continue; }
case 8: { r[1] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda11;"); pc = 9; continue; }
case 9: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda11;-><init>()V", r[1], new Value[]{}); pc = 10; continue; }
case 10: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V", Value.NULL, new Value[]{r[1], r[0]}); pc = 11; continue; }
case 11: { r[0] = Value.ref("Unknown"); pc = 12; continue; }
case 12: { rt.writeField("Lapp/revanced/extension/shared/Utils;->versionName:Ljava/lang/String;", Value.NULL, true, r[0]); pc = 13; continue; }
case 13: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->versionName:Ljava/lang/String;", Value.NULL, true); pc = 14; continue; }
case 14: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 2 && pc < 6) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=7; continue; } }
throw error;
}
}

}

static Value m_730f478efadedd28130cc2de(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils;->getContext()Landroid/content/Context;", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[0]}); pc = 3; continue; }
case 3: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Landroid/content/Context;->getPackageName()Ljava/lang/String;", r[0], new Value[]{}); pc = 4; continue; }
case 4: { r[0] = result; pc = 5; continue; }
case 5: { r[1] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;", Value.NULL, true); pc = 6; continue; }
case 6: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;", r[1], new Value[]{}); pc = 7; continue; }
case 7: { r[1] = result; pc = 8; continue; }
case 8: { r[2] = rt.readField("Landroid/os/Build$VERSION;->SDK_INT:I", Value.NULL, true); pc = 9; continue; }
case 9: { r[3] = Value.i32(33); pc = 10; continue; }
case 10: { pc = (r[2].i() < r[3].i()) ? 17 : 11; continue; }
case 11: { r[2] = Value.i64(0L); r[3] = r[2]; pc = 12; continue; }
case 12: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticApiModelOutline0;->m(J)Landroid/content/pm/PackageManager$PackageInfoFlags;", Value.NULL, new Value[]{r[2]}); pc = 13; continue; }
case 13: { r[2] = result; pc = 14; continue; }
case 14: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticApiModelOutline1;->m(Landroid/content/pm/PackageManager;Ljava/lang/String;Landroid/content/pm/PackageManager$PackageInfoFlags;)Landroid/content/pm/PackageInfo;", Value.NULL, new Value[]{r[1], r[0], r[2]}); pc = 15; continue; }
case 15: { r[0] = result; pc = 16; continue; }
case 16: { return rt.check(r[0], "Landroid/content/pm/PackageInfo;"); }
case 17: { r[2] = Value.i32(0); pc = 18; continue; }
case 18: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;", r[1], new Value[]{r[0], r[2]}); pc = 19; continue; }
case 19: { r[0] = result; pc = 20; continue; }
case 20: { return rt.check(r[0], "Landroid/content/pm/PackageInfo;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5a47b2f7416730ca5a80b50f(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i32(1); pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils;->showToast(Ljava/lang/String;I)V", Value.NULL, new Value[]{r[1], r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_cdd8ab49f971fd2d7842ba50(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;", Value.NULL, true); pc = 1; continue; }
case 1: { pc = (!ExecutableRuntime.equal(r[0], Value.i32(0))) ? 6 : 2; continue; }
case 2: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;"); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda8;-><init>()V", r[0], new Value[]{}); pc = 4; continue; }
case 4: { r[1] = Value.i32(0); pc = 5; continue; }
case 5: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V", Value.NULL, new Value[]{r[0], r[1]}); pc = 6; continue; }
case 6: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;", Value.NULL, true); pc = 7; continue; }
case 7: { return rt.check(r[0], "Landroid/content/Context;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_6cdc61fc1e4e0a2e5163bd6a(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Ljava/lang/String;");
r[2] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;", Value.NULL, new Value[]{r[1]}); pc = 1; continue; }
case 1: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;"); pc = 2; continue; }
case 2: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda17;-><init>(Ljava/lang/String;I)V", r[0], new Value[]{r[1], r[2]}); pc = 3; continue; }
case 3: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils;->runOnMainThreadNowOrLater(Ljava/lang/Runnable;)V", Value.NULL, new Value[]{r[0]}); pc = 4; continue; }
case 4: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_7d99b3ea9eec3382f4257bf3(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Failed to get package info"); pc = 1; continue; }
case 1: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_25b71942bb809b579086f918(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[2];
r[1] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils;->isCurrentlyOnMainThread()Z", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { pc = (ExecutableRuntime.equal(r[0], Value.i32(0))) ? 5 : 3; continue; }
case 3: { result = rt.invoke("interface", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/Runnable;->run()V", r[1], new Value[]{}); pc = 4; continue; }
case 4: { return Value.VOID; }
case 5: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils;->runOnMainThread(Ljava/lang/Runnable;)V", Value.NULL, new Value[]{r[1]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_5bb37b01a13b0d4ea722adf4(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.ref("Context is not set by extension hook, returning null"); pc = 1; continue; }
case 1: { return rt.check(r[0], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_52486034b7d7bcb0f773f677(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 0) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[1];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;", Value.NULL, new Value[]{}); pc = 1; continue; }
case 1: { r[0] = result; pc = 2; continue; }
case 2: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Landroid/os/Looper;->isCurrentThread()Z", r[0], new Value[]{}); pc = 3; continue; }
case 3: { r[0] = result; pc = 4; continue; }
case 4: { return rt.check(r[0], "Z"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_f893c6bf7073f583755e78ef(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = Value.i64(0L); r[1] = r[0]; pc = 1; continue; }
case 1: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils;->runOnMainThreadDelayed(Ljava/lang/Runnable;J)V", Value.NULL, new Value[]{r[2], r[0]}); pc = 2; continue; }
case 2: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8fd0d86a7e58b94e81a998f9(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[5];
r[2] = rt.check(arguments[0], "Ljava/lang/Runnable;");
r[3] = rt.check(arguments[1], "J"); r[4] = r[3];
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda22;"); pc = 1; continue; }
case 1: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda22;-><init>(Ljava/lang/Runnable;)V", r[0], new Value[]{r[2]}); pc = 2; continue; }
case 2: { r[2] = rt.allocate("Landroid/os/Handler;"); pc = 3; continue; }
case 3: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;", Value.NULL, new Value[]{}); pc = 4; continue; }
case 4: { r[1] = result; pc = 5; continue; }
case 5: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Landroid/os/Handler;-><init>(Landroid/os/Looper;)V", r[2], new Value[]{r[1]}); pc = 6; continue; }
case 6: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z", r[2], new Value[]{r[0], r[3]}); pc = 7; continue; }
case 7: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_b837e1738be4e47bbbf26f53(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[4];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
r[3] = rt.check(arguments[1], "I");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.readField("Lapp/revanced/extension/shared/Utils;->context:Landroid/content/Context;", Value.NULL, true); pc = 1; continue; }
case 1: { pc = (!ExecutableRuntime.equal(r[0], Value.i32(0))) ? 6 : 2; continue; }
case 2: { r[3] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda14;"); pc = 3; continue; }
case 3: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda14;-><init>(Ljava/lang/String;)V", r[3], new Value[]{r[2]}); pc = 4; continue; }
case 4: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;)V", Value.NULL, new Value[]{r[3]}); pc = 5; continue; }
case 5: { return Value.VOID; }
case 6: { r[1] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;"); pc = 7; continue; }
case 7: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda15;-><init>(Ljava/lang/String;)V", r[1], new Value[]{r[2]}); pc = 8; continue; }
case 8: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Logger;->printDebug(Lapp/revanced/extension/shared/Logger$LogMessage;)V", Value.NULL, new Value[]{r[1]}); pc = 9; continue; }
case 9: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;", Value.NULL, new Value[]{r[0], r[2], r[3]}); pc = 10; continue; }
case 10: { r[2] = result; pc = 11; continue; }
case 11: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Landroid/widget/Toast;->show()V", r[2], new Value[]{}); pc = 12; continue; }
case 12: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_8a392802ef9f0ac8a1805970(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/Runnable;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { result = rt.invoke("interface", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/Runnable;->run()V", r[2], new Value[]{}); pc = 1; continue; }
case 1: { return Value.VOID; }
case 2: { r[0] = Value.ref(exception); exception = null; pc = 3; continue; }
case 3: { r[1] = rt.allocate("Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;"); pc = 4; continue; }
case 4: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Utils$$ExternalSyntheticLambda7;-><init>(Ljava/lang/Runnable;Ljava/lang/Exception;)V", r[1], new Value[]{r[2], r[0]}); pc = 5; continue; }
case 5: { result = rt.invoke("static", "Lapp/revanced/extension/shared/Utils;", "Lapp/revanced/extension/shared/Logger;->printException(Lapp/revanced/extension/shared/Logger$LogMessage;Ljava/lang/Throwable;)V", Value.NULL, new Value[]{r[1], r[0]}); pc = 6; continue; }
case 6: { return Value.VOID; }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {
if(pc >= 0 && pc < 1) { if(rt.isInstance(ExecutableRuntime.caught(error), "Ljava/lang/Exception;")) { exception=ExecutableRuntime.caught(error); pc=2; continue; } }
throw error;
}
}

}

static Value m_404fd9479c428a1ecb569974(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Showing toast: "); pc = 2; continue; }
case 2: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V", r[0], new Value[]{r[1]}); pc = 3; continue; }
case 3: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;", r[0], new Value[]{r[2]}); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;", r[0], new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_76522245bcd200a9664b32cd(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 1) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[2] = rt.check(arguments[0], "Ljava/lang/String;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { r[1] = Value.ref("Cannot show toast (context is null): "); pc = 2; continue; }
case 2: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V", r[0], new Value[]{r[1]}); pc = 3; continue; }
case 3: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;", r[0], new Value[]{r[2]}); pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;", r[0], new Value[]{}); pc = 5; continue; }
case 5: { r[2] = result; pc = 6; continue; }
case 6: { return rt.check(r[2], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}

static Value m_68ae91754d630aeec02eb025(ExecutableRuntime rt, Value receiver, Value[] arguments) throws Throwable {
if(arguments.length != 2) throw new ExecutableRuntime.InvalidProgram("Parameter arity");
Value[] r = new Value[3];
r[1] = rt.check(arguments[0], "Ljava/lang/Runnable;");
r[2] = rt.check(arguments[1], "Ljava/lang/Exception;");
int pc=0; Value result=Value.VOID; Object exception=null;
for(;;) {
try { switch(pc) {
case 0: { r[0] = rt.allocate("Ljava/lang/StringBuilder;"); pc = 1; continue; }
case 1: { result = rt.invoke("direct", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;-><init>()V", r[0], new Value[]{}); pc = 2; continue; }
case 2: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/Object;->getClass()Ljava/lang/Class;", r[1], new Value[]{}); pc = 3; continue; }
case 3: { r[1] = result; pc = 4; continue; }
case 4: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/Class;->getSimpleName()Ljava/lang/String;", r[1], new Value[]{}); pc = 5; continue; }
case 5: { r[1] = result; pc = 6; continue; }
case 6: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;", r[0], new Value[]{r[1]}); pc = 7; continue; }
case 7: { r[1] = Value.ref(": "); pc = 8; continue; }
case 8: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;", r[0], new Value[]{r[1]}); pc = 9; continue; }
case 9: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/Throwable;->getMessage()Ljava/lang/String;", r[2], new Value[]{}); pc = 10; continue; }
case 10: { r[1] = result; pc = 11; continue; }
case 11: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;", r[0], new Value[]{r[1]}); pc = 12; continue; }
case 12: { result = rt.invoke("virtual", "Lapp/revanced/extension/shared/Utils;", "Ljava/lang/StringBuilder;->toString()Ljava/lang/String;", r[0], new Value[]{}); pc = 13; continue; }
case 13: { r[1] = result; pc = 14; continue; }
case 14: { return rt.check(r[1], "Ljava/lang/String;"); }
default: throw new ExecutableRuntime.InvalidProgram("Invalid control-flow block");
} } catch(Throwable error) {

throw error;
}
}

}
}
