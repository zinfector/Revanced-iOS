"""Compile a hash-bound executable-body bundle with the pinned macOS toolchain.

Inspection delivery only: this script never configures providers, runs original
policies, installs hooks, or packages an app.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import traceback
import zipfile

J2OBJC_COMMIT = "1671e9afb72a16126d448f468db3e582358fba47"


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value): Path(path).write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
def capture(command): return subprocess.check_output(list(map(str,command)),text=True).strip()
def run(command, log):
    with Path(log).open("w",encoding="utf-8") as stream:
        result=subprocess.run(list(map(str,command)),stdout=stream,stderr=subprocess.STDOUT)
    if result.returncode: raise RuntimeError("Command failed; see "+str(log))


def build(bundle,home,out):
    bundle,home,out=map(lambda p:Path(p).resolve(),(bundle,home,out))
    out.mkdir(parents=True,exist_ok=False)
    receipt=dict(schema="installer.executable-native-build.v1",status="started",arm64_ios_compiled=False,
                 original_bodies_executed=False,full_behavior_comparison_executed=False,
                 foreign_operations_admitted=False,native_hooks_installed=False,
                 app_integration_ready=False,legacy_ios_feature_code_used=False)
    write(out/"receipt.json",receipt)
    try:
        ledger=json.loads((bundle/"stage-ledger.json").read_text(encoding="utf-8"))
        actual={p.relative_to(bundle).as_posix():sha(p) for p in bundle.rglob("*") if p.is_file() and p.name!="stage-ledger.json"}
        if actual!=ledger["files"]:raise ValueError("Staged bundle content/hash drift")
        if capture(["git","-C",home.parent,"rev-parse","HEAD"])!=J2OBJC_COMMIT:raise ValueError("Unexpected J2ObjC revision")
        if (bundle/'foreign-bindings.json').exists():
            bindings=json.loads((bundle/'foreign-bindings.json').read_text(encoding='utf-8'))
            if bindings['held'] or bindings['additional_original_roots']:raise ValueError('Unclosed foreign providers')
            with zipfile.ZipFile(home/'lib/jre_emul.jar') as archive:
                for typ,witness in bindings['jre_classes'].items():
                    raw=archive.read(witness['name'].replace('.','/')+'.class')
                    if hashlib.sha256(raw).hexdigest()!=witness['classfile_sha256']:raise ValueError('Pinned JRE class-file drift: '+typ)
            receipt.update(foreign_bindings_connected=True,jre_classfile_witnesses_verified=len(bindings['jre_classes']),
                           foreign_binding_plan_sha256=sha(bundle/'foreign-bindings.json'))
        xcode=capture(["xcodebuild","-version"])
        if not xcode.startswith("Xcode 16.4\n"):raise ValueError("Xcode 16.4 required")
        receipt.update(stage_ledger_sha256=sha(bundle/"stage-ledger.json"),j2objc_commit=J2OBJC_COMMIT,
                       xcode=xcode,clang=capture(["xcrun","clang","--version"]),java=capture(["java","--version"]))
        inputs=bundle/"java";objc=out/"objc";objc.mkdir()
        files=sorted(inputs.rglob("*.java"));prefix=out/"prefixes.properties"
        prefix.write_text("rv.executable=RVE\n",encoding="utf-8",newline="\n")
        translate=[home/"j2objc","-source","17","-use-arc","--prefixes",prefix,"-sourcepath",inputs,"-d",objc,*files]
        receipt["translation_command"]=list(map(str,translate));write(out/"receipt.json",receipt)
        run(translate,out/"translation.log")
        sdk=capture(["xcrun","--sdk","iphoneos","--show-sdk-path"])
        payload=out/"ExecutableBodies.dylib";runtime=home/"lib/iphone/libjre_emul.a"
        common=["-target","arm64-apple-ios17.0","-isysroot",sdk,"-fobjc-arc","-fobjc-arc-exceptions","-fblocks","-O2","-g",
                "-Wno-parentheses-equality","-I",home/"include","-I",objc,*sorted(objc.rglob("*.m")),runtime,
                "-framework","Foundation","-framework","UIKit","-framework","QuartzCore","-framework","Security","-liconv","-lz","-licucore","-dynamiclib",
                "-Wl,-install_name,@executable_path/Frameworks/ExecutableBodies.dylib","-Wl,-headerpad,0x4000","-o",payload]
        args=out/"compile.args";args.write_text("\n".join(json.dumps(str(a)) for a in common),encoding="utf-8",newline="\n")
        command=["xcrun","--sdk","iphoneos","clang","@"+str(args)]
        receipt.update(ios_command=list(map(str,command)),runtime_sha256=sha(runtime),sdk=sdk)
        write(out/"receipt.json",receipt);run(command,out/"compile-ios.log")
        architecture=capture(["xcrun","lipo","-archs",payload])
        if architecture!="arm64":raise ValueError("Unexpected payload architecture: "+architecture)
        symbols=capture(["xcrun","nm","-g",payload]);(out/"symbols.txt").write_text(symbols+"\n",encoding="utf-8",newline="\n")
        defined=set(re.findall(r"\b[TD] (_\w+)$",symbols,re.MULTILINE))
        dependencies=capture(["xcrun","otool","-L",payload]);(out/"dependencies.txt").write_text(dependencies+"\n",encoding="utf-8",newline="\n")
        header=objc/"rv/executable/GeneratedEntryPoints.h";text=header.read_text(encoding="utf-8")
        emission=json.loads((bundle/"emission.json").read_text(encoding="utf-8"));inventory=[]
        for entry in emission["entry_points"]:
            names=set(re.findall(r"\b(RVEGeneratedEntryPoints_"+re.escape(entry["java_method"])+r"[A-Za-z0-9_]*)\s*\(",text))
            exports=sorted("_"+name for name in names if "_"+name in defined)
            if len(exports)!=1:raise ValueError("No unique compiled entry symbol for "+entry["descriptor"])
            declarations=[m.group(0) for m in re.finditer(r"[^;{}\n]*\b"+re.escape(exports[0][1:])+r"\s*\([^;]*\);",text)]
            inventory.append(dict(**entry,native_symbol=exports[0],header_declarations=declarations,
                                  header="rv/executable/GeneratedEntryPoints.h",header_sha256=sha(header),
                                  reference_representation="ExecutableRuntime.Instance/ArrayValue or admitted foreign object; source descriptors preserved"))
        write(out/"entry-point-inventory.json",dict(schema="installer.executable-native-inventory.v1",entries=inventory,
              native_binding_admitted=False,initialization="Explicit Foreign configuration before any original policy active use"))
        receipt.update(status="compiled",arm64_ios_compiled=True,architecture=architecture,payload_sha256=sha(payload),
                       entry_point_count=len(inventory),entry_point_inventory_sha256=sha(out/"entry-point-inventory.json"),
                       objc_files={p.relative_to(objc).as_posix():sha(p) for p in objc.rglob("*") if p.is_file()},
                       external_operation_count=len(emission["foreign_demands"]),original_method_count=len(emission["methods"]))
    except Exception as error:
        receipt.update(status="failed",error=str(error));(out/"failure.txt").write_text(traceback.format_exc(),encoding="utf-8",newline="\n")
        raise
    finally:
        write(out/"receipt.json",receipt)
        write(out/"artifact-ledger.json",{p.relative_to(out).as_posix():sha(p) for p in out.rglob("*") if p.is_file() and p.name!="artifact-ledger.json"})
    return receipt


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--bundle",type=Path,required=True);p.add_argument("--j2objc-home",type=Path,required=True);p.add_argument("--out",type=Path,required=True)
    a=p.parse_args();r=build(a.bundle,a.j2objc_home,a.out);print(json.dumps({k:r[k] for k in ("status","arm64_ios_compiled","original_method_count","external_operation_count")}))
